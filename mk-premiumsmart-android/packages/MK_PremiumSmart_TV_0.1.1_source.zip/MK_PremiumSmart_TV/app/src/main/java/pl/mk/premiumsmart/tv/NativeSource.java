package pl.mk.premiumsmart.tv;

import androidx.media3.datasource.okhttp.OkHttpDataSource;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** Pooled native HTTP transport, including host/path scoped source cookies. */
@androidx.media3.common.util.UnstableApi
final class NativeSource {
    private static final OkHttpClient BASE_HTTP=new OkHttpClient.Builder()
        .connectTimeout(15,TimeUnit.SECONDS).readTimeout(35,TimeUnit.SECONDS)
        .followSslRedirects(false).retryOnConnectionFailure(true).build();
    static OkHttpDataSource.Factory factory(JSONObject stream) {
        CookieJar cookies=cookieJar(stream.optJSONArray("cookies"));
        OkHttpClient client=BASE_HTTP.newBuilder().cookieJar(cookies).build();
        Map<String,String> headers=new HashMap<>();
        JSONObject values=stream.optJSONObject("headers");
        if(values!=null)for(Iterator<String> it=values.keys();it.hasNext();){
            String name=it.next();
            if(name.equals("User-Agent")||name.equals("Referer")||name.equals("Origin")||name.equals("Accept"))headers.put(name,values.optString(name));
        }
        return new OkHttpDataSource.Factory(client).setDefaultRequestProperties(headers);
    }

    static CookieJar cookieJar(JSONArray input){return new SessionCookies(input);}

    private static final class SessionCookies implements CookieJar {
        private final List<Cookie> stored=new ArrayList<>();
        SessionCookies(JSONArray input) {
            if(input==null)return;
            for(int i=0;i<input.length();i++)try{
                JSONObject value=input.getJSONObject(i);
                Cookie.Builder b=new Cookie.Builder().name(value.getString("name"))
                    .value(value.getString("value")).path(value.optString("path","/"));
                if(value.optBoolean("hostOnly",true))b.hostOnlyDomain(value.getString("domain"));
                else b.domain(value.getString("domain"));
                if(value.optBoolean("secure"))b.secure();
                long expires=value.optLong("expires");if(expires>0)b.expiresAt(expires*1000L);
                stored.add(b.build());
            }catch(Exception ignored){}
        }
        @Override public synchronized List<Cookie> loadForRequest(HttpUrl url) {
            List<Cookie> matches=new ArrayList<>();long now=System.currentTimeMillis();
            stored.removeIf(cookie->cookie.expiresAt()<now);
            for(Cookie cookie:stored)if(cookie.matches(url))matches.add(cookie);
            return matches;
        }
        @Override public synchronized void saveFromResponse(HttpUrl url,List<Cookie> cookies) {
            for(Cookie value:cookies){
                stored.removeIf(old->old.name().equals(value.name())&&old.domain().equals(value.domain())&&old.path().equals(value.path()));
                stored.add(value);
            }
        }
    }
}
