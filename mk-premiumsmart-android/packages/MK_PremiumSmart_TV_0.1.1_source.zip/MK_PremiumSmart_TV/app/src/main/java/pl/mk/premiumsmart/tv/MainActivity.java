package pl.mk.premiumsmart.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class MainActivity extends Activity {
    private final ArrayDeque<State> stack=new ArrayDeque<>();
    private JSONObject current=AppRuntime.object("action","main","title","PremiumSmart"),settings=new JSONObject();
    private JSONArray entries=new JSONArray();
    private int selected=0,generation=0;
    private boolean busy,ready;
    private LinearLayout root,content;
    private TextView heading,path,status,title,description,metadata;
    private ImageView poster;
    private GridLayout grid;
    private ScrollView scroll;
    private ProgressBar progress;
    private final List<View> rows=new ArrayList<>();
    private Updater updater;
    private static final class State {
        JSONObject item;JSONArray rows;int index;
        State(JSONObject item,JSONArray rows,int index){this.item=item;this.rows=rows;this.index=index;}
    }
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);return t;}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        updater=new Updater(this);build();setBusy(true,"Uruchamianie PremiumSmart…");
        AppRuntime.init(this,result->{
            if(isDestroyed())return;
            if(!result.optBoolean("ok")){setBusy(false,"");error(result);return;}
            ready=true;settings=result.optJSONObject("settings");if(settings==null)settings=new JSONObject();setBusy(false,"");load(current,false);
        });
    }
    private Button button(String label,Runnable click){
        Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);
        b.setBackgroundResource(R.drawable.focus_card);b.setOnClickListener(v->click.run());
        return b;
    }
    private void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(26),dp(16),dp(26),dp(14));root.setBackgroundColor(Color.rgb(11,16,27));setContentView(root);
        heading=text("MK PremiumSmart TV",25,Color.WHITE);heading.setTypeface(null,Typeface.BOLD);root.addView(heading);
        path=text("Filmy i seriale • bez logowania • "+BuildConfig.VERSION_NAME,12,0xffa9bacf);path.setPadding(0,dp(4),0,dp(8));root.addView(path);
        LinearLayout toolbar=new LinearLayout(this);
        for(Button b:new Button[]{button("⌕ Szukaj",this::search),button("Lista / kafelki",this::toggleView),button("Opcje",this::options),button("Główna",()->{if(!busy){stack.clear();load(AppRuntime.object("action","main","title","PremiumSmart"),false);}})}){
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1);p.setMargins(0,0,dp(8),0);toolbar.addView(b,p);
        }
        root.addView(toolbar);content=new LinearLayout(this);content.setPadding(0,dp(12),0,dp(6));root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        scroll=new ScrollView(this);scroll.setFillViewport(true);grid=new GridLayout(this);grid.setUseDefaultMargins(false);scroll.addView(grid,new ScrollView.LayoutParams(-1,-2));content.addView(scroll,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout detail=new LinearLayout(this);detail.setOrientation(LinearLayout.VERTICAL);detail.setPadding(dp(16),0,0,0);content.addView(detail,new LinearLayout.LayoutParams(dp(242),-1));
        poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.FIT_CENTER);poster.setBackgroundColor(0xff142033);detail.addView(poster,new LinearLayout.LayoutParams(-1,dp(194)));
        title=text("Wybierz film lub serial",18,Color.WHITE);title.setMaxLines(3);title.setPadding(0,dp(8),0,dp(5));detail.addView(title);
        metadata=text("Tutaj pojawi się okładka i opis",13,0xff55c9d1);metadata.setMaxLines(3);detail.addView(metadata);
        ScrollView descriptionScroll=new ScrollView(this);description=text("",14,0xffc7d4e8);description.setPadding(0,dp(8),0,0);descriptionScroll.addView(description);detail.addView(descriptionScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=new LinearLayout(this);progress=new ProgressBar(this);progress.setVisibility(View.GONE);footer.addView(progress,new LinearLayout.LayoutParams(dp(22),dp(22)));
        status=text("OK: wybierz • Przytrzymaj OK: ulubione • MENU: opcje • Wstecz: wróć",12,0xffa9bed5);status.setPadding(dp(8),0,0,0);footer.addView(status,new LinearLayout.LayoutParams(0,-2,1));root.addView(footer);
    }
    private void setBusy(boolean value,String message){busy=value;progress.setVisibility(value?View.VISIBLE:View.GONE);status.setText(message.isEmpty()?"OK: wybierz • Przytrzymaj OK: ulubione • MENU: opcje • Wstecz: wróć":message);}
    private JSONObject row(int index){JSONObject r=entries.optJSONObject(index);return r==null?new JSONObject():r;}
    private void request(JSONObject query,String message,AppRuntime.Callback callback){
        if(!ready)return;int token=++generation;setBusy(true,message);
        AppRuntime.submit(query,result->{if(isDestroyed()||token!=generation)return;setBusy(false,"");if(!result.optBoolean("ok")){error(result);return;}callback.done(result);});
    }
    private void load(JSONObject item,boolean push){
        if(busy&&ready)return;
        request(AppRuntime.object("op","browse","item",item),"Pobieranie listy…",result->{
            if(push)stack.push(new State(current,entries,selected));current=AppRuntime.copy(item);entries=result.optJSONArray("items");if(entries==null)entries=new JSONArray();selected=0;render();
        });
    }
    private void render(){
        grid.removeAllViews();rows.clear();boolean tiles=settings.optString("view","tiles").equals("tiles");
        String action=current.optString("action");boolean filmPage=action.equals("movies")||action.equals("page")||action.equals("search_results")||action.equals("favourites")||action.equals("continue");
        int cols=tiles&&filmPage?3:1;grid.setColumnCount(cols);grid.setRowCount(Math.max(1,(entries.length()+cols-1)/cols));
        path.setText("PremiumSmart  /  "+current.optString("title","Filmy i seriale")+"  •  "+entries.length()+" pozycji");
        if(entries.length()==0){grid.addView(text("Brak pozycji. Wróć lub zmień filtr.",18,Color.WHITE));return;}
        for(int i=0;i<entries.length();i++){
            final int index=i;JSONObject entry=row(i);LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setPadding(dp(8),dp(8),dp(8),dp(8));tile.setBackgroundResource(R.drawable.focus_card);tile.setFocusable(true);tile.setClickable(true);
            if(cols>1&&!entry.optString("icon").isEmpty()){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);tile.addView(image,new LinearLayout.LayoutParams(-1,dp(150)));Images.load(image,entry.optString("icon"));}
            String caption=(entry.optBoolean("watched")?"✓ ":"")+entry.optString("title");TextView label=text(caption,cols>1?15:18,Color.WHITE);label.setMaxLines(cols>1?3:2);label.setMinHeight(dp(cols>1?52:34));label.setGravity(Gravity.CENTER_VERTICAL);tile.addView(label);
            if(cols>1&&!entry.optString("rating_label").isEmpty())tile.addView(text(entry.optString("rating_label"),12,0xfff3d375));
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(GridLayout.spec(i/cols),GridLayout.spec(i%cols,1f));p.width=0;p.height=-2;p.setMargins(0,0,dp(8),dp(8));grid.addView(tile,p);rows.add(tile);
            tile.setOnFocusChangeListener((v,has)->{if(has){selected=index;detail(entry);}});tile.setOnClickListener(v->select(entry));tile.setOnLongClickListener(v->{favourite(entry);return true;});
        }
        selected=Math.max(0,Math.min(selected,rows.size()-1));rows.get(selected).requestFocus();detail(row(selected));
    }
    private void detail(JSONObject entry){
        title.setText(entry.optString("movie_title",entry.optString("title","")));String info=entry.optString("rating_label");
        for(String key:new String[]{"year","language_version","progress_label"})if(!entry.optString(key).isEmpty())info+=(info.isEmpty()?"":" • ")+entry.optString(key);
        metadata.setText(info.isEmpty()?"Wybierz pozycję przyciskiem OK":info);description.setText(entry.optString("synopsis",entry.optString("desc","")));Images.load(poster,entry.optString("icon"));
    }
    private void select(JSONObject item){
        if(busy)return;String action=item.optString("action");
        if(action.equals("search")){search();return;}
        if(action.equals("resolve")){resolve(item);return;}
        load(item,true);
    }
    private void resolve(JSONObject item){
        request(AppRuntime.object("op","resolve","item",item),"Pobieranie i weryfikacja źródła… Wstecz: anuluj",result->{
            JSONArray variants=result.optJSONArray("variants");if(variants==null||variants.length()==0){error(AppRuntime.object("message","Źródło nie zwróciło filmu."));return;}
            if(settings.optBoolean("auto_play",true)){play(item,result.optInt("preferred",0));return;}
            String[] labels=new String[variants.length()];for(int i=0;i<labels.length;i++)labels[i]=variants.optJSONObject(i).optString("label");
            new AlertDialog.Builder(this).setTitle("Wybierz jakość").setItems(labels,(dialog,index)->play(item,index)).setNegativeButton("Wróć",null).show();
        });
    }
    private void play(JSONObject item,int index){
        request(AppRuntime.object("op","play","item",item,"index",index),"Uruchamianie filmu…",result->{
            JSONObject saved=result.optJSONObject("progress");long position=saved==null?0:saved.optLong("position",0);boolean complete=saved!=null&&saved.optBoolean("completed");
            if(position>=15&&!complete)new AlertDialog.Builder(this).setTitle("Kontynuować oglądanie?").setMessage("Wznowić od "+stamp(position)+"?").setPositiveButton("Wznów",(d,w)->openPlayer(item,result,position)).setNegativeButton("Od początku",(d,w)->openPlayer(item,result,0)).show();
            else openPlayer(item,result,0);
        });
    }
    private void openPlayer(JSONObject item,JSONObject stream,long position){
        Intent intent=new Intent(this,PlayerActivity.class);intent.putExtra("entry",item.toString());intent.putExtra("stream",stream.toString());intent.putExtra("position",position);startActivityForResult(intent,200);
    }
    static String stamp(long seconds){return String.format(java.util.Locale.ROOT,"%d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60);}
    private void search(){
        if(busy||!ready)return;EditText field=new EditText(this);field.setSingleLine(true);field.setHint("Tytuł filmu lub serialu");
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Wyszukaj").setView(field).setPositiveButton("Szukaj",(d,w)->{String term=field.getText().toString().trim();if(!term.isEmpty())load(AppRuntime.object("title","Szukaj: "+term,"action","search_results","query",term),true);}).setNegativeButton("Wróć",null).create();
        dialog.setOnShowListener(d->{field.requestFocus();dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});dialog.show();
    }
    private void toggleView(){
        if(busy||!ready)return;String view=settings.optString("view","tiles").equals("tiles")?"list":"tiles";
        request(AppRuntime.object("op","settings","key","view","value",view),"Zmiana widoku…",result->{settings=result.optJSONObject("settings");render();});
    }
    private void favourite(JSONObject item){
        if(busy||!ready)return;String action=item.optString("action");if(!(action.equals("sources")||action.equals("seasons")||action.equals("resolve")))return;
        request(AppRuntime.object("op","favourite","item",item),"Zapisywanie…",result->{Toast.makeText(this,result.optBoolean("added")?"Dodano do ulubionych":"Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(current.optString("action").equals("favourites"))load(current,false);});
    }
    private void options(){
        if(busy||!ready)return;
        String[] labels={"Dodaj / usuń z ulubionych","Lista / kafelki","Jakość: "+(settings.optBoolean("auto_play",true)?"najlepsza automatycznie":"wybór ręczny"),"Odśwież listę","Sprawdź aktualizację","Autor i kontakt","Informacje i licencje"};
        new AlertDialog.Builder(this).setTitle("Opcje").setItems(labels,(dialog,which)->{
            if(which==0)favourite(row(selected));else if(which==1)toggleView();
            else if(which==2)request(AppRuntime.object("op","settings","key","auto_play","value",!settings.optBoolean("auto_play",true)),"Zapisywanie…",result->settings=result.optJSONObject("settings"));
            else if(which==3)load(current,false);else if(which==4)updater.check();
            else if(which==5)new AlertDialog.Builder(this).setTitle("MK PremiumSmart TV").setMessage("Projekt i rozwój: MK\nKontakt: bimer55@wp.pl\n\nPrzy zgłoszeniu podaj model urządzenia, wersję Androida i krótki opis problemu.\nWersja "+BuildConfig.VERSION_NAME).setPositiveButton("OK",null).show();
            else new AlertDialog.Builder(this).setTitle("Informacje").setMessage("Samodzielna aplikacja MK na bazie MK PremiumSmart E2 0.1.1.\nGPL-3.0. Publiczne źródła E2iPlayer oraz komponenty AndroidX Media3 i Chaquopy.\n\nPełne licencje i kod źródłowy są dołączone do wydania na GitHubie.\n\nAplikacja korzysta z anonimowej sesji serwisu. Dostępność zależy od źródeł.").setPositiveButton("OK",null).show();
        }).show();
    }
    private void error(JSONObject result){new AlertDialog.Builder(this).setTitle("Nie udało się otworzyć").setMessage(result.optString("message","Spróbuj ponownie później.")+(result.optString("reason").isEmpty()?"":"\nKod: "+result.optString("reason"))).setPositiveButton("OK",null).show();}
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(event.getAction()==KeyEvent.ACTION_UP){
            if(event.getKeyCode()==KeyEvent.KEYCODE_MENU){options();return true;}
            if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_YELLOW){toggleView();return true;}
            if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_BLUE&&!busy){updater.check();return true;}
        }
        return super.dispatchKeyEvent(event);
    }
    @Override public void onBackPressed(){
        if(busy){Pow.cancel();generation++;setBusy(false,"Anulowano. Wybierz inną pozycję.");return;}
        if(!stack.isEmpty()){State previous=stack.pop();current=previous.item;entries=previous.rows;selected=previous.index;render();}
        else new AlertDialog.Builder(this).setTitle("Zamknąć aplikację?").setPositiveButton("Wyjdź",(d,w)->finish()).setNegativeButton("Zostań",null).show();
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);
        if(code==210){updater.installPending();return;}
        if(code!=200)return;
        AppRuntime.submit(AppRuntime.object("op","stop"),null);
        if(data!=null&&data.getBooleanExtra("next",false)){
            try {
                JSONObject item=new JSONObject(data.getStringExtra("entry"));item.put("action","next_episode");
                request(AppRuntime.object("op","browse","item",item),"Sprawdzanie następnego odcinka…",answer->{
                    JSONArray next=answer.optJSONArray("items");if(next==null||next.length()==0){Toast.makeText(this,"Brak następnego odcinka",Toast.LENGTH_LONG).show();return;}
                    JSONObject episode=next.optJSONObject(0);new AlertDialog.Builder(this).setTitle("Następny odcinek").setMessage(episode.optString("title")).setPositiveButton("Otwórz",(d,w)->load(episode,true)).setNegativeButton("Później",null).show();
                });
            }catch(Exception ignored){}
        }else if(current.optString("action").equals("continue"))load(current,false);
    }
    @Override protected void onDestroy(){generation++;Pow.cancel();super.onDestroy();}
}
