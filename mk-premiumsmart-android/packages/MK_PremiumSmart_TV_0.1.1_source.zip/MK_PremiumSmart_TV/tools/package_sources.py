#!/usr/bin/env python3
"""Package exact corresponding sources; never includes signing material."""
import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parents[1]
dist=root/'dist';dist.mkdir(exist_ok=True)
release=json.loads((dist/'update.json').read_text())
output=dist/('MK_PremiumSmart_TV_'+release['version']+'_source.zip')
paths=[]
for folder in ['app/src','tools','tests','reference','gradle']:
    paths.extend(path for path in (root/folder).rglob('*') if path.is_file() and not any(part in ('__pycache__','java-classes') for part in path.parts))
paths.extend(root/name for name in ['README.md','LICENSE','THIRD_PARTY.txt','build.gradle','app/build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','.gitignore'])
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(paths):
        if path.suffix in ('.p12','.jks','.pyc') or path.name in ('password.txt','local.properties'):raise RuntimeError('private_material_in_source')
        archive.write(path,'MK_PremiumSmart_TV/'+str(path.relative_to(root)))
    archive.write(dist/'update.json','MK_PremiumSmart_TV/update.json')
print(json.dumps({'source':output.name,'size':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
