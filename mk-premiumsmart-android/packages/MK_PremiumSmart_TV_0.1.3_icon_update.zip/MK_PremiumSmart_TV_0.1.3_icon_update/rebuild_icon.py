#!/usr/bin/env python3
"""Rebuild this resource-only release from the exact previous MK APK.

JDK 17, Apktool 2.12.1. Align and sign the output with Android Build Tools.
No keys, accounts or playback sessions are included in this kit.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

p = argparse.ArgumentParser()
p.add_argument('base_apk', type=Path)
p.add_argument('apktool_jar', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parent
spec = json.loads((root / 'release.json').read_text())
if hashlib.sha256(a.base_apk.read_bytes()).hexdigest() != spec['base_sha256']:
    raise SystemExit('The input must be the exact previous MK release listed in release.json')
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp) / 'decoded'
    subprocess.run(['java', '-jar', str(a.apktool_jar), 'd', '-f', str(a.base_apk), '-o', str(work)], check=True)
    own = work / 'smali_classes2' / Path(*spec['application_id'].split('.'))
    for file in own.glob('*.smali'):
        data = file.read_text().replace(spec['old_version'], spec['version'])
        if file.name == 'BuildConfig.smali':
            data = data.replace('VERSION_CODE:I = ' + hex(spec['old_code']), 'VERSION_CODE:I = ' + hex(spec['code']))
        if file.name == 'Updater.smali':
            before = 'const-wide/16 v0, ' + hex(spec['old_code']) + '\n\n    cmp-long p1, p1, v0'
            assert data.count(before) == 1
            data = data.replace(before, 'const-wide/16 v0, ' + hex(spec['code']) + '\n\n    cmp-long p1, p1, v0')
        file.write_text(data)
    file = work / 'apktool.yml'
    data = file.read_text().replace('versionCode: ' + str(spec['old_code']), 'versionCode: ' + str(spec['code']))
    file.write_text(data.replace('versionName: ' + spec['old_version'], 'versionName: ' + spec['version']))
    icons = list((work / 'res').rglob('app_icon.png'))
    assert len(icons) == 2
    for file in icons:
        shutil.copyfile(root / 'app_icon.png', file)
    built = Path(temp) / 'built.apk'
    subprocess.run(['java', '-jar', str(a.apktool_jar), 'b', '-f', '-j', '1', str(work), '-o', str(built)], check=True)
    with zipfile.ZipFile(a.base_apk) as previous, zipfile.ZipFile(built) as current, zipfile.ZipFile(a.output, 'w') as out:
        for info in current.infolist():
            if info.filename.startswith('META-INF/') and (info.filename.endswith(('.SF', '.RSA', '.DSA')) or info.filename == 'META-INF/MANIFEST.MF'):
                continue
            data = previous.read('classes.dex') if info.filename == 'classes.dex' else current.read(info.filename)
            out.writestr(info, data)
    with zipfile.ZipFile(a.base_apk) as previous, zipfile.ZipFile(a.output) as current:
        for name in previous.namelist():
            if name.startswith(('assets/', 'lib/')) or name == 'classes.dex':
                assert previous.read(name) == current.read(name), name
print('Unsigned APK ready. Run zipalign -P 16 -f 4, then apksigner with your private release key.')
