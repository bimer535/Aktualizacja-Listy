.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lpl/mk/premiumsmart/tv/AppRuntime$Callback;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;ILpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iput p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$1:I

    iput-object p3, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$2:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    return-void
.end method


# virtual methods
.method public final done(Lorg/json/JSONObject;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iget v1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$1:I

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;->f$2:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    invoke-static {v0, v1, v2, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$ZC8g9OjCQ0au3DtxRUgwz28lQHs(Lpl/mk/premiumsmart/tv/MainActivity;ILpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V

    return-void
.end method
