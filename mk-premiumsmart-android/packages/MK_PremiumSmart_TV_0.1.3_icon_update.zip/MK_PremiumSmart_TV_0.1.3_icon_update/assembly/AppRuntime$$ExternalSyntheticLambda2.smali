.class public final synthetic Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;->f$0:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;->f$0:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lpl/mk/premiumsmart/tv/AppRuntime;->lambda$submit$2(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V

    return-void
.end method
