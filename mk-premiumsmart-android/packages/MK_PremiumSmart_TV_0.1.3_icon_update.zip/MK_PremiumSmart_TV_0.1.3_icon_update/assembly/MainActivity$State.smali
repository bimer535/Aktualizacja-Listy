.class final Lpl/mk/premiumsmart/tv/MainActivity$State;
.super Ljava/lang/Object;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/premiumsmart/tv/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "State"
.end annotation


# instance fields
.field index:I

.field item:Lorg/json/JSONObject;

.field rows:Lorg/json/JSONArray;


# direct methods
.method constructor <init>(Lorg/json/JSONObject;Lorg/json/JSONArray;I)V
    .locals 0

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$State;->item:Lorg/json/JSONObject;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$State;->rows:Lorg/json/JSONArray;

    iput p3, p0, Lpl/mk/premiumsmart/tv/MainActivity$State;->index:I

    return-void
.end method
