.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lpl/mk/premiumsmart/tv/AppRuntime$Callback;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda16;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    return-void
.end method


# virtual methods
.method public final done(Lorg/json/JSONObject;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda16;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-static {v0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$MMCCNS5mQ8a-hAv3cvRq4Wet0Iw(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    return-void
.end method
