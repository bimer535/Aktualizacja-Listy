.class public final Lpl/mk/premiumsmart/tv/Pow;
.super Ljava/lang/Object;
.source "Pow.java"


# static fields
.field private static volatile cancelled:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static absorb([ILjava/lang/String;)V
    .locals 11

    const/4 v0, 0x0

    .line 11
    aget v1, p0, v0

    const/4 v2, 0x1

    aget v3, p0, v2

    const/4 v4, 0x2

    aget v5, p0, v4

    const/4 v6, 0x3

    aget v7, p0, v6

    move v8, v0

    .line 12
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v9

    if-ge v8, v9, :cond_0

    .line 13
    invoke-virtual {p1, v8}, Ljava/lang/String;->charAt(I)C

    move-result v9

    and-int/lit16 v9, v9, 0xff

    add-int/2addr v1, v9

    const/4 v9, 0x7

    invoke-static {v1, v9}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v1

    add-int/2addr v1, v3

    xor-int/2addr v7, v1

    const/16 v10, 0x10

    invoke-static {v7, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v7

    add-int/2addr v5, v7

    xor-int/2addr v3, v5

    const/16 v10, 0xc

    .line 14
    invoke-static {v3, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    add-int/2addr v1, v3

    xor-int/2addr v7, v1

    const/16 v10, 0x8

    invoke-static {v7, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v7

    add-int/2addr v5, v7

    xor-int/2addr v3, v5

    invoke-static {v3, v9}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 16
    :cond_0
    aput v1, p0, v0

    aput v3, p0, v2

    aput v5, p0, v4

    aput v7, p0, v6

    return-void
.end method

.method public static cancel()V
    .locals 1

    const/4 v0, 0x1

    .line 6
    sput-boolean v0, Lpl/mk/premiumsmart/tv/Pow;->cancelled:Z

    return-void
.end method

.method public static find(Ljava/lang/String;JII)J
    .locals 10

    .line 41
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const-wide/16 v1, -0x2

    const/16 v3, 0x1000

    if-gt v0, v3, :cond_4

    const-wide/16 v4, 0x0

    cmp-long v0, p1, v4

    if-ltz v0, :cond_4

    const-wide v4, 0xffffffffL

    cmp-long v0, p1, v4

    if-gtz v0, :cond_4

    if-ltz p3, :cond_4

    if-gt p3, v3, :cond_4

    if-ltz p4, :cond_4

    const/16 v0, 0x100

    if-le p4, v0, :cond_0

    goto :goto_1

    .line 42
    :cond_0
    invoke-static {}, Lpl/mk/premiumsmart/tv/Pow;->initial()[I

    move-result-object v0

    const/16 v3, 0x200

    new-array v3, v3, [I

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v6, ":"

    invoke-virtual {p0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lpl/mk/premiumsmart/tv/Pow;->absorb([ILjava/lang/String;)V

    move-wide v6, p1

    :goto_0
    int-to-long v8, p3

    add-long/2addr v8, p1

    cmp-long p0, v6, v8

    if-gez p0, :cond_3

    cmp-long p0, v6, v4

    if-gtz p0, :cond_3

    .line 44
    sget-boolean p0, Lpl/mk/premiumsmart/tv/Pow;->cancelled:Z

    if-eqz p0, :cond_1

    return-wide v1

    .line 45
    :cond_1
    invoke-static {v6, v7}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0, v3}, Lpl/mk/premiumsmart/tv/Pow;->zeros([ILjava/lang/String;[I)I

    move-result p0

    if-lt p0, p4, :cond_2

    return-wide v6

    :cond_2
    const-wide/16 v8, 0x1

    add-long/2addr v6, v8

    goto :goto_0

    :cond_3
    const-wide/16 p0, -0x1

    return-wide p0

    :cond_4
    :goto_1
    return-wide v1
.end method

.method private static initial()[I
    .locals 4

    const v0, 0x3c6ef372

    const v1, -0x5ab00ac6

    const v2, 0x6a09e667

    const v3, -0x4498517b

    .line 9
    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    return-object v0
.end method

.method public static isCancelled()Z
    .locals 1

    .line 8
    sget-boolean v0, Lpl/mk/premiumsmart/tv/Pow;->cancelled:Z

    return v0
.end method

.method public static reset()V
    .locals 1

    const/4 v0, 0x0

    .line 7
    sput-boolean v0, Lpl/mk/premiumsmart/tv/Pow;->cancelled:Z

    return-void
.end method

.method public static zeroBits(Ljava/lang/String;)I
    .locals 2

    .line 39
    invoke-static {}, Lpl/mk/premiumsmart/tv/Pow;->initial()[I

    move-result-object v0

    const/16 v1, 0x200

    new-array v1, v1, [I

    invoke-static {v0, p0, v1}, Lpl/mk/premiumsmart/tv/Pow;->zeros([ILjava/lang/String;[I)I

    move-result p0

    return p0
.end method

.method private static zeros([ILjava/lang/String;[I)I
    .locals 17

    .line 19
    invoke-virtual/range {p0 .. p0}, [I->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    move-object/from16 v1, p1

    invoke-static {v0, v1}, Lpl/mk/premiumsmart/tv/Pow;->absorb([ILjava/lang/String;)V

    const/4 v1, 0x0

    aget v2, v0, v1

    const/4 v3, 0x1

    aget v3, v0, v3

    const/4 v4, 0x2

    aget v5, v0, v4

    const/4 v6, 0x3

    aget v0, v0, v6

    move v6, v1

    :goto_0
    const/16 v7, 0x208

    const/4 v8, 0x7

    const/16 v9, 0xc

    const/16 v10, 0x10

    const/16 v11, 0x8

    if-ge v6, v7, :cond_1

    add-int/2addr v2, v3

    xor-int/2addr v0, v2

    .line 21
    invoke-static {v0, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v3, v5

    invoke-static {v3, v9}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    add-int/2addr v2, v3

    xor-int/2addr v0, v2

    .line 22
    invoke-static {v0, v11}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v3, v5

    invoke-static {v3, v8}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    if-lt v6, v11, :cond_0

    add-int/lit8 v7, v6, -0x8

    xor-int v8, v2, v5

    .line 23
    aput v8, p2, v7

    :cond_0
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_1
    move v6, v1

    :goto_1
    const/16 v7, 0x200

    if-ge v6, v4, :cond_3

    move v12, v1

    :goto_2
    if-ge v12, v7, :cond_2

    .line 26
    aget v13, p2, v12

    and-int/lit16 v14, v13, 0x1ff

    aget v14, p2, v14

    add-int/2addr v13, v14

    const/16 v14, 0xd

    invoke-static {v13, v14}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v13

    add-int/lit8 v14, v12, 0x1

    and-int/lit16 v15, v14, 0x1ff

    aget v15, p2, v15

    const v16, -0x61c8864f

    mul-int v15, v15, v16

    xor-int/2addr v13, v15

    aput v13, p2, v12

    xor-int/2addr v2, v13

    add-int/2addr v2, v3

    xor-int/2addr v0, v2

    .line 27
    invoke-static {v0, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v3, v5

    invoke-static {v3, v9}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    add-int/2addr v2, v3

    xor-int/2addr v0, v2

    .line 28
    invoke-static {v0, v11}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v3, v5

    invoke-static {v3, v8}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v3

    move v12, v14

    goto :goto_2

    :cond_2
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_3
    move v4, v3

    move v3, v2

    move v2, v1

    :goto_3
    if-ge v1, v7, :cond_6

    add-int/2addr v3, v4

    xor-int/2addr v0, v3

    .line 32
    invoke-static {v0, v10}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v4, v5

    invoke-static {v4, v9}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v4

    add-int/2addr v3, v4

    xor-int/2addr v0, v3

    .line 33
    invoke-static {v0, v11}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v0

    add-int/2addr v5, v0

    xor-int/2addr v4, v5

    invoke-static {v4, v8}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v4

    move v6, v1

    move v12, v3

    :goto_4
    add-int/lit8 v13, v1, 0x40

    if-ge v6, v13, :cond_4

    .line 34
    aget v13, p2, v6

    add-int/2addr v12, v13

    const/4 v13, 0x5

    invoke-static {v12, v13}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v12

    aget v13, p2, v6

    const v14, -0x7a143589

    mul-int/2addr v13, v14

    xor-int/2addr v12, v13

    add-int/lit8 v6, v6, 0x1

    goto :goto_4

    :cond_4
    xor-int v1, v12, v5

    if-eqz v1, :cond_5

    .line 35
    invoke-static {v1}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result v0

    add-int/2addr v2, v0

    return v2

    :cond_5
    add-int/lit8 v2, v2, 0x20

    move v1, v13

    goto :goto_3

    :cond_6
    return v2
.end method
