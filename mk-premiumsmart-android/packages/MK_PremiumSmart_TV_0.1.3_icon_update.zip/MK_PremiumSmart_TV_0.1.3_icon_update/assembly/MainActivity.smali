.class public Lpl/mk/premiumsmart/tv/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lpl/mk/premiumsmart/tv/MainActivity$State;
    }
.end annotation


# instance fields
.field private busy:Z

.field private content:Landroid/widget/LinearLayout;

.field private current:Lorg/json/JSONObject;

.field private description:Landroid/widget/TextView;

.field private entries:Lorg/json/JSONArray;

.field private generation:I

.field private grid:Landroid/widget/GridLayout;

.field private heading:Landroid/widget/TextView;

.field private metadata:Landroid/widget/TextView;

.field private path:Landroid/widget/TextView;

.field private poster:Landroid/widget/ImageView;

.field private progress:Landroid/widget/ProgressBar;

.field private ready:Z

.field private root:Landroid/widget/LinearLayout;

.field private final rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private scroll:Landroid/widget/ScrollView;

.field private selected:I

.field private settings:Lorg/json/JSONObject;

.field private final stack:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lpl/mk/premiumsmart/tv/MainActivity$State;",
            ">;"
        }
    .end annotation
.end field

.field private status:Landroid/widget/TextView;

.field private title:Landroid/widget/TextView;

.field private updater:Lpl/mk/premiumsmart/tv/Updater;


# direct methods
.method public static synthetic $r8$lambda$-rDpHR2vEWam8Y8oCY2S8yVxio0(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;JLandroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct/range {p0 .. p6}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$play$10(Lorg/json/JSONObject;Lorg/json/JSONObject;JLandroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$283E77H2PgY_4hISYqkOtsSSTt4(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$favourite$16(Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$3jZPGE-9AoMK104IxADeuEbl_6Y(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$play$12(Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$3ktOm29qcdB6HRJHSPFePF-49J8(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$build$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$3qeK8oXRBp5WNpKV_6wCWchOPJ8(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->options()V

    return-void
.end method

.method public static synthetic $r8$lambda$8tl-pyrqOWj1F7G7aaxkAc5Hdj8(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$play$11(Lorg/json/JSONObject;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$J1emM9tO1uUnPf_3-m_MZKxYQrw(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$render$6(Lorg/json/JSONObject;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$KOMJQmrqOwFRDbfjUseRKBj2QHk(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$onActivityResult$21(Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MIkVEk15Tdbc7D3djtWqZwVDHUM(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$toggleView$15(Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MMCCNS5mQ8a-hAv3cvRq4Wet0Iw(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$options$17(Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MWuDusZkZi1PcoNNzdDTlkZI7g0(Lpl/mk/premiumsmart/tv/MainActivity;Landroid/widget/EditText;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$search$13(Landroid/widget/EditText;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$NdEnl1k9WpwiYYHDMkd63t8Cyj8(Lpl/mk/premiumsmart/tv/MainActivity;ILorg/json/JSONObject;Landroid/view/View;Z)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$render$5(ILorg/json/JSONObject;Landroid/view/View;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$ZC8g9OjCQ0au3DtxRUgwz28lQHs(Lpl/mk/premiumsmart/tv/MainActivity;ILpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$request$3(ILpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$c3XYi_AOTr9j0Uqdhv7FaHhyem4(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$onCreate$0(Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$dEqSK003SC1J8-IKfs_wSLFInkM(Lpl/mk/premiumsmart/tv/MainActivity;ZLorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$load$4(ZLorg/json/JSONObject;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$duVj25Xar3VEawcJgIfWmeJJvzY(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->toggleView()V

    return-void
.end method

.method public static synthetic $r8$lambda$jx3QDCpyamKDiwkkG4Z4y6hL_ZA(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$resolve$8(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$nd1RSPRKFEdckhMpUbyXwdpjVmc(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Landroid/view/View;)Z
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$render$7(Lorg/json/JSONObject;Landroid/view/View;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$o_SJ90jPQlb8csun18WuoPRV_nE(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->search()V

    return-void
.end method

.method public static synthetic $r8$lambda$phNBhLXuccAhO1V7mklkMR-ZaVM(Lpl/mk/premiumsmart/tv/MainActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$options$18(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$qN4Rawpg9V1WBSuopSoZZ4gUlyY(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$resolve$9(Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$t_SMSWdkzFENgUpY3OilKN5MHug(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$onActivityResult$20(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$xTi3hYen17HUFjHF6Gj9Jd2tXSw(Lpl/mk/premiumsmart/tv/MainActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->lambda$onBackPressed$19(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 24
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 25
    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->stack:Ljava/util/ArrayDeque;

    .line 26
    const-string v0, "title"

    const-string v1, "PremiumSmart"

    const-string v2, "action"

    const-string v3, "main"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    .line 27
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    const/4 v0, 0x0

    .line 28
    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    .line 36
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->rows:Ljava/util/List;

    return-void
.end method

.method private build()V
    .locals 15

    .line 60
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    const/high16 v2, 0x41d00000    # 26.0f

    invoke-direct {p0, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v3

    const/high16 v4, 0x41800000    # 16.0f

    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v5

    invoke-direct {p0, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v2

    const/high16 v6, 0x41600000    # 14.0f

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v6

    invoke-virtual {v0, v3, v5, v2, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    const/16 v2, 0x10

    const/16 v3, 0x1b

    const/16 v5, 0xb

    invoke-static {v5, v2, v3}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->setContentView(Landroid/view/View;)V

    .line 61
    const-string v0, "MK PremiumSmart TV"

    const/16 v2, 0x19

    const/4 v3, -0x1

    invoke-direct {p0, v0, v2, v3}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->heading:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->heading:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v0, -0x564531

    .line 62
    const-string v2, "Filmy i seriale \u2022 bez logowania \u2022 0.1.3"

    const/16 v5, 0xc

    invoke-direct {p0, v2, v5, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->path:Landroid/widget/TextView;

    const/high16 v2, 0x40800000    # 4.0f

    invoke-direct {p0, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v2

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v7

    const/4 v8, 0x0

    invoke-virtual {v0, v8, v2, v8, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->path:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 63
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    .line 64
    new-array v7, v2, [Landroid/widget/Button;

    new-instance v9, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda6;

    invoke-direct {v9, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda6;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v10, "\u2315 Szukaj"

    invoke-direct {p0, v10, v9}, Lpl/mk/premiumsmart/tv/MainActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    aput-object v9, v7, v8

    new-instance v9, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda7;

    invoke-direct {v9, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda7;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v10, "Lista / kafelki"

    invoke-direct {p0, v10, v9}, Lpl/mk/premiumsmart/tv/MainActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    aput-object v9, v7, v1

    new-instance v9, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda8;

    invoke-direct {v9, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda8;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v10, "Opcje"

    invoke-direct {p0, v10, v9}, Lpl/mk/premiumsmart/tv/MainActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    const/4 v10, 0x2

    aput-object v9, v7, v10

    new-instance v9, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda9;

    invoke-direct {v9, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda9;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v10, "G\u0142\u00f3wna"

    invoke-direct {p0, v10, v9}, Lpl/mk/premiumsmart/tv/MainActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    const/4 v10, 0x3

    aput-object v9, v7, v10

    move v9, v8

    :goto_0
    const/high16 v11, 0x3f800000    # 1.0f

    if-ge v9, v2, :cond_0

    aget-object v12, v7, v9

    .line 65
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x42200000    # 40.0f

    invoke-direct {p0, v14}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v14

    invoke-direct {v13, v8, v14, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v11

    invoke-virtual {v13, v8, v8, v11, v8}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v12, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    .line 67
    :cond_0
    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->content:Landroid/widget/LinearLayout;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-direct {p0, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v2

    const/high16 v7, 0x40c00000    # 6.0f

    invoke-direct {p0, v7}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v7

    invoke-virtual {v0, v8, v2, v8, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->content:Landroid/widget/LinearLayout;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v3, v8, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 68
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    new-instance v0, Landroid/widget/GridLayout;

    invoke-direct {v0, p0}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    invoke-virtual {v0, v8}, Landroid/widget/GridLayout;->setUseDefaultMargins(Z)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->scroll:Landroid/widget/ScrollView;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    new-instance v7, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v9, -0x2

    invoke-direct {v7, v3, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v7}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->content:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->scroll:Landroid/widget/ScrollView;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v8, v3, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 69
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v1

    invoke-virtual {v0, v1, v8, v8, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->content:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x43720000    # 242.0f

    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v4

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 70
    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->poster:Landroid/widget/ImageView;

    sget-object v2, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->poster:Landroid/widget/ImageView;

    const v2, -0xebdfcd

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setBackgroundColor(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->poster:Landroid/widget/ImageView;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x43420000    # 194.0f

    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 71
    const-string v1, "Wybierz film lub serial"

    const/16 v2, 0x12

    invoke-direct {p0, v1, v2, v3}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->title:Landroid/widget/TextView;

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->title:Landroid/widget/TextView;

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v2

    const/high16 v4, 0x40a00000    # 5.0f

    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v4

    invoke-virtual {v1, v8, v2, v8, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->title:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v1, 0xd

    const v2, -0xaa362f

    .line 72
    const-string v4, "Tutaj pojawi si\u0119 ok\u0142adka i opis"

    invoke-direct {p0, v4, v1, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->metadata:Landroid/widget/TextView;

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->metadata:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 73
    new-instance v1, Landroid/widget/ScrollView;

    invoke-direct {v1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/16 v2, 0xe

    const v4, -0x382b18

    const-string v7, ""

    invoke-direct {p0, v7, v2, v4}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v2

    iput-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->description:Landroid/widget/TextView;

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v4

    invoke-virtual {v2, v8, v4, v8, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->description:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v3, v8, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 74
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/ProgressBar;

    invoke-direct {v1, p0}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->progress:Landroid/widget/ProgressBar;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/ProgressBar;->setVisibility(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->progress:Landroid/widget/ProgressBar;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x41b00000    # 22.0f

    invoke-direct {p0, v3}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v4

    invoke-direct {p0, v3}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v3

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 75
    const-string v1, "OK: wybierz \u2022 Przytrzymaj OK: ulubione \u2022 MENU: opcje \u2022 Wstecz: wr\u00f3\u0107"

    const v2, -0x56412b

    invoke-direct {p0, v1, v5, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->status:Landroid/widget/TextView;

    invoke-direct {p0, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v2

    invoke-virtual {v1, v2, v8, v8, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->status:Landroid/widget/TextView;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v8, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private button(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;
    .locals 1

    .line 55
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41600000    # 14.0f

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setTextSize(F)V

    const/4 p1, -0x1

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setTextColor(I)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 56
    sget p1, Lpl/mk/premiumsmart/tv/R$drawable;->focus_card:I

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setBackgroundResource(I)V

    new-instance p1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda18;

    invoke-direct {p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda18;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private detail(Lorg/json/JSONObject;)V
    .locals 7

    .line 106
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->title:Landroid/widget/TextView;

    const-string v1, "title"

    const-string v2, ""

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "movie_title"

    invoke-virtual {p1, v3, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "rating_label"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x3

    .line 107
    new-array v3, v1, [Ljava/lang/String;

    const-string v4, "year"

    const/4 v5, 0x0

    aput-object v4, v3, v5

    const/4 v4, 0x1

    const-string v6, "language_version"

    aput-object v6, v3, v4

    const/4 v4, 0x2

    const-string v6, "progress_label"

    aput-object v6, v3, v4

    :goto_0
    if-ge v5, v1, :cond_2

    aget-object v4, v3, v5

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    move-object v0, v2

    goto :goto_1

    :cond_0
    const-string v0, " \u2022 "

    :goto_1
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 108
    :cond_2
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->metadata:Landroid/widget/TextView;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_3

    const-string v0, "Wybierz pozycj\u0119 przyciskiem OK"

    :cond_3
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->description:Landroid/widget/TextView;

    const-string v1, "desc"

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "synopsis"

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->poster:Landroid/widget/ImageView;

    const-string v1, "icon"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lpl/mk/premiumsmart/tv/Images;->load(Landroid/widget/ImageView;Ljava/lang/String;)V

    return-void
.end method

.method private dp(F)I
    .locals 1

    .line 42
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method private error(Lorg/json/JSONObject;)V
    .locals 5

    .line 160
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Nie uda\u0142o si\u0119 otworzy\u0107"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "message"

    const-string v3, "Spr\u00f3buj ponownie p\u00f3\u017aniej."

    invoke-virtual {p1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "reason"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "\nKod: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string v0, "OK"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private favourite(Lorg/json/JSONObject;)V
    .locals 3

    .line 146
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "action"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "sources"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "seasons"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "resolve"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 147
    :cond_1
    const-string v0, "favourite"

    const-string v1, "item"

    const-string v2, "op"

    filled-new-array {v2, v0, v1, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    new-instance v0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda15;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda15;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v1, "Zapisywanie\u2026"

    invoke-direct {p0, p1, v1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private synthetic lambda$build$2()V
    .locals 4

    .line 64
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->stack:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const-string v0, "title"

    const-string v1, "PremiumSmart"

    const-string v2, "action"

    const-string v3, "main"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    :cond_0
    return-void
.end method

.method static synthetic lambda$button$1(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 56
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private synthetic lambda$favourite$16(Lorg/json/JSONObject;)V
    .locals 2

    .line 147
    const-string v0, "added"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_0

    const-string p1, "Dodano do ulubionych"

    goto :goto_0

    :cond_0
    const-string p1, "Usuni\u0119to z ulubionych"

    :goto_0
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    const-string v1, "action"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "favourites"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    invoke-direct {p0, p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    :cond_1
    return-void
.end method

.method private synthetic lambda$load$4(ZLorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 4

    if-eqz p1, :cond_0

    .line 86
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->stack:Ljava/util/ArrayDeque;

    new-instance v0, Lpl/mk/premiumsmart/tv/MainActivity$State;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    iget v3, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {v0, v1, v2, v3}, Lpl/mk/premiumsmart/tv/MainActivity$State;-><init>(Lorg/json/JSONObject;Lorg/json/JSONArray;I)V

    invoke-virtual {p1, v0}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    :cond_0
    invoke-static {p2}, Lpl/mk/premiumsmart/tv/AppRuntime;->copy(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    const-string p1, "items"

    invoke-virtual {p3, p1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    if-nez p1, :cond_1

    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    :cond_1
    const/4 p1, 0x0

    iput p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->render()V

    return-void
.end method

.method private synthetic lambda$onActivityResult$20(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    const/4 p2, 0x1

    .line 184
    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    return-void
.end method

.method private synthetic lambda$onActivityResult$21(Lorg/json/JSONObject;)V
    .locals 2

    .line 183
    const-string v0, "items"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 184
    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object p1

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Nast\u0119pny odcinek"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "title"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda22;

    invoke-direct {v1, p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda22;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    const-string p1, "Otw\u00f3rz"

    invoke-virtual {v0, p1, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string v0, "P\u00f3\u017aniej"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 183
    :cond_1
    :goto_0
    const-string p1, "Brak nast\u0119pnego odcinka"

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$onBackPressed$19(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 172
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->finish()V

    return-void
.end method

.method private synthetic lambda$onCreate$0(Lorg/json/JSONObject;)V
    .locals 3

    .line 49
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 50
    :cond_0
    const-string v0, "ok"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const-string v1, ""

    const/4 v2, 0x0

    if-nez v0, :cond_1

    invoke-direct {p0, v2, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->error(Lorg/json/JSONObject;)V

    return-void

    :cond_1
    const/4 v0, 0x1

    .line 51
    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    const-string v0, "settings"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    if-nez p1, :cond_2

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    :cond_2
    invoke-direct {p0, v2, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    invoke-direct {p0, p1, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    return-void
.end method

.method private synthetic lambda$options$17(Lorg/json/JSONObject;)V
    .locals 1

    .line 154
    const-string v0, "settings"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    return-void
.end method

.method private synthetic lambda$options$18(Landroid/content/DialogInterface;I)V
    .locals 6

    if-nez p2, :cond_0

    .line 153
    iget p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->row(I)Lorg/json/JSONObject;

    move-result-object p1

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->favourite(Lorg/json/JSONObject;)V

    return-void

    :cond_0
    const/4 p1, 0x1

    if-ne p2, p1, :cond_1

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->toggleView()V

    return-void

    :cond_1
    const/4 v0, 0x2

    if-ne p2, v0, :cond_2

    .line 154
    iget-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    const-string v0, "auto_play"

    invoke-virtual {p2, v0, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p2

    xor-int/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const-string v0, "op"

    const-string v1, "settings"

    const-string v2, "key"

    const-string v3, "auto_play"

    const-string v4, "value"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda16;

    invoke-direct {p2, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda16;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v0, "Zapisywanie\u2026"

    invoke-direct {p0, p1, v0, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void

    :cond_2
    const/4 p1, 0x3

    if-ne p2, p1, :cond_3

    .line 155
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    return-void

    :cond_3
    const/4 p1, 0x4

    if-ne p2, p1, :cond_4

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->updater:Lpl/mk/premiumsmart/tv/Updater;

    invoke-virtual {p1}, Lpl/mk/premiumsmart/tv/Updater;->check()V

    return-void

    :cond_4
    const/4 p1, 0x5

    const/4 v0, 0x0

    .line 156
    const-string v1, "OK"

    if-ne p2, p1, :cond_5

    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string p2, "MK PremiumSmart TV"

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "Projekt i rozw\u00f3j: MK\nKontakt: bimer55@wp.pl\n\nPrzy zg\u0142oszeniu podaj model urz\u0105dzenia, wersj\u0119 Androida i kr\u00f3tki opis problemu.\nWersja 0.1.3"

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 157
    :cond_5
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string p2, "Informacje"

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "Samodzielna aplikacja MK na bazie MK PremiumSmart E2 0.1.1.\nGPL-3.0. Publiczne \u017ar\u00f3d\u0142a E2iPlayer oraz komponenty AndroidX Media3 i Chaquopy.\n\nPe\u0142ne licencje i kod \u017ar\u00f3d\u0142owy s\u0105 do\u0142\u0105czone do wydania na GitHubie.\n\nAplikacja korzysta z anonimowej sesji serwisu. Dost\u0119pno\u015b\u0107 zale\u017cy od \u017ar\u00f3de\u0142."

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private synthetic lambda$play$10(Lorg/json/JSONObject;Lorg/json/JSONObject;JLandroid/content/DialogInterface;I)V
    .locals 0

    .line 127
    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/premiumsmart/tv/MainActivity;->openPlayer(Lorg/json/JSONObject;Lorg/json/JSONObject;J)V

    return-void
.end method

.method private synthetic lambda$play$11(Lorg/json/JSONObject;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    const-wide/16 p3, 0x0

    .line 127
    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/premiumsmart/tv/MainActivity;->openPlayer(Lorg/json/JSONObject;Lorg/json/JSONObject;J)V

    return-void
.end method

.method private synthetic lambda$play$12(Lorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 11

    .line 126
    const-string v0, "progress"

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-wide/16 v1, 0x0

    if-nez v0, :cond_0

    move-wide v9, v1

    goto :goto_0

    :cond_0
    const-string v3, "position"

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v3

    move-wide v9, v3

    :goto_0
    if-eqz v0, :cond_1

    const-string v3, "completed"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    const-wide/16 v3, 0xf

    cmp-long v3, v9, v3

    if-ltz v3, :cond_2

    if-nez v0, :cond_2

    .line 127
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Kontynuowa\u0107 ogl\u0105danie?"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Wznowi\u0107 od "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v9, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->stamp(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "?"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v5, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;

    move-object v6, p0

    move-object v7, p1

    move-object v8, p2

    invoke-direct/range {v5 .. v10}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;J)V

    const-string p1, "Wzn\u00f3w"

    invoke-virtual {v0, p1, v5}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;

    invoke-direct {p2, p0, v7, v8}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    const-string v0, "Od pocz\u0105tku"

    invoke-virtual {p1, v0, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :cond_2
    move-object v6, p0

    move-object v7, p1

    move-object v8, p2

    .line 128
    invoke-direct {p0, v7, v8, v1, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->openPlayer(Lorg/json/JSONObject;Lorg/json/JSONObject;J)V

    return-void
.end method

.method private synthetic lambda$render$5(ILorg/json/JSONObject;Landroid/view/View;Z)V
    .locals 0

    if-eqz p4, :cond_0

    .line 101
    iput p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {p0, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->detail(Lorg/json/JSONObject;)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$render$6(Lorg/json/JSONObject;Landroid/view/View;)V
    .locals 0

    .line 101
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->select(Lorg/json/JSONObject;)V

    return-void
.end method

.method private synthetic lambda$render$7(Lorg/json/JSONObject;Landroid/view/View;)Z
    .locals 0

    .line 101
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->favourite(Lorg/json/JSONObject;)V

    const/4 p1, 0x1

    return p1
.end method

.method private synthetic lambda$request$3(ILpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V
    .locals 1

    .line 81
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_2

    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    const-string v0, ""

    invoke-direct {p0, p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    const-string p1, "ok"

    invoke-virtual {p3, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_1

    invoke-direct {p0, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->error(Lorg/json/JSONObject;)V

    return-void

    :cond_1
    invoke-interface {p2, p3}, Lpl/mk/premiumsmart/tv/AppRuntime$Callback;->done(Lorg/json/JSONObject;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private synthetic lambda$resolve$8(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 121
    invoke-direct {p0, p1, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->play(Lorg/json/JSONObject;I)V

    return-void
.end method

.method private synthetic lambda$resolve$9(Lorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 5

    .line 118
    const-string v0, "variants"

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    .line 119
    :cond_0
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    const-string v2, "auto_play"

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    const-string v0, "preferred"

    invoke-virtual {p2, v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result p2

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->play(Lorg/json/JSONObject;I)V

    return-void

    .line 120
    :cond_1
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result p2

    new-array v1, p2, [Ljava/lang/String;

    :goto_0
    if-ge v2, p2, :cond_2

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "label"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 121
    :cond_2
    new-instance p2, Landroid/app/AlertDialog$Builder;

    invoke-direct {p2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v0, "Wybierz jako\u015b\u0107"

    invoke-virtual {p2, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    new-instance v0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda23;

    invoke-direct {v0, p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda23;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    invoke-virtual {p2, v1, v0}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "Wr\u00f3\u0107"

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 118
    :cond_3
    :goto_1
    const-string p1, "message"

    const-string p2, "\u0179r\u00f3d\u0142o nie zwr\u00f3ci\u0142o filmu."

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->error(Lorg/json/JSONObject;)V

    return-void
.end method

.method private synthetic lambda$search$13(Landroid/widget/EditText;Landroid/content/DialogInterface;I)V
    .locals 6

    .line 138
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Szukaj: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "search_results"

    const-string v4, "query"

    const-string v0, "title"

    const-string v2, "action"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    :cond_0
    return-void
.end method

.method static synthetic lambda$search$14(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/content/DialogInterface;)V
    .locals 0

    .line 139
    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 p1, 0x5

    invoke-virtual {p0, p1}, Landroid/view/Window;->setSoftInputMode(I)V

    return-void
.end method

.method private synthetic lambda$toggleView$15(Lorg/json/JSONObject;)V
    .locals 1

    .line 143
    const-string v0, "settings"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->render()V

    return-void
.end method

.method private load(Lorg/json/JSONObject;Z)V
    .locals 3

    .line 84
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-eqz v0, :cond_0

    return-void

    .line 85
    :cond_0
    const-string v0, "browse"

    const-string v1, "item"

    const-string v2, "op"

    filled-new-array {v2, v0, v1, p1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda19;

    invoke-direct {v1, p0, p2, p1}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda19;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;ZLorg/json/JSONObject;)V

    const-string p1, "Pobieranie listy\u2026"

    invoke-direct {p0, v0, p1, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method

.method private openPlayer(Lorg/json/JSONObject;Lorg/json/JSONObject;J)V
    .locals 2

    .line 132
    const-string v0, "player"

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "android"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-class v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    goto :goto_0

    :cond_0
    const-class v0, Lpl/mk/premiumsmart/tv/PlayerActivity;

    .line 133
    :goto_0
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v0, "entry"

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "stream"

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "position"

    invoke-virtual {v1, p1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/16 p1, 0xc8

    invoke-virtual {p0, v1, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private options()V
    .locals 4

    .line 150
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x7

    .line 151
    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Dodaj / usu\u0144 z ulubionych"

    aput-object v2, v0, v1

    const-string v1, "Lista / kafelki"

    const/4 v2, 0x1

    aput-object v1, v0, v2

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    const-string v3, "auto_play"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "najlepsza automatycznie"

    goto :goto_0

    :cond_1
    const-string v1, "wyb\u00f3r r\u0119czny"

    :goto_0
    const-string v2, "Jako\u015b\u0107: "

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v0, v2

    const/4 v1, 0x3

    const-string v2, "Od\u015bwie\u017c list\u0119"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "Sprawd\u017a aktualizacj\u0119"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "Autor i kontakt"

    aput-object v2, v0, v1

    const/4 v1, 0x6

    const-string v2, "Informacje i licencje"

    aput-object v2, v0, v1

    .line 152
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "Opcje"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda24;

    invoke-direct {v2, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda24;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 158
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    :cond_2
    :goto_1
    return-void
.end method

.method private play(Lorg/json/JSONObject;I)V
    .locals 6

    .line 125
    const-string v4, "index"

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v0, "op"

    const-string v1, "play"

    const-string v2, "item"

    move-object v3, p1

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;

    invoke-direct {p2, p0, v3}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    const-string v0, "Uruchamianie filmu\u2026"

    invoke-direct {p0, p1, v0, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method

.method private render()V
    .locals 15

    .line 90
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    invoke-virtual {v0}, Landroid/widget/GridLayout;->removeAllViews()V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->rows:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    const-string v1, "view"

    const-string v2, "tiles"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 91
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    const-string v2, "action"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "movies"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_1

    const-string v2, "page"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "search_results"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "favourites"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "continue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v3

    goto :goto_1

    :cond_1
    :goto_0
    move v1, v4

    :goto_1
    const/4 v2, 0x3

    if-eqz v0, :cond_2

    if-eqz v1, :cond_2

    move v0, v2

    goto :goto_2

    :cond_2
    move v0, v4

    .line 92
    :goto_2
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    invoke-virtual {v1, v0}, Landroid/widget/GridLayout;->setColumnCount(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    iget-object v5, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v5

    add-int/2addr v5, v0

    sub-int/2addr v5, v4

    div-int/2addr v5, v0

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual {v1, v5}, Landroid/widget/GridLayout;->setRowCount(I)V

    .line 93
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->path:Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "PremiumSmart  /  "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v6, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    const-string v7, "Filmy i seriale"

    const-string v8, "title"

    invoke-virtual {v6, v8, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "  \u2022  "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " pozycji"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 94
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/16 v5, 0x12

    const/4 v6, -0x1

    if-nez v1, :cond_3

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    const-string v1, "Brak pozycji. Wr\u00f3\u0107 lub zmie\u0144 filtr."

    invoke-direct {p0, v1, v5, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->addView(Landroid/view/View;)V

    return-void

    :cond_3
    move v1, v3

    .line 95
    :goto_3
    iget-object v7, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v1, v7, :cond_a

    .line 96
    invoke-direct {p0, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->row(I)Lorg/json/JSONObject;

    move-result-object v7

    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v10, 0x41000000    # 8.0f

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v11

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v12

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v13

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v14

    invoke-virtual {v9, v11, v12, v13, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    sget v11, Lpl/mk/premiumsmart/tv/R$drawable;->focus_card:I

    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setClickable(Z)V

    if-le v0, v4, :cond_4

    .line 97
    const-string v11, "icon"

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_4

    new-instance v12, Landroid/widget/ImageView;

    invoke-direct {v12, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v13, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v12, v13}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x43160000    # 150.0f

    invoke-direct {p0, v14}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v14

    invoke-direct {v13, v6, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v12, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v12, v11}, Lpl/mk/premiumsmart/tv/Images;->load(Landroid/widget/ImageView;Ljava/lang/String;)V

    .line 98
    :cond_4
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "watched"

    invoke-virtual {v7, v12}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_5

    const-string v12, "\u2713 "

    goto :goto_4

    :cond_5
    const-string v12, ""

    :goto_4
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    if-le v0, v4, :cond_6

    const/16 v12, 0xf

    goto :goto_5

    :cond_6
    move v12, v5

    :goto_5
    invoke-direct {p0, v11, v12, v6}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v11

    if-le v0, v4, :cond_7

    move v12, v2

    goto :goto_6

    :cond_7
    const/4 v12, 0x2

    :goto_6
    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    if-le v0, v4, :cond_8

    const/high16 v12, 0x42500000    # 52.0f

    goto :goto_7

    :cond_8
    const/high16 v12, 0x42080000    # 34.0f

    :goto_7
    invoke-direct {p0, v12}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setMinHeight(I)V

    const/16 v12, 0x10

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-le v0, v4, :cond_9

    .line 99
    const-string v11, "rating_label"

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_9

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v12, 0xc

    const v13, -0xc2c8b

    invoke-direct {p0, v11, v12, v13}, Lpl/mk/premiumsmart/tv/MainActivity;->text(Ljava/lang/String;II)Landroid/widget/TextView;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 100
    :cond_9
    new-instance v11, Landroid/widget/GridLayout$LayoutParams;

    div-int v12, v1, v0

    invoke-static {v12}, Landroid/widget/GridLayout;->spec(I)Landroid/widget/GridLayout$Spec;

    move-result-object v12

    rem-int v13, v1, v0

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-static {v13, v14}, Landroid/widget/GridLayout;->spec(IF)Landroid/widget/GridLayout$Spec;

    move-result-object v13

    invoke-direct {v11, v12, v13}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    iput v3, v11, Landroid/widget/GridLayout$LayoutParams;->width:I

    const/4 v12, -0x2

    iput v12, v11, Landroid/widget/GridLayout$LayoutParams;->height:I

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v12

    invoke-direct {p0, v10}, Lpl/mk/premiumsmart/tv/MainActivity;->dp(F)I

    move-result v10

    invoke-virtual {v11, v3, v3, v12, v10}, Landroid/widget/GridLayout$LayoutParams;->setMargins(IIII)V

    iget-object v10, p0, Lpl/mk/premiumsmart/tv/MainActivity;->grid:Landroid/widget/GridLayout;

    invoke-virtual {v10, v9, v11}, Landroid/widget/GridLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v10, p0, Lpl/mk/premiumsmart/tv/MainActivity;->rows:Ljava/util/List;

    invoke-interface {v10, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 101
    new-instance v10, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;

    invoke-direct {v10, p0, v1, v7}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;ILorg/json/JSONObject;)V

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    new-instance v10, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda13;

    invoke-direct {v10, p0, v7}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda13;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v10, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda14;

    invoke-direct {v10, p0, v7}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda14;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_3

    .line 103
    :cond_a
    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->rows:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    sub-int/2addr v1, v4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->rows:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->row(I)Lorg/json/JSONObject;

    move-result-object v0

    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->detail(Lorg/json/JSONObject;)V

    return-void
.end method

.method private request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 2

    .line 80
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    invoke-direct {p0, v1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    .line 81
    new-instance p2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, v0, p3}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;ILpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    invoke-static {p1, p2}, Lpl/mk/premiumsmart/tv/AppRuntime;->submit(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method

.method private resolve(Lorg/json/JSONObject;)V
    .locals 3

    .line 117
    const-string v0, "resolve"

    const-string v1, "item"

    const-string v2, "op"

    filled-new-array {v2, v0, v1, p1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda4;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V

    const-string p1, "Pobieranie i weryfikacja \u017ar\u00f3d\u0142a\u2026 Wstecz: anuluj"

    invoke-direct {p0, v0, p1, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method

.method private row(I)Lorg/json/JSONObject;
    .locals 1

    .line 78
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    invoke-virtual {v0, p1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object p1

    if-nez p1, :cond_0

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    :cond_0
    return-object p1
.end method

.method private search()V
    .locals 4

    .line 137
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSingleLine(Z)V

    const-string v1, "Tytu\u0142 filmu lub serialu"

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 138
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "Wyszukaj"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0, v0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda2;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;Landroid/widget/EditText;)V

    const-string v3, "Szukaj"

    invoke-virtual {v1, v3, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "Wr\u00f3\u0107"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v1

    .line 139
    new-instance v2, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, v0, v1}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda3;-><init>(Landroid/widget/EditText;Landroid/app/AlertDialog;)V

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    invoke-virtual {v1}, Landroid/app/AlertDialog;->show()V

    :cond_1
    :goto_0
    return-void
.end method

.method private select(Lorg/json/JSONObject;)V
    .locals 2

    .line 111
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const-string v0, "action"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 112
    const-string v1, "search"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->search()V

    return-void

    .line 113
    :cond_1
    const-string v1, "resolve"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->resolve(Lorg/json/JSONObject;)V

    return-void

    :cond_2
    const/4 v0, 0x1

    .line 114
    invoke-direct {p0, p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    return-void
.end method

.method private setBusy(ZLjava/lang/String;)V
    .locals 1

    .line 77
    iput-boolean p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->progress:Landroid/widget/ProgressBar;

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p2, "OK: wybierz \u2022 Przytrzymaj OK: ulubione \u2022 MENU: opcje \u2022 Wstecz: wr\u00f3\u0107"

    :cond_1
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method static stamp(J)Ljava/lang/String;
    .locals 6

    .line 135
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-wide/16 v1, 0xe10

    div-long v1, p0, v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-wide/16 v2, 0x3c

    div-long v4, p0, v2

    rem-long/2addr v4, v2

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    rem-long/2addr p0, v2

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    filled-new-array {v1, v4, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%d:%02d:%02d"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private text(Ljava/lang/String;II)Landroid/widget/TextView;
    .locals 1

    .line 43
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p1, p2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    return-object v0
.end method

.method private toggleView()V
    .locals 9

    .line 142
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->ready:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->settings:Lorg/json/JSONObject;

    const-string v1, "view"

    const-string v2, "tiles"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v2, "list"

    :cond_1
    move-object v8, v2

    .line 143
    const-string v6, "view"

    const-string v7, "value"

    const-string v3, "op"

    const-string v4, "settings"

    const-string v5, "key"

    filled-new-array/range {v3 .. v8}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda20;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda20;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v2, "Zmiana widoku\u2026"

    invoke-direct {p0, v0, v2, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    .line 162
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_2

    .line 163
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v2, 0x52

    if-ne v0, v2, :cond_0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->options()V

    return v1

    .line 164
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v2, 0xb9

    if-ne v0, v2, :cond_1

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->toggleView()V

    return v1

    .line 165
    :cond_1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v2, 0xba

    if-ne v0, v2, :cond_2

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-nez v0, :cond_2

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->updater:Lpl/mk/premiumsmart/tv/Updater;

    invoke-virtual {p1}, Lpl/mk/premiumsmart/tv/Updater;->check()V

    return v1

    .line 167
    :cond_2
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    .line 175
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/16 p2, 0xd2

    if-ne p1, p2, :cond_0

    .line 176
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->updater:Lpl/mk/premiumsmart/tv/Updater;

    invoke-virtual {p1}, Lpl/mk/premiumsmart/tv/Updater;->installPending()V

    return-void

    :cond_0
    const/16 p2, 0xc8

    if-eq p1, p2, :cond_1

    goto :goto_0

    .line 178
    :cond_1
    const-string p1, "stop"

    const-string p2, "op"

    filled-new-array {p2, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->submit(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    const/4 p1, 0x0

    .line 179
    const-string v0, "action"

    if-eqz p3, :cond_2

    const-string v1, "next"

    invoke-virtual {p3, v1, p1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 181
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    const-string v1, "entry"

    invoke-virtual {p3, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-direct {p1, p3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p3, "next_episode"

    invoke-virtual {p1, v0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 182
    const-string p3, "browse"

    const-string v0, "item"

    filled-new-array {p2, p3, v0, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    const-string p2, "Sprawdzanie nast\u0119pnego odcinka\u2026"

    new-instance p3, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda10;

    invoke-direct {p3, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda10;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/MainActivity;->request(Lorg/json/JSONObject;Ljava/lang/String;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 187
    :cond_2
    iget-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "continue"

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_3

    iget-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    invoke-direct {p0, p2, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->load(Lorg/json/JSONObject;Z)V

    :catch_0
    :cond_3
    :goto_0
    return-void
.end method

.method public onBackPressed()V
    .locals 3

    .line 170
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->busy:Z

    if-eqz v0, :cond_0

    invoke-static {}, Lpl/mk/premiumsmart/tv/Pow;->cancel()V

    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    const/4 v0, 0x0

    const-string v1, "Anulowano. Wybierz inn\u0105 pozycj\u0119."

    invoke-direct {p0, v0, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    return-void

    .line 171
    :cond_0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->stack:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->stack:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lpl/mk/premiumsmart/tv/MainActivity$State;

    iget-object v1, v0, Lpl/mk/premiumsmart/tv/MainActivity$State;->item:Lorg/json/JSONObject;

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->current:Lorg/json/JSONObject;

    iget-object v1, v0, Lpl/mk/premiumsmart/tv/MainActivity$State;->rows:Lorg/json/JSONArray;

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->entries:Lorg/json/JSONArray;

    iget v0, v0, Lpl/mk/premiumsmart/tv/MainActivity$State;->index:I

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->selected:I

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->render()V

    return-void

    .line 172
    :cond_1
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Zamkn\u0105\u0107 aplikacj\u0119?"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda5;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    const-string v2, "Wyjd\u017a"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Zosta\u0144"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 45
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 46
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x1706

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 47
    new-instance p1, Lpl/mk/premiumsmart/tv/Updater;

    invoke-direct {p1, p0}, Lpl/mk/premiumsmart/tv/Updater;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity;->updater:Lpl/mk/premiumsmart/tv/Updater;

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/MainActivity;->build()V

    const/4 p1, 0x1

    const-string v0, "Uruchamianie PremiumSmart\u2026"

    invoke-direct {p0, p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->setBusy(ZLjava/lang/String;)V

    .line 48
    new-instance p1, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {p1, p0}, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda1;-><init>(Lpl/mk/premiumsmart/tv/MainActivity;)V

    invoke-static {p0, p1}, Lpl/mk/premiumsmart/tv/AppRuntime;->init(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 189
    iget v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lpl/mk/premiumsmart/tv/MainActivity;->generation:I

    invoke-static {}, Lpl/mk/premiumsmart/tv/Pow;->cancel()V

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method
