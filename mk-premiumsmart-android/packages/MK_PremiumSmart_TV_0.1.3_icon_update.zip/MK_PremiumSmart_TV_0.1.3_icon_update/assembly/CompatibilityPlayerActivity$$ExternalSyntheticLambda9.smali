.class public final synthetic Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda9;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    return-void
.end method


# virtual methods
.method public final onPrepared(Landroid/media/MediaPlayer;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda9;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-static {v0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->$r8$lambda$z2UKOpY4XGhBIQIc0MA8utpqSXg(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;)V

    return-void
.end method
