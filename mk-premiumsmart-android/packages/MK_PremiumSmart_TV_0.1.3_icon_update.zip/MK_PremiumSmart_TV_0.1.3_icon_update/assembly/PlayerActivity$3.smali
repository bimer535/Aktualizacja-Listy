.class Lpl/mk/premiumsmart/tv/PlayerActivity$3;
.super Ljava/lang/Object;
.source "PlayerActivity.java"

# interfaces
.implements Landroidx/media3/common/Player$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpl/mk/premiumsmart/tv/PlayerActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;


# direct methods
.method public static synthetic $r8$lambda$78jQ_-k5oa5PDg18gQuyA9dHTWk(Lpl/mk/premiumsmart/tv/PlayerActivity$3;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->lambda$onPlayerError$0(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$GL2SYPk_Lcpg2gV_LdNkfdILmEU(Lpl/mk/premiumsmart/tv/PlayerActivity$3;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->lambda$onPlayerError$1(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method constructor <init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V
    .locals 0

    .line 98
    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private synthetic lambda$onPlayerError$0(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 110
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$mleave(Lpl/mk/premiumsmart/tv/PlayerActivity;Z)V

    return-void
.end method

.method private synthetic lambda$onPlayerError$1(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 110
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgetplayer(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object p1

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->prepare()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgetplayer(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object p1

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->play()V

    return-void
.end method


# virtual methods
.method public onPlaybackStateChanged(I)V
    .locals 2

    .line 99
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgetbuffering(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroid/widget/TextView;

    move-result-object v0

    const/4 v1, 0x2

    if-ne p1, v1, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/16 v1, 0x8

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    const/4 v0, 0x4

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fputended(Lpl/mk/premiumsmart/tv/PlayerActivity;Z)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$msave(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgetentry(Lpl/mk/premiumsmart/tv/PlayerActivity;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "episode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    invoke-static {p1, v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$mleave(Lpl/mk/premiumsmart/tv/PlayerActivity;Z)V

    :cond_1
    return-void
.end method

.method public onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .locals 3

    .line 101
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 102
    :cond_0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgetbuffering(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 103
    invoke-virtual {p1}, Landroidx/media3/common/PlaybackException;->getErrorCodeName()Ljava/lang/String;

    move-result-object v0

    move-object v1, p1

    :goto_0
    if-eqz v1, :cond_2

    .line 104
    instance-of v2, v1, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz v2, :cond_1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u00b7 HTTP "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object v2, v1

    check-cast v2, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v2, v2, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    goto :goto_0

    :cond_2
    :goto_1
    if-eqz p1, :cond_6

    .line 106
    instance-of v1, p1, Ljava/net/UnknownHostException;

    if-eqz v1, :cond_3

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\nDNS: nie znaleziono serwera \u017ar\u00f3d\u0142a."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    .line 107
    :cond_3
    instance-of v1, p1, Ljavax/net/ssl/SSLException;

    if-eqz v1, :cond_4

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\nTLS: b\u0142\u0105d zabezpieczonego po\u0142\u0105czenia ze \u017ar\u00f3d\u0142em."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    .line 108
    :cond_4
    instance-of v1, p1, Ljava/net/SocketTimeoutException;

    if-eqz v1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\nSerwer \u017ar\u00f3d\u0142a nie odpowiedzia\u0142 w terminie."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    .line 105
    :cond_5
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    goto :goto_1

    .line 110
    :cond_6
    :goto_2
    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-direct {p1, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "B\u0142\u0105d odtwarzania"

    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Strumie\u0144 nie mo\u017ce by\u0107 odtworzony. Mo\u017cesz wr\u00f3ci\u0107 i wybra\u0107 inne \u017ar\u00f3d\u0142o.\n"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity$3;)V

    const-string v1, "Wr\u00f3\u0107"

    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda1;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity$3;)V

    const-string v1, "Pon\u00f3w"

    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method
