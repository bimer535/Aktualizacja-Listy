.class public Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;
.super Landroid/app/Activity;
.source "CompatibilityPlayerActivity.java"


# instance fields
.field private buttons:Landroid/widget/LinearLayout;

.field private centerDown:Z

.field private controller:Landroid/widget/MediaController;

.field private ended:Z

.field private entry:Lorg/json/JSONObject;

.field private final hideButtons:Ljava/lang/Runnable;

.field private lastDuration:J

.field private lastPosition:J

.field private leaving:Z

.field private media:Landroid/media/MediaPlayer;

.field private prepared:Z

.field private final saveTick:Ljava/lang/Runnable;

.field private status:Landroid/widget/TextView;

.field private stream:Lorg/json/JSONObject;

.field private final timer:Landroid/os/Handler;

.field private video:Landroid/widget/VideoView;


# direct methods
.method public static synthetic $r8$lambda$4K_A83c5RjS3TcsdKVtPqXWd67I(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;II)Z
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$4(Landroid/media/MediaPlayer;II)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$4YziBCpr0g3kZ0WyLmRGob2pgD0(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$Arji-0oPFENokNHlY378sKSAVjA(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$D3roZJtVej4oPW0JVv0yyFYC6UM(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->information()V

    return-void
.end method

.method public static synthetic $r8$lambda$Mk09kMXMR0uNtWuhyrwid7uuD2o(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Ljava/util/List;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$tracks$10(Ljava/util/List;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$OgRv1HJGDsUB3GuNY8RKAoWcqyI(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;II)Z
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$8(Landroid/media/MediaPlayer;II)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$PcORSMwe2cpOh1B3V48WdANRLgU(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->tracks()V

    return-void
.end method

.method public static synthetic $r8$lambda$S69gtwhWU7gWUaV050nZRC0Af8g(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$6(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$T-gLDTvO7mqk8DtHjYWakLQxCt8(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->switchPlayer()V

    return-void
.end method

.method public static synthetic $r8$lambda$bvdLF2QsWoHyUn_BrvaJ7T8iP2U(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$7(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$i92rHMs2ukzoG3LygFRq1xTtdgM(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$5(Landroid/media/MediaPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qtWS3VJVfnJMWnYBvRHNPVxkF-c(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$new$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$z2UKOpY4XGhBIQIc0MA8utpqSXg(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lambda$onCreate$3(Landroid/media/MediaPlayer;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgettimer(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$msave(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 26
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 35
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    .line 36
    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->saveTick:Ljava/lang/Runnable;

    .line 37
    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda3;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->hideButtons:Ljava/lang/Runnable;

    return-void
.end method

.method private button(Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 1

    .line 75
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance p1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda4;

    invoke-direct {p1, p2}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda4;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private information()V
    .locals 3

    .line 78
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Odtwarzacz: Android MediaPlayer\n\u0179r\u00f3d\u0142o: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v2, "provider"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 79
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_0

    iget-boolean v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Obraz: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getVideoWidth()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u00d7 "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getVideoHeight()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nPozycja: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastPosition:J

    invoke-static {v1, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->stamp(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nPr\u0119dko\u015b\u0107: 1,0\u00d7"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 80
    :cond_0
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "Informacje o odtwarzaniu"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "OK"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method static synthetic lambda$button$9(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 75
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private synthetic lambda$new$0()V
    .locals 2

    .line 37
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/VideoView;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$onCreate$1()V
    .locals 1

    const/4 v0, 0x0

    .line 51
    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$2()V
    .locals 1

    const/4 v0, 0x1

    .line 52
    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$3(Landroid/media/MediaPlayer;)V
    .locals 5

    .line 54
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    .line 55
    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setVideoScalingMode(I)V

    .line 56
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "position"

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    cmp-long v2, v0, v2

    if-lez v2, :cond_1

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    const-wide/16 v3, 0x3e8

    mul-long/2addr v0, v3

    const-wide/32 v3, 0x7fffffff

    invoke-static {v3, v4, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int v0, v0

    invoke-virtual {v2, v0}, Landroid/widget/VideoView;->seekTo(I)V

    .line 57
    :cond_1
    :try_start_0
    new-instance v0, Landroid/media/PlaybackParams;

    invoke-direct {v0}, Landroid/media/PlaybackParams;-><init>()V

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroid/media/PlaybackParams;->setSpeed(F)Landroid/media/PlaybackParams;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setPlaybackParams(Landroid/media/PlaybackParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 58
    :catch_0
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->start()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->requestFocus()Z

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->showButtons()V

    return-void
.end method

.method private synthetic lambda$onCreate$4(Landroid/media/MediaPlayer;II)Z
    .locals 1

    const/16 p1, 0x2bd

    const/4 p3, 0x0

    if-ne p2, p1, :cond_0

    .line 61
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const-string v0, "Buforowanie\u2026"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_0
    const/16 p1, 0x2be

    if-eq p2, p1, :cond_1

    const/4 p1, 0x3

    if-ne p2, p1, :cond_2

    .line 62
    :cond_1
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/16 p2, 0x8

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_2
    return p3
.end method

.method private synthetic lambda$onCreate$5(Landroid/media/MediaPlayer;)V
    .locals 1

    const/4 p1, 0x1

    .line 65
    iput-boolean p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->ended:Z

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v0, "episode"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p1

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$6(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 70
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->switchPlayer()V

    return-void
.end method

.method private synthetic lambda$onCreate$7(Landroid/content/DialogInterface;I)V
    .locals 0

    const/4 p1, 0x0

    .line 70
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$8(Landroid/media/MediaPlayer;II)Z
    .locals 2

    const/4 p1, 0x0

    .line 67
    iput-boolean p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 68
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->isFinishing()Z

    move-result p1

    if-nez p1, :cond_0

    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v0, "Odtwarzacz Android"

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Nie uda\u0142o si\u0119 odtworzy\u0107 tego wariantu. Kod: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, " / "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 69
    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda1;

    invoke-direct {p2, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda1;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    .line 70
    const-string p3, "Sprawd\u017a Media3"

    invoke-virtual {p1, p3, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda2;

    invoke-direct {p2, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda2;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string p3, "Wr\u00f3\u0107"

    invoke-virtual {p1, p3, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    :cond_0
    const/4 p1, 0x1

    return p1
.end method

.method private synthetic lambda$tracks$10(Ljava/util/List;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 92
    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    if-gez p2, :cond_0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->switchPlayer()V

    return-void

    :cond_0
    :try_start_0
    iget-object p2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {p2, p1}, Landroid/media/MediaPlayer;->selectTrack(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method private leave(Z)V
    .locals 3

    .line 105
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leaving:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leaving:Z

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "entry"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "next"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p1

    const/4 v0, -0x1

    invoke-virtual {p0, v0, p1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->setResult(ILandroid/content/Intent;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->finish()V

    return-void
.end method

.method private save()V
    .locals 14

    .line 101
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/VideoView;->getCurrentPosition()I

    move-result v0

    div-int/lit16 v0, v0, 0x3e8

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-long v2, v0

    iput-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastPosition:J

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {v0}, Landroid/widget/VideoView;->getDuration()I

    move-result v0

    div-int/lit16 v0, v0, 0x3e8

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-long v2, v0

    iput-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastDuration:J

    .line 102
    :cond_0
    iget-object v7, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    if-eqz v7, :cond_3

    iget-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastPosition:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    iget-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastDuration:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->ended:Z

    if-nez v0, :cond_1

    iget-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastDuration:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-lez v0, :cond_2

    iget-wide v4, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastPosition:J

    long-to-double v4, v4

    long-to-double v2, v2

    const-wide v12, 0x3fee666666666666L    # 0.95

    mul-double/2addr v2, v12

    cmpl-double v0, v4, v2

    if-ltz v0, :cond_2

    :cond_1
    const/4 v1, 0x1

    :cond_2
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    const-string v4, "op"

    const-string v5, "record"

    const-string v6, "item"

    const-string v8, "position"

    const-string v10, "duration"

    const-string v12, "completed"

    filled-new-array/range {v4 .. v13}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lpl/mk/premiumsmart/tv/AppRuntime;->submit(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    :cond_3
    return-void
.end method

.method private showButtons()V
    .locals 4

    .line 76
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->hideButtons:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->hideButtons:Ljava/lang/Runnable;

    const-wide/16 v2, 0xfa0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private switchPlayer()V
    .locals 4

    .line 96
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leaving:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leaving:Z

    .line 97
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const-class v1, Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "position"

    iget-wide v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->lastPosition:J

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x2000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 98
    invoke-virtual {p0, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->finish()V

    return-void
.end method

.method private tracks()V
    .locals 9

    .line 83
    const-string v0, "subtitles"

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->media:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_7

    iget-boolean v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    if-nez v2, :cond_0

    goto/16 :goto_2

    .line 85
    :cond_0
    :try_start_0
    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getTrackInfo()[Landroid/media/MediaPlayer$TrackInfo;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    move v5, v4

    .line 86
    :goto_0
    array-length v6, v1

    if-ge v5, v6, :cond_4

    .line 87
    aget-object v6, v1, v5

    invoke-virtual {v6}, Landroid/media/MediaPlayer$TrackInfo;->getTrackType()I

    move-result v6

    const/4 v7, 0x2

    if-eq v6, v7, :cond_1

    const/4 v8, 0x3

    if-eq v6, v8, :cond_1

    const/4 v8, 0x4

    if-ne v6, v8, :cond_3

    .line 88
    :cond_1
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v2, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    if-ne v6, v7, :cond_2

    const-string v6, "Audio: "

    goto :goto_1

    :cond_2
    const-string v6, "Napisy: "

    :goto_1
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    aget-object v7, v1, v5

    invoke-virtual {v7}, Landroid/media/MediaPlayer$TrackInfo;->getLanguage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 90
    :cond_4
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->stream:Lorg/json/JSONObject;

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    if-eqz v1, :cond_5

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->stream:Lorg/json/JSONObject;

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-lez v0, :cond_5

    const/4 v0, -0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v0, "Napisy zewn\u0119trzne \u2014 otw\u00f3rz Media3"

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 91
    :cond_5
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "Brak dodatkowych \u015bcie\u017cek w tym wariancie."

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "OK"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 92
    :cond_6
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v5, "\u015acie\u017cki filmu"

    invoke-virtual {v0, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-array v4, v4, [Ljava/lang/String;

    invoke-interface {v3, v4}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/CharSequence;

    new-instance v4, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;

    invoke-direct {v4, p0, v2}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Ljava/util/List;)V

    invoke-virtual {v0, v3, v4}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "Wr\u00f3\u0107"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_7
    :goto_2
    return-void
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4

    .line 108
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    .line 109
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    const/16 v2, 0x17

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/widget/VideoView;->hasFocus()Z

    move-result v1

    if-eqz v1, :cond_0

    if-ne v0, v2, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    if-nez v1, :cond_0

    iput-boolean v3, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->centerDown:Z

    return v3

    .line 110
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    if-ne v1, v3, :cond_9

    const/4 v1, 0x0

    if-ne v0, v2, :cond_1

    .line 111
    iget-boolean v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->centerDown:Z

    if-nez v2, :cond_2

    :cond_1
    const/16 v2, 0x55

    if-ne v0, v2, :cond_5

    :cond_2
    iput-boolean v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->centerDown:Z

    iget-boolean p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    if-eqz p1, :cond_4

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->pause()V

    goto :goto_0

    :cond_3
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->start()V

    :goto_0
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->controller:Landroid/widget/MediaController;

    const/16 v0, 0xbb8

    invoke-virtual {p1, v0}, Landroid/widget/MediaController;->show(I)V

    :cond_4
    return v3

    :cond_5
    const/16 v2, 0x56

    if-ne v0, v2, :cond_6

    .line 112
    invoke-direct {p0, v1}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return v3

    :cond_6
    const/16 v2, 0x52

    if-eq v0, v2, :cond_8

    const/16 v2, 0xa5

    if-ne v0, v2, :cond_7

    goto :goto_1

    :cond_7
    const/16 v1, 0xba

    if-ne v0, v1, :cond_9

    .line 114
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v1, "episode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-direct {p0, v3}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return v3

    .line 113
    :cond_8
    :goto_1
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->showButtons()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    return v3

    .line 116
    :cond_9
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public onBackPressed()V
    .locals 1

    const/4 v0, 0x0

    .line 118
    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->leave(Z)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 6

    .line 40
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 41
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x1706

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 42
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "entry"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "stream"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->stream:Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    const-string v0, "url"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 45
    const-string v0, "https"

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    goto/16 :goto_0

    .line 46
    :cond_0
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/high16 v1, -0x1000000

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    invoke-virtual {p0, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->setContentView(Landroid/view/View;)V

    .line 47
    new-instance v1, Landroid/widget/VideoView;

    invoke-direct {v1, p0}, Landroid/widget/VideoView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    const/16 v4, 0x11

    invoke-direct {v2, v3, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 48
    new-instance v1, Landroid/widget/MediaController;

    invoke-direct {v1, p0}, Landroid/widget/MediaController;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->controller:Landroid/widget/MediaController;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {v1, v2}, Landroid/widget/MediaController;->setAnchorView(Landroid/view/View;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->controller:Landroid/widget/MediaController;

    invoke-virtual {v1, v2}, Landroid/widget/VideoView;->setMediaController(Landroid/widget/MediaController;)V

    .line 49
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const-string v2, "Uruchamianie odtwarzacza Android\u2026"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/16 v2, 0x18

    const/16 v3, 0x10

    invoke-virtual {v1, v2, v3, v2, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    const/high16 v2, -0x50000000

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->status:Landroid/widget/TextView;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v2, v5, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 50
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    const/16 v2, 0xc

    invoke-virtual {v1, v3, v2, v3, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->buttons:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const v3, 0x800035

    invoke-direct {v2, v5, v5, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 51
    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string v1, "Wr\u00f3\u0107"

    invoke-direct {p0, v1, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda5;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string v1, "Audio / napisy"

    invoke-direct {p0, v1, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda6;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string v1, "Media3"

    invoke-direct {p0, v1, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda7;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda7;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string v1, "Informacje"

    invoke-direct {p0, v1, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 52
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v1, "episode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda8;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    const-string v1, "Nast\u0119pny odcinek"

    invoke-direct {p0, v1, v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->button(Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 53
    :cond_1
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    new-instance v1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda9;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 60
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    new-instance v1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda10;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda10;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    .line 65
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    new-instance v1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda11;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 66
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    new-instance v1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda12;-><init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 73
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->stream:Lorg/json/JSONObject;

    invoke-static {v1}, Lpl/mk/premiumsmart/tv/NativeSource;->platformHeaders(Lorg/json/JSONObject;)Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Landroid/widget/VideoView;->setVideoURI(Landroid/net/Uri;Ljava/util/Map;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    invoke-virtual {p1}, Landroid/widget/VideoView;->requestFocus()Z

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->saveTick:Ljava/lang/Runnable;

    const-wide/16 v1, 0x1388

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 45
    :cond_2
    :goto_0
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->finish()V

    return-void

    .line 43
    :catch_0
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->finish()V

    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 120
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->timer:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/VideoView;->stopPlayback()V

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 119
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->save()V

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->prepared:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->video:Landroid/widget/VideoView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/VideoView;->pause()V

    :cond_0
    return-void
.end method
