.class public final Lpl/mk/premiumsmart/tv/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lpl/mk/premiumsmart/tv/R$drawable;,
        Lpl/mk/premiumsmart/tv/R$style;,
        Lpl/mk/premiumsmart/tv/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
