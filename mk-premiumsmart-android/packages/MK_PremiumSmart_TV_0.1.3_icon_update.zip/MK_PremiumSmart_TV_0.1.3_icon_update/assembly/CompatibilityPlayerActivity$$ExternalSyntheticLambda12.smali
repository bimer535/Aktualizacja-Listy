.class public final synthetic Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda12;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda12;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-static {v0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->$r8$lambda$OgRv1HJGDsUB3GuNY8RKAoWcqyI(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Landroid/media/MediaPlayer;II)Z

    move-result p1

    return p1
.end method
