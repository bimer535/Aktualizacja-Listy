.class public final synthetic Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/content/Context;

.field public final synthetic f$1:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;->f$0:Landroid/content/Context;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;->f$1:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;->f$0:Landroid/content/Context;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;->f$1:Lpl/mk/premiumsmart/tv/AppRuntime$Callback;

    invoke-static {v0, v1}, Lpl/mk/premiumsmart/tv/AppRuntime;->lambda$init$1(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    return-void
.end method
