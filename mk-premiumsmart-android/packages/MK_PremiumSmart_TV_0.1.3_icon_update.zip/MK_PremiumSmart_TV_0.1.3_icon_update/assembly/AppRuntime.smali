.class final Lpl/mk/premiumsmart/tv/AppRuntime;
.super Ljava/lang/Object;
.source "AppRuntime.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lpl/mk/premiumsmart/tv/AppRuntime$Callback;
    }
.end annotation


# static fields
.field private static engine:Lcom/chaquo/python/PyObject;

.field private static final jobs:Ljava/util/concurrent/ExecutorService;

.field private static final main:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 15
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lpl/mk/premiumsmart/tv/AppRuntime;->jobs:Ljava/util/concurrent/ExecutorService;

    .line 16
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lpl/mk/premiumsmart/tv/AppRuntime;->main:Landroid/os/Handler;

    return-void
.end method

.method constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static copy(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 1

    .line 25
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    return-object p0
.end method

.method private static failure()Lorg/json/JSONObject;
    .locals 4

    const/4 v0, 0x0

    .line 47
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const-string v1, "message"

    const-string v2, "B\u0142\u0105d silnika aplikacji. Uruchom j\u0105 ponownie lub zg\u0142o\u015b problem: bimer55@wp.pl."

    const-string v3, "ok"

    filled-new-array {v3, v0, v1, v2}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method

.method static init(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 2

    .line 28
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    .line 29
    sget-object v0, Lpl/mk/premiumsmart/tv/AppRuntime;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1}, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda1;-><init>(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic lambda$init$0(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V
    .locals 0

    .line 36
    invoke-interface {p0, p1}, Lpl/mk/premiumsmart/tv/AppRuntime$Callback;->done(Lorg/json/JSONObject;)V

    return-void
.end method

.method static synthetic lambda$init$1(Landroid/content/Context;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 4

    .line 32
    :try_start_0
    invoke-static {}, Lcom/chaquo/python/Python;->isStarted()Z

    move-result v0

    if-nez v0, :cond_0

    new-instance v0, Lcom/chaquo/python/android/AndroidPlatform;

    invoke-direct {v0, p0}, Lcom/chaquo/python/android/AndroidPlatform;-><init>(Landroid/content/Context;)V

    invoke-static {v0}, Lcom/chaquo/python/Python;->start(Lcom/chaquo/python/Python$Platform;)V

    .line 33
    :cond_0
    invoke-static {}, Lcom/chaquo/python/Python;->getInstance()Lcom/chaquo/python/Python;

    move-result-object v0

    const-string v1, "engine"

    invoke-virtual {v0, v1}, Lcom/chaquo/python/Python;->getModule(Ljava/lang/String;)Lcom/chaquo/python/PyObject;

    move-result-object v0

    sput-object v0, Lpl/mk/premiumsmart/tv/AppRuntime;->engine:Lcom/chaquo/python/PyObject;

    .line 34
    new-instance v0, Lorg/json/JSONObject;

    sget-object v1, Lpl/mk/premiumsmart/tv/AppRuntime;->engine:Lcom/chaquo/python/PyObject;

    const-string v2, "init"

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    filled-new-array {v3, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v1, v2, p0}, Lcom/chaquo/python/PyObject;->callAttr(Ljava/lang/String;[Ljava/lang/Object;)Lcom/chaquo/python/PyObject;

    move-result-object p0

    invoke-virtual {p0}, Lcom/chaquo/python/PyObject;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 35
    :catch_0
    invoke-static {}, Lpl/mk/premiumsmart/tv/AppRuntime;->failure()Lorg/json/JSONObject;

    move-result-object v0

    .line 36
    :goto_0
    sget-object p0, Lpl/mk/premiumsmart/tv/AppRuntime;->main:Landroid/os/Handler;

    new-instance v1, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1, v0}, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V

    invoke-virtual {p0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic lambda$submit$2(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V
    .locals 0

    .line 44
    invoke-interface {p0, p1}, Lpl/mk/premiumsmart/tv/AppRuntime$Callback;->done(Lorg/json/JSONObject;)V

    return-void
.end method

.method static synthetic lambda$submit$3(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 3

    .line 42
    :try_start_0
    invoke-static {}, Lpl/mk/premiumsmart/tv/Pow;->reset()V

    new-instance v0, Lorg/json/JSONObject;

    sget-object v1, Lpl/mk/premiumsmart/tv/AppRuntime;->engine:Lcom/chaquo/python/PyObject;

    const-string v2, "request"

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v1, v2, p0}, Lcom/chaquo/python/PyObject;->callAttr(Ljava/lang/String;[Ljava/lang/Object;)Lcom/chaquo/python/PyObject;

    move-result-object p0

    invoke-virtual {p0}, Lcom/chaquo/python/PyObject;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 43
    :catch_0
    invoke-static {}, Lpl/mk/premiumsmart/tv/AppRuntime;->failure()Lorg/json/JSONObject;

    move-result-object v0

    :goto_0
    if-eqz p1, :cond_0

    .line 44
    sget-object p0, Lpl/mk/premiumsmart/tv/AppRuntime;->main:Landroid/os/Handler;

    new-instance v1, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;

    invoke-direct {v1, p1, v0}, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda2;-><init>(Lpl/mk/premiumsmart/tv/AppRuntime$Callback;Lorg/json/JSONObject;)V

    invoke-virtual {p0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method

.method static varargs object([Ljava/lang/Object;)Lorg/json/JSONObject;
    .locals 4

    .line 19
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v1, 0x0

    .line 20
    :goto_0
    :try_start_0
    array-length v2, p0

    if-ge v1, v2, :cond_0

    aget-object v2, p0, v1

    check-cast v2, Ljava/lang/String;

    add-int/lit8 v3, v1, 0x1

    aget-object v3, p0, v3

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v1, v1, 0x2

    goto :goto_0

    :cond_0
    return-object v0

    .line 21
    :catch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid request"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static submit(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V
    .locals 2

    .line 40
    sget-object v0, Lpl/mk/premiumsmart/tv/AppRuntime;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1}, Lpl/mk/premiumsmart/tv/AppRuntime$$ExternalSyntheticLambda3;-><init>(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
