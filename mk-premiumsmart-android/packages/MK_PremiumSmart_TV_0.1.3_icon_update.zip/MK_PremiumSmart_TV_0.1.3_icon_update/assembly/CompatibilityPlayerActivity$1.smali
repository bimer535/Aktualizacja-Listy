.class Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;
.super Ljava/lang/Object;
.source "CompatibilityPlayerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;


# direct methods
.method constructor <init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V
    .locals 0

    .line 36
    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 36
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->-$$Nest$msave(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->-$$Nest$fgettimer(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x1388

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
