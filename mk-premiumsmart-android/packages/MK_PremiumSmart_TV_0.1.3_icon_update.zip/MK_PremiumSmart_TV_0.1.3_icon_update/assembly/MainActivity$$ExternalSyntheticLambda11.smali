.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;

.field public final synthetic f$1:Lorg/json/JSONObject;

.field public final synthetic f$2:Lorg/json/JSONObject;

.field public final synthetic f$3:J


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$1:Lorg/json/JSONObject;

    iput-object p3, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$2:Lorg/json/JSONObject;

    iput-wide p4, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$3:J

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 7

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$1:Lorg/json/JSONObject;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$2:Lorg/json/JSONObject;

    iget-wide v3, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda11;->f$3:J

    move-object v5, p1

    move v6, p2

    invoke-static/range {v0 .. v6}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$-rDpHR2vEWam8Y8oCY2S8yVxio0(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;JLandroid/content/DialogInterface;I)V

    return-void
.end method
