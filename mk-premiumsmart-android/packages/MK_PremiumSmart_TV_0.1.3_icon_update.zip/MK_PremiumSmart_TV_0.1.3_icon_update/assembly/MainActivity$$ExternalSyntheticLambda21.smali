.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lpl/mk/premiumsmart/tv/AppRuntime$Callback;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final done(Lorg/json/JSONObject;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda21;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1, p1}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$3jZPGE-9AoMK104IxADeuEbl_6Y(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    return-void
.end method
