.class public final synthetic Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/PlayerActivity$3;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/PlayerActivity$3;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda1;->f$0:Lpl/mk/premiumsmart/tv/PlayerActivity$3;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$3$$ExternalSyntheticLambda1;->f$0:Lpl/mk/premiumsmart/tv/PlayerActivity$3;

    invoke-static {v0, p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity$3;->$r8$lambda$GL2SYPk_Lcpg2gV_LdNkfdILmEU(Lpl/mk/premiumsmart/tv/PlayerActivity$3;Landroid/content/DialogInterface;I)V

    return-void
.end method
