.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;ILorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iput p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$1:I

    iput-object p3, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$2:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 3

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iget v1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$1:I

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda12;->f$2:Lorg/json/JSONObject;

    invoke-static {v0, v1, v2, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$NdEnl1k9WpwiYYHDMkd63t8Cyj8(Lpl/mk/premiumsmart/tv/MainActivity;ILorg/json/JSONObject;Landroid/view/View;Z)V

    return-void
.end method
