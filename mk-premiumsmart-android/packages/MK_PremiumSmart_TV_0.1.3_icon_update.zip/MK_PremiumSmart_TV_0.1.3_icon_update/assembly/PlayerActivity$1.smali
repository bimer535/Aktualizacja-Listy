.class Lpl/mk/premiumsmart/tv/PlayerActivity$1;
.super Ljava/lang/Object;
.source "PlayerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/premiumsmart/tv/PlayerActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;


# direct methods
.method constructor <init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V
    .locals 0

    .line 49
    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 49
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$msave(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$1;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fgettimer(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x1388

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
