.class public final synthetic Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/MainActivity;

.field public final synthetic f$1:Lorg/json/JSONObject;

.field public final synthetic f$2:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$1:Lorg/json/JSONObject;

    iput-object p3, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$2:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$0:Lpl/mk/premiumsmart/tv/MainActivity;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$1:Lorg/json/JSONObject;

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/MainActivity$$ExternalSyntheticLambda17;->f$2:Lorg/json/JSONObject;

    invoke-static {v0, v1, v2, p1, p2}, Lpl/mk/premiumsmart/tv/MainActivity;->$r8$lambda$8tl-pyrqOWj1F7G7aaxkAc5Hdj8(Lpl/mk/premiumsmart/tv/MainActivity;Lorg/json/JSONObject;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method
