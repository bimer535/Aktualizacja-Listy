.class public final synthetic Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/Updater;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/Updater;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda3;->f$0:Lpl/mk/premiumsmart/tv/Updater;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda3;->f$0:Lpl/mk/premiumsmart/tv/Updater;

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/Updater;->$r8$lambda$bKiZ6KwxwT6JqfVY8PPYwo0TBtI(Lpl/mk/premiumsmart/tv/Updater;)V

    return-void
.end method
