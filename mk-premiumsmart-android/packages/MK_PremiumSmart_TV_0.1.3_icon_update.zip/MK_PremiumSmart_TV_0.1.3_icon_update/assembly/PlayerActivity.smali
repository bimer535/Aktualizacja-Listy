.class public Lpl/mk/premiumsmart/tv/PlayerActivity;
.super Landroid/app/Activity;
.source "PlayerActivity.java"


# instance fields
.field private buffering:Landroid/widget/TextView;

.field private centerToggles:Z

.field private ended:Z

.field private entry:Lorg/json/JSONObject;

.field private lastDuration:J

.field private lastPosition:J

.field private leaving:Z

.field private player:Landroidx/media3/exoplayer/ExoPlayer;

.field private final saveTick:Ljava/lang/Runnable;

.field private final timer:Landroid/os/Handler;

.field private videoDecoder:Ljava/lang/String;

.field private view:Landroidx/media3/ui/PlayerView;


# direct methods
.method public static synthetic $r8$lambda$4qwSDA1RDb7WCd5khQviK2m-fAk(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$onCreate$3(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$AtOkSj9_TcSVxjmuW3NxwL1vXbM(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$tracks$6(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$Dt_IE_QFJYg8qlGsiVMQYpQ7VYE(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$onCreate$1(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$XCiKCacThXAamXXlWVsXuacUJfc(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$onCreate$4(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$m0x5X_kdPLczqYBrBQ3nXwdirIs(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$onCreate$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$y-AZCU0Qr_95L5JdV_yOzG3jC-0(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->lambda$onCreate$2(Landroid/view/View;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetbuffering(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetentry(Lpl/mk/premiumsmart/tv/PlayerActivity;)Lorg/json/JSONObject;
    .locals 0

    iget-object p0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetplayer(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroidx/media3/exoplayer/ExoPlayer;
    .locals 0

    iget-object p0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettimer(Lpl/mk/premiumsmart/tv/PlayerActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->timer:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputended(Lpl/mk/premiumsmart/tv/PlayerActivity;Z)V
    .locals 0

    iput-boolean p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->ended:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputvideoDecoder(Lpl/mk/premiumsmart/tv/PlayerActivity;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->videoDecoder:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$mleave(Lpl/mk/premiumsmart/tv/PlayerActivity;Z)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msave(Lpl/mk/premiumsmart/tv/PlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->save()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 40
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 45
    const-string v0, "oczekiwanie"

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->videoDecoder:Ljava/lang/String;

    .line 46
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->timer:Landroid/os/Handler;

    .line 49
    new-instance v0, Lpl/mk/premiumsmart/tv/PlayerActivity$1;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$1;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    iput-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->saveTick:Ljava/lang/Runnable;

    return-void
.end method

.method private information()V
    .locals 5

    .line 121
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Odtwarzacz: Media3\n\u0179r\u00f3d\u0142o: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v2, "provider"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nDekoder: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->videoDecoder:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 122
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getVideoFormat()Landroidx/media3/common/Format;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 123
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\nObraz: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, v1, Landroidx/media3/common/Format;->width:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u00d7 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, v1, Landroidx/media3/common/Format;->height:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u00b7 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, v1, Landroidx/media3/common/Format;->frameRate:F

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " kl./s\nKodek: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, v1, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 124
    :cond_0
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getVideoDecoderCounters()Landroidx/media3/exoplayer/DecoderCounters;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 125
    invoke-virtual {v1}, Landroidx/media3/exoplayer/DecoderCounters;->ensureUpdated()V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\nWy\u015bwietlone klatki: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, v1, Landroidx/media3/exoplayer/DecoderCounters;->renderedOutputBufferCount:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\nPomini\u0119te klatki: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, v1, Landroidx/media3/exoplayer/DecoderCounters;->droppedBufferCount:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 126
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nBufor: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getTotalBufferedDuration()J

    move-result-wide v1

    const-wide/16 v3, 0x3e8

    div-long/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " s\nPr\u0119dko\u015b\u0107: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getPlaybackParameters()Landroidx/media3/common/PlaybackParameters;

    move-result-object v1

    iget v1, v1, Landroidx/media3/common/PlaybackParameters;->speed:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u00d7"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 127
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "Informacje o odtwarzaniu"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "OK"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private synthetic lambda$onCreate$0(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x0

    .line 61
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/view/View;)V
    .locals 0

    .line 62
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->tracks()V

    return-void
.end method

.method private synthetic lambda$onCreate$2(Landroid/view/View;)V
    .locals 0

    .line 63
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->switchPlayer()V

    return-void
.end method

.method private synthetic lambda$onCreate$3(Landroid/view/View;)V
    .locals 0

    .line 64
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->information()V

    return-void
.end method

.method private synthetic lambda$onCreate$4(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    .line 66
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method static synthetic lambda$onCreate$5(Landroid/widget/LinearLayout;I)V
    .locals 0

    .line 85
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void
.end method

.method private synthetic lambda$tracks$6(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 131
    :try_start_0
    new-instance p1, Landroidx/media3/ui/TrackSelectionDialogBuilder;

    if-nez p2, :cond_0

    const-string v0, "Audio"

    goto :goto_0

    :cond_0
    const-string v0, "Napisy"

    :goto_0
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-nez p2, :cond_1

    const/4 p2, 0x1

    goto :goto_1

    :cond_1
    const/4 p2, 0x3

    :goto_1
    invoke-direct {p1, p0, v0, v1, p2}, Landroidx/media3/ui/TrackSelectionDialogBuilder;-><init>(Landroid/content/Context;Ljava/lang/CharSequence;Landroidx/media3/common/Player;I)V

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/media3/ui/TrackSelectionDialogBuilder;->setAllowAdaptiveSelections(Z)Landroidx/media3/ui/TrackSelectionDialogBuilder;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/media3/ui/TrackSelectionDialogBuilder;->build()Landroid/app/Dialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 132
    :catch_0
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string p2, "Brak dodatkowych \u015bcie\u017cek w tym \u017ar\u00f3dle."

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "OK"

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private leave(Z)V
    .locals 2

    .line 140
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->leaving:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->leaving:Z

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->save()V

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "next"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "entry"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 p1, -0x1

    invoke-virtual {p0, p1, v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->setResult(ILandroid/content/Intent;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->finish()V

    return-void
.end method

.method private save()V
    .locals 15

    .line 136
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v3

    const-wide/16 v5, 0x3e8

    div-long/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    iput-wide v3, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastPosition:J

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getDuration()J

    move-result-wide v3

    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v0, v3, v7

    if-nez v0, :cond_0

    move-wide v3, v1

    goto :goto_0

    :cond_0
    div-long/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    :goto_0
    iput-wide v3, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastDuration:J

    .line 137
    :cond_1
    iget-object v8, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    if-eqz v8, :cond_4

    iget-wide v3, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastPosition:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    iget-wide v3, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastDuration:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->ended:Z

    if-nez v0, :cond_3

    iget-wide v3, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastDuration:J

    cmp-long v0, v3, v1

    if-lez v0, :cond_2

    iget-wide v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastPosition:J

    long-to-double v0, v0

    long-to-double v2, v3

    const-wide v4, 0x3fee666666666666L    # 0.95

    mul-double/2addr v2, v4

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_2

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v0, 0x1

    :goto_2
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    const-string v5, "op"

    const-string v6, "record"

    const-string v7, "item"

    const-string v9, "position"

    const-string v11, "duration"

    const-string v13, "completed"

    filled-new-array/range {v5 .. v14}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/premiumsmart/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lpl/mk/premiumsmart/tv/AppRuntime;->submit(Lorg/json/JSONObject;Lpl/mk/premiumsmart/tv/AppRuntime$Callback;)V

    :cond_4
    return-void
.end method

.method private switchPlayer()V
    .locals 4

    .line 116
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->leaving:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->save()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->leaving:Z

    .line 117
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const-class v1, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "position"

    iget-wide v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->lastPosition:J

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x2000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 118
    invoke-virtual {p0, v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->finish()V

    return-void
.end method

.method private tracks()V
    .locals 4

    .line 130
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u015acie\u017cki filmu"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "Audio"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "Napisy"

    aput-object v3, v1, v2

    new-instance v2, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 133
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 6

    .line 143
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    const/16 v1, 0x17

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    if-ne v0, v1, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    move-result v0

    if-nez v0, :cond_0

    .line 144
    iput-boolean v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->centerToggles:Z

    return v2

    .line 146
    :cond_0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_8

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-ne v0, v2, :cond_8

    .line 147
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v3, 0x55

    const/4 v4, 0x0

    if-eq v0, v3, :cond_6

    if-ne v0, v1, :cond_1

    .line 148
    iget-boolean v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->centerToggles:Z

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    const/16 v1, 0x56

    if-ne v0, v1, :cond_2

    .line 149
    invoke-direct {p0, v4}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return v2

    :cond_2
    const/16 v1, 0xba

    if-ne v0, v1, :cond_3

    .line 150
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v3, "episode"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-direct {p0, v2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return v2

    .line 151
    :cond_3
    iget-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v1}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    move-result v1

    if-nez v1, :cond_8

    const/16 v1, 0x15

    const/16 v3, 0x16

    if-eq v0, v1, :cond_4

    if-ne v0, v3, :cond_8

    .line 152
    :cond_4
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v4

    if-ne v0, v3, :cond_5

    const/16 v0, 0x3a98

    goto :goto_0

    :cond_5
    const/16 v0, -0x3a98

    :goto_0
    int-to-long v0, v0

    add-long/2addr v4, v0

    const-wide/16 v0, 0x0

    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    invoke-interface {p1, v0, v1}, Landroidx/media3/exoplayer/ExoPlayer;->seekTo(J)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->showController()V

    return v2

    .line 148
    :cond_6
    :goto_1
    iput-boolean v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->centerToggles:Z

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_7

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->pause()V

    goto :goto_2

    :cond_7
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->play()V

    :goto_2
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->showController()V

    return v2

    .line 155
    :cond_8
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public onBackPressed()V
    .locals 1

    const/4 v0, 0x0

    .line 157
    invoke-direct {p0, v0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 13

    .line 51
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x1706

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 52
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "entry"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 54
    :try_start_1
    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "stream"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 55
    const-string v0, "url"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 56
    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v2

    const-string v3, "https"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a

    invoke-virtual {v1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_a

    invoke-virtual {v1}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    goto/16 :goto_4

    .line 57
    :cond_0
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    new-instance v4, Landroidx/media3/ui/PlayerView;

    invoke-direct {v4, p0}, Landroidx/media3/ui/PlayerView;-><init>(Landroid/content/Context;)V

    iput-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0, v2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->setContentView(Landroid/view/View;)V

    .line 58
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const-string v5, "Buforowanie\u2026"

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/high16 v5, 0x41b00000    # 22.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/high16 v5, -0x50000000

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/16 v5, 0x18

    const/16 v6, 0x10

    invoke-virtual {v4, v5, v6, v5, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v7, 0x11

    const/4 v8, -0x2

    invoke-direct {v5, v8, v8, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 59
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v5, 0xc

    invoke-virtual {v4, v6, v5, v6, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 60
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const v6, 0x800035

    invoke-direct {v5, v8, v8, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 61
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Wr\u00f3\u0107"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda1;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda1;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 62
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Audio / napisy"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda2;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda2;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 63
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Odtwarzacz Android"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda3;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda3;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 64
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Informacje"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda4;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda4;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 65
    iget-object v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v5, "episode"

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 66
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Nast\u0119pny odcinek"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda5;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda5;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 68
    :cond_1
    new-instance v2, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;

    invoke-direct {v2, p0}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;-><init>(Landroid/content/Context;)V

    .line 69
    invoke-virtual {v2}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->buildUponParameters()Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v5

    .line 70
    const-string v6, "language"

    const-string v7, "pl"

    invoke-virtual {p1, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setPreferredAudioLanguage(Ljava/lang/String;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v5

    invoke-virtual {v5, v7}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v5

    const-string v7, "adaptive"

    const/4 v8, 0x1

    .line 71
    invoke-virtual {p1, v7, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v7

    xor-int/2addr v7, v8

    invoke-virtual {v5, v7}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setForceHighestSupportedBitrate(Z)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v5

    const/4 v7, 0x0

    .line 72
    invoke-virtual {v5, v7}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setExceedVideoConstraintsIfNecessary(Z)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v5

    .line 73
    const-string v9, "width"

    invoke-virtual {p1, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    const-string v10, "height"

    invoke-virtual {p1, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v10

    if-lez v10, :cond_3

    if-lez v9, :cond_2

    goto :goto_0

    :cond_2
    const v9, 0x7fffffff

    .line 74
    :goto_0
    invoke-virtual {v5, v9, v10}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setMaxVideoSize(II)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    .line 75
    :cond_3
    invoke-virtual {v2, v5}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->setParameters(Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;)V

    .line 76
    new-instance v5, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    invoke-direct {v5}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;-><init>()V

    const v9, 0x15f90

    const/16 v10, 0x1770

    const/16 v11, 0x7530

    const/16 v12, 0xbb8

    .line 77
    invoke-virtual {v5, v11, v9, v12, v10}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBufferDurationsMs(IIII)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    move-result-object v5

    const/high16 v9, 0x4000000

    invoke-virtual {v5, v9}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setTargetBufferBytes(I)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->build()Landroidx/media3/exoplayer/DefaultLoadControl;

    move-result-object v5

    .line 78
    new-instance v9, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    new-instance v10, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    invoke-direct {v10, p0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    invoke-virtual {v10, v8}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setEnableDecoderFallback(Z)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object v8

    invoke-direct {v9, p0, v8}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;Landroidx/media3/exoplayer/RenderersFactory;)V

    .line 79
    invoke-virtual {v9, v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setTrackSelector(Landroidx/media3/exoplayer/trackselection/TrackSelector;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    invoke-virtual {v2, v5}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setLoadControl(Landroidx/media3/exoplayer/LoadControl;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    new-instance v5, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 80
    invoke-static {p1}, Lpl/mk/premiumsmart/tv/NativeSource;->factory(Lorg/json/JSONObject;)Landroidx/media3/datasource/okhttp/OkHttpDataSource$Factory;

    move-result-object v8

    invoke-direct {v5, v8}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    invoke-virtual {v2, v5}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v2

    iput-object v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    .line 81
    iget-object v5, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v5, v2}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    iget-object v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v2, v12}, Landroidx/media3/ui/PlayerView;->setControllerShowTimeoutMs(I)V

    .line 82
    iget-object v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$2;

    invoke-direct {v5, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$2;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-interface {v2, v5}, Landroidx/media3/exoplayer/ExoPlayer;->addAnalyticsListener(Landroidx/media3/exoplayer/analytics/AnalyticsListener;)V

    .line 85
    iget-object v2, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    new-instance v5, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda6;

    invoke-direct {v5, v4}, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda6;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual {v2, v5}, Landroidx/media3/ui/PlayerView;->setControllerVisibilityListener(Landroidx/media3/ui/PlayerView$ControllerVisibilityListener;)V

    .line 86
    new-instance v2, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {v2}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    invoke-virtual {v2, v1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v1

    new-instance v2, Landroidx/media3/common/MediaMetadata$Builder;

    invoke-direct {v2}, Landroidx/media3/common/MediaMetadata$Builder;-><init>()V

    iget-object v4, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v5, "Film"

    const-string v8, "title"

    invoke-virtual {v4, v8, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v9, "movie_title"

    invoke-virtual {v4, v9, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroidx/media3/common/MediaMetadata$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/MediaMetadata$Builder;->build()Landroidx/media3/common/MediaMetadata;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setMediaMetadata(Landroidx/media3/common/MediaMetadata;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v1

    .line 87
    const-string v2, "mime_type"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "application/x-mpegURL"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {v1, v4}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 89
    :cond_4
    :try_start_2
    const-string v2, "subtitles"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    if-nez p1, :cond_5

    .line 90
    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    .line 91
    :cond_5
    :goto_1
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v7, v4, :cond_9

    .line 92
    invoke-virtual {p1, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    .line 93
    invoke-virtual {v5}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    invoke-virtual {v5}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_6

    goto :goto_3

    .line 94
    :cond_6
    new-instance v9, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    invoke-direct {v9, v5}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;-><init>(Landroid/net/Uri;)V

    const-string v5, "format"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v10, "srt"

    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_7

    const-string v5, "application/x-subrip"

    goto :goto_2

    :cond_7
    const-string v5, "text/vtt"

    :goto_2
    invoke-virtual {v9, v5}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v5

    const-string v9, "und"

    invoke-virtual {v4, v6, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLanguage(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v5

    const-string v9, "Napisy"

    invoke-virtual {v4, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLabel(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    :goto_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 96
    :cond_9
    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setSubtitleConfigurations(Ljava/util/List;)Landroidx/media3/common/MediaItem$Builder;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 98
    :catch_0
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    new-instance v0, Lpl/mk/premiumsmart/tv/PlayerActivity$3;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/PlayerActivity$3;-><init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V

    invoke-interface {p1, v0}, Landroidx/media3/exoplayer/ExoPlayer;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 113
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-virtual {v1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object v0

    invoke-interface {p1, v0}, Landroidx/media3/exoplayer/ExoPlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "position"

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const-wide/16 v2, 0x3e8

    mul-long/2addr v0, v2

    invoke-interface {p1, v0, v1}, Landroidx/media3/exoplayer/ExoPlayer;->seekTo(J)V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->prepare()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->play()V

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->requestFocus()Z

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->timer:Landroid/os/Handler;

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->saveTick:Ljava/lang/Runnable;

    const-wide/16 v1, 0x1388

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 56
    :cond_a
    :goto_4
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->finish()V

    return-void

    .line 54
    :catch_1
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->finish()V

    return-void

    .line 52
    :catch_2
    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->finish()V

    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 159
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->timer:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->save()V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    iput-object v1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 158
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/PlayerActivity;->save()V

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->pause()V

    :cond_0
    return-void
.end method
