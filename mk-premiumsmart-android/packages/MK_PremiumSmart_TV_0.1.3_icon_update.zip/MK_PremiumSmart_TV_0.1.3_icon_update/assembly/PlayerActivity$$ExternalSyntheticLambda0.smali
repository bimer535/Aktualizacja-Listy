.class public final synthetic Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/PlayerActivity;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {v0, p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->$r8$lambda$AtOkSj9_TcSVxjmuW3NxwL1vXbM(Lpl/mk/premiumsmart/tv/PlayerActivity;Landroid/content/DialogInterface;I)V

    return-void
.end method
