.class Lpl/mk/premiumsmart/tv/PlayerActivity$2;
.super Ljava/lang/Object;
.source "PlayerActivity.java"

# interfaces
.implements Landroidx/media3/exoplayer/analytics/AnalyticsListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpl/mk/premiumsmart/tv/PlayerActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;


# direct methods
.method constructor <init>(Lpl/mk/premiumsmart/tv/PlayerActivity;)V
    .locals 0

    .line 82
    iput-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$2;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onVideoDecoderInitialized(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;JJ)V
    .locals 0

    .line 83
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/PlayerActivity$2;->this$0:Lpl/mk/premiumsmart/tv/PlayerActivity;

    invoke-static {p1, p2}, Lpl/mk/premiumsmart/tv/PlayerActivity;->-$$Nest$fputvideoDecoder(Lpl/mk/premiumsmart/tv/PlayerActivity;Ljava/lang/String;)V

    return-void
.end method
