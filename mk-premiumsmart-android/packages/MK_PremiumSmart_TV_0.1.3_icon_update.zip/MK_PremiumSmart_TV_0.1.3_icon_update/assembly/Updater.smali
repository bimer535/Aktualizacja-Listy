.class final Lpl/mk/premiumsmart/tv/Updater;
.super Ljava/lang/Object;
.source "Updater.java"


# static fields
.field private static final BASE:Ljava/lang/String; = "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/"

.field private static final jobs:Ljava/util/concurrent/ExecutorService;


# instance fields
.field private final activity:Lpl/mk/premiumsmart/tv/MainActivity;

.field private pending:Ljava/io/File;

.field private running:Z


# direct methods
.method public static synthetic $r8$lambda$CxXjH_06YaMQLDTrYOGC2lulKdg(Lpl/mk/premiumsmart/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/Updater;->lambda$download$4()V

    return-void
.end method

.method public static synthetic $r8$lambda$NCSWwCO5Q_4f3bLOvPtBSgSQeiI(Lpl/mk/premiumsmart/tv/Updater;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/premiumsmart/tv/Updater;->lambda$installPending$7(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$bKiZ6KwxwT6JqfVY8PPYwo0TBtI(Lpl/mk/premiumsmart/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/Updater;->lambda$check$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$cZf63_yUm79rJ5NMo3wKT3kgPLw(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/premiumsmart/tv/Updater;->lambda$check$0(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$dXA32yKtvC_C4T_qBpo2XpDhED8(Lpl/mk/premiumsmart/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/Updater;->lambda$download$5()V

    return-void
.end method

.method public static synthetic $r8$lambda$edkgnSE_c5bfyeqFLFXVglB1jNc(Lpl/mk/premiumsmart/tv/Updater;JLjava/lang/String;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/premiumsmart/tv/Updater;->lambda$check$1(JLjava/lang/String;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static synthetic $r8$lambda$oOGIVBQ8L3MusFVwWtNioXV73lo(Lpl/mk/premiumsmart/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/premiumsmart/tv/Updater;->lambda$check$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$w68vqe0ElNL2iCpNYHArDq4kC7U(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/Updater;->lambda$download$6(Lorg/json/JSONObject;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 26
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lpl/mk/premiumsmart/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method constructor <init>(Lpl/mk/premiumsmart/tv/MainActivity;)V
    .locals 0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    return-void
.end method

.method private download(Lorg/json/JSONObject;)V
    .locals 3

    .line 53
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v2, "Pobieranie aktualizacji\u2026"

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 54
    sget-object v0, Lpl/mk/premiumsmart/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda7;-><init>(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private downloadFile(Lorg/json/JSONObject;Ljava/io/File;)V
    .locals 21
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v0, p1

    .line 65
    const-string v1, "SHA-256"

    const-string v2, "size"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    const-string v5, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/"

    invoke-static {v0, v5}, Lpl/mk/premiumsmart/tv/UpdatePackage;->parts(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/util/List;

    move-result-object v5

    .line 68
    :try_start_0
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v6

    .line 69
    new-instance v7, Ljava/io/FileOutputStream;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    move-object/from16 v8, p2

    :try_start_1
    invoke-direct {v7, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    .line 70
    :try_start_2
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    const-wide/16 v11, 0x0

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lpl/mk/premiumsmart/tv/UpdatePackage$Part;

    .line 71
    new-instance v14, Ljava/net/URL;

    iget-object v15, v13, Lpl/mk/premiumsmart/tv/UpdatePackage$Part;->url:Ljava/lang/String;

    invoke-direct {v14, v15}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v14}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v14

    check-cast v14, Ljava/net/HttpURLConnection;

    const/16 v15, 0x3a98

    invoke-virtual {v14, v15}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v15, 0x7530

    invoke-virtual {v14, v15}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v15, 0x0

    invoke-virtual {v14, v15}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 72
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 74
    :try_start_3
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v10

    const/16 v15, 0xc8

    if-ne v10, v15, :cond_5

    .line 75
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v10
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const v15, 0x8000

    .line 76
    :try_start_4
    new-array v15, v15, [B

    move-object/from16 v18, v1

    const-wide/16 v16, 0x0

    .line 77
    :goto_1
    invoke-virtual {v10, v15}, Ljava/io/InputStream;->read([B)I

    move-result v1

    move-wide/from16 v19, v3

    const/4 v3, -0x1

    if-eq v1, v3, :cond_1

    int-to-long v3, v1

    add-long v16, v16, v3

    add-long/2addr v11, v3

    iget-wide v3, v13, Lpl/mk/premiumsmart/tv/UpdatePackage$Part;->size:J

    cmp-long v3, v16, v3

    if-gtz v3, :cond_0

    cmp-long v3, v11, v19

    if-gtz v3, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v9, v15, v3, v1}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {v6, v15, v3, v1}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {v7, v15, v3, v1}, Ljava/io/FileOutputStream;->write([BII)V

    move-wide/from16 v3, v19

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :cond_1
    if-eqz v10, :cond_2

    .line 78
    :try_start_5
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V

    .line 79
    :cond_2
    iget-wide v3, v13, Lpl/mk/premiumsmart/tv/UpdatePackage$Part;->size:J

    cmp-long v1, v16, v3

    if-nez v1, :cond_3

    invoke-virtual {v9}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    invoke-static {v1}, Lpl/mk/premiumsmart/tv/Updater;->hex([B)Ljava/lang/String;

    move-result-object v1

    iget-object v3, v13, Lpl/mk/premiumsmart/tv/UpdatePackage$Part;->sha256:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    if-eqz v1, :cond_3

    .line 80
    :try_start_6
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    move-object/from16 v1, v18

    move-wide/from16 v3, v19

    goto/16 :goto_0

    .line 79
    :cond_3
    :try_start_7
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "part_checksum"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :catchall_0
    move-exception v0

    move-object v1, v0

    if-eqz v10, :cond_4

    .line 75
    :try_start_8
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v0

    :try_start_9
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_4
    :goto_2
    throw v1

    .line 74
    :cond_5
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "http"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :catchall_2
    move-exception v0

    .line 80
    :try_start_a
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    :cond_6
    move-wide/from16 v19, v3

    .line 82
    :try_start_b
    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V

    cmp-long v1, v11, v19

    if-nez v1, :cond_7

    .line 83
    invoke-virtual {v6}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    invoke-static {v1}, Lpl/mk/premiumsmart/tv/Updater;->hex([B)Ljava/lang/String;

    move-result-object v1

    const-string v2, "sha256"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    :cond_7
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "checksum"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    :catchall_3
    move-exception v0

    move-object v1, v0

    .line 69
    :try_start_c
    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    goto :goto_3

    :catchall_4
    move-exception v0

    :try_start_d
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_5

    :catchall_5
    move-exception v0

    goto :goto_4

    :catchall_6
    move-exception v0

    move-object/from16 v8, p2

    .line 84
    :goto_4
    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    throw v0
.end method

.method private fetch(Ljava/lang/String;I)[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 29
    const-string v0, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 30
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/16 v0, 0x3a98

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v0, 0x7530

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 31
    const-string v1, "Cache-Control"

    const-string v2, "no-cache"

    invoke-virtual {p1, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    :try_start_0
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    const/16 v2, 0xc8

    if-ne v1, v2, :cond_4

    .line 34
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    :try_start_1
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const v3, 0x8000

    .line 35
    :try_start_2
    new-array v3, v3, [B

    .line 36
    :goto_0
    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_1

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v5

    add-int/2addr v5, v4

    if-gt v5, p2, :cond_0

    invoke-virtual {v2, v3, v0, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    new-instance p2, Ljava/lang/Exception;

    const-string v0, "limit"

    invoke-direct {p2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 37
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v1, :cond_2

    :try_start_4
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 38
    :cond_2
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object p2

    :catchall_0
    move-exception p2

    .line 34
    :try_start_5
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    :try_start_6
    invoke-virtual {p2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    move-exception p2

    if-eqz v1, :cond_3

    :try_start_7
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception v0

    :try_start_8
    invoke-virtual {p2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_2
    throw p2

    .line 33
    :cond_4
    new-instance p2, Ljava/lang/Exception;

    const-string v0, "http"

    invoke-direct {p2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :catchall_4
    move-exception p2

    .line 38
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p2

    .line 29
    :cond_5
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "address"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private static hex([B)Ljava/lang/String;
    .locals 6

    .line 86
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%02x"

    invoke-static {v4, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private synthetic lambda$check$0(Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 48
    invoke-direct {p0, p1}, Lpl/mk/premiumsmart/tv/Updater;->download(Lorg/json/JSONObject;)V

    return-void
.end method

.method private synthetic lambda$check$1(JLjava/lang/String;Lorg/json/JSONObject;)V
    .locals 2

    const/4 v0, 0x0

    .line 48
    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const-wide/16 v0, 0x4

    cmp-long p1, p1, v0

    if-gtz p1, :cond_1

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string p2, "Wersja 0.1.3 jest aktualna"

    const/4 p3, 0x1

    invoke-static {p1, p2, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_1
    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object p2, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-direct {p1, p2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Aktualizacja "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "notes"

    const-string p3, "Pobra\u0107 now\u0105 wersj\u0119?"

    invoke-virtual {p4, p2, p3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p2, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, p4}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;-><init>(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;)V

    const-string p3, "Pobierz"

    invoke-virtual {p1, p3, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "P\u00f3\u017aniej"

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private synthetic lambda$check$2()V
    .locals 3

    const/4 v0, 0x0

    .line 49
    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v1, "Nie uda\u0142o si\u0119 sprawdzi\u0107 aktualizacji. Spr\u00f3buj p\u00f3\u017aniej."

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method private synthetic lambda$check$3()V
    .locals 8

    const-string v0, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/packages/MK_PremiumSmart_TV_"

    const-string v1, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/update.json?t="

    .line 44
    :try_start_0
    new-instance v7, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x4000

    invoke-direct {p0, v1, v3}, Lpl/mk/premiumsmart/tv/Updater;->fetch(Ljava/lang/String;I)[B

    move-result-object v1

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v7, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 45
    const-string v1, "versionCode"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v4

    const-string v1, "version"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 46
    const-string v1, "applicationId"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "pl.mk.premiumsmart.tv"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "[0-9]+\\.[0-9]+\\.[0-9]+"

    invoke-virtual {v6, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "url"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ".apk"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 47
    const-string v0, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/"

    invoke-static {v7, v0}, Lpl/mk/premiumsmart/tv/UpdatePackage;->parts(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/util/List;

    .line 48
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    new-instance v2, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda1;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v3, p0

    :try_start_1
    invoke-direct/range {v2 .. v7}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda1;-><init>(Lpl/mk/premiumsmart/tv/Updater;JLjava/lang/String;Lorg/json/JSONObject;)V

    invoke-virtual {v0, v2}, Lpl/mk/premiumsmart/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_0
    move-object v3, p0

    .line 46
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "manifest"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_0
    move-object v3, p0

    .line 49
    :catch_1
    iget-object v0, v3, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    new-instance v1, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda2;-><init>(Lpl/mk/premiumsmart/tv/Updater;)V

    invoke-virtual {v0, v1}, Lpl/mk/premiumsmart/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private synthetic lambda$download$4()V
    .locals 1

    const/4 v0, 0x0

    .line 60
    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    invoke-virtual {p0}, Lpl/mk/premiumsmart/tv/Updater;->installPending()V

    return-void
.end method

.method private synthetic lambda$download$5()V
    .locals 3

    const/4 v0, 0x0

    .line 61
    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v1, "Nie uda\u0142o si\u0119 pobra\u0107 lub zweryfikowa\u0107 aktualizacji."

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$download$6(Lorg/json/JSONObject;)V
    .locals 6

    .line 56
    :try_start_0
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v1}, Lpl/mk/premiumsmart/tv/MainActivity;->getCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "updates"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/Exception;

    const-string v0, "cache"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    .line 57
    :cond_1
    :goto_0
    new-instance v1, Ljava/io/File;

    const-string v2, "update.apk"

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {p0, p1, v1}, Lpl/mk/premiumsmart/tv/Updater;->downloadFile(Lorg/json/JSONObject;Ljava/io/File;)V

    .line 58
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->getPackageArchiveInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 59
    const-string v2, "pl.mk.premiumsmart.tv"

    iget-object v3, v0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1c

    if-lt v2, v3, :cond_2

    invoke-virtual {v0}, Landroid/content/pm/PackageInfo;->getLongVersionCode()J

    move-result-wide v2

    goto :goto_1

    :cond_2
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    int-to-long v2, v0

    :goto_1
    const-string v0, "versionCode"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v4

    cmp-long p1, v2, v4

    if-nez p1, :cond_3

    .line 60
    iput-object v1, p0, Lpl/mk/premiumsmart/tv/Updater;->pending:Ljava/io/File;

    iget-object p1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    new-instance v0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda5;-><init>(Lpl/mk/premiumsmart/tv/Updater;)V

    invoke-virtual {p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    .line 59
    :cond_3
    new-instance p1, Ljava/lang/Exception;

    const-string v0, "package"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 61
    :catch_0
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    new-instance v0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda6;-><init>(Lpl/mk/premiumsmart/tv/Updater;)V

    invoke-virtual {p1, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private synthetic lambda$installPending$7(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 90
    iget-object p1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    new-instance p2, Landroid/content/Intent;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "package:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v1}, Lpl/mk/premiumsmart/tv/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    invoke-direct {p2, v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/16 v0, 0xd2

    invoke-virtual {p1, p2, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method


# virtual methods
.method check()V
    .locals 3

    .line 41
    iget-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/premiumsmart/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v1, "Sprawdzanie aktualizacji\u2026"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 42
    sget-object v0, Lpl/mk/premiumsmart/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda3;-><init>(Lpl/mk/premiumsmart/tv/Updater;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method installPending()V
    .locals 4

    .line 88
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->pending:Ljava/io/File;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 89
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v2, 0x0

    if-lt v0, v1, :cond_1

    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/premiumsmart/tv/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/pm/PackageManager;->canRequestPackageInstalls()Z

    move-result v0

    if-nez v0, :cond_1

    .line 90
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Zezw\u00f3l na instalacj\u0119 aktualizacji"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Android wymaga jednorazowego zezwolenia dla MK PremiumSmart TV. Po jego w\u0142\u0105czeniu wr\u00f3\u0107 do aplikacji."

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda4;-><init>(Lpl/mk/premiumsmart/tv/Updater;)V

    const-string v3, "Ustawienia"

    invoke-virtual {v0, v3, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "P\u00f3\u017aniej"

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 92
    :cond_1
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v1, "pl.mk.premiumsmart.tv.files"

    iget-object v3, p0, Lpl/mk/premiumsmart/tv/Updater;->pending:Ljava/io/File;

    invoke-static {v0, v1, v3}, Landroidx/core/content/FileProvider;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0

    .line 93
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v3, "application/vnd.android.package-archive"

    invoke-virtual {v1, v0, v3}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 94
    :try_start_0
    iget-object v3, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    invoke-virtual {v3, v0}, Lpl/mk/premiumsmart/tv/MainActivity;->startActivity(Landroid/content/Intent;)V

    iput-object v2, p0, Lpl/mk/premiumsmart/tv/Updater;->pending:Ljava/io/File;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater;->activity:Lpl/mk/premiumsmart/tv/MainActivity;

    const-string v2, "Brak instalatora APK na urz\u0105dzeniu."

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_0
    return-void
.end method
