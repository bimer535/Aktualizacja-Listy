.class public final synthetic Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

.field public final synthetic f$1:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;->f$1:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;->f$0:Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity$$ExternalSyntheticLambda13;->f$1:Ljava/util/List;

    invoke-static {v0, v1, p1, p2}, Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;->$r8$lambda$Mk09kMXMR0uNtWuhyrwid7uuD2o(Lpl/mk/premiumsmart/tv/CompatibilityPlayerActivity;Ljava/util/List;Landroid/content/DialogInterface;I)V

    return-void
.end method
