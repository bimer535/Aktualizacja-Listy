.class public final synthetic Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/premiumsmart/tv/Updater;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/Updater;

    iput-object p2, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;->f$0:Lpl/mk/premiumsmart/tv/Updater;

    iget-object v1, p0, Lpl/mk/premiumsmart/tv/Updater$$ExternalSyntheticLambda0;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1, p1, p2}, Lpl/mk/premiumsmart/tv/Updater;->$r8$lambda$cZf63_yUm79rJ5NMo3wKT3kgPLw(Lpl/mk/premiumsmart/tv/Updater;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method
