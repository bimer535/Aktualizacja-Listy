# MK PremiumSmart TV 0.1.3 — aktualizacja ikony

Zielona kwadratowa ikona. Działanie aplikacji zachowano z podpisanego APK 0.1.2,
a nie ze starszych źródeł 0.1.1. Runtime Python, adaptery źródeł i biblioteki natywne
są identyczne bajt po bajcie. Zmiany kodu dotyczą wyłącznie numeru wersji.

To zestaw odtwarzający zmianę zasobów, nie pełne odtworzenie źródeł Java 0.1.2.
Wymaga własnego wcześniejszego MK_PremiumSmart_TV_0.1.2.apk o SHA-256 podanym
w release.json, JDK 17 i Apktool 2.12.1.

python3 rebuild_icon.py MK_PremiumSmart_TV_0.1.2.apk apktool.jar unsigned.apk

Następnie zipalign -P 16 -f 4 i apksigner. Klucz MK pozostaje prywatny.
Obecne pliki smali pakietu MK zachowano w assembly/ jako punkt odniesienia.
Publiczne starsze źródła 0.1.1 pozostają w repozytorium.
