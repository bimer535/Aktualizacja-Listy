#!/usr/bin/env python3
"""Build helper for this workspace; uses standard installed Gradle/SDK elsewhere."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.parse

project=Path(__file__).resolve().parents[1]
local=project.parent/'android-build-tools'
env=dict(os.environ)
gradle=shutil.which('gradle')
if (local/'gradle-8.11.1/bin/gradle').exists():
    gradle=str(local/'gradle-8.11.1/bin/gradle')
    env['JAVA_HOME']=(local/'jdk-path.txt').read_text().strip()
    env['MK_BUILD_PYTHON']=str(Path('/root/.local/bin/python3.11'))
    home=local/'gradle-home';home.mkdir(exist_ok=True)
    proxy=urllib.parse.urlsplit(env.get('HTTPS_PROXY',''))
    properties=''
    if proxy.hostname and proxy.port:
        properties=''.join('systemProp.%s.proxyHost=%s\nsystemProp.%s.proxyPort=%s\n'%(scheme,proxy.hostname,scheme,proxy.port) for scheme in ('http','https'))
    properties+='systemProp.java.net.preferIPv4Stack=true\n'
    if Path('/etc/ssl/certs/java/cacerts').is_file():properties+='systemProp.javax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts\n'
    (home/'gradle.properties').write_text(properties)
    env['GRADLE_USER_HOME']=str(home)
if not gradle:raise SystemExit('Install Gradle 8.11.1, JDK 17, Android SDK 35 and Python 3.11.')
raise SystemExit(subprocess.call([gradle,'-p',str(project)]+sys.argv[1:],env=env))
