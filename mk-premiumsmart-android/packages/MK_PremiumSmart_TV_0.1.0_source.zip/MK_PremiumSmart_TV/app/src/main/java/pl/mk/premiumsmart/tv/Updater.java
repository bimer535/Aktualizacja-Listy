package pl.mk.premiumsmart.tv;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.Executors;

final class Updater {
    private static final String BASE="https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-premiumsmart-android/";
    private final MainActivity activity;
    private File pending;
    private boolean running;
    private static final java.util.concurrent.ExecutorService jobs=Executors.newSingleThreadExecutor();
    Updater(MainActivity activity){this.activity=activity;}
    private byte[] fetch(String address,int limit) throws Exception {
        if(!address.startsWith(BASE))throw new Exception("address");
        HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();connection.setConnectTimeout(15000);connection.setReadTimeout(30000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Cache-Control","no-cache");
        try {
            if(connection.getResponseCode()!=200)throw new Exception("http");
            try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                byte[] buffer=new byte[32768];int count;
                while((count=input.read(buffer))!=-1){if(output.size()+count>limit)throw new Exception("limit");output.write(buffer,0,count);}return output.toByteArray();
            }
        }finally{connection.disconnect();}
    }
    void check(){
        if(running)return;running=true;Toast.makeText(activity,"Sprawdzanie aktualizacji…",Toast.LENGTH_SHORT).show();
        jobs.execute(()->{
            try {
                JSONObject manifest=new JSONObject(new String(fetch(BASE+"update.json",16384),java.nio.charset.StandardCharsets.UTF_8));
                long code=manifest.getLong("versionCode");String version=manifest.getString("version");
                if(!manifest.optString("applicationId").equals("pl.mk.premiumsmart.tv")||!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+")||!manifest.getString("url").equals(BASE+"packages/MK_PremiumSmart_TV_"+version+".apk"))throw new Exception("manifest");
                activity.runOnUiThread(()->{running=false;if(activity.isDestroyed())return;if(code<=BuildConfig.VERSION_CODE)Toast.makeText(activity,"Wersja "+BuildConfig.VERSION_NAME+" jest aktualna",Toast.LENGTH_LONG).show();else new AlertDialog.Builder(activity).setTitle("Aktualizacja "+version).setMessage(manifest.optString("notes","Pobrać nową wersję?")).setPositiveButton("Pobierz",(d,w)->download(manifest)).setNegativeButton("Później",null).show();});
            }catch(Exception error){activity.runOnUiThread(()->{running=false;if(!activity.isDestroyed())Toast.makeText(activity,"Nie udało się sprawdzić aktualizacji. Spróbuj później.",Toast.LENGTH_LONG).show();});}
        });
    }
    private void download(JSONObject manifest){
        if(running)return;running=true;Toast.makeText(activity,"Pobieranie aktualizacji…",Toast.LENGTH_LONG).show();
        jobs.execute(()->{
            try {
                File directory=new File(activity.getCacheDir(),"updates");if(!directory.isDirectory()&&!directory.mkdirs())throw new Exception("cache");
                File file=new File(directory,"update.apk");downloadFile(manifest,file);
                android.content.pm.PackageInfo info=activity.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),0);
                if(info==null||!"pl.mk.premiumsmart.tv".equals(info.packageName)||(Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode)!=manifest.getLong("versionCode"))throw new Exception("package");
                pending=file;activity.runOnUiThread(()->{running=false;installPending();});
            }catch(Exception error){activity.runOnUiThread(()->{running=false;Toast.makeText(activity,"Nie udało się pobrać lub zweryfikować aktualizacji.",Toast.LENGTH_LONG).show();});}
        });
    }
    private void downloadFile(JSONObject manifest,File file) throws Exception {
        String address=manifest.getString("url");long expected=manifest.getLong("size");
        if(!address.startsWith(BASE+"packages/")||expected<1000||expected>100*1024*1024)throw new Exception("manifest");
        HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();connection.setConnectTimeout(15000);connection.setReadTimeout(30000);connection.setInstanceFollowRedirects(false);
        boolean success=false;
        try {
            if(connection.getResponseCode()!=200)throw new Exception("http");
            MessageDigest digest=MessageDigest.getInstance("SHA-256");long total=0;
            try(InputStream input=connection.getInputStream();FileOutputStream output=new FileOutputStream(file)){
                byte[] buffer=new byte[32768];int count;
                while((count=input.read(buffer))!=-1){total+=count;if(total>expected)throw new Exception("size");digest.update(buffer,0,count);output.write(buffer,0,count);}
            }
            if(total!=expected)throw new Exception("size");StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
            if(!hex.toString().equals(manifest.getString("sha256")))throw new Exception("checksum");success=true;
        }finally{connection.disconnect();if(!success)file.delete();}
    }
    void installPending(){
        if(pending==null||activity.isDestroyed())return;
        if(Build.VERSION.SDK_INT>=26&&!activity.getPackageManager().canRequestPackageInstalls()){
            new AlertDialog.Builder(activity).setTitle("Zezwól na instalację aktualizacji").setMessage("Android wymaga jednorazowego zezwolenia dla MK PremiumSmart TV. Po jego włączeniu wróć do aplikacji.").setPositiveButton("Ustawienia",(d,w)->activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())),210)).setNegativeButton("Później",null).show();return;
        }
        Uri uri=FileProvider.getUriForFile(activity,"pl.mk.premiumsmart.tv.files",pending);
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {activity.startActivity(intent);pending=null;}catch(Exception error){Toast.makeText(activity,"Brak instalatora APK na urządzeniu.",Toast.LENGTH_LONG).show();}
    }
}
