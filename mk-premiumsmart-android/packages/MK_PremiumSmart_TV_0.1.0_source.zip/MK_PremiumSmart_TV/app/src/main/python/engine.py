# SPDX-License-Identifier: GPL-3.0-only
"""Android bridge to the working E2 catalogue and source adapters; no accounts."""
import json
from pathlib import Path
import re
import threading
import urllib.error
import catalogue
import resolver
import access_cache
import watchstate
from relay import Relay
from source_adapter import source_options

MESSAGES={
 'catalogue_access_denied':'Serwis zablokował dostęp do katalogu. Spróbuj ponownie później.',
 'catalogue_session_required':'Nie udało się uzyskać anonimowej sesji. Spróbuj ponownie.',
 'catalogue_http_error':'Nie udało się pobrać katalogu. Sprawdź połączenie.',
 'language_version_unavailable':'Brak źródeł z wybraną wersją językową. Sprawdź „Wszystkie wersje”.',
 'source_returned_no_variants':'Źródło nie zwróciło filmu. Wybierz inne źródło.',
 'source_access_denied':'Serwer tego źródła odmówił dostępu. Wybierz inne źródło.',
 'source_temporarily_unavailable':'Serwer tego źródła jest obecnie niedostępny.',
 'manifest_not_hls':'Serwer nie zwrócił prawidłowego strumienia wideo.',
 'manifest_http_error':'Nie udało się pobrać strumienia. Sprawdź inne źródło.',
 'player_source_not_found':'Źródło filmu zmieniło się. Odśwież jego listę.',
}


class Cancelled(Exception):pass


class Http(resolver.Http):
    def getPage(self,url,params=None,post_data=None):
        try:
            from java import jclass
            if jclass('pl.mk.premiumsmart.tv.Pow').isCancelled():raise Cancelled()
        except ImportError:pass
        return super().getPage(url,params,post_data)


class QuietNotify:
    def setStatus(self,text):pass


resolver.NOTIFY=QuietNotify()


def entry_copy(value):
    result=dict(value)
    if result.get('action')=='resolve':
        result['action']='sources';result['title']=result.get('movie_title',result.get('title','Film'))
    return result


class Backend:
    def __init__(self,files,cache):
        self.files=Path(files);self.cache=Path(cache)
        self.files.mkdir(parents=True,exist_ok=True);self.cache.mkdir(parents=True,exist_ok=True)
        access_cache.PATH=self.cache/'source-access.json'
        self.library=watchstate.Library(self.files/'library.json')
        if 'settings' not in self.library.read():self.library.setting('view','tiles')
        self.history_path=self.files/'history.json'
        self.client=Http();self.options=[];self.relay=None;self.mutex=threading.RLock()

    def history(self):
        try:
            values=json.loads(self.history_path.read_text())
            return [value for value in values if isinstance(value,str) and 0<len(value)<=200][:20] if isinstance(values,list) else []
        except (OSError,ValueError):return []

    def stop(self):
        relay=self.relay;self.relay=None;self.options=[]
        if relay:relay.close()

    def request(self,value):
        operation=value.get('op','browse');current=value.get('item',{})
        if operation=='state':return {'settings':self.library.settings()}
        if operation=='settings':
            self.library.setting(value['key'],value['value']);return {'settings':self.library.settings()}
        if operation=='favourite':
            return {'added':self.library.toggle(entry_copy(current))}
        if operation=='progress':return {'progress':self.library.progress(current.get('url',''))}
        if operation=='record':
            self.library.record(entry_copy(current),value.get('position',0),value.get('duration',0),value.get('completed',False));return {}
        if operation=='stop':self.stop();return {}
        if operation=='resolve':
            self.stop();self.options=source_options(self.client,current)
            return {'variants':[{'label':self.label(option,i),'height':option.get('height',0)} for i,option in enumerate(self.options)],
                    'preferred':watchstate.preferred_variant(self.options)}
        if operation=='play':
            index=value['index']
            if type(index) is not int or not 0<=index<len(self.options):raise ValueError('invalid_variant')
            if self.relay:self.relay.close()
            self.relay=Relay(self.options[index],self.client)
            subtitles=[]
            for track in getattr(self.options[index]['url'],'meta',{}).get('external_sub_tracks',[])[:20]:
                if not isinstance(track,dict):continue
                try:url=resolver.checked_url(track.get('url',''))
                except (ValueError,resolver.ResolveError):continue
                subtitles.append({'url':self.relay.route(url),'language':str(track.get('lang') or 'und'),
                                  'title':str(track.get('title') or track.get('lang') or 'Napisy'),
                                  'format':'srt' if track.get('format')=='srt' or '.srt' in url else 'vtt'})
            return {'url':self.relay.url,'subtitles':subtitles,'progress':self.library.progress(current.get('url',''))}
        action=current.get('action','main')
        if action=='favourites':items=self.library.favourites()
        elif action=='continue':items=self.library.continuing()
        elif action=='history':items=[{'title':term,'action':'search_results','query':term} for term in self.history()]
        else:
            if action=='search_results':
                term=current.get('query','').strip()[:200]
                if not term:raise ValueError('empty_search')
                current=dict(current,query=term)
                watchstate.Library(self.history_path).write([term]+[v for v in self.history() if v!=term][:19])
            items=catalogue.browse(self.client,current)
        for item in items:
            item['watched']=bool(self.library.progress(item.get('url','')).get('completed'))
        return {'items':items}

    @staticmethod
    def label(option,index):
        name=option.get('name') or 'Wariant '+str(index+1)
        height=option.get('height',0);language=option.get('language') or 'Auto'
        bitrate=option.get('bitrate') or 0
        return '%s · %s%s%s'%(language,str(height)+'p · ' if height else '',name,(' · %.1f Mb/s'%(bitrate/1_000_000)) if bitrate else '')


backend=None


def init(files,cache):
    global backend
    if backend is None:backend=Backend(files,cache)
    return json.dumps({'ok':True,'settings':backend.library.settings()})


def request(data):
    try:
        value=json.loads(data)
        with backend.mutex:result=backend.request(value)
        return json.dumps(dict(result,ok=True),ensure_ascii=False)
    except Exception as error:
        if isinstance(error,Cancelled):reason='cancelled';message='Anulowano.'
        elif isinstance(error,(urllib.error.URLError,TimeoutError)):
            reason='connection_failed';message='Nie udało się połączyć z serwerem. Sprawdź internet lub wybierz inne źródło.'
        else:
            raw=str(error);reason=raw if re.fullmatch('[a-z_]{1,80}',raw) else type(error).__name__
            message=MESSAGES.get(reason,'Nie udało się otworzyć pozycji. Spróbuj innego źródła lub odśwież listę.')
        return json.dumps({'ok':False,'reason':reason,'message':message},ensure_ascii=False)
