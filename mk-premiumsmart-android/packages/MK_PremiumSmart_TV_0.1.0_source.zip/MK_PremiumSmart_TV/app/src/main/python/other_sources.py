# SPDX-License-Identifier: GPL-3.0-only
"""Public VOE and MixDrop parsers with standalone, non-executing helpers.

Parser methods come from e2iplayer-2026.10.18.05, libs/urlparser.py.
The packed-JavaScript reader substitutes strings; it never evaluates JS.
"""
import ast
import base64
import html
import hashlib
import json
import re
from urllib.parse import urljoin, urlsplit
from resolver import (urlparser,SetIPTVPlayerLastHostError,printDBG,_,json_loads,
                      getDirectM3U8Playlist,ResolveError,checked_url)



def ensure_str(value):
    return value.decode('utf-8') if isinstance(value,bytes) else str(value)


class ph:
    @staticmethod
    def search(text,pattern):
        match=re.search(pattern,text,re.S)
        return match.groups() if match else ('',)


def get_packed_data(text):
    literal=r'''(?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")'''
    pattern=re.compile(r'\}\s*\(\s*('+literal+r'),\s*(\d+),\s*(\d+),\s*('+literal+r')\.split\([\'\"]\|[\'\"]\)',re.S)
    for _hop in range(5):
        match=pattern.search(text)
        if not match:break
        payload=ast.literal_eval(match[1]);radix=int(match[2]);count=int(match[3]);words=ast.literal_eval(match[4]).split('|')
        if not 2<=radix<=62 or count>100000 or len(payload)>2*1024*1024:return ''
        alphabet='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        def replace(token):
            value=0
            for char in token[0]:
                digit=alphabet.find(char)
                if digit<0 or digit>=radix:return token[0]
                value=value*radix+digit
                if value>=count:return token[0]
            return words[value] if value<len(words) and words[value] else token[0]
        decoded=re.sub(r'\b[0-9A-Za-z]+\b',replace,payload)
        text=text[:match.start()]+decoded+text[match.end():]
    return text


class OtherSources:
    def __init__(self,client):self.cm=client

    def parserSTREAMUP(self,baseUrl):
        # Public parserSTREAMUP: Vidara uses its own JSON API, not Byse's API.
        host=urlparser.getDomain(baseUrl,False)
        match=re.match(r'^/(?:e/|v/)?([A-Za-z0-9]+)(?:/|$)',urlsplit(baseUrl).path)
        if not match:return []
        headers=self.cm.getDefaultHeader()
        headers.update({'Referer':str(baseUrl),'Origin':host.rstrip('/'),'Content-Type':'application/json'})
        ok,body=self.cm.getPage(host+'api/stream',{'header':headers},json.dumps({'filecode':match[1],'device':'web'}))
        if not ok:return []
        try:data=json.loads(body)
        except ValueError:return []
        if not isinstance(data,dict):return []
        source=data.get('streaming_url')
        if not isinstance(source,str) or not source:return []
        meta={'User-Agent':headers['User-Agent'],'Referer':host,'Origin':host.rstrip('/')}
        meta['external_sub_tracks']=[{'title':sub.get('language',''),'lang':sub.get('language',''),'url':sub['file_path']}
            for sub in data.get('subtitles') or [] if isinstance(sub,dict) and sub.get('file_path')]
        url=urlparser.decorateUrl(checked_url(source.replace('\r','').replace('\n','')),meta)
        return getDirectM3U8Playlist(url) if '.m3u8' in urlsplit(url).path else [{'name':'MP4','url':url}]

    def parserVIDSST(self,baseUrl):
        # Public parserVIDSST: ArtPlayer exposes const url (HLS or MP4).
        headers=self.cm.getDefaultHeader();headers['Referer']=str(baseUrl)
        ok,body=self.cm.getPage(baseUrl,{'header':headers})
        if not ok:return []
        body=body.replace(r'\/', '/')
        match=re.search(r'''\bconst\s+url\s*=\s*["'](https://[^"']+\.(?:m3u8|mp4)[^"']*)["']''',body)
        if not match:
            match=re.search(r'''["'](https://[^"']+/master\.m3u8[^"']*)["']''',body)
        if not match:return []
        meta={'User-Agent':headers['User-Agent'],'Referer':str(baseUrl),'Origin':urlparser.getDomain(baseUrl,False).rstrip('/')}
        subtitle=re.search(r'''"subtitleUrl"\s*:\s*"([^"\n]+)"''',body)
        if subtitle:
            label=re.search(r'''"subtitleLabel"\s*:\s*"([^"\n]*)"''',body)
            language=label[1] if label else ''
            meta['external_sub_tracks']=[{'title':language,'lang':language,'url':urljoin(baseUrl,subtitle[1])}]
        source=urlparser.decorateUrl(checked_url(match[1]),meta)
        return getDirectM3U8Playlist(source) if '.m3u8' in urlsplit(source).path else [{'name':'MP4','url':source}]

    def parserABYSS(self,baseUrl):
        # Public parserABYSS, using existing PyCryptodome instead of pyaes.
        from Crypto.Cipher import AES
        def ctr(data,seed):
            key=hashlib.md5(seed).hexdigest().encode('ascii')
            return AES.new(key,AES.MODE_CTR,nonce=b'',initial_value=int.from_bytes(key[:16],'big')).encrypt(data)
        def num_seed(value):
            return bytes(int(char) if char.isdigit() else ord(char)&255 for char in str(value))
        headers=self.cm.getDefaultHeader();headers['Referer']=getattr(baseUrl,'meta',{}).get('Referer',urljoin(baseUrl,'/'))
        ok,body=self.cm.getPage(baseUrl,{'header':headers})
        if not ok:return []
        match=re.search(r'''(?:const|var|let)\s+datas\s*=\s*["']([^"']+)["']''',body)
        if not match:return []
        try:data=json.loads(base64.b64decode(match[1],validate=True).decode('latin-1'))
        except (ValueError,UnicodeError):return []
        if not isinstance(data,dict):return []
        media=data.get('media');slug=data.get('slug');md5_id=data.get('md5_id');user=data.get('user_id')
        if not isinstance(media,dict):
            if not isinstance(media,str) or not all((slug,md5_id,user)):return []
            encrypted=bytes(ord(char)&255 for char in media);seed='%s:%s:%s'%(user,slug,md5_id)
            media=None
            for candidate in (seed.encode(),num_seed(seed)):
                try:media=json.loads(ctr(encrypted,candidate).decode('utf-8'))
                except (ValueError,UnicodeError):continue
                if isinstance(media,dict):break
            if not isinstance(media,dict):return []
        meta={'User-Agent':headers['User-Agent'],'Referer':urljoin(self.cm.meta.get('url',str(baseUrl)),'/')}
        result=[];mp4=media.get('mp4') or {}
        domains=[domain for domain in mp4.get('domains') or [] if isinstance(domain,str) and domain]
        for source in sorted((value for value in mp4.get('sources') or [] if isinstance(value,dict) and value.get('status') is not False),key=lambda value:int(value.get('size') or 0),reverse=True):
            label=str(source.get('label') or source.get('res_id') or 'MP4')
            url=source.get('file')
            if not url:
                size=source.get('size');res=source.get('res_id');sub=source.get('sub') or ''
                if not (size and res and domains and md5_id and slug):continue
                domain=next((value for value in domains if sub and sub in value),domains[int(size)%len(domains)])
                path=('/mp4/%s/%s/%s?v=%s'%(md5_id,res,size,slug)).encode()
                token=base64.b64encode(base64.b64encode(ctr(path,num_seed(size))).rstrip(b'=')).rstrip(b'=').decode()
                url='%s/sora/%s/%s'%(domain if domain.startswith('https://') else 'https://'+domain,size,token)
            result.append({'name':'Abyss '+label,'height':int(re.sub(r'\D','',label) or 0),'url':urlparser.decorateUrl(checked_url(url.replace(r'\/', '/')),meta)})
        hls=media.get('hls') or {}
        for key in ('file','url','master','src','source'):
            if isinstance(hls.get(key),str) and hls[key]:
                result.extend(getDirectM3U8Playlist(urlparser.decorateUrl(checked_url(hls[key].replace(r'\/', '/')),meta)))
                break
        return result

    def parserSTREAMTAPE(self,baseUrl):
        headers=self.cm.getDefaultHeader();headers['Referer']=getattr(baseUrl,'meta',{}).get('Referer',str(baseUrl))
        ok,body=self.cm.getPage(baseUrl,{'header':headers})
        if self.cm.meta.get('status_code')==404 and headers['Referer']!=str(baseUrl):
            headers['Referer']=str(baseUrl);ok,body=self.cm.getPage(baseUrl,{'header':headers})
        if not ok:return []
        if '<title>Site Unavailable</title>' in body:raise ResolveError('source_temporarily_unavailable')
        for expression in re.findall(r'innerHTML\s*=\s*([^;]+);',body):
            if len(expression)>10000:continue
            expression=re.sub(r'\.substring\(\s*(\d+)\s*\)',r'[\1:]',expression)
            try:
                tree=ast.parse(expression.strip(),mode='eval')
                if sum(1 for _ in ast.walk(tree))>1000:continue
                def read(node):
                    if isinstance(node,ast.Constant) and isinstance(node.value,str):return node.value
                    if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return read(node.left)+read(node.right)
                    if isinstance(node,ast.Subscript) and isinstance(node.slice,ast.Slice) and node.slice.upper is None and node.slice.step is None:
                        lower=node.slice.lower
                        if isinstance(lower,ast.Constant) and type(lower.value) is int and 0<=lower.value<=10000:return read(node.value)[lower.value:]
                    raise ValueError('unsupported_streamtape_expression')
                value=html.unescape(read(tree.body).replace('\\/','/'))
                if value.startswith('//'):value='https:'+value
                value=checked_url(value)
                return [{'name':'MP4','url':urlparser.decorateUrl(value,{'User-Agent':headers['User-Agent'],'Referer':headers['Referer']})}]
            except (SyntaxError,ValueError,ResolveError):continue
        return []

    def parserSST(self,baseUrl):
        # Public parserSST method, adapted for attribute order and HLS links.
        headers=self.cm.getDefaultHeader();headers['Referer']=getattr(baseUrl,'meta',{}).get('Referer',str(baseUrl))
        ok,data=self.cm.getPage(baseUrl,{'header':headers})
        if not ok:return []
        page=self.cm.meta.get('url',str(baseUrl));host=urlparser.getDomain(page,False)
        meta={'User-Agent':headers['User-Agent'],'Referer':page,'Origin':host.rstrip('/')}
        links=[]
        for tag in re.findall(r'<source\b[^>]*>',data,re.I):
            source=ph.search(tag,r'''\bsrc\s*=\s*["']([^"']+)''')[0]
            label=ph.search(tag,r'''\b(?:label|res)\s*=\s*["']([^"']+)''')[0]
            if source:links.append((label or 'MP4',urljoin(page,source)))
        if not links:
            source=ph.search(data,r'''\bfile\s*:\s*["']([^"']+)''')[0]
            if '[' in source:
                links=re.findall(r'\[(\d+p)\](https?://[^\s,\]]+)',source)
            elif source:links=[('MP4',urljoin(page,source.replace(r'\/','/')))]
        result=[]
        for label,source in links:
            if not self.cm.isValidUrl(source):continue
            url=urlparser.decorateUrl(source,meta)
            if '.m3u8' in source:result.extend(getDirectM3U8Playlist(url))
            else:result.append({'name':label,'url':url})
        return result

    def parserVOESX(self, baseUrl):
            def voe_decode(ct, lut=None):
                txt = "".join(chr((ord(i) - 52) % 26 + 65) if 65 <= ord(i) <= 90 else chr((ord(i) - 84) % 26 + 97) if 97 <= ord(i) <= 122 else i for i in ct)
                if not lut:
                    lut = [re.escape(marker) for marker in ("#&", "%?", "*~", "~@", "^^", "!!", "@$")]
                for pattern in lut:
                    txt = re.sub(pattern, "_", txt)
                txt = "".join(txt.split("_"))

                def fix_b64_padding(s):
                    return s + "=" * (-len(s) % 4)

                try:
                    step1 = base64.b64decode(fix_b64_padding(txt)).decode()
                    step2 = "".join(chr(ord(c) - 3) for c in step1)
                    final = base64.b64decode(fix_b64_padding(step2[::-1])).decode()
                    return json_loads(final)
                except Exception as e:
                    printDBG(e)
                    return ""

            printDBG("parserVOESX baseUrl[%r]" % baseUrl)
            sts, data = self.cm.getPage(baseUrl, {'header': {'Referer': getattr(baseUrl, 'meta', {}).get('Referer', str(baseUrl))}})
            if not sts or not any(marker in data for marker in ("const currentUrl", "application/json", '";function', "hls")):
                # add 061026: VOE drops its rotation domains quickly (gone, or parked with a "Redirecting..." page);
                # the file id still plays via voe.sx
                fileId = ph.search(baseUrl, r"//[^/]+/(?:e/)?([0-9A-Za-z]+)")[0]
                if not fileId or "//voe.sx/" in baseUrl:
                    return False
                printDBG("parserVOESX %s gone or no VOE page -> voe.sx" % urlparser.getDomain(baseUrl))
                sts, data = self.cm.getPage("https://voe.sx/e/%s" % fileId)
                if not sts:
                    return False
            pageUrl = self.cm.meta.get("url", baseUrl)
            # fix 061026: the redirect page can lead to another redirect page (after ResolveURL voesx.py)
            for _hop in range(5):
                if "const currentUrl" not in data:
                    break
                nextUrl = ph.search(data, r"""window.location.href\s*=\s*['"]([^"^']+?)['"]""")[0]
                if not nextUrl:
                    break
                previousUrl = pageUrl
                pageUrl = urljoin(pageUrl, nextUrl)
                sts, data = self.cm.getPage(pageUrl, {"header": {"Referer": previousUrl}})
                if not sts:
                    return False
            if "<title>404" in data:
                SetIPTVPlayerLastHostError(_("The video has been removed."))
                return []
            # add 061026: the junk strings of the decoder change with VOE's player script, which lists them
            # (['@$','^^',...]); the built-in list stays the fallback
            lut = None
            script = ph.search(data, r"""json">\["[^"]+"]</script>\s*<script\s*src="([^"]+)""")[0]
            if script:
                stsS, dataS = self.cm.getPage(urljoin(pageUrl, script))
                table = ph.search(dataS, r"""(\[(?:'\W{2}'[,\]]){1,9})""")[0] if stsS else ""
                if table:
                    lut = [re.escape(x) for x in table[2:-2].split("','")]
                    printDBG("parserVOESX junk table from the player script: %s" % table)
            r = re.search(r"""['"]?hls['"]?\s*?:\s*?['"]([^'^"]+?)['"]""", data)
            if r:
                value = r.group(1)
                hlsUrl = value if value.startswith(("https://", "//")) else ensure_str(base64.b64decode(value + "=" * (-len(value) % 4)))
                if hlsUrl.startswith("//"):
                    hlsUrl = "https:" + hlsUrl
                if self.cm.isValidUrl(hlsUrl):
                    params = {"iptv_proto": "m3u8", "Referer": pageUrl, "Origin": urlparser.getDomain(pageUrl, False).rstrip("/")}
                    hlsUrl = urlparser.decorateUrl(hlsUrl, params)
                    return getDirectM3U8Playlist(hlsUrl, checkExt=False, checkContent=True, sortWithMaxBitrate=999999999)
            else:
                r = re.search(r'\w+="([^"]+)";function', data)
                if not r:
                    r = re.search(r"""application/json">[^>]"([^"]+)""", data)
                urltab = []
                if r:
                    payload = ensure_str(r.group(1))
                    r = voe_decode(payload, lut)
                    if not r and lut:
                        r = voe_decode(payload)
                    if r:
                        subtitles = [{"title": "", "lang": x.get("label"), "url": urljoin(pageUrl, x.get("file"))} for x in r.get("captions", []) if x.get("kind") == "captions"]
                        key_list = ["source", "file", "direct_access_url"]
                        for key in key_list:
                            if key in r:
                                url = r[key]
                                if ".m3u8" in url:
                                    url = urlparser.decorateUrl(url, {"iptv_proto": "m3u8", "Referer": pageUrl, "Origin": urlparser.getDomain(pageUrl, False).rstrip("/"), "external_sub_tracks": subtitles})
                                    urltab.extend(getDirectM3U8Playlist(url, checkExt=False, checkContent=True, sortWithMaxBitrate=999999999))
                                else:
                                    if subtitles:
                                        url = urlparser.decorateUrl(url, {"external_sub_tracks": subtitles})
                                    urltab.append({"name": "MP4", "url": url})
                return urltab

    def parserMIXDROP(self, baseUrl):  # add 041026 - like ResolveURL mixdrop.py
            printDBG("parserMIXDROP baseUrl[%s]" % baseUrl)
            mediaId = re.search(r"/[fe]/(\w+)", baseUrl)
            if not mediaId:
                return []
            # ids are the same on every mixdrop domain; old ones are parked (.co, .vc, ...), mixdrop.ag redirects to the live one
            url = "https://mixdrop.ag/e/%s" % mediaId.group(1)
            HTTP_HEADER = self.cm.getDefaultHeader()
            HTTP_HEADER.update({"Referer": "https://mixdrop.ag/", "Origin": "https://mixdrop.ag"})
            urlParams = {"header": HTTP_HEADER}
            sts, data = self.cm.getPage(url, urlParams)
            if not sts:
                return []
            url = self.cm.meta.get("url", "") or url
            redirect = re.search(r"""location\s*=\s*["'](/[^'"]+)""", data)
            if redirect:
                url = urljoin(url, redirect.group(1))
                sts, data = self.cm.getPage(url, urlParams)
                if not sts:
                    return []
            if "(p,a,c,k,e,d)" in data:
                data = get_packed_data(data) or data
            src = re.search(r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)', data)
            if not src:
                if re.search(r"can(?:'|&#0?39;)t find the (?:video|file)", data):
                    # download-only uploads (e.g. .ts recordings) and deleted files have no embed
                    SetIPTVPlayerLastHostError(_("MixDrop: this file is not available as a video stream (deleted or download only)."))
                return []
            src = src.group(1)
            if src.startswith("//"):
                src = "https:" + src
            return [{"name": "MP4", "url": urlparser.decorateUrl(src, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": url})}]

