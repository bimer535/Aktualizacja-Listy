# SPDX-License-Identifier: GPL-3.0-only
"""Unchanged source routing from MK PremiumSmart E2 0.1.1."""
import urllib.parse
import catalogue, resolver, access_cache
from other_sources import OtherSources

def source_options(client,item):
    resolver.ACTIVE_HTTP=client
    values=catalogue.videos(client,item)
    selected=next((value for value in values if value.get('id')==item.get('video_id') and item.get('video_id') is not None),None)
    if selected is None:
        selected=next((value for value in values if catalogue.provider(value)==item.get('provider') and (not item.get('source_language') or value.get('language_type')==item['source_language'])),None)
    if selected is None:raise resolver.ResolveError('player_source_not_found')
    current=urllib.parse.urljoin(catalogue.BASE,selected['src'])
    current=resolver.checked_url(current)
    provider=catalogue.provider(selected)
    if provider=='byse':
        engine=resolver.Byse(client);engine.BYSE_ACCESS=access_cache.load()
        try:result=engine.parserBYSE(resolver.URL(current,{'Referer':catalogue.BASE}))
        finally:
            try:access_cache.save(engine.BYSE_ACCESS)
            except OSError:pass
    elif provider in ('voe','mix','streamtape','vidara','vidsst','abyss'):
        parser=OtherSources(client)
        method={'voe':parser.parserVOESX,'mix':parser.parserMIXDROP,'streamtape':parser.parserSTREAMTAPE,
                'vidara':parser.parserSTREAMUP,'vidsst':parser.parserVIDSST,'abyss':parser.parserABYSS}[provider]
        result=method(resolver.URL(current,{'Referer':catalogue.BASE}))
    else:
        path=urllib.parse.urlsplit(current).path.lower()
        if path.endswith('.m3u8'):
            result=resolver.hls_options(client,resolver.URL(current,{'Referer':catalogue.BASE}))
        elif path.endswith(('.mp4','.mkv','.webm')):
            result=[{'name':'Video','url':resolver.URL(current,{'Referer':catalogue.BASE})}]
        else:result=OtherSources(client).parserSST(resolver.URL(current,{'Referer':catalogue.BASE}))
    if not result:
        if client.meta.get('status_code')==403:raise resolver.ResolveError('source_access_denied')
        if client.meta.get('status_code',0)>=500:raise resolver.ResolveError('source_temporarily_unavailable')
        raise resolver.ResolveError('source_returned_no_variants')
    for option in result:
        meta=dict(getattr(option['url'],'meta',{}));meta.setdefault('User-Agent',client.getDefaultHeader()['User-Agent']);meta.setdefault('Referer',current)
        option['url']=resolver.URL(option['url'],meta)
    return result

