# SPDX-License-Identifier: GPL-3.0-only
"""Standalone PremiumSmart catalogue, based on the public E2i API flow."""
import base64
from datetime import date
import html
import json
import re
from urllib.parse import urljoin,urlsplit,urlencode,quote

BASE='https://premiumsmart.eu/'
API=BASE+'api/v1/'
LANGUAGES=('Lektor PL','Lektor AI','PL','Dubbing','CAM')
ORDERS=(('Najnowsze dodane','created_at:desc'),('Najnowszy rocznik','release_date:desc'),('Najwyżej oceniane','rating:desc'),('Najpopularniejsze','popularity:desc'))


def item(title,action,**kwargs):return dict(title=title,action=action,**kwargs)
def clean(value):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',str(value or '')))).strip()


def menu():
    return [item('Filmy','categories',kind='filmy'),item('Seriale','categories',kind='seriale'),item('Kontynuuj oglądanie','continue'),item('Ulubione','favourites'),item('Wyszukaj','search'),item('Historia wyszukiwania','history')]


def api(client,path):
    url=path if path.startswith('https://') else API+path
    parsed=urlsplit(url)
    if parsed.scheme!='https' or parsed.netloc!='premiumsmart.eu' or not parsed.path.startswith('/api/v1/'):raise ValueError('invalid_catalogue_address')
    for attempt in range(2):
        ok,body=client.getPage(url,{'header':{'Accept':'application/json, text/plain, */*','Referer':BASE}})
        if ok:
            try:
                value=json.loads(body)
                if isinstance(value,dict):return value
            except ValueError:pass
        status=client.meta.get('status_code')
        if status==403:raise ValueError('catalogue_access_denied')
        if attempt==0:client.getPage(BASE)  # Anonymous session cookie set by the public homepage.
    raise ValueError('catalogue_session_required' if status==401 else 'catalogue_http_error')


def icon(url):
    value=urljoin(BASE,str(url or ''))
    return value.replace('/original/','/w500/') if value.startswith('https://image.tmdb.org/t/p/original/') else value


def title_entry(value):
    if not isinstance(value,dict) or not value.get('id') or not value.get('name'):return None
    title=clean(value['name']);year=str(value.get('year') or value.get('release_date') or '')[:4]
    language=clean((value.get('primary_video') or {}).get('language_type',''));desc=clean(value.get('description',''));extra={}
    try:
        rating=float(value.get('rating'))
        if 0<=rating<=10:extra={'rating':rating,'rating_label':'Ocena: %s/10'%('%g'%rating).replace('.',',')}
    except (ValueError,TypeError):pass
    return item(title+(' ('+year+')' if year else ''),'seasons' if value.get('is_series') else 'sources',url=API+'titles/'+str(int(value['id'])),title_id=int(value['id']),series_title=title,year=year,language_version=language,icon=icon(value.get('poster')),desc=' · '.join(x for x in (year,language,extra.get('rating_label')) if x)+'\n'+desc,synopsis=desc,**extra)


def pages(client,path,per_page=100):
    result=[];seen=set();page=1
    for _ in range(50):
        if page in seen:break
        seen.add(page);data=api(client,path+'?'+urlencode({'perPage':per_page,'page':page}))
        pagination=data.get('pagination') or {};result.extend(pagination.get('data') or []);page=pagination.get('next_page')
        if not page:break
    return result


def title_id_of(current):
    match=re.search(r'/titles/(\d+)',current.get('series_url') or current.get('url',''))
    if not match:raise ValueError('invalid_title_id')
    return int(match[1])


def seasons(client,current):
    title_id=title_id_of(current);result=[]
    for value in sorted(pages(client,'titles/%s/seasons'%title_id,30),key=lambda s:int(s.get('number') or 0)):
        if value.get('number') is None or not value.get('available_episodes_count',1):continue
        number=str(int(value['number']))
        result.append(dict(current,title='Sezon '+number,action='episodes',season=number,series_url=API+'titles/'+str(title_id),icon=icon(value.get('poster')) if value.get('poster') else current.get('icon','')))
    return result


def episodes(client,current):
    title_id=title_id_of(current);season=str(int(current['season']));result=[]
    for value in sorted(pages(client,'titles/%s/seasons/%s/episodes'%(title_id,season)),key=lambda s:int(s.get('episode_number') or 0)):
        number=value.get('episode_number')
        if not number or value.get('has_sources') is False:continue
        title='%s — S%02dE%02d'%(current.get('series_title','Serial'),int(season),int(number))
        if value.get('name'):title+=' · '+clean(value['name'])
        result.append(dict(current,title=title,action='sources',episode=int(number),url=API+'titles/%s/seasons/%s/episodes/%s'%(title_id,season,number),series_url=API+'titles/'+str(title_id),synopsis=clean(value.get('description')),icon=icon(value.get('poster')) if value.get('poster') else current.get('icon','')))
    return result


def videos(client,current):
    data=api(client,current['url'])
    return [v for v in (data.get('episode') or data.get('title') or {}).get('videos',[]) if isinstance(v,dict) and (v.get('category') or 'full')=='full' and v.get('src')]


def provider(value):
    name=clean(value.get('name','')).lower();host=(urlsplit(value.get('src','')).hostname or '').lower()
    if name=='vidara' or 'vidara' in host:return 'vidara'
    if name=='byse' or any(term in host for term in ('byse','mfw09')):return 'byse'
    if name=='vidsst' or host=='vids.st':return 'vidsst'
    if name=='abyss' or 'abyssplayer' in host or 'abysscdn' in host:return 'abyss'
    if 'voe' in name or 'voe.sx' in host:return 'voe'
    if 'mix' in name or 'mixdrop' in host or 'mxdrop' in host:return 'mix'
    if 'streamtape' in name or 'streamtape' in host:return 'streamtape'
    return 'other'


def source_items(client,current):
    result=[]
    for index,value in enumerate(videos(client,current)):
        kind=provider(value);language=clean(value.get('language_type',''));selected=current.get('version','')
        if selected and language!=selected:continue
        label=' · '.join(x for x in (language,clean(value.get('name')) or kind,clean(value.get('quality'))) if x)
        result.append(dict(current,title=label or 'Źródło',movie_title=current.get('title','Film'),action='resolve',provider=kind,video_id=value.get('id'),provider_index=index,source_language=language))
    return sorted(result,key=lambda v:((0 if v.get('source_language')=='Lektor PL' else 1),('byse','vidara','voe','mix','streamtape','vidsst','abyss','other').index(v['provider'])))


def listing_path(current):
    kind=current.get('kind','filmy')
    if kind not in ('filmy','seriale'):raise ValueError('invalid_catalogue_kind')
    query={'perPage':40,'order':current.get('order','created_at:desc'),'page':max(1,int(current.get('page',1)))}
    if query['order'] not in dict(ORDERS).values():raise ValueError('invalid_sort')
    filters=[]
    if current.get('year'):
        year=int(current['year'])
        if not 1900<=year<=date.today().year+5:raise ValueError('invalid_year')
        filters.append({'key':'release_date','operator':'between','value':{'start':'%04d-01-01T00:00:00.000Z'%year,'end':'%04d-12-31T23:59:59.999Z'%year}})
    if filters:query['filters']=quote(base64.b64encode(json.dumps(filters,separators=(',',':')).encode()).decode(),safe='')
    return 'channel/'+kind+'?'+urlencode(query)


def browse(client,current):
    action=current.get('action','main')
    if action=='main':return menu()
    if action=='categories':return [dict(current,title='Wszystkie wersje',action='years',version='')]+[dict(current,title=('Preferuj: ' if current.get('kind')=='seriale' else '')+value,action='years',version=value) for value in LANGUAGES]
    if action=='years':return [dict(current,title='Wszystkie roczniki',action='sort',year='')]+[dict(current,title=str(y),action='sort',year=str(y)) for y in range(date.today().year,1899,-1)]
    if action=='sort':return [dict(current,title=title,action='movies',order=order,page=1) for title,order in ORDERS]
    if action in ('movies','page'):
        selected=current.get('version','');page=max(1,int(current.get('page',1)));result=[];seen=set()
        if selected and selected not in LANGUAGES:raise ValueError('invalid_language_version')
        # The site supports release-date filtering, but not language_type on
        # channels. Apply its primary-video label across consecutive pages.
        for _ in range(8):
            if page in seen:break
            seen.add(page)
            data=api(client,listing_path(dict(current,page=page)));content=(data.get('channel') or {}).get('content') or {}
            for value in content.get('data') or []:
                entry=title_entry(value)
                if entry and (not selected or entry['action']=='seasons' or entry['language_version']==selected):
                    entry['version']=selected;result.append(entry)
            page=content.get('next_page')
            if not page or len(result)>=40 or not selected:break
        if page and page not in seen:result.append(dict(current,title='Następna strona',action='page',page=int(page)))
        return result
    if action=='search_results':
        data=api(client,'search/'+quote(current['query'].strip(),safe='')+'?limit=50')
        return [entry for v in data.get('results') or [] if v.get('model_type','title')=='title' and (entry:=title_entry(v))]
    if action=='seasons':return seasons(client,current)
    if action=='episodes':return episodes(client,current)
    if action=='sources':
        result=source_items(client,current)
        if not result and current.get('version'):raise ValueError('language_version_unavailable')
        return result
    if action=='next_episode':
        for season in seasons(client,dict(current,url=current['series_url'])):
            if int(season['season'])<int(current['season']):continue
            for episode in episodes(client,season):
                if (int(episode['season']),int(episode['episode']))>(int(current['season']),int(current['episode'])):return [episode]
        return []
    raise ValueError('unknown_catalogue_action')
