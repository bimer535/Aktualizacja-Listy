import pl.mk.premiumsmart.tv.Pow;
public class PowCheck { public static void main(String[] args) {
 for(String s:args)System.out.println(Pow.zeroBits(s));
 System.out.println("found="+Pow.find("example",0,256,8));
 Pow.cancel();System.out.println("cancel="+Pow.find("example",0,256,32));
}}