from pathlib import Path
import ast,struct,time
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_PROT_ALL,UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_PC,UC_ARM_REG_C1_C0_2,UC_ARM_REG_FPEXC
ROOT=Path(__file__).resolve().parents[1]
file=ROOT/'src/MKPremiumSmartE2/libmkpremiumsmart_pow_armv7.so'
base,stack,buffer,stop=0x100000,0x200000,0x300000,0x400000
uc=Uc(UC_ARCH_ARM,UC_MODE_ARM)
for address,size in [(base,0x100000),(stack,0x100000),(buffer,0x10000),(stop,0x1000)]:uc.mem_map(address,size,UC_PROT_ALL)
with file.open('rb') as stream:
 elf=ELFFile(stream)
 for segment in elf.iter_segments():
  if segment['p_type']=='PT_LOAD':uc.mem_write(base+segment['p_vaddr'],segment.data())
 symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.dynsym').iter_symbols()}
uc.reg_write(UC_ARM_REG_C1_C0_2,uc.reg_read(UC_ARM_REG_C1_C0_2)|0xF00000)
uc.reg_write(UC_ARM_REG_FPEXC,0x40000000)
def hook(uc,address,size,_):
 if address==stop:uc.emu_stop()
uc.hook_add(UC_HOOK_CODE,hook)
def invoke(name,data,*args):
 uc.mem_write(buffer,data)
 uc.reg_write(UC_ARM_REG_SP,stack+0xF0000);uc.reg_write(UC_ARM_REG_LR,stop)
 for reg,val in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],[buffer,len(data),*args]):uc.reg_write(reg,val)
 if len(args)>2:uc.mem_write(stack+0xF0000,struct.pack('<I',args[2]))
 uc.emu_start(base+symbols[name],stop,timeout=20_000_000,count=25_000_000)
 if uc.reg_read(UC_ARM_REG_PC)!=stop:raise AssertionError('Emulation did not return')
 return uc.reg_read(UC_ARM_REG_R0)
root=ast.parse((ROOT/'reference/public_byse_method.txt').read_text())
nodes=[n for n in ast.walk(root) if isinstance(n,ast.FunctionDef) and n.name in ('grAbsorb','gr','powBytes')]
space={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'public_hash','exec'),space)
for value in ['example:0','abc:12','x:123','n'*64+':999']+[f'arm-vector:{i}' for i in range(12)]:
 expected=space['gr']((1779033703,3144134277,1013904242,2773480762),list(value.encode()))
 got=invoke('mk_pow_zero_bits',value.encode());assert got==expected,(value,got,expected)
expected=next(i for i in range(256) if space['gr'](space['grAbsorb'](list(b'arm-search:')),list(str(i).encode()))>=4)
assert invoke('mk_pow_find',b'arm-search',0,256,4)==expected
print('PASS: ARM library matches public Python hash on 16 vectors and proof search; expected solution',expected)
