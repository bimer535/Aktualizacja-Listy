#!/usr/bin/env python3
"""Background catalogue/resolver worker; only constructed events reach the GUI."""
import argparse
import html
import json
import os
from pathlib import Path
import re
import signal
import ssl
import tempfile
import time
import urllib.parse
import urllib.error

import catalogue
import access_cache
import resolver
from watchstate import preferred_variant
from relay import Relay
from other_sources import OtherSources

REPORT=Path('/tmp/mk_premiumsmart_report.json')


def emit(stage,**fields):
    print(json.dumps(dict(stage=stage,**fields),ensure_ascii=False),flush=True)


def atomic(path,data):
    fd,name=tempfile.mkstemp(prefix='mk-premiumsmart-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:json.dump(data,out,ensure_ascii=False)
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def source_options(client,item):
    resolver.ACTIVE_HTTP=client
    values=catalogue.videos(client,item)
    selected=next((value for value in values if value.get('id')==item.get('video_id') and item.get('video_id') is not None),None)
    if selected is None:
        selected=next((value for value in values if catalogue.provider(value)==item.get('provider') and (not item.get('source_language') or value.get('language_type')==item['source_language'])),None)
    if selected is None:raise resolver.ResolveError('player_source_not_found')
    current=urllib.parse.urljoin(catalogue.BASE,selected['src'])
    current=resolver.checked_url(current)
    provider=catalogue.provider(selected)
    if provider=='byse':
        engine=resolver.Byse(client);engine.BYSE_ACCESS=access_cache.load()
        try:result=engine.parserBYSE(resolver.URL(current,{'Referer':catalogue.BASE}))
        finally:
            try:access_cache.save(engine.BYSE_ACCESS)
            except OSError:pass
    elif provider in ('voe','mix','streamtape','vidara','vidsst','abyss'):
        parser=OtherSources(client)
        method={'voe':parser.parserVOESX,'mix':parser.parserMIXDROP,'streamtape':parser.parserSTREAMTAPE,
                'vidara':parser.parserSTREAMUP,'vidsst':parser.parserVIDSST,'abyss':parser.parserABYSS}[provider]
        result=method(resolver.URL(current,{'Referer':catalogue.BASE}))
    else:
        path=urllib.parse.urlsplit(current).path.lower()
        if path.endswith('.m3u8'):
            result=resolver.hls_options(client,resolver.URL(current,{'Referer':catalogue.BASE}))
        elif path.endswith(('.mp4','.mkv','.webm')):
            result=[{'name':'Video','url':resolver.URL(current,{'Referer':catalogue.BASE})}]
        else:result=OtherSources(client).parserSST(resolver.URL(current,{'Referer':catalogue.BASE}))
    if not result:
        if client.meta.get('status_code')==403:raise resolver.ResolveError('source_access_denied')
        if client.meta.get('status_code',0)>=500:raise resolver.ResolveError('source_temporarily_unavailable')
        raise resolver.ResolveError('source_returned_no_variants')
    for option in result:
        meta=dict(getattr(option['url'],'meta',{}));meta.setdefault('User-Agent',client.getDefaultHeader()['User-Agent']);meta.setdefault('Referer',current)
        option['url']=resolver.URL(option['url'],meta)
    return result


def label(option,index):
    language={'pl':'Polski','pol':'Polski','en':'English','eng':'English'}.get(option.get('language'),option.get('language') or 'Auto')
    if option.get('width') and option.get('height'):
        return '[%s] bitrate: %s res: %sx%s %s' % (language,option.get('bitrate',0),option['width'],option['height'],option.get('codecs',''))
    return '[%s] %s' % (language,option.get('name') or ('Wariant %d' % (index+1)))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--request',type=Path,required=True)
    parser.add_argument('--result',type=Path,required=True)
    parser.add_argument('--control',type=Path,required=True)
    args=parser.parse_args()
    def stop(*_):raise KeyboardInterrupt
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    relay=None;client=resolver.Http();stage='prepare';item={}
    try:
        request=json.loads(args.request.read_text())
        item=request['item']
        if item['action']!='resolve':
            stage='catalogue';emit(stage)
            entries=catalogue.browse(client,item)
            atomic(args.result,{'items':entries});emit('catalogue_ready',count=len(entries));return 0
        stage='resolve';emit(stage)
        options=source_options(client,item)
        if not options:raise resolver.ResolveError('source_returned_no_variants')
        if item.get('auto_quality'):
            selection=preferred_variant(options)
            emit('variant_selected',language=options[selection].get('language','Auto'),height=options[selection].get('height',0))
        else:
            atomic(args.result,{'variants':[label(v,i) for i,v in enumerate(options)]})
            emit('choose_variant',count=len(options))
            deadline=time.monotonic()+900
            selection=None
            while time.monotonic()<deadline:
                if args.control.is_file():
                    choice=json.loads(args.control.read_text())
                    selection=choice.get('index');break
                time.sleep(.2)
        if isinstance(selection,bool) or not isinstance(selection,int) or not 0<=selection<len(options):
            raise resolver.ResolveError('variant_selection_cancelled')
        stage='playback_relay';relay=Relay(options[selection],client)
        # The native Enigma2 player receives only a loopback URL.
        emit('play_ready',url=relay.url)
        atomic(REPORT,{'status':'RELAY_READY','version':'0.1.2','requests':client.steps,
                       'source_provider':item.get('provider',''),'source_metrics':getattr(client,'source_metrics',{}),'video_playback_confirmed':False,'e2i_imported':False})
        while True:time.sleep(1)
    except KeyboardInterrupt:emit('cancelled');return 130
    except Exception as error:
        reason=str(error) if isinstance(error,(resolver.ResolveError,ValueError)) and re.fullmatch(r'[a-z_]{1,80}',str(error)) else type(error).__name__
        if isinstance(error,urllib.error.URLError):
            reason='source_tls_error' if isinstance(error.reason,ssl.SSLError) else 'source_connection_failed'
        elif isinstance(error,TimeoutError):reason='source_connection_failed'
        atomic(REPORT,{'status':'ERROR','version':'0.1.2','stage':stage,'reason':reason,'requests':client.steps,'source_provider':item.get('provider',''),'source_metrics':getattr(client,'source_metrics',{}),'e2i_imported':False})
        emit('error',reason=reason);return 1
    finally:
        if relay:relay.close()


if __name__=='__main__':raise SystemExit(main())
