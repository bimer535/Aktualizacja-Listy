import base64
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
from urllib.parse import parse_qs,urlsplit,unquote

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKPremiumSmartE2'))
import catalogue as c
import resolver
import worker
import watchstate
import poster
from other_sources import OtherSources


def title(number,language='Lektor PL',year=2020):
    return {'id':number,'name':'Tytuł '+str(number),'year':year,'is_series':False,
            'poster':'https://image.tmdb.org/t/p/original/example.jpg',
            'primary_video':{'language_type':language},'rating':7.5}


class Client:
    def __init__(self,responses):self.responses=list(responses);self.calls=[];self.meta={};self.steps=[]
    def getPage(self,url,params=None,post_data=None):
        self.calls.append((str(url),params));status,data=self.responses.pop(0)
        self.meta={'url':str(url),'status_code':status}
        return status==200,json.dumps(data) if isinstance(data,dict) else data
    def getDefaultHeader(self):return {'User-Agent':'test'}


class CatalogueTests(unittest.TestCase):
    def test_anonymous_session_cookie_bootstrap_retries_api_once(self):
        client=Client([(401,{}),(200,'<html>anonymous cookie set</html>'),(200,{'results':[]})])
        self.assertEqual(c.api(client,'search/test'),{'results':[]})
        self.assertEqual([v[0] for v in client.calls],[c.API+'search/test',c.BASE,c.API+'search/test'])
        blocked=Client([(403,'Forbidden')])
        with self.assertRaisesRegex(ValueError,'catalogue_access_denied'):c.api(blocked,'channel/filmy')
        self.assertEqual(len(blocked.calls),1)

    def test_year_uses_real_release_date_range_and_filter_encoding(self):
        path=c.listing_path({'kind':'filmy','year':'2020','order':'release_date:desc','version':'Lektor PL'})
        query=parse_qs(urlsplit(path).query)
        filters=json.loads(base64.b64decode(unquote(query['filters'][0])))
        self.assertEqual(filters,[{'key':'release_date','operator':'between','value':{'start':'2020-01-01T00:00:00.000Z','end':'2020-12-31T23:59:59.999Z'}}])
        self.assertNotIn('language_type',str(filters))  # Site rejects that channel filter.

    def test_language_filter_spans_pages_and_keeps_ai_separate(self):
        client=Client([(200,{'channel':{'content':{'data':[title(1,'Lektor AI')],'next_page':2}}}),
                       (200,{'channel':{'content':{'data':[title(2),title(3,'Dubbing')],'next_page':None}}})])
        entries=c.browse(client,{'action':'movies','kind':'filmy','version':'Lektor PL','year':'2020'})
        self.assertEqual([e['title_id'] for e in entries],[2]);self.assertEqual(len(client.calls),2)
        self.assertEqual(entries[0]['version'],'Lektor PL')

    def test_bounded_scan_has_next_button_even_if_no_matching_versions_yet(self):
        responses=[(200,{'channel':{'content':{'data':[title(i,'Dubbing')],'next_page':i+2}}}) for i in range(8)]
        result=c.browse(Client(responses),{'action':'movies','kind':'filmy','version':'Lektor AI'})
        self.assertEqual(result,[{'action':'page','kind':'filmy','version':'Lektor AI','title':'Następna strona','page':9}])

    def test_sources_keep_selected_language_and_skip_trailers(self):
        videos=[{'id':1,'src':'https://byse.example/e/a','name':'Byse','language_type':'Lektor AI'},
                {'id':2,'src':'https://byse.example/e/b','name':'Byse','language_type':'Lektor PL'},
                {'id':3,'src':'https://youtube.com/embed/a','category':'trailer','name':'Trailer'}]
        result=c.source_items(Client([(200,{'title':{'videos':videos}})]),dict(c.title_entry(title(10)),version='Lektor PL'))
        self.assertEqual(len(result),1);self.assertEqual(result[0]['video_id'],2)
        self.assertNotIn('src',result[0]);self.assertNotIn('byse.example',str(result[0]))

    def test_series_and_next_episode_use_paginated_seasons_and_episode_numbers(self):
        current={'url':c.API+'titles/20','series_url':c.API+'titles/20','series_title':'Serial','season':'1','episode':1,'action':'next_episode'}
        client=Client([(200,{'pagination':{'data':[{'number':1}],'next_page':None}}),
                       (200,{'pagination':{'data':[{'episode_number':1,'name':'Pierwszy'},{'episode_number':2,'name':'Drugi','has_sources':True}],'next_page':None}})])
        result=c.browse(client,current)
        self.assertEqual(len(result),1);self.assertEqual(result[0]['episode'],2)
        self.assertTrue(result[0]['url'].endswith('/titles/20/seasons/1/episodes/2'))

    def test_worker_requeries_title_and_resolves_new_video_id_without_e2i(self):
        client=Client([(200,{'title':{'videos':[{'id':999,'name':'Byse','language_type':'Lektor PL','src':'https://bysetayico.com/e/test'}]}})])
        with patch.object(resolver.Byse,'parserBYSE',return_value=[{'url':resolver.URL('https://cdn.example/master.m3u8')}]),\
             patch.object(worker.access_cache,'save'),patch.object(worker.access_cache,'load',return_value={}):
            result=worker.source_options(client,{'url':c.API+'titles/20','provider':'byse','video_id':111,'source_language':'Lektor PL'})
        self.assertEqual(str(result[0]['url']),'https://cdn.example/master.m3u8')

    def test_streamtape_string_slicing_is_parsed_without_executing_scripts(self):
        client=Client([(200,"document.getElementById('robotlink').innerHTML = '//' + ('xxcdn.example/movie.mp4').substring(2);")])
        result=OtherSources(client).parserSTREAMTAPE(resolver.URL('https://streamtape.com/e/test'))
        self.assertEqual(str(result[0]['url']),'https://cdn.example/movie.mp4')
        malicious=Client([(200,"node.innerHTML = __import__('os').system('echo WRONG');")])
        self.assertEqual(OtherSources(malicious).parserSTREAMTAPE('https://streamtape.com/e/test'),[])

    def test_vidara_uses_its_json_api_instead_of_byse(self):
        value={'id':1,'name':'Vidara','src':'https://vidaraa.cc/file123','language_type':'Lektor PL'}
        client=Client([(200,{'title':{'videos':[value]}}),
                       (200,{'streaming_url':'https://cdn.example/movie.mp4'})])
        self.assertEqual(c.provider(value),'vidara')
        result=worker.source_options(client,{'url':c.API+'titles/20','provider':'vidara','video_id':1})
        self.assertEqual(client.calls[1][0],'https://vidaraa.cc/api/stream')
        self.assertEqual(str(result[0]['url']),'https://cdn.example/movie.mp4')
        self.assertEqual(result[0]['url'].meta['Referer'],'https://vidaraa.cc/')

    def test_vidsst_artplayer_mp4_and_hls_keep_required_headers(self):
        self.assertEqual(c.provider({'name':'VidsST','src':'https://vids.st/e/1'}),'vidsst')
        client=Client([(200,r'''const url = "https:\/\/cdn.example\/film.mp4";''')])
        result=OtherSources(client).parserVIDSST('https://vids.st/e/1')
        self.assertEqual(str(result[0]['url']),'https://cdn.example/film.mp4')
        self.assertEqual(result[0]['url'].meta['Origin'],'https://vids.st')
        client=Client([(200,'const url = "https://cdn.example/master.m3u8";')])
        with patch('other_sources.getDirectM3U8Playlist',return_value=['HLS']) as hls:
            self.assertEqual(OtherSources(client).parserVIDSST('https://vids.st/e/1'),['HLS'])
            self.assertEqual(hls.call_args.args[0].meta['Referer'],'https://vids.st/e/1')

    def test_abyss_payload_and_unavailable_streamtape(self):
        payload={'media':{'mp4':{'sources':[{'label':'1080p','file':'https://cdn.example/film.mp4'}]}}}
        body='const datas = "'+base64.b64encode(json.dumps(payload).encode()).decode()+'";'
        result=OtherSources(Client([(200,body)])).parserABYSS('https://player.abyssplayer.com/example')
        self.assertEqual(str(result[0]['url']),'https://cdn.example/film.mp4')
        self.assertEqual(result[0]['height'],1080)
        self.assertEqual(result[0]['url'].meta['Referer'],'https://player.abyssplayer.com/')
        client=Client([(200,'<title>Site Unavailable</title>')])
        with self.assertRaisesRegex(resolver.ResolveError,'source_temporarily_unavailable'):
            OtherSources(client).parserSTREAMTAPE('https://streamtape.com/e/example')

    def test_library_and_posters_are_independent_from_ekino(self):
        with tempfile.TemporaryDirectory() as folder:
            library=watchstate.Library(Path(folder)/'library.json');entry=c.title_entry(title(30));entry['version']='Lektor PL'
            library.record(entry,180,1200);library.toggle(entry)
            self.assertEqual(library.favourites()[0]['version'],'Lektor PL')
            self.assertEqual(library.continuing()[0]['url'],c.API+'titles/30')
        self.assertEqual(poster.valid_url(entry['icon']),'https://image.tmdb.org/t/p/w500/example.jpg')
        with self.assertRaises(ValueError):poster.valid_url('https://image.tmdb.org/other/example.jpg')


if __name__=='__main__':unittest.main()
