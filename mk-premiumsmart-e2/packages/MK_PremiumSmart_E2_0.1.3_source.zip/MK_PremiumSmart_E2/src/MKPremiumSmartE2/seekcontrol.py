# SPDX-License-Identifier: GPL-3.0-only
"""Time jumps for OpenPLi/OpenATV MoviePlayer, without speed/trick-mode calls."""
import time

PTS = 90000
_LOADED_KEYMAPS = set()


class StreamSeekMixin:
    def mk_init_seek_controls(self, keymap_path, context):
        from Components.ActionMap import ActionMap
        import keymapparser
        filename = str(keymap_path)
        if filename not in _LOADED_KEYMAPS:
            keymapparser.readKeymap(filename)
            _LOADED_KEYMAPS.add(filename)
        self._mk_seek_target = None
        self._mk_seek_observed = None
        self._mk_seek_at = float('-inf')
        self._mk_seek_notice_at = float('-inf')
        self['mkSeekActions'] = ActionMap([context], {
            'consume': self.mk_seek_consume,
            'left': self.mk_seek_back,
            'right': self.mk_seek_forward,
            'seekBack': self.mk_seek_back,
            'seekFwd': self.mk_seek_forward,
            'seekBackManual': self.mk_seek_back_long,
            'seekFwdManual': self.mk_seek_forward_long,
            'SeekbarBack': self.mk_seek_back_long,
            'SeekbarFwd': self.mk_seek_forward_long,
        }, -15)

    def mk_seek_consume(self):
        return 1

    def mk_seek_back(self):
        return self.mk_jump(-10)

    def mk_seek_forward(self):
        return self.mk_jump(10)

    def mk_seek_back_long(self):
        return self.mk_jump(-60)

    def mk_seek_forward_long(self):
        return self.mk_jump(60)

    @staticmethod
    def _mk_valid_pts(result):
        if (isinstance(result, (tuple, list)) and len(result) >= 2 and
                result[0] == 0 and type(result[1]) is int and result[1] >= 0):
            return result[1]
        return None

    def _mk_seek_notice(self, text):
        now = time.monotonic()
        if now - self._mk_seek_notice_at < 8:
            return
        self._mk_seek_notice_at = now
        from Screens.MessageBox import MessageBox
        self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=5)

    def mk_jump(self, seconds):
        # Always consume mapped keys: returning 0 would fall back to the native
        # OpenPLi x2/x4 winding code which ServiceApp can reject.
        if getattr(self, 'mk_leaving', False):
            return 1
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            if seek is None or not (seek.isCurrentlySeekable() & 1):
                self._mk_seek_notice('To źródło lub odtwarzacz nie udostępnia przewijania. Spróbuj innego źródła lub odtwarzacza w MENU wtyczki.')
                return 1
            now = time.monotonic()
            try:
                position = self._mk_valid_pts(seek.getPlayPosition())
            except (AttributeError, TypeError, RuntimeError):
                position = None
            target = None
            delta = int(seconds) * PTS
            if position is not None:
                base = position
                # Native players acknowledge a seek before their position query
                # catches up. Consecutive key presses must accumulate, not all
                # seek to the same +10s point. Discard the pending point after 3s.
                if (self._mk_seek_target is not None and self._mk_seek_observed is not None and
                        now - self._mk_seek_at < 3 and
                        abs(position - self._mk_seek_observed) <= 2 * PTS and
                        abs(position - self._mk_seek_target) > 2 * PTS):
                    base = self._mk_seek_target
                target = max(0, base + delta)
                try:
                    length = self._mk_valid_pts(seek.getLength())
                except (AttributeError, TypeError, RuntimeError):
                    length = None
                if length is not None and length > 0:
                    # ServiceApp stops playback for targets beyond the duration.
                    target = min(target, max(0, length - PTS))
                delta = target - position
                if delta == 0:
                    return 1
                result = seek.seekTo(target)
                if result != 0:
                    result = seek.seekRelative(1 if delta > 0 else -1, abs(delta))
            else:
                result = seek.seekRelative(1 if delta > 0 else -1, abs(delta))
            if result != 0:
                self._mk_seek_target = None
                self._mk_seek_notice('Odtwarzacz odrzucił zmianę pozycji. To źródło może nie obsługiwać przewijania.')
                return 1
            self._mk_seek_target = target
            self._mk_seek_observed = position
            self._mk_seek_at = now
            # User navigation wins over an automatic resume still being retried.
            self.mk_resume = 0
            self.mk_seek_sent = False
            if getattr(self, 'seekstate', None) == self.SEEK_STATE_PAUSE:
                pause = service.pause()
                if pause is not None:
                    pause.pause()
            show = getattr(self, 'showAfterSeek', None) or getattr(self, 'show', None)
            if show:
                show()
        except (AttributeError, TypeError, RuntimeError, OverflowError, ValueError):
            self._mk_seek_target = None
            self._mk_seek_notice('Nie udało się zmienić pozycji filmu. Zaczekaj na rozpoczęcie odtwarzania lub wybierz inne źródło.')
        return 1
