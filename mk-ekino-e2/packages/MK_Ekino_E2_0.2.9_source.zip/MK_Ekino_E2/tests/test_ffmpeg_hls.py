"""Optional real HLS parser check; use MK_EKINO_FFPROBE for a current build."""
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock
import urllib.parse

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/MKEkinoE2'))
import relay
import resolver

FFPROBE=os.environ.get('MK_EKINO_FFPROBE')


@unittest.skipUnless(FFPROBE and shutil.which('ffmpeg'),'set MK_EKINO_FFPROBE and provide ffmpeg')
class FFmpegHLSTests(unittest.TestCase):
    def test_strict_hls_reader_accepts_ts_and_fragmented_mp4_through_relay(self):
        for container in ('mpegts','fmp4'):
            with self.subTest(container=container),tempfile.TemporaryDirectory() as directory:
                folder=Path(directory)
                subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=25',
                                '-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','2',
                                '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-hls_time','1',
                                '-hls_list_size','0','-hls_segment_type',container,str(folder/'test.m3u8')],
                               check=True,capture_output=True,timeout=20)
                # Reproduce a CDN using opaque/masked names for its fragments.
                text=(folder/'test.m3u8').read_text();resources={}
                for line in text.splitlines():
                    if line and not line.startswith('#'):
                        resources['masked'+str(len(resources))+'.css']=line
                for masked,original in resources.items():text=text.replace(original,masked)
                class Response(io.BytesIO):
                    code=200
                    def __init__(self,url):
                        self.url=url;name=Path(urllib.parse.urlsplit(url).path).name
                        data=text.encode() if name=='test.m3u8' else (folder/resources.get(name,name)).read_bytes()
                        super().__init__(data)
                        self.headers={'Content-Length':str(len(data)),
                                      'Content-Type':'application/vnd.apple.mpegurl' if name.endswith('.m3u8') else 'text/css'}
                    def geturl(self):return self.url
                client=Mock(opener=Mock(open=lambda request,**kwargs:Response(request.full_url)))
                server=relay.Relay({'name':'HLS','url':resolver.URL('https://cdn.example/test.m3u8')},client)
                try:
                    result=subprocess.run([FFPROBE,'-v','error','-show_entries','stream=codec_name,width,height',
                                           '-of','json',server.url],capture_output=True,text=True,timeout=15)
                    self.assertEqual(result.returncode,0,result.stderr.replace(server.token,'LOCAL_TOKEN'))
                    streams=json.loads(result.stdout)['streams']
                    self.assertEqual({stream['codec_name'] for stream in streams},{'h264','aac'})
                    self.assertTrue(any(stream.get('width')==320 for stream in streams))
                    self.assertGreater(server.snapshot()['media_bytes'],0)
                    self.assertEqual(server.snapshot()['errors'],0)
                finally:server.close()
