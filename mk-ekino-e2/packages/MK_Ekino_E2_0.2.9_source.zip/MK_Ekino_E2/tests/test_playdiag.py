import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/MKEkinoE2'))
import playdiag


class DiagnosticTests(unittest.TestCase):
    def test_native_text_and_credentials_are_not_saved(self):
        text='Invalid data found at https://example.org/PRIVATE_TOKEN/master.m3u8 Cookie=SECRET error: -1094995529'
        result=playdiag.error_summary(text)
        self.assertEqual(result['native_error_category'],'invalid_media')
        self.assertEqual(result['native_error_codes'],['-1094995529'])
        self.assertNotIn('PRIVATE_TOKEN',json.dumps(result))
        self.assertNotIn('SECRET',json.dumps(result))
        self.assertEqual(playdiag.error_summary(None),{'native_error_present':False})
        self.assertEqual(playdiag.error_summary(''),{'native_error_present':False})

    def test_report_is_atomic_private_and_write_failure_is_nonfatal(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'player.json'
            with patch.object(playdiag,'PATH',path):
                playdiag.write({'phase':'opening'})
                self.assertEqual(json.loads(path.read_text()),{'phase':'opening'})
                self.assertEqual(path.stat().st_mode&0o777,0o600)
                playdiag.write({'phase':'eof'})
                self.assertEqual(list(Path(name).iterdir()),[path])
            with patch.object(playdiag,'PATH',Path(name)/'missing'/'player.json'):
                playdiag.write({'phase':'eof'})
