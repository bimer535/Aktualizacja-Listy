#!/usr/bin/env python3
"""Regenerate the static contact QR; qrcode/Pillow are build-only dependencies."""
from pathlib import Path
import qrcode

ROOT=Path(__file__).resolve().parents[1]
qr=qrcode.QRCode(version=2,error_correction=qrcode.constants.ERROR_CORRECT_M,
                 box_size=8,border=4)
qr.add_data('mailto:bimer55@wp.pl');qr.make(fit=False)
qr.make_image(fill_color='black',back_color='white').convert('RGB').save(ROOT/'src/MKEkinoE2/contact_qr.png')
