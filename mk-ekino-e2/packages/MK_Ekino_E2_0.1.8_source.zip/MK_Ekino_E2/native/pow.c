/* SPDX-License-Identifier: GPL-3.0-only
 * MK, 2026. Native implementation of the public Byse proof-of-work hash.
 * Algorithm matches parserBYSE/grAbsorb/gr in the public E2iPlayer source.
 * No network, file access, allocation, global state or source credentials.
 */
#include <stdint.h>
#include <stddef.h>
#define ROL(v,n) (((v)<<(n))|((v)>>(32-(n))))
#define QR() do { a+=b; d^=a; d=ROL(d,16); c+=d; b^=c; b=ROL(b,12); \
                  a+=b; d^=a; d=ROL(d,8); c+=d; b^=c; b=ROL(b,7); } while(0)
static void absorb(uint32_t state[4], const unsigned char *data, size_t length) {
    uint32_t a=state[0],b=state[1],c=state[2],d=state[3];
    for(size_t i=0;i<length;i++) {
        a+=data[i]; a=ROL(a,7); a+=b; d^=a; d=ROL(d,16); c+=d; b^=c; b=ROL(b,12);
        a+=b; d^=a; d=ROL(d,8); c+=d; b^=c; b=ROL(b,7);
    }
    state[0]=a;state[1]=b;state[2]=c;state[3]=d;
}
static unsigned zeros(const uint32_t state[4],const unsigned char *tail,size_t length) {
    uint32_t st[4]={state[0],state[1],state[2],state[3]};absorb(st,tail,length);
    uint32_t a=st[0],b=st[1],c=st[2],d=st[3],r[512];
    for(unsigned i=0;i<8;i++) {QR();}
    for(unsigned i=0;i<512;i++) {QR();r[i]=a^c;}
    for(unsigned i=0;i<2;i++) for(unsigned s=0;s<512;s++) {
        uint32_t x=r[s];x+=r[x&511];x=ROL(x,13);x^=r[(s+1)&511]*UINT32_C(2654435761);
        r[s]=x;a^=x;QR();
    }
    unsigned result=0;
    for(unsigned i=0;i<512;i+=64) {
        QR();uint32_t s=a;
        for(unsigned j=i;j<i+64;j++) {s+=r[j];s=ROL(s,5);s^=r[j]*UINT32_C(2246822519);}
        s^=c;
        if(s) {while(!(s&UINT32_C(0x80000000))) {result++;s<<=1;}return result;}
        result+=32;
    }
    return result;
}
unsigned mk_pow_zero_bits(const unsigned char *input,uint32_t length) {
    const uint32_t initial[4]={1779033703U,3144134277U,1013904242U,2773480762U};
    return zeros(initial,input,length);
}
int64_t mk_pow_find(const unsigned char *nonce,uint32_t length,uint32_t start,uint32_t count,uint32_t difficulty) {
    if(length>4096 || count>4096 || difficulty>256) return -2;
    uint32_t st[4]={1779033703U,3144134277U,1013904242U,2773480762U};
    absorb(st,nonce,length);const unsigned char colon=':';absorb(st,&colon,1);
    for(uint32_t i=0;i<count;i++) {
        uint32_t value=start+i;if(value<start) return -2;
        unsigned char digits[10],reversed[10];unsigned len=0;
        do {reversed[len++]=(unsigned char)('0'+value%10);value/=10;} while(value);
        for(unsigned j=0;j<len;j++) digits[j]=reversed[len-1-j];
        if(zeros(st,digits,len)>=difficulty) return (int64_t)(start+i);
    }
    return -1;
}
