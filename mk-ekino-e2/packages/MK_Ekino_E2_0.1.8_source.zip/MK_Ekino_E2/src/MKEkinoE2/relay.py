"""Loopback-only HLS relay, preserving the chosen audio/video rendition."""
import re
import secrets
import threading
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import resolver


class Relay:
    def __init__(self, option, client):
        self.option=option
        self.client=client
        self.token=secrets.token_urlsafe(24)
        self.targets={};self.reverse={};self.lock=threading.RLock()
        self.headers={k:v for k,v in getattr(option['url'],'meta',{}).items()
                      if k in ('User-Agent','Referer','Origin')}
        self.headers['Accept-Encoding']='identity'
        owner=self
        class Handler(BaseHTTPRequestHandler):
            protocol_version='HTTP/1.0'
            def log_message(self,*args):pass
            def do_GET(self):owner.serve(self)
            def do_HEAD(self):owner.serve(self,head=True)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        self.port=self.server.server_port
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()

    def route(self,url):
        value=str(url)
        with self.lock:
            if value not in self.reverse:
                # A bounded VOD playlist may have thousands of segment URLs.
                if len(self.targets)>=100000:raise ValueError('relay_resource_limit')
                key=str(len(self.targets));self.targets[key]=value;self.reverse[value]=key
            return 'http://127.0.0.1:%d/%s/%s' % (self.port,self.token,self.reverse[value])

    @property
    def url(self):
        suffix='m3u8' if '.m3u8' in str(self.option['url']).lower() or getattr(self.option['url'],'meta',{}).get('video_url') else 'mp4'
        return 'http://127.0.0.1:%d/%s/master.%s' % (self.port,self.token,suffix)

    def master(self):
        option=self.option;meta=getattr(option['url'],'meta',{})
        if not meta.get('video_url'):return None
        lines=['#EXTM3U','#EXT-X-VERSION:6']
        audio=meta.get('audio_url')
        if audio:
            lang=option.get('language','')
            lines.append('#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="selected",NAME="%s",LANGUAGE="%s",DEFAULT=YES,AUTOSELECT=YES,URI="%s"' %
                         (lang or 'Audio',lang,self.route(audio)))
        attrs=['BANDWIDTH='+str(max(1,int(option.get('bitrate',0))))]
        if option.get('width') and option.get('height'):
            attrs.append('RESOLUTION=%dx%d' % (option['width'],option['height']))
        if option.get('codecs'):attrs.append('CODECS="'+option['codecs']+'"')
        if audio:attrs.append('AUDIO="selected"')
        lines.extend(['#EXT-X-STREAM-INF:'+','.join(attrs),self.route(meta['video_url'])])
        return ('\n'.join(lines)+'\n').encode()

    def rewrite(self,body,base):
        lines=[]
        for line in body.decode('utf-8-sig').splitlines():
            if line and not line.startswith('#'):
                line=self.route(urllib.parse.urljoin(base,line.strip()))
            elif line.startswith('#'):
                line=re.sub(r'URI="([^\"]+)"',lambda m:'URI="'+self.route(urllib.parse.urljoin(base,m[1]))+'"',line)
            lines.append(line)
        return ('\n'.join(lines)+'\n').encode()

    def serve(self,request,head=False):
        prefix='/'+self.token+'/'
        if not request.path.startswith(prefix):request.send_error(404);return
        key=request.path[len(prefix):]
        if key in ('master.m3u8','master.mp4'):
            data=self.master()
            if data is not None:
                request.send_response(200);request.send_header('Content-Type','application/vnd.apple.mpegurl')
                request.send_header('Content-Length',str(len(data)));request.end_headers()
                if not head:request.wfile.write(data)
                return
            target=str(self.option['url'])
        else:
            with self.lock:target=self.targets.get(key)
        if not target:request.send_error(404);return
        try:
            headers=dict(self.headers)
            if request.headers.get('Range'):headers['Range']=request.headers['Range']
            upstream=urllib.request.Request(resolver.checked_url(target),headers=headers,method='HEAD' if head else 'GET')
            with self.client.opener.open(upstream,timeout=25) as response:
                kind=response.headers.get('Content-Type','application/octet-stream')
                playlist=(urllib.parse.urlsplit(response.geturl()).path.lower().endswith('.m3u8') or 'mpegurl' in kind.lower())
                if playlist and not head:
                    raw=response.read(resolver.MAX_PAGE+1)
                    if len(raw)>resolver.MAX_PAGE:raise ValueError('playlist_too_large')
                    data=self.rewrite(raw,response.geturl())
                    request.send_response(200);request.send_header('Content-Type','application/vnd.apple.mpegurl')
                    request.send_header('Content-Length',str(len(data)));request.end_headers();request.wfile.write(data)
                else:
                    request.send_response(response.code)
                    for name in ['Content-Type','Content-Length','Content-Range','Accept-Ranges']:
                        if response.headers.get(name):request.send_header(name,response.headers[name])
                    request.end_headers()
                    if not head:
                        while True:
                            data=response.read(65536)
                            if not data:break
                            request.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:
            # Do not print request URLs or raw upstream exception text.
            try:request.send_error(502)
            except OSError:pass

    def close(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=2)
