#!/usr/bin/env python3
"""Check public Ekino source discovery independently of E2iPlayer.

Only normal public GET requests are made. No account files, browser cookies,
private E2i modules or video segments are read. URLs, cookies and page bodies
are not included in the report. No CAPTCHA or access restriction is bypassed.
"""
import argparse
import html
import http.cookiejar
import ipaddress
import json
import os
from pathlib import Path
import re
import ssl
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

BASE = 'https://ekino.ws/'
TITLE = BASE + 'movie/show/ponad-prawem-hd-by-any-means-2026-lektor/43152'
UA = ('Mozilla/5.0 (X11; Linux x86_64; rv:128.0) '
      'Gecko/20100101 Firefox/128.0')
MAX_BYTES = 2 * 1024 * 1024


class ProbeError(Exception):
    pass


def public_url(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username
            or parsed.password or parsed.port not in (None, 443)):
        raise ProbeError('unsupported_source_address')
    host = parsed.hostname.lower()
    if '.' not in host or host.endswith(('.localhost', '.local', '.internal')):
        raise ProbeError('source_address_not_public')
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ProbeError('source_address_not_public')
    return url


class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        public_url(newurl)
        return super().redirect_request(request, fp, code, message, headers, newurl)


def page_info(body, content_type=''):
    lower = body.lower()
    result = {
        'cloudflare_page': any(x in lower for x in (
            'attention required! | cloudflare', 'cf-chl-', 'challenge-platform')),
        'captcha_present': any(x in lower for x in ('turnstile', 'g-recaptcha', 'hcaptcha')),
        'manifest_type': '', 'video_options': [],
    }
    if '<mpd' in lower or 'application/dash+xml' in content_type:
        try:
            root = ET.fromstring(body)
            for node in root.iter():
                if node.tag.rsplit('}', 1)[-1] != 'Representation':
                    continue
                height = node.get('height', '')
                width = node.get('width', '')
                if height.isdigit() and width.isdigit():
                    item = {'width': int(width), 'height': int(height)}
                    if item not in result['video_options']:
                        result['video_options'].append(item)
            result['manifest_type'] = 'dash'
        except ET.ParseError:
            result['manifest_type'] = 'invalid_dash'
    elif body.lstrip().startswith('#EXTM3U'):
        result['manifest_type'] = 'hls'
        for width, height in re.findall(r'RESOLUTION=(\d+)x(\d+)', body):
            item = {'width': int(width), 'height': int(height)}
            if item not in result['video_options']:
                result['video_options'].append(item)
    elif content_type.startswith(('video/', 'audio/')):
        result['manifest_type'] = 'media'
    return result


def next_link(body, current):
    # Inspect the normal link/iframe chain without executing scripts.
    patterns = [
        r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*target=',
        r'<iframe\b[^>]*src=["\']([^"\']+)["\']',
        r'<source\b[^>]*src=["\']([^"\']+)["\']',
        r'["\'](?:file|src)["\']\s*:\s*["\']([^"\']+\.(?:mpd|m3u8)(?:\?[^"\']*)?)["\']',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, body, re.I):
            value = html.unescape(match.group(1)).replace('\\/', '/')
            target = urllib.parse.urljoin(current, value)
            if target != current and urllib.parse.urlsplit(target).scheme == 'https':
                return target
    return None


class Client:
    def __init__(self):
        jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=ssl.create_default_context()),
            urllib.request.HTTPCookieProcessor(jar), PublicRedirect())

    def get(self, url, referer=BASE):
        public_url(url)
        request = urllib.request.Request(url, headers={
            'User-Agent': UA, 'Referer': referer,
            'Accept': '*/*', 'Accept-Language': 'pl-PL,pl;q=0.9',
            'Accept-Encoding': 'identity'})
        try:
            response = self.opener.open(request, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            content_type = response.headers.get('Content-Type', '').lower()
            # Do not read movie data if an embed redirects directly to video.
            raw = b'' if content_type.startswith(('video/', 'audio/')) else response.read(MAX_BYTES + 1)
            if len(raw) > MAX_BYTES:
                raise ProbeError('page_too_large')
            body = raw.decode('utf-8-sig', 'replace')
            info = {'http_status': response.code,
                    'hostname': urllib.parse.urlsplit(response.geturl()).hostname,
                    'bytes_read': len(raw), **page_info(body, content_type)}
            return response.geturl(), body, info


def probe(client):
    report = {'status': 'CHECKED', 'e2i_imported': False,
              'account_files_read': False, 'video_playback_tested': False,
              'stream_urls_printed': False, 'sources': []}
    title_url, body, info = client.get(TITLE)
    report['title_page'] = info
    if info['http_status'] != 200 or info['cloudflare_page']:
        report['status'] = 'TITLE_BLOCKED'
        return report
    players = re.findall(r"ShowPlayer\(['\"]([^'\"]+)['\"],\s*['\"]([^'\"]+)['\"]\)", body)
    seen = set()
    for provider, key in players:
        if provider not in ('player', 'upzone') or (provider, key) in seen:
            continue
        seen.add((provider, key))
        if len(report['sources']) >= 2:
            break
        source = {'provider': provider, 'steps': []}
        report['sources'].append(source)
        current = BASE + 'watch/f/' + provider + '/' + urllib.parse.quote(key, safe='')
        referer = title_url
        visited = set()
        for index in range(4):
            if current in visited:
                break
            visited.add(current)
            try:
                final, body, step = client.get(current, referer)
            except (ProbeError, urllib.error.URLError, OSError) as error:
                source['reason'] = str(error) if isinstance(error, ProbeError) else type(error).__name__
                break
            source['steps'].append(step)
            if step['http_status'] != 200 or step['cloudflare_page'] or step['manifest_type']:
                break
            target = next_link(body, final)
            if not target:
                source['reason'] = 'no_plain_embed_or_manifest_link'
                break
            referer, current = final, target
    if not report['sources']:
        report['status'] = 'NO_MATCHING_SOURCES'
    elif all(not s['steps'] or s['steps'][0]['http_status'] != 200 for s in report['sources']):
        report['status'] = 'WATCH_BLOCKED'
    return report


def save_report(path, report):
    # Write only the constructed report; page bodies and cookies stay in memory.
    descriptor, name = tempfile.mkstemp(prefix='ekino-probe-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as output:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, default=Path('/tmp/mk_ekino_sources_report.json'))
    args = parser.parse_args()
    try:
        report = probe(Client())
    except Exception as error:
        report = {'status': 'ERROR', 'reason': str(error) if isinstance(error, ProbeError)
                  else type(error).__name__, 'account_files_read': False}
    save_report(args.report, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
