#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Standalone Ekino/Byse resolver diagnostic for Python 3, without E2iPlayer.

The parserBYSE method below is retained from the PUBLIC e2iplayer-2026.10.18.05
archive, IPTVPlayer/libs/urlparser.py. Existing source comments and credits
are preserved. Standalone adapters: MK, 2026-10-22. GPL-3.0 text is embedded
at the end of this file. No private PE2I code or E2i account data is used.
Only public source discovery and manifest inspection are performed, not video
playback or downloads. Cookies and transient source URLs stay in memory.
"""
import argparse
import base64
from binascii import hexlify
import hashlib
from hashlib import sha256
import html as html_lib
import http.cookiejar
import ipaddress
import json
import os
from os import urandom
from pathlib import Path
from random import uniform
import re
import ssl
import tempfile
import time
import urllib.error
import urllib.parse
from urllib.parse import urlsplit as urlparse
import urllib.request
import xml.etree.ElementTree as ET

BASE = 'https://ekino.ws/'
TITLE = BASE + 'movie/show/ponad-prawem-hd-by-any-means-2026-lektor/43152'
MAX_PAGE = 2 * 1024 * 1024
DEFAULT_UA = ('Mozilla/5.0 (X11; Linux x86_64; rv:128.0) '
              'Gecko/20100101 Firefox/128.0')


class ResolveError(Exception):
    pass


class URL(str):
    def __new__(cls, value, meta=None):
        result = str.__new__(cls, value)
        result.meta = dict(meta if meta is not None else getattr(value, 'meta', {}))
        return result


class Body(str):
    pass


def b64urlEncode(value, strip=False):
    value = value.encode() if isinstance(value, str) else value
    out = base64.urlsafe_b64encode(value).decode('ascii')
    return out.rstrip('=') if strip else out


def json_dumps(value):
    return json.dumps(value, separators=(',', ':'))


def json_loads(value):
    return json.loads(value)


def printDBG(*args, **kwargs):
    # Original debug messages may contain temporary source URLs: discard them.
    pass


def _(value):
    return value


LAST_HOST_ERROR = False


def SetIPTVPlayerLastHostError(*args):
    global LAST_HOST_ERROR
    LAST_HOST_ERROR = True


class Notify:
    last = 0
    def setStatus(self, text):
        now = time.monotonic()
        if now - self.last > 5:
            self.last = now
            print(json.dumps({'stage': 'source_access_work',
                              'account_files_read': False}), flush=True)


NOTIFY = Notify()


def GetIPTVNotify():
    return NOTIFY


def checked_url(url):
    value = str(url)
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or '').lower()
    if (parsed.scheme != 'https' or not host or parsed.username or parsed.password
            or parsed.port not in (None, 443) or '.' not in host
            or host.endswith(('.local', '.localhost', '.internal'))):
        raise ResolveError('unsupported_source_address')
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ResolveError('source_address_not_public')
    return value


class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Http:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=ssl.create_default_context()),
            urllib.request.HTTPCookieProcessor(self.jar), PublicRedirect())
        self.meta = {}
        self.steps = []

    def getDefaultHeader(self):
        return {'User-Agent': DEFAULT_UA, 'Accept-Encoding': 'identity', 'Accept': '*/*'}

    def getPage(self, url, params=None, post_data=None):
        params = params or {}
        headers = self.getDefaultHeader()
        headers.update(params.get('header', {}))
        payload = post_data.encode('utf-8') if isinstance(post_data, str) else post_data
        if isinstance(payload, dict):
            payload = urllib.parse.urlencode(payload).encode()
        request = urllib.request.Request(checked_url(url), data=payload, headers=headers)
        try:
            response = self.opener.open(request, timeout=min(params.get('timeout', 25), 40))
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read(MAX_PAGE + 1)
            if len(raw) > MAX_PAGE:
                raise ResolveError('source_response_too_large')
            body = Body(raw.decode('utf-8-sig', 'replace'))
            content_type = response.headers.get('Content-Type', '')
            self.meta = {'url': response.geturl(), 'status_code': response.code,
                         'content-type': content_type}
            body.meta = dict(self.meta)
            step = {'hostname': urllib.parse.urlsplit(response.geturl()).hostname,
                    'http_status': response.code, 'bytes_read': len(raw),
                    'request': 'POST' if payload is not None else 'GET'}
            # Endpoint categories, not video IDs, tokens, bodies or stream URLs.
            path = urllib.parse.urlsplit(str(url)).path
            for kind in ['captcha/verify', 'access/challenge', 'access/attest',
                         'playback', 'settings', 'details', 'captcha']:
                if path.endswith('/' + kind):
                    step['endpoint'] = kind
                    break
            if len(self.steps) < 40:
                self.steps.append(step)
            allowed = any(low <= response.code <= high
                          for low, high in params.get('ignore_http_code_ranges', []))
            return response.code == 200 or allowed, body


class urlparser:
    @staticmethod
    def getDomain(url, onlyDomain=True):
        parsed = urllib.parse.urlsplit(str(url))
        return parsed.netloc if onlyDomain else parsed.scheme + '://' + parsed.netloc + '/'

    @staticmethod
    def decorateUrl(url, meta):
        return URL(url, meta)


def attrs(line):
    return {k: quoted or unquoted for k, quoted, unquoted in re.findall(
        r'([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))(?:,|$)', line)}


def hls_options(client, url):
    ok, body = client.getPage(url, {'header': getattr(url, 'meta', {})})
    if not ok:
        raise ResolveError('manifest_http_error')
    if not body.lstrip().startswith('#EXTM3U'):
        raise ResolveError('manifest_not_hls')
    lines = body.splitlines()
    audio = {}
    for line in lines:
        if line.startswith('#EXT-X-MEDIA:'):
            item = attrs(line.split(':', 1)[1])
            if item.get('TYPE') == 'AUDIO':
                audio.setdefault(item.get('GROUP-ID', ''), []).append(item)
    result = []
    for i, line in enumerate(lines):
        if not line.startswith('#EXT-X-STREAM-INF:'):
            continue
        a = attrs(line.split(':', 1)[1])
        res = re.fullmatch(r'(\d+)x(\d+)', a.get('RESOLUTION', ''))
        resolution = (int(res[1]), int(res[2])) if res else (0, 0)
        bandwidth = int(a.get('BANDWIDTH', '0')) if a.get('BANDWIDTH', '0').isdigit() else 0
        video_uri = next((v.strip() for v in lines[i + 1:] if v.strip() and not v.startswith('#')), None)
        if not video_uri:
            continue
        renditions = audio.get(a.get('AUDIO', ''), []) or [{}]
        for track in renditions:
            language = track.get('LANGUAGE', '')
            if not re.fullmatch(r'[A-Za-z0-9_-]{0,16}', language):
                language = 'other'
            codec = a.get('CODECS', '')
            if not re.fullmatch(r'[A-Za-z0-9., _-]{0,120}', codec):
                codec = 'other'
            meta = dict(getattr(url, 'meta', {}))
            meta.update(language=language, video_url=urllib.parse.urljoin(url, video_uri),
                        audio_url=urllib.parse.urljoin(url, track['URI']) if track.get('URI') else '')
            result.append({'name': 'HLS', 'url': URL(url, meta),
                           'width': resolution[0], 'height': resolution[1],
                           'bitrate': bandwidth, 'language': language, 'codecs': codec})
    return result or [{'name': 'HLS', 'url': url, 'width': 0, 'height': 0,
                       'bitrate': 0, 'language': '', 'codecs': ''}]


ACTIVE_HTTP = None


def getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999):
    return hls_options(ACTIVE_HTTP, url)


class python_aesgcm:
    @staticmethod
    def new(key):
        from Crypto.Cipher import AES
        class Cipher:
            def open(self, iv, payload):
                if len(payload) < 16:
                    raise ResolveError('invalid_playback_payload')
                return AES.new(key, AES.MODE_GCM, nonce=iv).decrypt_and_verify(payload[:-16], payload[-16:])
        return Cipher()


ECDSA_NIST256p = None


class ECDSA_SigningKey:
    @staticmethod
    def generate(curve=None, hashfunc=None):
        from Crypto.PublicKey import ECC
        from Crypto.Signature import DSS
        from Crypto.Hash import SHA256
        key = ECC.generate(curve='P-256')
        class Verifying:
            def to_string(self):
                return int(key.pointQ.x).to_bytes(32, 'big') + int(key.pointQ.y).to_bytes(32, 'big')
        class Signing:
            verifying_key = Verifying()
            def sign(self, value, hashfunc=None):
                return DSS.new(key, 'fips-186-3', encoding='binary').sign(SHA256.new(value))
        return Signing()


class Byse:
    BYSE_ACCESS = {}
    def __init__(self, client):
        self.cm = client

    def parserBYSE(self, baseUrl):  # fix 240826 - captcha/proof-of-work challenge support
            UA = "Mozilla/5.0 (Linux; Android 10; TX6s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

            def fp(x, y, z):  # thx Gujal00
                v_id = hexlify(urandom(x)).decode()
                d_id = hexlify(urandom(x)).decode()
                ctime = int(time.time())
                t_data = {"viewer_id": v_id, "device_id": d_id, "confidence": round(uniform(y, z), 2), "iat": ctime, "exp": ctime + 600}
                t_bdata = b64urlEncode(json_dumps(t_data), strip=True)
                t_sig = b64urlEncode(sha256(t_bdata.encode()).digest(), strip=True)
                token = "{0}.{1}".format(t_bdata, t_sig)
                t_data.update({"token": token})
                t_data.pop("iat")
                t_data.pop("exp")
                return {"fingerprint": t_data}

            def ft(e):
                t = e.replace("-", "+").replace("_", "/")
                r = 0 if len(t) % 4 == 0 else 4 - len(t) % 4
                n = t + "=" * r
                return base64.b64decode(n)

            def xn(e, v):
                if v:
                    v = int(v)
                    if 0 < v <= len(e):
                        e = [e[v - 1], e[len(e) - v]]
                t = list(map(ft, e))
                return b"".join(t)

            def fh(v):
                return b64urlEncode(sha256(str(v).encode("ascii")).digest(), strip=True)

            def wn(challenge):
                sk = ECDSA_SigningKey.generate(curve=ECDSA_NIST256p, hashfunc=sha256)
                vk = sk.verifying_key.to_string()
                nonce = str(challenge.get("nonce") or "")
                signature = sk.sign(nonce.encode(), hashfunc=sha256)
                pub = {"crv": "P-256", "ext": True, "key_ops": ["verify"], "kty": "EC", "x": b64urlEncode(vk[:32], strip=True), "y": b64urlEncode(vk[32:], strip=True)}
                r = uniform(0, 1)
                return {
                    "viewer_id": "", "device_id": "", "challenge_id": challenge.get("challenge_id", ""), "nonce": nonce,
                    "signature": b64urlEncode(signature, strip=True), "public_key": pub,
                    "client": {
                        "user_agent": UA, "architecture": "arm", "bitness": "32", "platform": "Android", "platform_version": "10.0.0",
                        "model": "TX6s", "ua_full_version": "137.0.7337.0",
                        "brand_full_versions": [{"brand": "Chromium", "version": "137.0.7337.0"}],
                        "pixel_ratio": 1, "screen_width": 1280, "screen_height": 720, "color_depth": 24,
                        "languages": ["en-US"], "timezone": "America/New_York", "hardware_concurrency": 4, "device_memory": 2,
                        "touch_points": 1, "webgl_vendor": "Google Inc. (ARM)", "webgl_renderer": "ANGLE (ARM, Mali-G31 MP2, OpenGL ES 3.2)",
                        "canvas_hash": fh(r), "audio_hash": fh(r + 1), "webgl_params_hash": fh(r + 2), "fonts_hash": fh(r + 3), "codecs_hash": fh(r + 4),
                        "media_devices": "ai1ao1vi4", "pointer_type": "coarse",
                        "extra": {"vendor": "Google Inc.", "appVersion": UA[len("Mozilla/"):]},
                    },
                    "storage": {}, "attributes": {"entropy": "high"},
                }

            # Proof of work of the player (assets/pow-*.js: gr/wr/Er): find a counter s so that the custom
            # 512-word ChaCha-style hash of "<pow_nonce>:<s>" starts with pow_difficulty zero bits. Pure Python
            # is ~100x slower than the browser, so the solver is written flat: the ChaCha quarter round (ye) is
            # inlined on local variables (no function calls or list writes per round), the constant
            # "<pow_nonce>:" prefix is absorbed only once, and gr() stops at the first non-zero output word.
            def powBytes(s):
                # like the player's yr(): one byte per char code (& 255); a list behaves the same on py2 and py3
                return [ord(ch) & 255 for ch in s]

            def grAbsorb(data, state=(1779033703, 3144134277, 1013904242, 2773480762)):
                M = 0xFFFFFFFF
                a, b, c, d = state
                for i in data:
                    a = (a + i) & M
                    a = ((a << 7) | (a >> 25)) & M
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 16) | (d >> 16)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 12) | (b >> 20)) & M
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 8) | (d >> 24)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 7) | (b >> 25)) & M
                return a, b, c, d

            def gr(state, tail):
                # number of leading zero bits of the player's gr() hash of (absorbed prefix + tail), same as
                # wr(gr()) in the player JS; the eight output words are only computed until one is non-zero
                M = 0xFFFFFFFF
                a, b, c, d = grAbsorb(tail, state)
                for _i in range(8):
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 16) | (d >> 16)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 12) | (b >> 20)) & M
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 8) | (d >> 24)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 7) | (b >> 25)) & M
                r = [0] * 512
                for i in range(512):
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 16) | (d >> 16)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 12) | (b >> 20)) & M
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 8) | (d >> 24)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 7) | (b >> 25)) & M
                    r[i] = a ^ c
                for _i in range(2):
                    for s in range(512):
                        x = r[s]
                        x = (x + r[x & 511]) & M
                        x = ((x << 13) | (x >> 19)) & M
                        x ^= (r[(s + 1) & 511] * 2654435761) & M
                        r[s] = x
                        a ^= x
                        a = (a + b) & M
                        d ^= a
                        d = ((d << 16) | (d >> 16)) & M
                        c = (c + d) & M
                        b ^= c
                        b = ((b << 12) | (b >> 20)) & M
                        a = (a + b) & M
                        d ^= a
                        d = ((d << 8) | (d >> 24)) & M
                        c = (c + d) & M
                        b ^= c
                        b = ((b << 7) | (b >> 25)) & M
                zeros = 0
                for i in range(0, 512, 64):
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 16) | (d >> 16)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 12) | (b >> 20)) & M
                    a = (a + b) & M
                    d ^= a
                    d = ((d << 8) | (d >> 24)) & M
                    c = (c + d) & M
                    b ^= c
                    b = ((b << 7) | (b >> 25)) & M
                    s = a
                    for x in r[i:i + 64]:
                        s = (s + x) & M
                        s = ((s << 5) | (s >> 27)) & M
                        s ^= (x * 2246822519) & M
                    s ^= c
                    if s:
                        return zeros + 32 - s.bit_length()
                    zeros += 32
                return zeros

            def er(t, e, timeout, progress=None):
                # returns (solution or None, hashes tried); the time limit is checked every 16 hashes
                # (a few seconds at most even on a slow ARM box); progress(seconds) about once a second
                if e <= 0:
                    return "0", 0
                state = grAbsorb(powBytes(t + ":"))
                start = shown = time.time()
                s = 0
                while True:
                    for _i in range(16):
                        if gr(state, powBytes(str(s))) >= e:
                            return str(s), s + 1
                        s += 1
                    now = time.time()
                    if now - start > timeout:
                        return None, s
                    if progress and now - shown >= 1.0:
                        shown = now
                        progress(int(now - start))

            def powProgress(seconds):
                # add 101026: the loading line tells why the start takes so long (up to a few minutes on a box);
                # a framework without the status line (zadmario) just waits
                notify = GetIPTVNotify()
                if hasattr(notify, "setStatus"):
                    notify.setStatus("%s\n%s" % (_("Loading"), _("%s: decrypting the stream, this can take a while (%d s)") % ("Byse", seconds)))

            def statusCode(data, sts):
                try:
                    code = getattr(data, "meta", {}).get("status_code")
                    if code:
                        return code
                except Exception:
                    pass
                return 200 if sts else 0

            def tryJson(data):
                try:
                    return json_loads(data)
                except Exception:
                    return None

            def jsonPost():
                # params for the API POST endpoints (challenge/attest/captcha/
                # verify/playback). Send a real JSON Content-Type (pycurl otherwise
                # defaults to application/x-www-form-urlencoded) and disable the
                # automatic "Expect: 100-continue" handshake, matching the site's
                # own frontend and upstream ResolveURL (jdata=True).
                hdr = dict(HTTP_HEADER)
                hdr["Content-Type"] = "application/json"
                hdr["Expect"] = ""
                return {"header": hdr, "raw_post_data": True, "timeout": 40}

            # embedding site of a domain-locked video (e.g. serijebalkan.com): its Referer comes in the link meta
            parent = getattr(baseUrl, "meta", {}).get("Referer", "")
            baseUrl = baseUrl.replace("/d/", "/e/")
            printDBG("parserBYSE baseUrl[%s]" % baseUrl)
            urltab = []
            for redirectDomain in ["boosteradx.online", "byse.sx", "streamlyplayer.online"]:
                baseUrl = baseUrl.replace(redirectDomain, "streamlyplayero.online")
            ref = urlparser.getDomain(baseUrl, False)
            if "streamlyplayero.online" in ref:
                # fix 101026: streamlyplayero.online only frames the player of the current byse domain (bysekoze.com),
                # its api answers with that html page - follow the frame
                sts, page = self.cm.getPage(baseUrl, {"header": {"User-Agent": UA, "Referer": parent or ref}})
                frame = re.search(r"""<iframe[^>]+src=["'](https?://[^/"']+/)(?:e|d)/""", page) if sts else None
                if frame and frame.group(1) != ref:
                    baseUrl = baseUrl.replace(ref, frame.group(1), 1)
                    ref = frame.group(1)
            midMatch = re.search(r"/(?:e|d|download)/([0-9a-zA-Z]+)", baseUrl)
            if not midMatch:
                return []
            mid = midMatch.group(1)
            HTTP_HEADER = self.cm.getDefaultHeader()
            HTTP_HEADER["User-Agent"] = UA
            HTTP_HEADER["Referer"] = ref
            HTTP_HEADER["Origin"] = ref[:-1]

            embed = ""
            detailsUrl = "%sapi/videos/%s/details" % (ref, mid)
            # with_metadata=True is required for statusCode() below to see the
            # real HTTP status: getPageWithPyCurl() treats a 404 as sts=True by
            # default (ignore_http_code_ranges), and only attaches .meta when
            # asked to - without it, statusCode() always fell through to its
            # sts-based 200/0 guess and this 404 retry never actually fired,
            # even though the site returns a valid JSON body on 404s.
            sts, data = self.cm.getPage(detailsUrl, {"header": dict(HTTP_HEADER), "with_metadata": True})
            details = tryJson(data) if sts else None
            if details is None or statusCode(data, sts) == 404:
                embed = "embed/"
                detailsUrl = "%sapi/videos/%s/%sdetails" % (ref, mid, embed)
                hdr = dict(HTTP_HEADER)
                if parent:  # add 041026: domain-locked videos check Referer/Origin of the embedding site
                    hdr["Referer"] = urlparser.getDomain(parent, False)
                    hdr["Origin"] = hdr["Referer"][:-1]
                # 404 {"error": "video record missing: video not found"}, 403 {"error": "embedding from this domain is not allowed ..."}
                sts, data = self.cm.getPage(detailsUrl, {"header": hdr, "ignore_http_code_ranges": [(403, 404)]})
                if not sts:
                    return []
                details = tryJson(data)
                if not isinstance(details, dict):
                    return []
                if details.get("error") and not details.get("embed_frame_url"):
                    printDBG("parserBYSE details error [%s]" % details["error"])
                    SetIPTVPlayerLastHostError(_("The video has been removed.") if "not found" in details["error"] else _("Content not available"))
                    return []

            embedUrl = details.get("embed_frame_url")
            if embedUrl:
                ref = urlparser.getDomain(embedUrl, False)
                HTTP_HEADER["X-Embed-Parent"] = baseUrl
                HTTP_HEADER["Referer"] = ref
                HTTP_HEADER["Origin"] = ref[:-1]
                if parent:  # the player sends the embedding site as embedParentHost / Referrer
                    HTTP_HEADER["X-Embed-Origin"] = urlparser.getDomain(parent).replace("www.", "", 1)
                    HTTP_HEADER["X-Embed-Referer"] = urlparser.getDomain(parent, False)

            settingsUrl = "%sapi/videos/%s/%ssettings" % (ref, mid, embed)
            sts, data = self.cm.getPage(settingsUrl, {"header": dict(HTTP_HEADER)})
            settings = tryJson(data) if sts else None
            if settings is None:
                settings = {}

            playbackUrl = "%sapi/videos/%s/%splayback" % (ref, mid, embed)
            needCaptcha = settings.get("captcha_required")
            if not needCaptcha:
                # fix 071026: when the settings call fails (settings = {}) the plain playback answers
                # HTTP 428 {"error":"captcha_required"}: fall back to the captcha flow instead of returning nothing
                params = jsonPost()
                params["ignore_http_code_ranges"] = [(428, 428)]
                sts, data = self.cm.getPage(playbackUrl, params, json_dumps(fp(16, 0.83, 0.94)))
                if sts and (tryJson(data) or {}).get("error") == "captcha_required":
                    printDBG("parserBYSE playback needs a captcha although settings said no")
                    needCaptcha = True
            if needCaptcha:
                # a solved captcha stays valid for the player domain for a while (verify expires_in, 1800 s):
                # reuse it for the next video instead of solving the proof of work again (minutes on a slow box)
                sts = False
                access = self.BYSE_ACCESS.get(ref)
                if access and access[0] > time.time():
                    HTTP_HEADER["X-Captcha-Token"] = access[2]
                    sts, data = self.cm.getPage(playbackUrl, jsonPost(), json_dumps({"fingerprint": access[1]}))
                    printDBG("parserBYSE reused captcha token: %s" % sts)
                    if not sts or tryJson(data) is None:
                        sts = False
                        self.BYSE_ACCESS.pop(ref, None)
                if not sts:
                    challengeUrl = "%sapi/videos/access/challenge" % ref
                    sts, data = self.cm.getPage(challengeUrl, jsonPost(), "")
                    challenge = tryJson(data) if sts else None
                    if challenge is None:
                        return []

                    attestUrl = "%sapi/videos/access/attest" % ref
                    sts, data = self.cm.getPage(attestUrl, jsonPost(), json_dumps(wn(challenge)))
                    attest = tryJson(data) if sts else None
                    if not attest or not attest.get("token"):  # fix 071026: fingerprint rejected - tell the user
                        printDBG("parserBYSE attest failed [%s]" % data)
                        SetIPTVPlayerLastHostError(_("%s could not solve the captcha.") % "Byse")
                        return []
                    fingerprint = {"token": attest.get("token"), "viewer_id": attest.get("viewer_id"), "device_id": attest.get("device_id"), "confidence": attest.get("confidence")}

                    captchaUrl = "%sapi/videos/%s/%scaptcha" % (ref, mid, embed)
                    sts, data = self.cm.getPage(captchaUrl, jsonPost(), json_dumps({"fingerprint": fingerprint}))
                    captcha = tryJson(data) if sts else None
                    if not captcha or not captcha.get("pow_token"):  # fix 071026
                        printDBG("parserBYSE captcha request failed [%s]" % data)
                        SetIPTVPlayerLastHostError(_("%s could not solve the captcha.") % "Byse")
                        return []
                    # mobile fingerprints get difficulty 12 (~4096 hashes, ~1 min on an ARM box), desktop ones 16;
                    # the pow_token is valid for expires_in (1800 s), so the box may take longer than the
                    # browser's 20 s
                    difficulty = int(captcha.get("pow_difficulty") or 0)
                    timeLimit = min(180.0, max(20.0, float(captcha.get("expires_in") or 300) - 60.0))
                    powStart = time.time()
                    powProgress(0)
                    solution, hashes = er(captcha.get("pow_nonce") or "", difficulty, timeLimit, powProgress)
                    printDBG("parserBYSE proof of work difficulty %d: %s after %d hashes in %.1fs" % (difficulty, solution, hashes, time.time() - powStart))
                    if solution is None:
                        SetIPTVPlayerLastHostError(_("%s could not solve the captcha.") % "Byse")
                        return []

                    verifyUrl = "%sapi/videos/%s/%scaptcha/verify" % (ref, mid, embed)
                    verifyPost = {"pow_token": captcha.get("pow_token"), "solution": solution, "fingerprint": fingerprint}
                    sts, data = self.cm.getPage(verifyUrl, jsonPost(), json_dumps(verifyPost))
                    verify = tryJson(data) if sts else None
                    if not verify or not verify.get("token"):
                        printDBG("parserBYSE captcha verify failed [%s]" % data)
                        SetIPTVPlayerLastHostError(_("%s could not solve the captcha.") % "Byse")
                        return []
                    HTTP_HEADER["X-Captcha-Token"] = verify["token"]
                    lifetime = min(float(verify.get("expires_in") or 0), 1800.0) - 60.0
                    if lifetime > 0:
                        self.BYSE_ACCESS[ref] = (time.time() + lifetime, fingerprint, verify["token"])

                    sts, data = self.cm.getPage(playbackUrl, jsonPost(), json_dumps({"fingerprint": fingerprint}))
            if not sts:
                return []

            html = tryJson(data)
            if html is None:
                return []
            if html.get("error") and not html.get("sources") and not html.get("playback"):  # fix 071026: surface API errors
                printDBG("parserBYSE playback error [%s]" % html["error"])
                SetIPTVPlayerLastHostError(_("%s could not solve the captcha.") % "Byse" if "captcha" in html["error"] else _("Content not available"))
                return []
            sources = html.get("sources")
            if not sources:
                pd = html.get("playback")
                if pd:
                    iv = ft(pd.get("iv"))
                    key = xn(pd.get("key_parts"), pd.get("version"))
                    pl = ft(pd.get("payload"))
                    cipher = python_aesgcm.new(key)
                    ct = cipher.open(iv, pl)
                    html = json_loads(ct.decode("latin-1"))
                    sources = html.get("sources")
            if sources:
                seen = set()
                for x in sources:
                    if not x.get("url") or x["url"] in seen:
                        continue  # fix 101026: the playback data names the same master playlist up to three times
                    seen.add(x["url"])
                    url = urlparser.decorateUrl(x.get("url"), {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": ref, "Origin": ref[:-1]})
                    if ".m3u8" in url:
                        urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
                    else:
                        urltab.append({"name": x.get("label", ""), "url": url})
            return urltab


def embed_link(body, current):
    for pattern in [r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*target=',
                    r'<iframe\b[^>]*src=["\']([^"\']+)["\']']:
        match = re.search(pattern, body, re.I)
        if match:
            value = html_lib.unescape(match.group(1)).replace('\\/', '/')
            return urllib.parse.urljoin(current, value)
    return None


def resolve_example(client):
    global ACTIVE_HTTP, LAST_HOST_ERROR
    ACTIVE_HTTP, LAST_HOST_ERROR = client, False
    report = {'status': 'ERROR', 'stage': 'title_page', 'e2i_imported': False,
              'private_plugin_used': False, 'account_files_read': False,
              'stream_urls_printed': False, 'video_playback_tested': False}
    try:
        ok, body = client.getPage(TITLE, {'header': {'Referer': BASE}})
        if not ok:
            raise ResolveError('title_http_error')
        match = re.search(r"ShowPlayer\(['\"]player['\"],\s*['\"]([^'\"]+)['\"]\)", body)
        if not match:
            raise ResolveError('player_source_not_found')
        current = BASE + 'watch/f/player/' + urllib.parse.quote(match.group(1), safe='')
        parent = TITLE
        visited = set()
        for _step in range(6):
            if current in visited:
                raise ResolveError('embed_redirect_loop')
            visited.add(current)
            host = urllib.parse.urlsplit(current).hostname
            if host == 'mfw09.org':
                report['stage'] = 'resolve_byse'
                options = Byse(client).parserBYSE(URL(current, {'Referer': parent}))
                if not options:
                    raise ResolveError('byse_returned_no_stream_variants')
                safe = []
                for item in options[:80]:
                    value = {key: item.get(key, 0) for key in ('width', 'height', 'bitrate')}
                    value.update(language=item.get('language', ''), codecs=item.get('codecs', ''))
                    target = urllib.parse.urlsplit(item.get('url', '')).path.lower()
                    value['stream_type'] = 'hls' if '.m3u8' in target else 'dash' if '.mpd' in target else 'other'
                    safe.append(value)
                report.update(status='VARIANTS_RESOLVED', stage='manifest_inspected',
                              provider='player', variant_count=len(options), variants=safe)
                return report
            report['stage'] = 'watch_embed'
            ok, body = client.getPage(current, {'header': {'Referer': parent}})
            if not ok:
                raise ResolveError('watch_or_embed_http_error')
            final = client.meta.get('url', current)
            if urllib.parse.urlsplit(final).hostname == 'mfw09.org':
                current = final
                continue
            target = embed_link(body, final)
            if not target:
                raise ResolveError('no_normal_embed_link')
            parent, current = final, target
        raise ResolveError('embed_chain_too_long')
    except KeyboardInterrupt:
        report.update(status='CANCELLED', reason='user_cancelled')
    except Exception as error:
        report['reason'] = str(error) if isinstance(error, ResolveError) else type(error).__name__
    finally:
        report['requests'] = client.steps
    return report


def write_private_report(path, value):
    descriptor, name = tempfile.mkstemp(prefix='mk-ekino-resolver-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as out:
            json.dump(value, out, ensure_ascii=False, indent=2)
            out.write('\n')
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def main():
    parser = argparse.ArgumentParser(description='Standalone player/Byse manifest test, without E2i.')
    parser.add_argument('--report', type=Path, default=Path('/tmp/mk_ekino_resolver_report.json'))
    args = parser.parse_args()
    try:
        import Crypto.Cipher.AES
        import Crypto.PublicKey.ECC
    except ImportError:
        report = {'status': 'ERROR', 'reason': 'pycryptodome_missing', 'account_files_read': False}
    else:
        report = resolve_example(Http())
    write_private_report(args.report, report)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return 0 if report['status'] == 'VARIANTS_RESOLVED' else 1


if __name__ == '__main__':
    raise SystemExit(main())

# Complete upstream license, retained for redistribution.
LICENSE_TEXT = '                    GNU GENERAL PUBLIC LICENSE\n                       Version 3, 29 June 2007\n\n Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>\n Everyone is permitted to copy and distribute verbatim copies\n of this license document, but changing it is not allowed.\n\n                            Preamble\n\n  The GNU General Public License is a free, copyleft license for\nsoftware and other kinds of works.\n\n  The licenses for most software and other practical works are designed\nto take away your freedom to share and change the works.  By contrast,\nthe GNU General Public License is intended to guarantee your freedom to\nshare and change all versions of a program--to make sure it remains free\nsoftware for all its users.  We, the Free Software Foundation, use the\nGNU General Public License for most of our software; it applies also to\nany other work released this way by its authors.  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthem if you wish), that you receive source code or can get it if you\nwant it, that you can change the software or use pieces of it in new\nfree programs, and that you know you can do these things.\n\n  To protect your rights, we need to prevent others from denying you\nthese rights or asking you to surrender the rights.  Therefore, you have\ncertain responsibilities if you distribute copies of the software, or if\nyou modify it: responsibilities to respect the freedom of others.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must pass on to the recipients the same\nfreedoms that you received.  You must make sure that they, too, receive\nor can get the source code.  And you must show them these terms so they\nknow their rights.\n\n  Developers that use the GNU GPL protect your rights with two steps:\n(1) assert copyright on the software, and (2) offer you this License\ngiving you legal permission to copy, distribute and/or modify it.\n\n  For the developers\' and authors\' protection, the GPL clearly explains\nthat there is no warranty for this free software.  For both users\' and\nauthors\' sake, the GPL requires that modified versions be marked as\nchanged, so that their problems will not be attributed erroneously to\nauthors of previous versions.\n\n  Some devices are designed to deny users access to install or run\nmodified versions of the software inside them, although the manufacturer\ncan do so.  This is fundamentally incompatible with the aim of\nprotecting users\' freedom to change the software.  The systematic\npattern of such abuse occurs in the area of products for individuals to\nuse, which is precisely where it is most unacceptable.  Therefore, we\nhave designed this version of the GPL to prohibit the practice for those\nproducts.  If such problems arise substantially in other domains, we\nstand ready to extend this provision to those domains in future versions\nof the GPL, as needed to protect the freedom of users.\n\n  Finally, every program is threatened constantly by software patents.\nStates should not allow patents to restrict development and use of\nsoftware on general-purpose computers, but in those that do, we wish to\navoid the special danger that patents applied to a free program could\nmake it effectively proprietary.  To prevent this, the GPL assures that\npatents cannot be used to render the program non-free.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n                       TERMS AND CONDITIONS\n\n  0. Definitions.\n\n  "This License" refers to version 3 of the GNU General Public License.\n\n  "Copyright" also means copyright-like laws that apply to other kinds of\nworks, such as semiconductor masks.\n\n  "The Program" refers to any copyrightable work licensed under this\nLicense.  Each licensee is addressed as "you".  "Licensees" and\n"recipients" may be individuals or organizations.\n\n  To "modify" a work means to copy from or adapt all or part of the work\nin a fashion requiring copyright permission, other than the making of an\nexact copy.  The resulting work is called a "modified version" of the\nearlier work or a work "based on" the earlier work.\n\n  A "covered work" means either the unmodified Program or a work based\non the Program.\n\n  To "propagate" a work means to do anything with it that, without\npermission, would make you directly or secondarily liable for\ninfringement under applicable copyright law, except executing it on a\ncomputer or modifying a private copy.  Propagation includes copying,\ndistribution (with or without modification), making available to the\npublic, and in some countries other activities as well.\n\n  To "convey" a work means any kind of propagation that enables other\nparties to make or receive copies.  Mere interaction with a user through\na computer network, with no transfer of a copy, is not conveying.\n\n  An interactive user interface displays "Appropriate Legal Notices"\nto the extent that it includes a convenient and prominently visible\nfeature that (1) displays an appropriate copyright notice, and (2)\ntells the user that there is no warranty for the work (except to the\nextent that warranties are provided), that licensees may convey the\nwork under this License, and how to view a copy of this License.  If\nthe interface presents a list of user commands or options, such as a\nmenu, a prominent item in the list meets this criterion.\n\n  1. Source Code.\n\n  The "source code" for a work means the preferred form of the work\nfor making modifications to it.  "Object code" means any non-source\nform of a work.\n\n  A "Standard Interface" means an interface that either is an official\nstandard defined by a recognized standards body, or, in the case of\ninterfaces specified for a particular programming language, one that\nis widely used among developers working in that language.\n\n  The "System Libraries" of an executable work include anything, other\nthan the work as a whole, that (a) is included in the normal form of\npackaging a Major Component, but which is not part of that Major\nComponent, and (b) serves only to enable use of the work with that\nMajor Component, or to implement a Standard Interface for which an\nimplementation is available to the public in source code form.  A\n"Major Component", in this context, means a major essential component\n(kernel, window system, and so on) of the specific operating system\n(if any) on which the executable work runs, or a compiler used to\nproduce the work, or an object code interpreter used to run it.\n\n  The "Corresponding Source" for a work in object code form means all\nthe source code needed to generate, install, and (for an executable\nwork) run the object code and to modify the work, including scripts to\ncontrol those activities.  However, it does not include the work\'s\nSystem Libraries, or general-purpose tools or generally available free\nprograms which are used unmodified in performing those activities but\nwhich are not part of the work.  For example, Corresponding Source\nincludes interface definition files associated with source files for\nthe work, and the source code for shared libraries and dynamically\nlinked subprograms that the work is specifically designed to require,\nsuch as by intimate data communication or control flow between those\nsubprograms and other parts of the work.\n\n  The Corresponding Source need not include anything that users\ncan regenerate automatically from other parts of the Corresponding\nSource.\n\n  The Corresponding Source for a work in source code form is that\nsame work.\n\n  2. Basic Permissions.\n\n  All rights granted under this License are granted for the term of\ncopyright on the Program, and are irrevocable provided the stated\nconditions are met.  This License explicitly affirms your unlimited\npermission to run the unmodified Program.  The output from running a\ncovered work is covered by this License only if the output, given its\ncontent, constitutes a covered work.  This License acknowledges your\nrights of fair use or other equivalent, as provided by copyright law.\n\n  You may make, run and propagate covered works that you do not\nconvey, without conditions so long as your license otherwise remains\nin force.  You may convey covered works to others for the sole purpose\nof having them make modifications exclusively for you, or provide you\nwith facilities for running those works, provided that you comply with\nthe terms of this License in conveying all material for which you do\nnot control copyright.  Those thus making or running the covered works\nfor you must do so exclusively on your behalf, under your direction\nand control, on terms that prohibit them from making any copies of\nyour copyrighted material outside their relationship with you.\n\n  Conveying under any other circumstances is permitted solely under\nthe conditions stated below.  Sublicensing is not allowed; section 10\nmakes it unnecessary.\n\n  3. Protecting Users\' Legal Rights From Anti-Circumvention Law.\n\n  No covered work shall be deemed part of an effective technological\nmeasure under any applicable law fulfilling obligations under article\n11 of the WIPO copyright treaty adopted on 20 December 1996, or\nsimilar laws prohibiting or restricting circumvention of such\nmeasures.\n\n  When you convey a covered work, you waive any legal power to forbid\ncircumvention of technological measures to the extent such circumvention\nis effected by exercising rights under this License with respect to\nthe covered work, and you disclaim any intention to limit operation or\nmodification of the work as a means of enforcing, against the work\'s\nusers, your or third parties\' legal rights to forbid circumvention of\ntechnological measures.\n\n  4. Conveying Verbatim Copies.\n\n  You may convey verbatim copies of the Program\'s source code as you\nreceive it, in any medium, provided that you conspicuously and\nappropriately publish on each copy an appropriate copyright notice;\nkeep intact all notices stating that this License and any\nnon-permissive terms added in accord with section 7 apply to the code;\nkeep intact all notices of the absence of any warranty; and give all\nrecipients a copy of this License along with the Program.\n\n  You may charge any price or no price for each copy that you convey,\nand you may offer support or warranty protection for a fee.\n\n  5. Conveying Modified Source Versions.\n\n  You may convey a work based on the Program, or the modifications to\nproduce it from the Program, in the form of source code under the\nterms of section 4, provided that you also meet all of these conditions:\n\n    a) The work must carry prominent notices stating that you modified\n    it, and giving a relevant date.\n\n    b) The work must carry prominent notices stating that it is\n    released under this License and any conditions added under section\n    7.  This requirement modifies the requirement in section 4 to\n    "keep intact all notices".\n\n    c) You must license the entire work, as a whole, under this\n    License to anyone who comes into possession of a copy.  This\n    License will therefore apply, along with any applicable section 7\n    additional terms, to the whole of the work, and all its parts,\n    regardless of how they are packaged.  This License gives no\n    permission to license the work in any other way, but it does not\n    invalidate such permission if you have separately received it.\n\n    d) If the work has interactive user interfaces, each must display\n    Appropriate Legal Notices; however, if the Program has interactive\n    interfaces that do not display Appropriate Legal Notices, your\n    work need not make them do so.\n\n  A compilation of a covered work with other separate and independent\nworks, which are not by their nature extensions of the covered work,\nand which are not combined with it such as to form a larger program,\nin or on a volume of a storage or distribution medium, is called an\n"aggregate" if the compilation and its resulting copyright are not\nused to limit the access or legal rights of the compilation\'s users\nbeyond what the individual works permit.  Inclusion of a covered work\nin an aggregate does not cause this License to apply to the other\nparts of the aggregate.\n\n  6. Conveying Non-Source Forms.\n\n  You may convey a covered work in object code form under the terms\nof sections 4 and 5, provided that you also convey the\nmachine-readable Corresponding Source under the terms of this License,\nin one of these ways:\n\n    a) Convey the object code in, or embodied in, a physical product\n    (including a physical distribution medium), accompanied by the\n    Corresponding Source fixed on a durable physical medium\n    customarily used for software interchange.\n\n    b) Convey the object code in, or embodied in, a physical product\n    (including a physical distribution medium), accompanied by a\n    written offer, valid for at least three years and valid for as\n    long as you offer spare parts or customer support for that product\n    model, to give anyone who possesses the object code either (1) a\n    copy of the Corresponding Source for all the software in the\n    product that is covered by this License, on a durable physical\n    medium customarily used for software interchange, for a price no\n    more than your reasonable cost of physically performing this\n    conveying of source, or (2) access to copy the\n    Corresponding Source from a network server at no charge.\n\n    c) Convey individual copies of the object code with a copy of the\n    written offer to provide the Corresponding Source.  This\n    alternative is allowed only occasionally and noncommercially, and\n    only if you received the object code with such an offer, in accord\n    with subsection 6b.\n\n    d) Convey the object code by offering access from a designated\n    place (gratis or for a charge), and offer equivalent access to the\n    Corresponding Source in the same way through the same place at no\n    further charge.  You need not require recipients to copy the\n    Corresponding Source along with the object code.  If the place to\n    copy the object code is a network server, the Corresponding Source\n    may be on a different server (operated by you or a third party)\n    that supports equivalent copying facilities, provided you maintain\n    clear directions next to the object code saying where to find the\n    Corresponding Source.  Regardless of what server hosts the\n    Corresponding Source, you remain obligated to ensure that it is\n    available for as long as needed to satisfy these requirements.\n\n    e) Convey the object code using peer-to-peer transmission, provided\n    you inform other peers where the object code and Corresponding\n    Source of the work are being offered to the general public at no\n    charge under subsection 6d.\n\n  A separable portion of the object code, whose source code is excluded\nfrom the Corresponding Source as a System Library, need not be\nincluded in conveying the object code work.\n\n  A "User Product" is either (1) a "consumer product", which means any\ntangible personal property which is normally used for personal, family,\nor household purposes, or (2) anything designed or sold for incorporation\ninto a dwelling.  In determining whether a product is a consumer product,\ndoubtful cases shall be resolved in favor of coverage.  For a particular\nproduct received by a particular user, "normally used" refers to a\ntypical or common use of that class of product, regardless of the status\nof the particular user or of the way in which the particular user\nactually uses, or expects or is expected to use, the product.  A product\nis a consumer product regardless of whether the product has substantial\ncommercial, industrial or non-consumer uses, unless such uses represent\nthe only significant mode of use of the product.\n\n  "Installation Information" for a User Product means any methods,\nprocedures, authorization keys, or other information required to install\nand execute modified versions of a covered work in that User Product from\na modified version of its Corresponding Source.  The information must\nsuffice to ensure that the continued functioning of the modified object\ncode is in no case prevented or interfered with solely because\nmodification has been made.\n\n  If you convey an object code work under this section in, or with, or\nspecifically for use in, a User Product, and the conveying occurs as\npart of a transaction in which the right of possession and use of the\nUser Product is transferred to the recipient in perpetuity or for a\nfixed term (regardless of how the transaction is characterized), the\nCorresponding Source conveyed under this section must be accompanied\nby the Installation Information.  But this requirement does not apply\nif neither you nor any third party retains the ability to install\nmodified object code on the User Product (for example, the work has\nbeen installed in ROM).\n\n  The requirement to provide Installation Information does not include a\nrequirement to continue to provide support service, warranty, or updates\nfor a work that has been modified or installed by the recipient, or for\nthe User Product in which it has been modified or installed.  Access to a\nnetwork may be denied when the modification itself materially and\nadversely affects the operation of the network or violates the rules and\nprotocols for communication across the network.\n\n  Corresponding Source conveyed, and Installation Information provided,\nin accord with this section must be in a format that is publicly\ndocumented (and with an implementation available to the public in\nsource code form), and must require no special password or key for\nunpacking, reading or copying.\n\n  7. Additional Terms.\n\n  "Additional permissions" are terms that supplement the terms of this\nLicense by making exceptions from one or more of its conditions.\nAdditional permissions that are applicable to the entire Program shall\nbe treated as though they were included in this License, to the extent\nthat they are valid under applicable law.  If additional permissions\napply only to part of the Program, that part may be used separately\nunder those permissions, but the entire Program remains governed by\nthis License without regard to the additional permissions.\n\n  When you convey a copy of a covered work, you may at your option\nremove any additional permissions from that copy, or from any part of\nit.  (Additional permissions may be written to require their own\nremoval in certain cases when you modify the work.)  You may place\nadditional permissions on material, added by you to a covered work,\nfor which you have or can give appropriate copyright permission.\n\n  Notwithstanding any other provision of this License, for material you\nadd to a covered work, you may (if authorized by the copyright holders of\nthat material) supplement the terms of this License with terms:\n\n    a) Disclaiming warranty or limiting liability differently from the\n    terms of sections 15 and 16 of this License; or\n\n    b) Requiring preservation of specified reasonable legal notices or\n    author attributions in that material or in the Appropriate Legal\n    Notices displayed by works containing it; or\n\n    c) Prohibiting misrepresentation of the origin of that material, or\n    requiring that modified versions of such material be marked in\n    reasonable ways as different from the original version; or\n\n    d) Limiting the use for publicity purposes of names of licensors or\n    authors of the material; or\n\n    e) Declining to grant rights under trademark law for use of some\n    trade names, trademarks, or service marks; or\n\n    f) Requiring indemnification of licensors and authors of that\n    material by anyone who conveys the material (or modified versions of\n    it) with contractual assumptions of liability to the recipient, for\n    any liability that these contractual assumptions directly impose on\n    those licensors and authors.\n\n  All other non-permissive additional terms are considered "further\nrestrictions" within the meaning of section 10.  If the Program as you\nreceived it, or any part of it, contains a notice stating that it is\ngoverned by this License along with a term that is a further\nrestriction, you may remove that term.  If a license document contains\na further restriction but permits relicensing or conveying under this\nLicense, you may add to a covered work material governed by the terms\nof that license document, provided that the further restriction does\nnot survive such relicensing or conveying.\n\n  If you add terms to a covered work in accord with this section, you\nmust place, in the relevant source files, a statement of the\nadditional terms that apply to those files, or a notice indicating\nwhere to find the applicable terms.\n\n  Additional terms, permissive or non-permissive, may be stated in the\nform of a separately written license, or stated as exceptions;\nthe above requirements apply either way.\n\n  8. Termination.\n\n  You may not propagate or modify a covered work except as expressly\nprovided under this License.  Any attempt otherwise to propagate or\nmodify it is void, and will automatically terminate your rights under\nthis License (including any patent licenses granted under the third\nparagraph of section 11).\n\n  However, if you cease all violation of this License, then your\nlicense from a particular copyright holder is reinstated (a)\nprovisionally, unless and until the copyright holder explicitly and\nfinally terminates your license, and (b) permanently, if the copyright\nholder fails to notify you of the violation by some reasonable means\nprior to 60 days after the cessation.\n\n  Moreover, your license from a particular copyright holder is\nreinstated permanently if the copyright holder notifies you of the\nviolation by some reasonable means, this is the first time you have\nreceived notice of violation of this License (for any work) from that\ncopyright holder, and you cure the violation prior to 30 days after\nyour receipt of the notice.\n\n  Termination of your rights under this section does not terminate the\nlicenses of parties who have received copies or rights from you under\nthis License.  If your rights have been terminated and not permanently\nreinstated, you do not qualify to receive new licenses for the same\nmaterial under section 10.\n\n  9. Acceptance Not Required for Having Copies.\n\n  You are not required to accept this License in order to receive or\nrun a copy of the Program.  Ancillary propagation of a covered work\noccurring solely as a consequence of using peer-to-peer transmission\nto receive a copy likewise does not require acceptance.  However,\nnothing other than this License grants you permission to propagate or\nmodify any covered work.  These actions infringe copyright if you do\nnot accept this License.  Therefore, by modifying or propagating a\ncovered work, you indicate your acceptance of this License to do so.\n\n  10. Automatic Licensing of Downstream Recipients.\n\n  Each time you convey a covered work, the recipient automatically\nreceives a license from the original licensors, to run, modify and\npropagate that work, subject to this License.  You are not responsible\nfor enforcing compliance by third parties with this License.\n\n  An "entity transaction" is a transaction transferring control of an\norganization, or substantially all assets of one, or subdividing an\norganization, or merging organizations.  If propagation of a covered\nwork results from an entity transaction, each party to that\ntransaction who receives a copy of the work also receives whatever\nlicenses to the work the party\'s predecessor in interest had or could\ngive under the previous paragraph, plus a right to possession of the\nCorresponding Source of the work from the predecessor in interest, if\nthe predecessor has it or can get it with reasonable efforts.\n\n  You may not impose any further restrictions on the exercise of the\nrights granted or affirmed under this License.  For example, you may\nnot impose a license fee, royalty, or other charge for exercise of\nrights granted under this License, and you may not initiate litigation\n(including a cross-claim or counterclaim in a lawsuit) alleging that\nany patent claim is infringed by making, using, selling, offering for\nsale, or importing the Program or any portion of it.\n\n  11. Patents.\n\n  A "contributor" is a copyright holder who authorizes use under this\nLicense of the Program or a work on which the Program is based.  The\nwork thus licensed is called the contributor\'s "contributor version".\n\n  A contributor\'s "essential patent claims" are all patent claims\nowned or controlled by the contributor, whether already acquired or\nhereafter acquired, that would be infringed by some manner, permitted\nby this License, of making, using, or selling its contributor version,\nbut do not include claims that would be infringed only as a\nconsequence of further modification of the contributor version.  For\npurposes of this definition, "control" includes the right to grant\npatent sublicenses in a manner consistent with the requirements of\nthis License.\n\n  Each contributor grants you a non-exclusive, worldwide, royalty-free\npatent license under the contributor\'s essential patent claims, to\nmake, use, sell, offer for sale, import and otherwise run, modify and\npropagate the contents of its contributor version.\n\n  In the following three paragraphs, a "patent license" is any express\nagreement or commitment, however denominated, not to enforce a patent\n(such as an express permission to practice a patent or covenant not to\nsue for patent infringement).  To "grant" such a patent license to a\nparty means to make such an agreement or commitment not to enforce a\npatent against the party.\n\n  If you convey a covered work, knowingly relying on a patent license,\nand the Corresponding Source of the work is not available for anyone\nto copy, free of charge and under the terms of this License, through a\npublicly available network server or other readily accessible means,\nthen you must either (1) cause the Corresponding Source to be so\navailable, or (2) arrange to deprive yourself of the benefit of the\npatent license for this particular work, or (3) arrange, in a manner\nconsistent with the requirements of this License, to extend the patent\nlicense to downstream recipients.  "Knowingly relying" means you have\nactual knowledge that, but for the patent license, your conveying the\ncovered work in a country, or your recipient\'s use of the covered work\nin a country, would infringe one or more identifiable patents in that\ncountry that you have reason to believe are valid.\n\n  If, pursuant to or in connection with a single transaction or\narrangement, you convey, or propagate by procuring conveyance of, a\ncovered work, and grant a patent license to some of the parties\nreceiving the covered work authorizing them to use, propagate, modify\nor convey a specific copy of the covered work, then the patent license\nyou grant is automatically extended to all recipients of the covered\nwork and works based on it.\n\n  A patent license is "discriminatory" if it does not include within\nthe scope of its coverage, prohibits the exercise of, or is\nconditioned on the non-exercise of one or more of the rights that are\nspecifically granted under this License.  You may not convey a covered\nwork if you are a party to an arrangement with a third party that is\nin the business of distributing software, under which you make payment\nto the third party based on the extent of your activity of conveying\nthe work, and under which the third party grants, to any of the\nparties who would receive the covered work from you, a discriminatory\npatent license (a) in connection with copies of the covered work\nconveyed by you (or copies made from those copies), or (b) primarily\nfor and in connection with specific products or compilations that\ncontain the covered work, unless you entered into that arrangement,\nor that patent license was granted, prior to 28 March 2007.\n\n  Nothing in this License shall be construed as excluding or limiting\nany implied license or other defenses to infringement that may\notherwise be available to you under applicable patent law.\n\n  12. No Surrender of Others\' Freedom.\n\n  If conditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot convey a\ncovered work so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you may\nnot convey it at all.  For example, if you agree to terms that obligate you\nto collect a royalty for further conveying from those to whom you convey\nthe Program, the only way you could satisfy both those terms and this\nLicense would be to refrain entirely from conveying the Program.\n\n  13. Use with the GNU Affero General Public License.\n\n  Notwithstanding any other provision of this License, you have\npermission to link or combine any covered work with a work licensed\nunder version 3 of the GNU Affero General Public License into a single\ncombined work, and to convey the resulting work.  The terms of this\nLicense will continue to apply to the part which is the covered work,\nbut the special requirements of the GNU Affero General Public License,\nsection 13, concerning interaction through a network will apply to the\ncombination as such.\n\n  14. Revised Versions of this License.\n\n  The Free Software Foundation may publish revised and/or new versions of\nthe GNU General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\n  Each version is given a distinguishing version number.  If the\nProgram specifies that a certain numbered version of the GNU General\nPublic License "or any later version" applies to it, you have the\noption of following the terms and conditions either of that numbered\nversion or of any later version published by the Free Software\nFoundation.  If the Program does not specify a version number of the\nGNU General Public License, you may choose any version ever published\nby the Free Software Foundation.\n\n  If the Program specifies that a proxy can decide which future\nversions of the GNU General Public License can be used, that proxy\'s\npublic statement of acceptance of a version permanently authorizes you\nto choose that version for the Program.\n\n  Later license versions may give you additional or different\npermissions.  However, no additional obligations are imposed on any\nauthor or copyright holder as a result of your choosing to follow a\nlater version.\n\n  15. Disclaimer of Warranty.\n\n  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\nAPPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\nHOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY\nOF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,\nTHE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR\nPURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM\nIS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF\nALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n  16. Limitation of Liability.\n\n  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS\nTHE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY\nGENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE\nUSE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF\nDATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD\nPARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),\nEVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF\nSUCH DAMAGES.\n\n  17. Interpretation of Sections 15 and 16.\n\n  If the disclaimer of warranty and limitation of liability provided\nabove cannot be given local legal effect according to their terms,\nreviewing courts shall apply local law that most closely approximates\nan absolute waiver of all civil liability in connection with the\nProgram, unless a warranty or assumption of liability accompanies a\ncopy of the Program in return for a fee.\n\n                     END OF TERMS AND CONDITIONS\n\n            How to Apply These Terms to Your New Programs\n\n  If you develop a new program, and you want it to be of the greatest\npossible use to the public, the best way to achieve this is to make it\nfree software which everyone can redistribute and change under these terms.\n\n  To do so, attach the following notices to the program.  It is safest\nto attach them to the start of each source file to most effectively\nstate the exclusion of warranty; and each file should have at least\nthe "copyright" line and a pointer to where the full notice is found.\n\n    <one line to give the program\'s name and a brief idea of what it does.>\n    Copyright (C) <year>  <name of author>\n\n    This program is free software: you can redistribute it and/or modify\n    it under the terms of the GNU General Public License as published by\n    the Free Software Foundation, either version 3 of the License, or\n    (at your option) any later version.\n\n    This program is distributed in the hope that it will be useful,\n    but WITHOUT ANY WARRANTY; without even the implied warranty of\n    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n    GNU General Public License for more details.\n\n    You should have received a copy of the GNU General Public License\n    along with this program.  If not, see <https://www.gnu.org/licenses/>.\n\nAlso add information on how to contact you by electronic and paper mail.\n\n  If the program does terminal interaction, make it output a short\nnotice like this when it starts in an interactive mode:\n\n    <program>  Copyright (C) <year>  <name of author>\n    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w\'.\n    This is free software, and you are welcome to redistribute it\n    under certain conditions; type `show c\' for details.\n\nThe hypothetical commands `show w\' and `show c\' should show the appropriate\nparts of the General Public License.  Of course, your program\'s commands\nmight be different; for a GUI interface, you would use an "about box".\n\n  You should also get your employer (if you work as a programmer) or school,\nif any, to sign a "copyright disclaimer" for the program, if necessary.\nFor more information on this, and how to apply and follow the GNU GPL, see\n<https://www.gnu.org/licenses/>.\n\n  The GNU General Public License does not permit incorporating your program\ninto proprietary programs.  If your program is a subroutine library, you\nmay consider it more useful to permit linking proprietary applications with\nthe library.  If this is what you want to do, use the GNU Lesser General\nPublic License instead of this License.  But first, please read\n<https://www.gnu.org/licenses/why-not-lgpl.html>.\n'
PUBLIC_SOURCE = {'archive_name': 'e2iplayer-2026.10.18.05.zip', 'archive_sha256': '54ab58dd51d4bc4490129f5889cfbff5f330cb339de8845452a156ee39dbbddd', 'member': 'e2iplayer-2026.10.18.05/IPTVPlayer/libs/urlparser.py', 'source_sha256': '07d09e80291192f46011b84b3a5d5b375284ddc63b01085a4e2f46fcf5705705', 'function': 'parserBYSE', 'line': 3153, 'end_line': 3545, 'private_pe2i_used': False, 'license': 'GPL-3.0', 'modification': 'Standalone HTTP, crypto and HLS adapters; original resolver method retained.'}
