#!/usr/bin/env python3
"""Build optional ARMv7 acceleration using pip package ziglang==0.14.1."""
from importlib.metadata import version
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

def main():
    if version('ziglang')!='0.14.1':raise SystemExit('Install ziglang==0.14.1 in the build environment.')
    output=ROOT/'src/MKEkinoE2/libmkekino_pow_armv7.so'
    subprocess.run([sys.executable,'-m','ziglang','cc','-target','arm-linux-musleabihf',
                    '-mcpu=cortex_a7','-O3','-ffreestanding','-fno-stack-protector',
                    '-fno-builtin','-nostdlib','-shared','-s',
                    '-Wl,-soname,libmkekino_pow_armv7.so',str(ROOT/'native/pow.c'),
                    '-o',str(output)],check=True)
    print(output)

if __name__=='__main__':main()
