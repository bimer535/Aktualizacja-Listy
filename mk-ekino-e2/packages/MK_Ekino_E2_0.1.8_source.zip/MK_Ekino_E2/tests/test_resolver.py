import ast
import base64
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('ekino_resolver', ROOT/'tools/mk_ekino_resolver_test.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)

HLS = '''#EXTM3U
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",LANGUAGE="pl",NAME="Polski",URI="audio/pl.m3u8"
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",LANGUAGE="en",NAME="English",URI="audio/en.m3u8"
#EXT-X-STREAM-INF:BANDWIDTH=6387008,RESOLUTION=1920x800,CODECS="mp4a.40.2,avc1.640028",AUDIO="audio"
video/high.m3u8
'''


class Fake:
    def __init__(self, encrypted=False, denied=False):
        self.meta = {}
        self.steps = []
        self.calls = []
        self.encrypted, self.denied = encrypted, denied

    def getDefaultHeader(self):
        return {'User-Agent': 'Test'}

    def getPage(self, url, params=None, post_data=None):
        url = str(url)
        self.calls.append((url,params,post_data))
        data = ''
        if url == r.TITLE:
            data = "ShowPlayer('player','PRIVATE-WATCH-ID')"
        elif '/watch/f/' in url:
            data = '<iframe src="https://mfw09.org/e/PrivateId"></iframe>'
        elif url.endswith('/details'):
            data = '{}'
        elif url.endswith('/settings'):
            data = '{"captcha_required":false}'
        elif url.endswith('/playback'):
            if self.denied:
                data = '{}'
            else:
                payload = {'sources':[{'url':'https://cdn.example/master.m3u8?private=hidden','label':'source'}]}
                if self.encrypted:
                    from Crypto.Cipher import AES
                    key, iv = b'K'*32, b'N'*12
                    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
                    ct, tag = cipher.encrypt_and_digest(json.dumps(payload).encode())
                    encode = lambda b: base64.urlsafe_b64encode(b).decode().rstrip('=')
                    payload={'playback':{'iv':encode(iv),'key_parts':[encode(key)],'payload':encode(ct+tag)}}
                data = json.dumps(payload)
        elif 'master.m3u8' in url:
            data = HLS
        else:
            raise AssertionError('Unexpected request')
        self.meta = {'url':url,'status_code':200}
        body = r.Body(data); body.meta = dict(self.meta)
        return True,body


class ResolverTests(unittest.TestCase):
    def test_public_method_retained_and_no_private_plugin_import(self):
        original = ast.parse((ROOT/'reference/public_byse_method.txt').read_text()).body[0]
        merged = ast.parse((ROOT/'tools/mk_ekino_resolver_test.py').read_text())
        copied = next(n for n in ast.walk(merged) if isinstance(n,ast.FunctionDef) and n.name=='parserBYSE')
        self.assertEqual(ast.dump(original),ast.dump(copied))
        imports=[n.module for n in ast.walk(merged) if isinstance(n,ast.ImportFrom)]
        self.assertFalse(any(i and 'IPTVPlayer' in i for i in imports))

    def test_plain_api_to_two_languages_preserves_native_cinema_resolution(self):
        client = Fake()
        result = r.resolve_example(client)
        self.assertEqual(result['status'],'VARIANTS_RESOLVED')
        self.assertEqual(result['variant_count'],2)
        self.assertEqual([x['language'] for x in result['variants']],['pl','en'])
        self.assertTrue(all(x['width']==1920 and x['height']==800 for x in result['variants']))
        output=json.dumps(result)
        for secret in ['PRIVATE-WATCH-ID','PrivateId','private=hidden','cdn.example']:
            self.assertNotIn(secret,output)
        playback=next(c for c in client.calls if c[0].endswith('/playback'))
        self.assertEqual(playback[1]['header']['Content-Type'],'application/json')
        self.assertTrue(playback[2].startswith('{'))

    def test_encrypted_playback_metadata_uses_standard_aes_gcm(self):
        self.assertEqual(r.resolve_example(Fake(encrypted=True))['status'],'VARIANTS_RESOLVED')

    def test_no_sources_does_not_claim_playback_or_variants(self):
        result=r.resolve_example(Fake(denied=True))
        self.assertEqual(result['status'],'ERROR')
        self.assertEqual(result['reason'],'byse_returned_no_stream_variants')
        self.assertFalse(result['video_playback_tested'])

    def test_ecdsa_adapter_produces_verifiable_p256_signature(self):
        from Crypto.Hash import SHA256
        from Crypto.PublicKey import ECC
        from Crypto.Signature import DSS
        key=r.ECDSA_SigningKey.generate()
        raw=key.verifying_key.to_string()
        pub=ECC.construct(curve='P-256',point_x=int.from_bytes(raw[:32],'big'),point_y=int.from_bytes(raw[32:],'big'))
        DSS.new(pub,'fips-186-3',encoding='binary').verify(SHA256.new(b'example nonce'),key.sign(b'example nonce'))

    def test_nonpublic_literal_addresses_rejected(self):
        for url in ['http://example.org/','https://127.0.0.1/','https://device.local/','https://u:p@example.org/']:
            with self.assertRaises(r.ResolveError):r.checked_url(url)


if __name__=='__main__':unittest.main()
