import hashlib
import importlib.util
import io
import json
import random
from pathlib import Path
import subprocess
import sys
import tarfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import catalogue
import updater


def archive(entries):
    output=io.BytesIO()
    with tarfile.open(fileobj=output,mode='w:gz') as tar:
        for name,body in entries:
            info=tarfile.TarInfo(name);info.size=len(body);tar.addfile(info,io.BytesIO(body))
    return output.getvalue()


def package(control_version='0.2.0',extra_control=False,bad_path=False):
    control=archive([('./control',('Package: '+updater.PACKAGE+'\nVersion: '+control_version+'\n').encode())]+([('./postinst',b'bad')] if extra_control else []))
    payload=archive([('etc/other' if bad_path else './usr/lib/enigma2/python/Plugins/Extensions/MKEkinoE2/plugin.py',random.Random(7).randbytes(4096))])
    result=bytearray(b'!<arch>\n')
    for name,data in [('debian-binary',b'2.0\n'),('control.tar.gz',control),('data.tar.gz',payload)]:
        header=(name+'/').ljust(16)+'0'.ljust(12)+'0'.ljust(6)+'0'.ljust(6)+'100644'.ljust(8)+str(len(data)).ljust(10)+'`\n'
        result.extend(header.encode()+data+(b'\n' if len(data)%2 else b''))
    # Manifest deliberately rejects implausibly small packages; the fixture is still >1 KiB.
    return bytes(result)


class UpdateTests(unittest.TestCase):
    def release(self,data):
        return {'package':updater.PACKAGE,'version':'0.2.0','url':updater.BASE+'packages/MK_Ekino_E2_0.2.0.ipk',
                'sha256':hashlib.sha256(data).hexdigest(),'size':len(data),'notes':'Test'}

    def test_version_ordering_is_numeric_and_current_release_is_not_an_update(self):
        release=self.release(package())
        self.assertGreater(updater.version('0.10.0'),updater.version('0.9.9'))
        with patch.object(updater,'download',return_value=json.dumps(release).encode()):
            self.assertEqual(updater.check('0.1.3')['status'],'available')
            self.assertEqual(updater.check('0.2.0')['status'],'current')
            self.assertEqual(updater.check('0.3.0')['status'],'current')

    def test_manifest_accepts_only_own_versioned_package_url(self):
        data=package();release=self.release(data)
        # Validate shape on a realistically sized byte count.
        release['size']=150000
        self.assertEqual(updater.validate(release)['version'],'0.2.0')
        for changes in [{'url':'https://example.org/test.ipk'},{'package':'another-plugin'},{'sha256':'x'},{'size':True},{'version':'../../escape'}]:
            with self.assertRaises(updater.UpdateError):updater.validate(dict(release,**changes))

    def test_package_identity_checksum_hooks_and_paths_are_checked_before_install(self):
        data=package();updater.verify_package(data,self.release(data))
        with self.assertRaisesRegex(updater.UpdateError,'checksum'):updater.verify_package(data+b'x',self.release(data))
        for bad in [package(control_version='0.1.0'),package(extra_control=True),package(bad_path=True)]:
            with self.assertRaises(updater.UpdateError):updater.verify_package(bad,self.release(bad))

    def test_install_checks_opkg_result_and_installed_version(self):
        data=package();release=self.release(data)
        responses=[subprocess.CompletedProcess([],0,b'Installed'),subprocess.CompletedProcess([],0,b'Version: 0.2.0\nStatus: install user installed\n')]
        with patch.object(updater,'download',return_value=data),patch.object(updater.subprocess,'run',side_effect=responses) as run:
            result=updater.install(release,'0.1.3','0.2.0',release['sha256'])
            self.assertEqual(result['status'],'installed')
            self.assertEqual(run.call_args_list[0].args[0][:2],['/usr/bin/opkg','install'])
        with patch.object(updater,'download',return_value=data),patch.object(updater.subprocess,'run',return_value=subprocess.CompletedProcess([],1,b'Failure')):
            with self.assertRaisesRegex(updater.UpdateError,'install_failed'):updater.install(release,'0.1.3','0.2.0',release['sha256'])

    def test_release_changed_or_downgrade_never_starts_download(self):
        release=self.release(package())
        with patch.object(updater,'download') as download:
            with self.assertRaisesRegex(updater.UpdateError,'release_changed'):updater.install(release,'0.1.3','0.3.0',release['sha256'])
            with self.assertRaisesRegex(updater.UpdateError,'not_newer'):updater.install(release,'0.2.0','0.2.0',release['sha256'])
            download.assert_not_called()


class RatingTests(unittest.TestCase):
    def card(self,score,votes):
        return '''<div class="movies-list-item"><a href="/movie/show/test/123"><img alt="Test" src="/cover.jpg"></a>
        <div class="title"><a>Test</a></div><div class="movieDesc">Description</div>
        <div class="info-list"><div class="sum-vote"><div style="padding-top:7px;">%s</div></div>
        <div class="h-line"></div><font>Ocen</font><br /><font>%s</font><br /></div></div>''' % (score,votes)

    def test_score_and_vote_count_are_read_from_existing_card_html(self):
        entries=catalogue.cards(self.card('8.5','17'),'https://ekino.ws/movie/cat/+')
        self.assertEqual(entries[0]['rating'],8.5);self.assertEqual(entries[0]['rating_votes'],17)
        self.assertIn('Ekino: 8,5/10 · głosów: 17',entries[0]['desc'])

    def test_unrated_is_not_presented_as_a_real_zero_score(self):
        result=catalogue.cards(self.card('0','0'),'https://ekino.ws/movie/cat/+')[0]
        self.assertEqual(result['rating_label'],'Ekino: brak ocen')
        self.assertEqual(catalogue.card_rating(self.card('bad','0')),{})


if __name__=='__main__':unittest.main()
