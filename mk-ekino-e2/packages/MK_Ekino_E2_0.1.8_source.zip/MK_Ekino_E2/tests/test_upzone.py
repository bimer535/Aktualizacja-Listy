import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import resolver
import worker
from other_sources import OtherSources,decode_upzone
from test_resolver import HLS

VECTORS=json.loads((ROOT/'reference/upzone_vectors.json').read_text())['vectors']
MP4=VECTORS[1]
MANIFEST=VECTORS[2]
EMBED='https://upzone.cc/embed/Example123'


def player(vector):return '<script>video.src=cnc(atob("'+vector['encoded']+'"));</script>'


class Client:
    def __init__(self,pages):self.pages=pages;self.calls=[];self.meta={}
    def getDefaultHeader(self):return {'User-Agent':'test'}
    def getPage(self,url,params=None,post_data=None):
        self.calls.append((str(url),params))
        page=self.pages[str(url)]
        status,body=page if isinstance(page,tuple) else (200,page)
        self.meta={'url':str(url),'status_code':status}
        return status==200,resolver.Body(body)


class UpzoneTests(unittest.TestCase):
    def test_python_decoder_matches_original_public_duktape_vectors(self):
        # Includes all 256 possible input bytes and four representative URLs.
        for vector in VECTORS:
            with self.subTest(encoded=vector['encoded'][:12]):
                self.assertEqual(decode_upzone(vector['encoded']),vector['decoded'])
        for bad in ('!!!!','x'*5000,None):
            with self.assertRaises(ValueError):decode_upzone(bad)

    def test_direct_embed_returns_mp4_with_final_referrer_and_agent(self):
        client=Client({EMBED:player(MP4)})
        options=OtherSources(client).parserUPZONECC(resolver.URL(EMBED,{'Referer':'https://ekino.ws/watch/f/upzone/test'}))
        self.assertEqual(str(options[0]['url']),MP4['decoded'])
        self.assertEqual(options[0]['url'].meta,{'Referer':EMBED,'User-Agent':'test','Origin':'https://upzone.cc'})
        self.assertEqual(len(client.calls),1)
        self.assertEqual(client.calls[0][1]['header']['Referer'],'https://ekino.ws/watch/f/upzone/test')

    def test_file_page_follows_public_embed_path_and_decodes_only_valid_url(self):
        page='https://upzone.cc/Example123'
        client=Client({page:'<html>file</html>',EMBED:'"'+'a'*200+'"\n'+player(MP4)})
        options=OtherSources(client).parserUPZONECC(page)
        self.assertEqual(str(options[0]['url']),MP4['decoded'])
        self.assertEqual([call[0] for call in client.calls],[page,EMBED])

    def test_hls_variants_use_upzone_headers_and_existing_audio_selection(self):
        client=Client({EMBED:player(MANIFEST),MANIFEST['decoded']:HLS});resolver.ACTIVE_HTTP=client
        options=OtherSources(client).parserUPZONECC(EMBED)
        self.assertEqual([item['language'] for item in options],['pl','en'])
        self.assertEqual(client.calls[-1][1]['header']['Referer'],EMBED)
        self.assertEqual(client.calls[-1][1]['header']['Origin'],'https://upzone.cc')

    def test_cloudflare_refusal_is_reported_without_retry_or_decoding(self):
        for page in [(403,'Forbidden'),(200,'<script src="/cdn-cgi/challenge-platform/cf-chl-test"></script>')]:
            client=Client({EMBED:page})
            with self.assertRaisesRegex(resolver.ResolveError,'source_access_denied'):
                OtherSources(client).parserUPZONECC(EMBED)
            self.assertEqual(len(client.calls),1)

    def test_free_transfer_limit_is_distinct_from_missing_payload(self):
        client=Client({EMBED:'Transfer dla darmowych użytkowników został <b>wyczerpany</b>. Wymagane PREMIUM.'})
        with self.assertRaisesRegex(resolver.ResolveError,'upzone_transfer_limit'):
            OtherSources(client).parserUPZONECC(EMBED)
        client=Client({EMBED:'<a>Kup konto PREMIUM</a><p>Nie znaleziono filmu.</p>'})
        with self.assertRaisesRegex(resolver.ResolveError,'upzone_payload_not_found'):
            OtherSources(client).parserUPZONECC(EMBED)

    def test_unrelated_host_is_not_treated_as_upzone(self):
        client=Client({})
        with self.assertRaisesRegex(resolver.ResolveError,'upzone_address_not_supported'):
            OtherSources(client).parserUPZONECC('https://upzone.cc.example/embed/test')
        self.assertEqual(client.calls,[])

    def test_worker_resolves_selected_upzone_link_independently_of_e2i(self):
        title='https://ekino.ws/movie/show/example/123'
        watch='https://ekino.ws/watch/f/upzone/FreshId'
        client=Client({title:"ShowPlayer('upzone','FreshId')",watch:'<iframe src="'+EMBED+'"></iframe>',EMBED:player(MP4)})
        options=worker.source_options(client,{'url':title,'provider':'upzone','provider_index':0})
        self.assertEqual(str(options[0]['url']),MP4['decoded'])
        self.assertEqual([call[0] for call in client.calls],[title,watch,EMBED])


if __name__=='__main__':unittest.main()
