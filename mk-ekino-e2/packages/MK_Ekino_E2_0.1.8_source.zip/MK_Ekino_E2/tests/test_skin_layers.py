import ast
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]


def current_skin():
    tree=ast.parse((ROOT/'src/MKEkinoE2/plugin.py').read_text())
    screen=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='MKEkino')
    return ast.literal_eval(next(node.value for node in screen.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='skin' for target in node.targets)))


def overlap(first,second):
    def box(element):
        x,y=map(int,element.attrib['position'].split(','));w,h=map(int,element.attrib['size'].split(','))
        return x,y,x+w,y+h
    a,b=box(first),box(second)
    return max(a[0],b[0])<min(a[2],b[2]) and max(a[1],b[1])<min(a[3],b[3])


def hidden_by_later_backgrounds(skin):
    # OpenATV Screen.createGUIScreen creates named GUIComponents first,
    # then additionalWidgets such as eLabel. Later equal-z siblings cover them.
    # Source: openatv/enigma2 26c24da, lib/python/Screens/Screen.py.
    root=ET.fromstring(skin)
    backgrounds=root.findall('eLabel')
    return {widget.attrib['name'] for widget in root.findall('widget')
            if any(overlap(widget,background) and
                   int(background.attrib.get('zPosition',0))>=int(widget.attrib.get('zPosition',0))
                   for background in backgrounds)}


class SkinLayersTests(unittest.TestCase):
    def test_previous_default_layer_reproduces_loaded_but_invisible_menu(self):
        previous=re.sub(r' zPosition="[01]"','',current_skin())
        hidden=hidden_by_later_backgrounds(previous)
        self.assertTrue({'heading','path','list','selected_title','description'}.issubset(hidden))
        self.assertNotIn('counter',hidden)
        self.assertNotIn('blue',hidden)

    def test_text_and_list_are_above_all_overlapping_backgrounds(self):
        self.assertEqual(hidden_by_later_backgrounds(current_skin()),set())
        root=ET.fromstring(current_skin())
        poster=next(e for e in root.findall('widget') if e.attrib['name']=='poster')
        hint=next(e for e in root.findall('widget') if e.attrib['name']=='poster_hint')
        self.assertGreater(int(poster.attrib['zPosition']),int(hint.attrib['zPosition']))


if __name__=='__main__':unittest.main()
