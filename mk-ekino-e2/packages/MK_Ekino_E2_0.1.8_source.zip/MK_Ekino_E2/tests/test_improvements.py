import ast
import base64
import ctypes
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import Mock,patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import access_cache
import fast_pow
import resolver
from other_sources import OtherSources,get_packed_data
from test_resolver import HLS


def reference_hash():
    root=ast.parse((ROOT/'reference/public_byse_method.txt').read_text())
    names=('grAbsorb','gr','powBytes')
    nodes=[n for n in ast.walk(root) if isinstance(n,ast.FunctionDef) and n.name in names]
    space={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'public_hash','exec'),space)
    return space


class PowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.addClassCleanup(cls.temp.cleanup)
        cls.library=Path(cls.temp.name)/'pow.so'
        subprocess.run(['gcc','-O3','-shared','-fPIC',str(ROOT/'native/pow.c'),'-o',str(cls.library)],check=True)

    def test_native_hash_matches_independent_public_python_reference(self):
        lib=fast_pow.native_library(self.library);self.assertIsNotNone(lib)
        ref=reference_hash()
        for value in [b'example:0',b'a:1',b'long-'+b'n'*100+b':999']+[('vector:'+str(i)).encode() for i in range(30)]:
            self.assertEqual(lib.mk_pow_zero_bits(value,len(value)),ref['gr']((1779033703,3144134277,1013904242,2773480762),list(value)))

    def test_native_solver_finds_same_first_solution_and_respects_timeout(self):
        solve=fast_pow.make_solver(self.library);ref=reference_hash();state=ref['grAbsorb'](list(b'proof:'))
        expected=next(i for i in range(2000) if ref['gr'](state,list(str(i).encode()))>=6)
        self.assertEqual(solve('proof',6,10),(str(expected),expected+1))
        solution,count=solve('timeout',256,0)
        self.assertIsNone(solution);self.assertEqual(count,256)

    def test_missing_native_library_preserves_python_fallback(self):
        self.assertIsNone(fast_pow.make_solver(Path('/missing/optional-module.so')))


class CacheTests(unittest.TestCase):
    def value(self,expiry):return [expiry,{'viewer_id':'test-viewer','device_id':'test-device','confidence':.9,'token':'private-fp'},'private-access']

    def test_cache_is_private_and_expiry_is_enforced(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'cache.json'
            access_cache.save({'https://mfw09.org/':self.value(time.time()+120)},path)
            self.assertEqual(path.stat().st_mode&0o777,0o600)
            self.assertIn('https://mfw09.org/',access_cache.load(path))
            data=json.loads(path.read_text());data['https://mfw09.org/'][0]=time.time()-1;path.write_text(json.dumps(data))
            self.assertEqual(access_cache.load(path),{})
            self.assertEqual(access_cache.valid({'https://mfw09.org/':self.value(time.time()+9999)}),{})

    def test_corrupt_or_unsafe_origins_are_ignored(self):
        self.assertEqual(access_cache.valid({'http://example.org/':self.value(time.time()+30)}),{})
        self.assertEqual(access_cache.valid({'https://u:p@example.org/':self.value(time.time()+30)}),{})

    def test_cached_access_skips_all_challenge_requests(self):
        class Client:
            def __init__(self):self.meta={};self.calls=[]
            def getDefaultHeader(self):return {'User-Agent':'test'}
            def getPage(self,url,params=None,post_data=None):
                self.calls.append((url,params,post_data));self.meta={'url':str(url),'status_code':200}
                data='{}'
                if str(url).endswith('/settings'):data='{"captcha_required":true}'
                if str(url).endswith('/playback'):data=json.dumps({'sources':[{'url':'https://cdn.example/master.m3u8'}]})
                if 'master.m3u8' in url:data=HLS
                body=resolver.Body(data);body.meta=dict(self.meta);return True,body
        client=Client();engine=resolver.Byse(client)
        engine.BYSE_ACCESS={'https://mfw09.org/':self.value(time.time()+300)}
        resolver.ACTIVE_HTTP=client
        self.assertEqual(len(engine.parserBYSE(resolver.URL('https://mfw09.org/e/example'))),2)
        self.assertFalse(any('/access/' in str(c[0]) or str(c[0]).endswith('/captcha') for c in client.calls))
        playback=next(c for c in client.calls if str(c[0]).endswith('/playback'))
        self.assertEqual(playback[1]['header']['X-Captcha-Token'],'private-access')

    def test_rejected_cached_access_renews_through_native_solver_hook(self):
        class Client:
            def __init__(self):self.meta={};self.calls=[];self.playbacks=0
            def getDefaultHeader(self):return {'User-Agent':'test'}
            def getPage(self,url,params=None,post_data=None):
                url=str(url);self.calls.append((url,params,post_data));self.meta={'url':url,'status_code':200}
                data={}
                if url.endswith('/settings'):data={'captcha_required':True}
                elif url.endswith('/playback'):
                    self.playbacks+=1
                    data={'error':'captcha_required'} if self.playbacks==1 else {'sources':[{'url':'https://cdn.example/master.m3u8'}]}
                elif url.endswith('/access/challenge'):data={'challenge_id':'test','nonce':'test'}
                elif url.endswith('/access/attest'):data={'token':'new-fp','viewer_id':'v','device_id':'d','confidence':.9}
                elif url.endswith('/captcha'):data={'pow_token':'test','pow_nonce':'test','pow_difficulty':4,'expires_in':300}
                elif url.endswith('/captcha/verify'):data={'token':'fresh-access','expires_in':1800}
                body=resolver.Body(HLS if 'master.m3u8' in url else json.dumps(data));body.meta=dict(self.meta)
                return True,body
        client=Client();engine=resolver.Byse(client);engine.pow_solver=Mock(return_value=('3',4))
        engine.BYSE_ACCESS={'https://mfw09.org/':self.value(time.time()+300)}
        resolver.ACTIVE_HTTP=client
        self.assertEqual(len(engine.parserBYSE(resolver.URL('https://mfw09.org/e/example'))),2)
        engine.pow_solver.assert_called_once()
        self.assertEqual(engine.pow_stats['engine'],'native_armv7')
        self.assertEqual(engine.BYSE_ACCESS['https://mfw09.org/'][2],'fresh-access')
        challenge=next(c for c in client.calls if c[0].endswith('/access/challenge'))
        self.assertNotIn('X-Captcha-Token',challenge[1]['header'])


class OtherSourceTests(unittest.TestCase):
    def test_voe_base64_hls_produces_language_variants(self):
        class Client:
            def __init__(self):self.meta={}
            def isValidUrl(self,value):return value.startswith('https://')
            def getPage(self,url,params=None,post_data=None):
                self.meta={'url':str(url)}
                data=HLS if 'master.m3u8' in url else 'hls: "'+base64.b64encode(b'https://cdn.example/master.m3u8').decode()+'"'
                return True,resolver.Body(data)
        client=Client();resolver.ACTIVE_HTTP=client
        self.assertEqual([v['language'] for v in OtherSources(client).parserVOESX('https://voe.sx/e/example')],['pl','en'])

    def test_mixdrop_packed_script_is_parsed_without_js_execution(self):
        page="eval(function(p,a,c,k,e,d){return p}('0.1=\"//2/3.4\";',36,5,'MDCore|wurl|cdn.example|movie|mp4'.split('|'),0,{}))"
        self.assertIn('MDCore.wurl="//cdn.example/movie.mp4"',get_packed_data(page))
        client=Mock();client.getDefaultHeader.return_value={'User-Agent':'test'}
        client.meta={'url':'https://mixdrop.ag/e/example'};client.getPage.return_value=(True,resolver.Body(page))
        options=OtherSources(client).parserMIXDROP('https://mixdrop.ag/e/example')
        self.assertEqual(str(options[0]['url']),'https://cdn.example/movie.mp4')


if __name__=='__main__':unittest.main()
