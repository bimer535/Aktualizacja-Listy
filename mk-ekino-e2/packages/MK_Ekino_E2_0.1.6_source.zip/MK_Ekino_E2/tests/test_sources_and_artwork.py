import base64
import codecs
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import catalogue
import poster
import resolver
import worker
from other_sources import OtherSources,get_packed_data
from test_resolver import HLS


class SourceTests(unittest.TestCase):
    def client(self,page):
        class Client:
            def __init__(self):self.meta={};self.calls=[]
            def getDefaultHeader(self):return {'User-Agent':'test'}
            def isValidUrl(self,url):return url.startswith('https://')
            def getPage(self,url,params=None,post_data=None):
                self.calls.append((url,params));self.meta={'url':str(url),'status_code':200}
                return True,resolver.Body(HLS if '.m3u8' in str(url) else page)
        client=Client();resolver.ACTIVE_HTTP=client;return client

    def test_mixdrop_packed_payload_handles_escaped_quotes(self):
        payload='0.1="//2/3.4";0.5="it\'s available";'
        page="eval(function(p,a,c,k,e,d){return p}(%r,36,6,'MDCore|wurl|cdn.example|movie|mp4|title'.split('|'),0,{}))" % payload
        decoded=get_packed_data(page)
        self.assertIn('MDCore.wurl="//cdn.example/movie.mp4"',decoded)
        options=OtherSources(self.client(page)).parserMIXDROP('https://mixdrop.ag/e/example')
        self.assertEqual(str(options[0]['url']),'https://cdn.example/movie.mp4')

    def test_voe_encoded_json_handles_all_literal_noise_markers(self):
        first=base64.b64encode(json.dumps({'source':'https://cdn.example/master.m3u8'}).encode()).decode()
        transformed=''.join(chr(ord(c)+3) for c in first[::-1])
        second=base64.b64encode(transformed.encode()).decode()
        noise='#&%?*~~@^^!!@$'
        payload=codecs.encode(second[:12]+noise+second[12:],'rot_13')
        page='<script type="application/json">["'+payload+'"]</script>'
        client=self.client(page)
        options=OtherSources(client).parserVOESX('https://voe.sx/e/example')
        self.assertEqual([o['language'] for o in options],['pl','en'])

    def test_voe_plain_hls_url_preserves_final_origin_headers(self):
        client=self.client('hls: "https://cdn.example/master.m3u8"')
        options=OtherSources(client).parserVOESX('https://voe.sx/e/example')
        self.assertEqual(len(options),2)
        self.assertEqual(client.calls[-1][1]['header']['Referer'],'https://voe.sx/e/example')
        self.assertEqual(client.calls[-1][1]['header']['Origin'],'https://voe.sx')

    def test_sst_and_html5_sources_offer_all_public_quality_links(self):
        page='<video><source label="1080p" src="https://cdn.example/1080.mp4"><source src="https://cdn.example/720.mp4" label="720p"></video>'
        client=self.client(page)
        options=OtherSources(client).parserSST('https://wrzucaj.pl/example')
        self.assertEqual([o['name'] for o in options],['1080p','720p'])
        self.assertEqual(options[0]['url'].meta['Referer'],'https://wrzucaj.pl/example')
        page='new Playerjs({file:"[360p]https://cdn.example/360.mp4,[720p]https://cdn.example/720.mp4"})'
        self.assertEqual(len(OtherSources(self.client(page)).parserSST('https://shvid.example/e/test')),2)

    def test_multiple_links_from_same_provider_remain_selectable_without_saving_session_ids(self):
        text="ShowPlayer('player','ID-ONE') ShowPlayer('player','ID-TWO') ShowPlayer('player','ID-ONE')"
        entries=catalogue.source_items(text,{'url':'https://ekino.ws/movie/show/example','title':'Film'})
        self.assertEqual([e['provider_index'] for e in entries],[0,1])
        self.assertNotIn('ID-ONE',json.dumps(entries))
        client=Mock();client.meta={'url':'https://ekino.ws/watch/f/player/NEW-TWO','status_code':200}
        client.getPage.side_effect=[(True,"ShowPlayer('player','NEW-ONE') ShowPlayer('player','NEW-TWO')"),
                                    (True,'<iframe src="https://mfw09.org/e/example"></iframe>')]
        with patch.object(resolver.Byse,'parserBYSE',return_value=[{'name':'ok'}]):worker.source_options(client,entries[1])
        self.assertTrue(str(client.getPage.call_args_list[1].args[0]).endswith('/NEW-TWO'))

    def test_cloudflare_block_is_reported_before_parser_or_player(self):
        client=Mock();client.meta={'status_code':403,'url':'https://ekino.ws/'}
        client.getPage.side_effect=[(True,"ShowPlayer('mix','ID')"),(False,'Attention Required! | Cloudflare')]
        with self.assertRaisesRegex(resolver.ResolveError,'source_access_denied'):
            worker.source_options(client,{'provider':'mix','url':'https://ekino.ws/movie/show/example'})


class PosterTests(unittest.TestCase):
    def test_poster_cache_reuses_image_and_rejects_html_or_oversized_responses(self):
        url='https://ekino.ws/static/thumb/example.jpg'
        class Response(io.BytesIO):
            def geturl(self):return url
        with tempfile.TemporaryDirectory() as temporary:
            cache=Path(temporary)
            opener=Mock();opener.open.return_value=Response(b'\xff\xd8\xff'+b'jpeg-fixture')
            with patch.object(poster.urllib.request,'build_opener',return_value=opener):
                path=poster.fetch(url,cache)
                self.assertEqual(poster.fetch(url,cache),path)
                self.assertEqual(opener.open.call_count,1)
                self.assertEqual(path.stat().st_mode&0o777,0o600)
                path.unlink();opener.open.return_value=Response(b'<html>error</html>')
                with self.assertRaisesRegex(ValueError,'poster_not_image'):poster.fetch(url,cache)
                opener.open.return_value=Response(b'\xff\xd8\xff'+b'x'*poster.MAX_BYTES)
                with self.assertRaisesRegex(ValueError,'poster_too_large'):poster.fetch(url,cache)

    def test_artwork_is_limited_to_ekino_thumbnails(self):
        for url in ['https://example.org/movie.jpg','http://ekino.ws/static/thumb/x.jpg','https://ekino.ws/other/x.jpg','https://user@ekino.ws/static/thumb/x.jpg']:
            with self.assertRaises(ValueError):poster.valid_url(url)


if __name__=='__main__':unittest.main()
