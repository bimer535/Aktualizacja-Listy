# SPDX-License-Identifier: GPL-3.0-only
"""MK Ekino E2: independent catalogue and native Enigma2 playback UI."""
import json
from pathlib import Path
import shutil
import tempfile
import urllib.parse

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBar import MoviePlayer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import eConsoleAppContainer, eServiceReference, eTimer

ROOT=Path(__file__).resolve().parent
VERSION='0.1.3'
HISTORY=Path('/etc/mk-ekino-e2/history.json')


def read_history():
    try:
        values=json.loads(HISTORY.read_text())
        return [s for s in values if isinstance(s,str) and 0<len(s)<=200][:20] if isinstance(values,list) else []
    except (OSError,ValueError):return []


def save_history(term):
    values=[term]+[s for s in read_history() if s!=term]
    HISTORY.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    path=HISTORY.with_suffix('.tmp')
    fd=__import__('os').open(path,__import__('os').O_CREAT|__import__('os').O_TRUNC|__import__('os').O_WRONLY,0o600)
    with __import__('os').fdopen(fd,'w',encoding='utf-8') as out:json.dump(values[:20],out,ensure_ascii=False)
    path.replace(HISTORY)


class Notices(Screen):
    skin='''<screen name="MKEkinoNotices" position="center,center" size="1160,630" title="MK Ekino E2 — informacje i licencja">
      <widget name="text" position="25,20" size="1110,565" font="Regular;19" />
      <widget name="hint" position="25,590" size="1110,30" font="Regular;20" />
    </screen>'''
    def __init__(self,session):
        Screen.__init__(self,session)
        self['text']=ScrollLabel((ROOT/'NOTICE.txt').read_text()+'\n'+(ROOT/'LICENSE').read_text())
        self['hint']=Label('↑/↓ lub CH+/CH−: przewiń · EXIT: wróć')
        self['actions']=ActionMap(['OkCancelActions','NavigationActions'],{'cancel':self.close,'ok':self.close,
            'up':self['text'].pageUp,'down':self['text'].pageDown,
            'pageUp':self['text'].pageUp,'pageDown':self['text'].pageDown},-2)


class EkinoMoviePlayer(MoviePlayer):
    skinName='MoviePlayer'

    def __init__(self,session,service,**kwargs):
        MoviePlayer.__init__(self,session,service,**kwargs)
        self.mk_leaving=False
        # Close on key release, so the same EXIT cannot also move back in Ekino.
        self['mkExitActions']=ActionMap(['OkCancelActions','InfobarShowHideActions'],{
            'cancel':self.exit_to_ekino,'close':self.exit_to_ekino,'hide':self.exit_to_ekino},-10)

    def leavePlayerOnExit(self):
        return 1  # Consume the make event; the release above stops playback.

    def exit_to_ekino(self):
        if not self.mk_leaving:
            self.mk_leaving=True
            self.leavePlayer()
        return 1


class Updates(Screen):
    skin='''<screen name="MKEkinoUpdates" position="center,center" size="1050,470" title="MK Ekino E2 — aktualizacja">
      <widget name="text" position="30,25" size="990,350" font="Regular;25" />
      <widget name="hint" position="30,400" size="990,40" font="Regular;22" foregroundColor="#66aaff" />
    </screen>'''

    def __init__(self,session):
        Screen.__init__(self,session)
        self['text']=Label('Zainstalowana wersja: '+VERSION+'\nSprawdzanie aktualizacji na GitHubie…')
        self['hint']=Label('EXIT: wróć')
        self['actions']=ActionMap(['OkCancelActions','ColorActions'],{
            'cancel':self.back,'ok':self.confirm,'blue':self.confirm,'green':self.confirm},-2)
        self.container=None;self.busy=False;self.installing=False;self.closed=False
        self.release=None;self.buffer='';self.restart_needed=False
        self.timer=eTimer();self.timer.callback.append(self.check)
        self.onLayoutFinish.append(self.layout_finished);self.onClose.append(self.cleanup)

    def layout_finished(self):self.timer.start(150,True)

    def check(self):self.run(False)

    def run(self,install):
        if self.busy or self.closed:return
        self.busy=True;self.installing=install;self.buffer=''
        self.container=eConsoleAppContainer()
        self.container.dataAvail.append(self.data);self.container.appClosed.append(self.finished)
        python='/usr/bin/python3'
        args=[python,python,'-u',str(ROOT/'updater.py'),'--current',VERSION]
        if install:
            args+=['--install','--expected-version',self.release['version'],'--expected-sha',self.release['sha256']]
            self['text'].setText('Pobieranie, sprawdzanie i instalacja wersji '+self.release['version']+'…')
            self['hint'].setText('Poczekaj na zakończenie instalacji.')
        if self.container.execute(*args):self.finished(1)

    def data(self,data):
        if not self.closed:self.buffer=(self.buffer+(data.decode('utf-8','replace') if isinstance(data,bytes) else data))[-32768:]

    def detach(self):
        if self.container is not None:
            for event,callback in [(self.container.dataAvail,self.data),(self.container.appClosed,self.finished)]:
                if callback in event:event.remove(callback)
            self.container=None

    def finished(self,code):
        self.busy=False;self.detach()
        if self.closed:return
        result={}
        for line in self.buffer.splitlines():
            try:
                candidate=json.loads(line)
                if isinstance(candidate,dict):result=candidate
            except ValueError:pass
        status=result.get('status')
        self['hint'].setText('EXIT: wróć')
        if code==0 and status=='available' and isinstance(result.get('version'),str) and isinstance(result.get('sha256'),str):
            self.release=result
            self['text'].setText('Zainstalowana: '+VERSION+'\nDostępna: '+result['version']+'\n\n'+result.get('notes',''))
            self['hint'].setText('OK / niebieski: zainstaluj · EXIT: wróć')
        elif code==0 and status=='current':
            self['text'].setText('Wersja '+VERSION+' jest aktualna.')
        elif code==0 and status=='installed':
            self.restart_needed=True;self.release=None
            self['text'].setText('Zainstalowano wersję '+result['version']+'.\nUruchom ponownie interfejs Enigma2, aby jej użyć.')
            self['hint'].setText('OK: restart interfejsu · EXIT: restart później')
            self.confirm()
        else:
            self.release=None
            messages={'checksum_mismatch':'Pobrany plik jest niekompletny lub ma niezgodną sumę kontrolną.',
                'install_failed':'Instalacja nie powiodła się. Sprawdź wolne miejsce i dostępność zależności.',
                'installed_version_not_confirmed':'Nie potwierdzono nowej wersji w menedżerze pakietów.',
                'release_changed':'Wydanie zmieniło się podczas sprawdzania. Otwórz aktualizacje ponownie.'}
            self['text'].setText(messages.get(result.get('reason'),'Nie udało się sprawdzić lub pobrać aktualizacji. Spróbuj ponownie później.'))

    def confirm(self):
        if self.busy:return
        if self.restart_needed:
            self.session.openWithCallback(self.restart,MessageBox,'Uruchomić ponownie interfejs Enigma2?',type=MessageBox.TYPE_YESNO,default=False)
        elif self.release:
            self.session.openWithCallback(self.accepted,MessageBox,'Zainstalować MK Ekino E2 '+self.release['version']+'?',type=MessageBox.TYPE_YESNO,default=False)

    def accepted(self,answer):
        if answer and self.release and not self.closed:self.run(True)

    def restart(self,answer):
        if answer and not self.closed:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop,3)

    def back(self):
        if self.busy and self.installing:return
        self.close()

    def cleanup(self):
        self.closed=True;self.timer.stop()
        if self.busy and not self.installing and self.container is not None:self.container.sendCtrlC()
        self.detach()


class MKEkino(Screen):
    skin='''<screen name="MKEkinoE2" position="center,center" size="1200,650" title="MK Ekino E2" backgroundColor="#080808">
      <widget name="heading" position="25,15" size="1150,38" font="Regular;28" foregroundColor="white" />
      <widget name="path" position="25,58" size="1150,32" font="Regular;20" foregroundColor="#b0b0b0" />
      <widget name="list" position="25,100" size="1150,370" scrollbarMode="showOnDemand" />
      <widget name="description" position="25,482" size="1150,80" font="Regular;20" foregroundColor="#e6d3b2" />
      <widget name="status" position="25,565" size="1150,30" font="Regular;20" foregroundColor="white" />
      <widget name="red" position="25,608" size="260,30" font="Regular;21" foregroundColor="#ff5555" />
      <widget name="green" position="305,608" size="260,30" font="Regular;21" foregroundColor="#66ee66" />
      <widget name="yellow" position="585,608" size="260,30" font="Regular;21" foregroundColor="#ffff66" />
      <widget name="blue" position="865,608" size="310,30" font="Regular;21" foregroundColor="#66aaff" />
    </screen>'''
    def __init__(self,session):
        Screen.__init__(self,session)
        self['heading']=Label('MK Ekino E2  ·  '+VERSION)
        self['path']=Label('Filmy i seriale')
        self['list']=MenuList([])
        self['description']=Label('')
        self['status']=Label('OK: wybierz · ↑/↓: nawigacja')
        self['red']=Label('Wyjdź / Wróć');self['green']=Label('Wyszukaj')
        self['yellow']=Label('Odśwież');self['blue']=Label('Aktualizacja')
        self['actions']=ActionMap(['OkCancelActions','ColorActions','NavigationActions','InfoActions','MenuActions'],{
            'ok':self.select,'cancel':self.back,'red':self.back,'green':self.search,
            'yellow':self.refresh,'blue':self.updates,
            'info':self.notices,'menu':self.notices,
            'up':lambda:self.move('up'),'down':lambda:self.move('down'),
            'pageUp':lambda:self.move('pageUp'),'pageDown':lambda:self.move('pageDown')},-2)
        self['list'].onSelectionChanged.append(self.selection_changed)
        self.current={'action':'main','title':'Ekino'};self.entries=[];self.stack=[]
        self.container=None;self.running=False;self.stopping=False;self.closed=False
        self.job_dir=None;self.pending=None;self.buffer='';self.push=False;self.playing=False
        self.timer=eTimer();self.timer.callback.append(lambda:self.load(self.current,push=False))
        self.onLayoutFinish.append(self.layout_finished)
        self.onClose.append(self.cleanup)

    def layout_finished(self):
        # OpenATV 7.4 treats plain functions in onLayoutFinish as exec() text.
        # A bound screen method is called normally by createGUIScreen.
        self.timer.start(150,True)

    def move(self,method):
        getattr(self['list'],method)()
        self.selection_changed()

    def selection_changed(self):
        value=self['list'].getCurrent()
        self['description'].setText(value[1].get('desc','') if value else '')

    def show_items(self,items):
        self.entries=items
        self['list'].setList([(self.display_title(x),x) for x in items])
        self['path'].setText(' > '.join([s[0].get('title','') for s in self.stack]+[self.current.get('title','Ekino')]))
        self['status'].setText('OK: wybierz · %d pozycji' % len(items) if items else 'Brak pozycji. EXIT: wróć.')
        self.selection_changed()

    @staticmethod
    def display_title(entry):
        if entry.get('rating_label'):
            if entry.get('rating_votes')==0:return '[brak ocen] '+entry['title']
            score=('%g' % entry['rating']).replace('.',',')
            return '['+score+'/10] '+entry['title']
        return entry['title']

    def select(self):
        value=self['list'].getCurrent()
        if not value or self.running:return
        entry=value[1]
        if entry['action']=='search':self.search()
        elif entry['action']=='history':
            self.stack.append((self.current,self.entries,self['list'].getSelectedIndex()))
            self.current=entry
            self.show_items([{'title':term,'action':'search_results','query':term} for term in read_history()])
        else:self.load(entry)

    def search(self):
        if self.running:return
        self.session.openWithCallback(self.search_done,VirtualKeyBoard,title='Tytuł filmu lub serialu',text='')

    def search_done(self,term):
        if not isinstance(term,str) or not term.strip():return
        term=term.strip()[:200]
        try:save_history(term)
        except OSError:pass
        self.load({'action':'search_results','title':'Szukaj: '+term,'query':term})

    def refresh(self):
        if self.running:return
        if self.current.get('action')=='history':
            self.show_items([{'title':term,'action':'search_results','query':term} for term in read_history()])
        else:self.load(self.current,push=False)

    def updates(self):
        if not self.running:self.session.open(Updates)

    def notices(self):self.session.open(Notices)

    def load(self,entry,push=True):
        if self.running or self.closed:return
        self.release_job()
        self.job_dir=Path(tempfile.mkdtemp(prefix='mk-ekino-ui-'))
        self.pending=dict(entry);self.push=push
        (self.job_dir/'request.json').write_text(json.dumps({'item':entry},ensure_ascii=False))
        (self.job_dir/'request.json').chmod(0o600)
        self.container=eConsoleAppContainer()
        self.container.dataAvail.append(self.data)
        self.container.appClosed.append(self.finished)
        self.buffer='';self.stopping=False;self.running=True
        python='/usr/bin/python3'
        result=self.container.execute(python,python,'-u',str(ROOT/'worker.py'),
            '--request',str(self.job_dir/'request.json'),'--result',str(self.job_dir/'result.json'),
            '--control',str(self.job_dir/'control.json'))
        self['status'].setText('Pobieranie źródła...' if entry['action']=='resolve' else 'Pobieranie listy...')
        if result:self.running=False;self.error('worker_start_failed')

    def data(self,data):
        if self.closed or self.stopping:return
        self.buffer=(self.buffer+(data.decode('utf-8','replace') if isinstance(data,bytes) else data))[-65536:]
        while '\n' in self.buffer:
            line,self.buffer=self.buffer.split('\n',1)
            try:event=json.loads(line)
            except (ValueError,TypeError):continue
            stage=event.get('stage') if isinstance(event,dict) else None
            if stage=='catalogue_ready':
                try:items=json.loads((self.job_dir/'result.json').read_text())['items']
                except (OSError,ValueError,KeyError):self.error('invalid_worker_result');continue
                if self.push:self.stack.append((self.current,self.entries,self['list'].getSelectedIndex()))
                self.current=self.pending;self.show_items(items)
            elif stage=='choose_variant':
                try:labels=json.loads((self.job_dir/'result.json').read_text())['variants']
                except (OSError,ValueError,KeyError):self.error('invalid_worker_result');self.stop_job();continue
                self.session.openWithCallback(self.variant_selected,ChoiceBox,title='Wybierz język i jakość',
                                              list=[(value,index) for index,value in enumerate(labels)])
            elif stage=='source_access_work':self['status'].setText('Weryfikacja źródła… może potrwać kilka minut. EXIT: anuluj.')
            elif stage=='play_ready':self.play(event.get('url',''))
            elif stage=='error':self.error(event.get('reason','error'))

    def variant_selected(self,choice):
        if self.closed or self.stopping or not self.running:return
        if choice is None:self.stop_job();return
        path=self.job_dir/'selection.tmp'
        path.write_text(json.dumps({'index':choice[1]}));path.chmod(0o600)
        path.replace(self.job_dir/'control.json')
        self['status'].setText('Uruchamianie filmu...')

    def play(self,url):
        parsed=urllib.parse.urlsplit(url)
        if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or not parsed.port:
            self.error('invalid_local_playback_address');self.stop_job();return
        ref=eServiceReference(4097,0,url)
        ref.setName(self.pending.get('movie_title','Ekino'))
        self.playing=True
        self.session.openWithCallback(self.movie_closed,EkinoMoviePlayer,ref,fromMovieSelection=False)

    def movie_closed(self,*args):
        self.playing=False;self.stop_job()

    def error(self,reason):
        messages={'upzone_not_yet_supported':'Źródło upzone nie jest jeszcze obsługiwane w tej wersji. Wybierz player.',
                  'watch_or_embed_http_error':'Źródło odmówiło dostępu. Odśwież listę źródeł lub spróbuj później.',
                  'source_returned_no_variants':'Źródło nie zwróciło dostępnych wariantów filmu.',
                  'catalogue_http_error':'Nie udało się pobrać katalogu. Sprawdź połączenie.',
                  'variant_selection_cancelled':'Wybór anulowany.'}
        text=messages.get(reason,'Nie udało się otworzyć pozycji: '+str(reason))
        self['status'].setText(text)
        self.session.open(MessageBox,text,type=MessageBox.TYPE_ERROR,timeout=12)

    def stop_job(self):
        if self.running and not self.stopping:
            self.stopping=True;self.container.sendCtrlC()
        elif not self.running:self.release_job()

    def finished(self,code):
        self.running=False;self.stopping=False
        if not self.closed and not self.playing:self['status'].setText('OK: wybierz · EXIT: wróć')
        self.release_job()

    def release_job(self):
        if self.running:return
        if self.container is not None:
            for event,callback in [(self.container.dataAvail,self.data),(self.container.appClosed,self.finished)]:
                if callback in event:event.remove(callback)
            self.container=None
        if self.job_dir is not None:
            shutil.rmtree(self.job_dir,ignore_errors=True);self.job_dir=None

    def back(self):
        if self.running:self.stop_job();return
        if self.stack:
            self.current,items,index=self.stack.pop();self.show_items(items)
            self['list'].moveToIndex(index)
        else:self.close()

    def cleanup(self):
        self.closed=True;self.timer.stop();self.stop_job()
        # Screen.doClose clears our state after onClose. Disconnect callbacks
        # now so a finishing worker cannot call into the destroyed screen.
        if self.container is not None:
            for event,callback in [(self.container.dataAvail,self.data),(self.container.appClosed,self.finished)]:
                if callback in event:event.remove(callback)
        self.running=False
        self.release_job()


def main(session,**kwargs):session.open(MKEkino)


def Plugins(**kwargs):
    return [PluginDescriptor(name='MK Ekino E2',description='Filmy i seriale — samodzielna wtyczka MK',
                             where=PluginDescriptor.WHERE_PLUGINMENU,icon='icon.png',fnc=main)]
