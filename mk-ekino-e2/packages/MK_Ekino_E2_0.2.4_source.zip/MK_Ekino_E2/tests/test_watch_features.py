import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import catalogue
import watchstate
import worker
from test_gui import load_ui

MOVIE={'title':'Test film','url':'https://ekino.ws/movie/show/test/123','action':'sources',
       'icon':'https://ekino.ws/static/thumb/test.jpg','rating_label':'Ekino: 8/10'}
EPISODE=dict(MOVIE,title='S01E01',url='https://ekino.ws/serie/watch/test+season[1]+episode[1]+',
             series_url='https://ekino.ws/serie/show/test/123',series_title='Test serial',season='1',episode=1)


class StateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'library.json';self.library=watchstate.Library(self.path)

    def test_resume_is_persistent_by_catalogue_url_and_does_not_store_stream_credentials(self):
        self.library.record(dict(MOVIE,stream='https://secret.example/token',provider='player'),320,3600)
        second=watchstate.Library(self.path)
        self.assertEqual(second.progress(MOVIE['url'])['position'],320)
        self.assertEqual(second.continuing()[0]['progress_label'],'Wznów od 0:05:20')
        self.assertNotIn('secret',self.path.read_text());self.assertEqual(self.path.stat().st_mode&0o777,0o600)
        second.record(MOVIE,0,0)  # Not ready / no seek position must not erase progress.
        self.assertEqual(second.progress(MOVIE['url'])['position'],320)

    def test_favourites_and_preferences_survive_completed_playback(self):
        self.assertTrue(self.library.toggle(MOVIE));self.assertTrue(self.library.toggle(dict(EPISODE,action='seasons',url=EPISODE['series_url'])))
        self.library.setting('view','tiles');self.library.setting('auto_play',False)
        self.library.record(MOVIE,3600,3600,True)
        self.assertEqual(self.library.continuing(),[])
        self.assertEqual(len(self.library.favourites()),2)
        self.assertEqual(self.library.settings(),{'view':'tiles','auto_play':False,'playback_service':4097})
        self.assertFalse(self.library.toggle(MOVIE));self.assertEqual(len(self.library.favourites()),1)

    def test_player_preference_is_persistent_and_invalid_services_fall_back(self):
        self.library.setting('playback_service',5002)
        self.assertEqual(watchstate.Library(self.path).settings()['playback_service'],5002)
        self.library.setting('playback_service','5002')
        self.assertEqual(self.library.settings()['playback_service'],4097)
        self.library.setting('playback_service',9999)
        self.assertEqual(self.library.settings()['playback_service'],4097)

    def test_invalid_json_and_stream_addresses_are_not_library_entries(self):
        self.path.write_text('{')
        self.assertEqual(self.library.continuing(),[]);self.assertTrue(self.library.settings()['auto_play'])
        for url in ('http://ekino.ws/movie/show/test','https://cdn.example/movie.mp4','http://127.0.0.1:8123/master.mp4'):
            self.assertFalse(self.library.toggle(dict(MOVIE,url=url)))

    def test_auto_quality_prefers_polish_then_largest_resolution_and_bitrate(self):
        options=[{'language':'en','width':3840,'height':2160,'bitrate':10000000},
                 {'language':'pol','width':1280,'height':720,'bitrate':4000000},
                 {'language':'pl','width':1920,'height':1080,'bitrate':6000000},
                 {'language':'pl-PL','width':1920,'height':1080,'bitrate':8000000}]
        self.assertEqual(watchstate.preferred_variant(options),3)
        self.assertEqual(watchstate.preferred_variant([options[0],{}]),1)
        self.assertIsNone(watchstate.preferred_variant([]))

    def test_next_episode_advances_across_seasons_and_preserves_series_context(self):
        text='''<p>Sezon 2</p><ul class="list-series"><a href="/serie/watch/test+season[2]+episode[1]+">Następny sezon</a></ul>
        <p>Sezon 1</p><ul class="list-series"><a href="/serie/watch/test+season[1]+episode[1]+">Pierwszy</a>
        <a href="/serie/watch/test+season[1]+episode[2]+">Drugi</a></ul>'''
        client=Mock();client.getPage.return_value=(True,text)
        result=catalogue.browse(client,dict(EPISODE,action='next_episode',episode=2))
        self.assertEqual((result[0]['season'],result[0]['episode']),('2',1))
        self.assertEqual(result[0]['series_url'],EPISODE['series_url'])
        self.assertEqual(catalogue.browse(client,dict(result[0],action='next_episode')),[])

    def test_worker_auto_mode_starts_selected_polish_relay_without_waiting_for_control_file(self):
        folder=Path(self.temp.name);request=folder/'request.json'
        request.write_text(json.dumps({'item':dict(MOVIE,action='resolve',provider='player',auto_quality=True)}))
        options=[{'url':'https://cdn.example/4k.m3u8','language':'en','height':2160},
                 {'url':'https://cdn.example/1080.m3u8','language':'pl','height':1080}]
        args=['worker.py','--request',str(request),'--result',str(folder/'result.json'),'--control',str(folder/'missing-control.json')]
        with patch.object(sys,'argv',args),patch.object(worker,'source_options',return_value=options),\
             patch.object(worker,'REPORT',folder/'report.json'),patch.object(worker,'Relay') as relay,\
             patch.object(worker,'emit') as emit,patch.object(worker.time,'sleep',side_effect=KeyboardInterrupt):
            relay.return_value.snapshot.return_value={'local_requests':0,'media_bytes':0,'errors':0}
            self.assertEqual(worker.main(),130)
            self.assertIs(relay.call_args.args[0],options[1])
            self.assertNotIn('choose_variant',[call.args[0] for call in emit.call_args_list])
            report=json.loads((folder/'report.json').read_text())
            self.assertEqual(report['selected_variant']['height'],1080)
            self.assertEqual(report['relay']['media_bytes'],0)


class PlaybackTests(unittest.TestCase):
    def setUp(self):
        self.ui=load_ui();self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.ui.watchstate.PATH=Path(self.temp.name)/'library.json';self.library=self.ui.watchstate.Library()
        self.session=Mock();self.screen=self.ui.MKEkino(self.session)
        self.addCleanup(self.finish)
        self.seek=Mock();self.seek.getPlayPosition.return_value=(0,320*90000);self.seek.getLength.return_value=(0,3600*90000)
        self.seek.isCurrentlySeekable.return_value=1;self.seek.seekTo.return_value=0
        self.session.nav.getCurrentService.return_value.seek.return_value=self.seek
        self.session.nav.getCurrentService.return_value.audioTracks.return_value=None

    def finish(self):self.screen.running=False;self.screen.release_job()

    def test_player_selection_does_not_save_unavailable_service(self):
        with patch.object(self.ui,'external_player_available',return_value=False):
            self.screen.player_selected(('exteplayer3',5002))
        self.assertEqual(self.library.settings()['playback_service'],4097)
        self.assertIn('ServiceApp',self.screen['status'].text)
        with patch.object(self.ui,'external_player_available',return_value=True):
            self.screen.player_selected(('exteplayer3',5002))
        self.assertEqual(self.library.settings()['playback_service'],5002)
        self.assertEqual(self.ui.MKEkino(self.session).preferences['playback_service'],5002)

    def test_external_player_request_and_service_reference_match(self):
        self.screen.preferences['playback_service']=5002
        with patch.object(self.ui,'external_player_available',return_value=True):
            self.screen.load(dict(MOVIE,action='resolve',provider='player'))
        request=json.loads((self.screen.job_dir/'request.json').read_text())
        self.assertEqual(request['item']['playback_service'],5002)
        self.screen.play('http://127.0.0.1:8123/master.m3u8')
        ref=self.session.openWithCallback.call_args.args[2]
        self.assertEqual(ref.args,(5002,0,'http://127.0.0.1:8123/master.m3u8'))

    def test_missing_serviceapp_stops_before_resolving(self):
        self.screen.preferences['playback_service']=5002
        with patch.object(self.ui,'external_player_available',return_value=False):
            self.screen.load(dict(MOVIE,action='resolve'))
        self.assertFalse(self.screen.running)
        self.assertIsNone(self.screen.job_dir)
        self.assertIn('ServiceApp',self.screen['status'].text)

    def player(self,entry=MOVIE,resume=0):
        return self.ui.EkinoMoviePlayer(self.session,'service',mk_entry=entry,mk_library=self.library,mk_resume=resume,fromMovieSelection=False)

    def test_checkpoint_and_close_save_position_and_timer_disconnects(self):
        player=self.player();player.mk_start()
        for _ in range(15):player.mk_tick()
        self.assertEqual(self.library.progress(MOVIE['url'])['position'],320)
        self.seek.getPlayPosition.return_value=(0,450*90000)
        player.mk_cleanup()
        self.assertEqual(self.library.progress(MOVIE['url'])['position'],450)
        self.assertEqual(player.mk_timer.callback,[])

    def test_resume_waits_for_seekable_service_and_uses_90khz_units(self):
        player=self.player(resume=320)
        self.seek.isCurrentlySeekable.return_value=0;player.mk_tick();self.seek.seekTo.assert_not_called()
        self.seek.isCurrentlySeekable.return_value=1;player.mk_tick();self.seek.seekTo.assert_called_once_with(320*90000)
        player.mk_tick()  # Confirm the new position rather than trusting seekTo's return code.
        self.assertEqual(player.mk_resume,0)
        player.mk_cleanup()

    def test_polish_track_is_selected_when_mp4_has_multiple_audio_tracks(self):
        tracks=Mock();tracks.getNumberOfTracks.return_value=2
        tracks.getTrackInfo.side_effect=lambda i:Mock(getLanguage=lambda:'eng' if i==0 else 'pol')
        self.session.nav.getCurrentService.return_value.audioTracks.return_value=tracks
        player=self.player();player.mk_tick();player.mk_tick()
        tracks.selectTrack.assert_called_once_with(1);player.mk_cleanup()

    def test_eof_marks_completed_but_early_network_end_does_not(self):
        player=self.player(EPISODE);player.close=Mock();self.seek.getPlayPosition.return_value=(0,3600*90000)
        player.doEofInternal(True)
        self.assertTrue(self.library.progress(EPISODE['url'])['completed']);player.close.assert_called_once_with({'completed':True})
        player.mk_cleanup()
        other=self.player();other.close=Mock();self.seek.getPlayPosition.return_value=(0,3*90000)
        other.doEofInternal(True);other.close.assert_called_once_with({'completed':False});other.mk_cleanup()

    def test_resume_confirmation_receives_saved_position_after_new_stream_is_created(self):
        self.library.record(MOVIE,320,3600)
        self.screen.load(dict(MOVIE,action='resolve',movie_title=MOVIE['title'],provider='player'))
        self.screen.play('http://127.0.0.1:12345/new/master.mp4')
        self.assertIn('0:05:20',self.session.openWithCallback.call_args.args[2])
        self.session.openWithCallback.call_args.args[0](True)
        kwargs=self.session.openWithCallback.call_args.kwargs
        self.assertEqual(kwargs['mk_resume'],320);self.assertEqual(kwargs['mk_entry']['url'],MOVIE['url'])

    def test_auto_source_waits_for_catalogue_worker_exit_before_starting_player(self):
        self.screen.load(MOVIE)
        options=[dict(MOVIE,action='resolve',movie_title=MOVIE['title'],provider='player')]
        (self.screen.job_dir/'result.json').write_text(json.dumps({'items':options}))
        self.screen.data('{"stage":"catalogue_ready"}\n')
        first=self.screen.container
        self.assertEqual(self.screen.after_job['provider'],'player')
        self.screen.finished(0)
        self.assertIsNot(self.screen.container,first)
        request=json.loads((self.screen.job_dir/'request.json').read_text())
        self.assertTrue(request['item']['auto_quality']);self.assertEqual(request['item']['provider'],'player')

    def test_next_episode_is_queued_until_previous_relay_exits(self):
        self.screen.load(dict(EPISODE,action='resolve',provider='player'))
        self.screen.playback_entry=EPISODE
        self.screen.movie_closed({'completed':True})
        self.session.openWithCallback.call_args.args[0](True)
        self.assertEqual(self.screen.after_job['action'],'next_episode')
        self.screen.finished(130)
        request=json.loads((self.screen.job_dir/'request.json').read_text())
        self.assertEqual(request['item']['action'],'next_episode')

    def test_favourites_open_locally_and_empty_library_never_starts_worker(self):
        self.library.toggle(MOVIE);self.screen.local_list({'action':'favourites','title':'Ulubione'})
        self.assertEqual(self.screen.entries[0]['url'],MOVIE['url']);self.assertFalse(self.screen.running)


class GridTests(unittest.TestCase):
    def setUp(self):
        self.ui=load_ui();self.session=Mock()
        self.entries=[dict(MOVIE,title='Film '+str(i),icon='https://ekino.ws/static/thumb/p%d.jpg'%i) for i in range(6)]
        self.grid=self.ui.PosterGrid(self.session,self.entries)
        self.addCleanup(self.grid.cleanup)

    def test_grid_navigation_changes_page_and_selection_and_returns_original_index(self):
        self.grid.layout_finished();self.assertTrue(self.grid['mark0'].visible)
        self.grid.move(4)
        self.assertEqual(self.grid.page,1);self.assertEqual(self.grid['title0'].text,'Film 4')
        self.grid.move(1);self.assertTrue(self.grid['mark1'].visible)
        self.grid.close=Mock();self.grid.choose();self.grid.close.assert_called_once_with(('select',5))

    def test_old_page_decode_never_overwrites_new_page_cover(self):
        self.grid.layout_finished()
        self.grid.cached=Mock(return_value=Path('/tmp/fixture.jpg'))
        self.grid.decode_available();old=self.grid.decoding[0]
        self.grid.move(4);self.grid.decoded(0)
        self.assertFalse(self.grid['cover0'].visible)
        self.assertNotEqual(self.grid.decoding[0],old)
        self.grid.decoded(0);self.assertTrue(self.grid['cover0'].visible)

    def test_grid_fetch_and_decoder_callbacks_are_detached_before_screen_destruction(self):
        self.grid.layout_finished();self.grid.cached=Mock(return_value=None);self.grid.fetch_covers()
        process=self.grid.process
        self.grid.cleanup()
        self.assertEqual(process.interrupts,1);self.assertEqual(process.dataAvail,[]);self.assertEqual(process.appClosed,[])
        self.assertTrue(all(not decoder.callbacks for decoder in self.grid.decoders))

    def test_four_large_covers_fit_the_screen_with_preserved_aspect(self):
        root=ET.fromstring(self.grid.skin)
        for element in root.findall('widget'):
            x,y=map(int,element.attrib['position'].split(','));w,h=map(int,element.attrib['size'].split(','))
            self.assertTrue(0<=x and 0<=y and x+w<=1200 and y+h<=650)
            if element.attrib['name'].startswith('cover'):self.assertEqual((w,h),(200,300))


if __name__=='__main__':unittest.main()
