import io
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKEkinoE2'))
import catalogue
import relay
import resolver
import worker


class CatalogueTests(unittest.TestCase):
    def test_filters_combine_in_requested_order(self):
        doc='''<ul class="movieCategories"><li><a href="/movie/cat/kategoria[36]">4K / FHD</a></li></ul>
        <ul class="quality"><li data-id="Lektor"><a>Lektor</a></li></ul>
        <ul class="filtyear"><li data-id="2026">2026</li></ul>'''
        cat=catalogue.filters(doc,'categories',{})[1]
        version=catalogue.filters(doc,'versions',cat)[1]
        year=catalogue.filters(doc,'years',version)[1]
        self.assertEqual(year['action'],'movies')
        self.assertIn('kategoria[36]+wersja[Lektor]+rok[2026]+',catalogue.movie_url(year))

    def test_seasons_are_sorted_and_episode_urls_are_preserved(self):
        doc='''<p>Sezon 2</p><ul class="list-series"><a href="/serie/watch/example+season[2]+episode[3]+">Odcinek 3</a>
        <a href="/serie/watch/example+season[2]+episode[1]+">Pierwszy</a></ul>
        <p>Sezon 1</p><ul class="list-series"></ul>'''
        self.assertEqual([x['season'] for x in catalogue.seasons(doc,{'url':'https://ekino.ws/serie/show/example'})],['1','2'])
        entries=catalogue.episodes(doc,{'season':'2'})
        self.assertEqual([x['episode'] for x in entries],[1,3])
        self.assertTrue(entries[0]['url'].endswith('season[2]+episode[1]+'))

    def test_provider_selection_does_not_reuse_session_bound_watch_ids(self):
        doc="""<ul class="players"></ul> ShowPlayer('player','PRIVATE-SESSION-ID')
        ShowPlayer('upzone','PRIVATE-ID2') ShowPlayer('mix','PRIVATE-MIX1')
        ShowPlayer('wrzucaj','PRIVATE-ID3') ShowPlayer('mix','PRIVATE-MIX2')
        ShowPlayer('upzone','PRIVATE-ID4') ShowPlayer('voe','PRIVATE-VOE')
        ShowPlayer('shvid','PRIVATE-SHVID')"""
        entries=catalogue.source_items(doc,{'url':'https://ekino.ws/movie/show/example','title':'Example'})
        self.assertEqual([x['provider'] for x in entries],['player','voe','mix','mix'])
        self.assertEqual([x['provider_index'] for x in entries],[0,0,0,1])
        self.assertNotIn('PRIVATE-',json.dumps(entries))

    def test_worker_reloads_title_before_resolving_selected_provider(self):
        client=Mock()
        client.getPage.side_effect=[(True,"ShowPlayer('player','NEW-SESSION-ID')"),
                                   (True,'<iframe src="https://mfw09.org/e/example"></iframe>')]
        client.meta={'url':'https://ekino.ws/watch/f/player/NEW-SESSION-ID'}
        with patch.object(resolver.Byse,'parserBYSE',return_value=[{'name':'ok'}]) as call:
            self.assertTrue(worker.source_options(client,{'provider':'player','url':'https://ekino.ws/movie/show/example'}))
        self.assertEqual(client.getPage.call_count,2)
        self.assertEqual(str(call.call_args[0][0]),'https://mfw09.org/e/example')


class Response(io.BytesIO):
    code=200
    def __init__(self,url,body,kind):
        super().__init__(body)
        self.url=url;self.headers={'Content-Type':kind,'Content-Length':str(len(body))}
    def geturl(self):return self.url


class RelayTests(unittest.TestCase):
    def test_extensionless_playlist_with_text_content_type_is_rewritten(self):
        def upstream(request,**kwargs):
            if request.full_url.endswith('/opaque'):
                return Response(request.full_url,b'#EXTM3U\n#EXTINF:4,\nmedia.css\n#EXT-X-ENDLIST\n','text/plain')
            packet=b'G'+bytes(187)
            return Response(request.full_url,packet*4,'text/css')
        server=relay.Relay({'name':'HLS','url':resolver.URL('https://cdn.example/opaque')},Mock(opener=Mock(open=upstream)))
        try:
            with urllib.request.urlopen(server.url) as r:
                self.assertIn('mpegurl',r.headers['Content-Type']);body=r.read().decode()
            target=next(v for v in body.splitlines() if v.startswith('http'))
            self.assertTrue(target.startswith('http://127.0.0.1:'))
            with urllib.request.urlopen(target) as r:
                self.assertEqual(r.headers['Content-Type'],'video/mp2t');self.assertEqual(len(r.read()),752)
            state=server.snapshot();self.assertEqual(state['playlists'],1);self.assertEqual(state['media_bytes'],752)
        finally:server.close()

    def test_upstream_http_failure_is_counted_without_recording_stream_token(self):
        def upstream(request,**kwargs):
            raise urllib.error.HTTPError(request.full_url,403,'Forbidden',{},None)
        server=relay.Relay({'url':resolver.URL('https://cdn.example/v.mp4?token=secret')},Mock(opener=Mock(open=upstream)))
        try:
            with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(server.url)
            report=server.snapshot();self.assertEqual(report['last_http_status'],403);self.assertEqual(report['errors'],1)
            self.assertNotIn('secret',json.dumps(report));self.assertNotIn('cdn.example',json.dumps(report))
        finally:server.close()

    def test_mp4_root_preserves_byte_range_and_source_headers(self):
        seen=[]
        def open_request(request,**kwargs):
            seen.append(request)
            response=Response(request.full_url,b'2345','video/mp4');response.code=206
            response.headers.update({'Content-Range':'bytes 2-5/10','Accept-Ranges':'bytes'})
            return response
        client=Mock(opener=Mock(open=open_request))
        server=relay.Relay({'url':resolver.URL('https://cdn.example/movie.mp4',{'Referer':'https://mixdrop.ag/'})},client)
        try:
            self.assertTrue(server.url.endswith('/master.mp4'))
            request=urllib.request.Request(server.url,headers={'Range':'bytes=2-5'})
            with urllib.request.urlopen(request,timeout=5) as response:
                self.assertEqual(response.status,206)
                self.assertEqual(response.headers['Content-Range'],'bytes 2-5/10')
                self.assertEqual(response.read(),b'2345')
            self.assertEqual(seen[0].get_header('Range'),'bytes=2-5')
            self.assertEqual(seen[0].get_header('Referer'),'https://mixdrop.ag/')
        finally:server.close()

    def test_selected_audio_and_nested_playlist_resources_are_proxied_with_headers(self):
        seen=[]
        def open_request(request,**kwargs):
            seen.append(request)
            if request.full_url.endswith('video.m3u8'):
                return Response(request.full_url,b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key.bin"\n#EXTINF:4,\nsegment.ts\n#EXT-X-ENDLIST\n','application/vnd.apple.mpegurl')
            if request.full_url.endswith('segment.ts'):
                return Response(request.full_url,b'media-bytes','video/mp2t')
            raise AssertionError('Unexpected upstream URL')
        client=Mock(opener=Mock(open=open_request))
        url=resolver.URL('https://cdn.example/master.m3u8',{'video_url':'https://cdn.example/video.m3u8',
              'audio_url':'https://cdn.example/polish.m3u8','User-Agent':'ResolverUA','Referer':'https://mfw09.org/'})
        option={'url':url,'language':'pl','width':1920,'height':800,'bitrate':6387008,'codecs':'avc1.640028,mp4a.40.2'}
        server=relay.Relay(option,client)
        try:
            with urllib.request.urlopen(server.url,timeout=5) as response:master=response.read().decode()
            self.assertIn('LANGUAGE="pl"',master)
            self.assertIn('RESOLUTION=1920x800',master)
            self.assertNotIn('cdn.example',master)
            video=master.strip().splitlines()[-1]
            with urllib.request.urlopen(video,timeout=5) as response:playlist=response.read().decode()
            self.assertNotIn('cdn.example',playlist)
            self.assertIn('URI="http://127.0.0.1:',playlist)
            segment=next(x for x in playlist.splitlines() if x.startswith('http'))
            with urllib.request.urlopen(segment,timeout=5) as response:self.assertEqual(response.read(),b'media-bytes')
            self.assertEqual(seen[-1].get_header('User-agent'),'ResolverUA')
            self.assertEqual(seen[-1].get_header('Referer'),'https://mfw09.org/')
            with self.assertRaises(urllib.error.HTTPError):
                urllib.request.urlopen(server.url.replace(server.token,'invalid'),timeout=5)
        finally:server.close()


if __name__=='__main__':unittest.main()
