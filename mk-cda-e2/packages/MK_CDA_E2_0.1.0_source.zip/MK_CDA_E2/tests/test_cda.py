import html
import http.cookiejar
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/MKCDAE2'))
import account
import catalogue
import cda
import poster
import resolver
import watchstate
import worker


class Client:
    def __init__(self,responses):self.responses=list(responses);self.calls=[];self.meta={};self.jar=http.cookiejar.CookieJar();self.steps=[]
    def getPage(self,url,params=None,post_data=None):
        self.calls.append((str(url),params or {},post_data));status,body=self.responses.pop(0)
        self.meta={'url':str(url),'status_code':status};return status==200,body


def cover(identifier='123ab',access='Za darmo'):
    return '''<span class="cover-area"><a class="cover-big"><span class="cover-area-img">
      <img class="cover-img" src="//icdn.2cda.pl/vid/premium/1/348x487/example.webp"></span></a>
      <span class="description-cover-container">Komedia<br><br>Opis filmu<span class="btn-more-desc"> (...)</span></span>
      <a class="kino-title" href="https://www.cda.pl/video/%s/vfilm">Film &amp; test (2025) Lektor PL</a>
      <span class="cloud-gray">%s</span></span>'''%(identifier,access)


def player(video):return "<div player_data='"+html.escape(json.dumps({'video':video}),quote=True)+"'></div>"


class CDATests(unittest.TestCase):
    def test_catalogue_canonicalizes_urls_and_excludes_paid_rows_in_free_mode(self):
        values=catalogue.film_items(cover()+cover('456','Premium')+cover(),'2')
        self.assertEqual(len(values),1);self.assertEqual(values[0]['url'],'https://www.cda.pl/video/123ab')
        self.assertEqual(values[0]['title'],'Film & test (2025) Lektor PL')
        self.assertEqual(values[0]['year'],'2025');self.assertEqual(values[0]['language_version'],'Lektor PL')
        self.assertTrue(values[0]['icon'].startswith('https://icdn.2cda.pl/'))

    def test_free_filter_survives_jsonrpc_pagination(self):
        first=cover()+'''<div id="loadMoreButton"></div><script>json_client.katalogLoadMore(page,"all","new",{});</script>'''
        client=Client([(200,first),(200,json.dumps({'result':{'status':'end','html':cover('next')+cover('paid','Premium')}}))])
        values=catalogue.browse(client,{'action':'movies','access':'2','order':'new','page':1})
        nxt=values[-1];self.assertEqual(nxt['page'],2)
        values=catalogue.browse(client,nxt)
        self.assertEqual([v['url'] for v in values],['https://www.cda.pl/video/next'])
        self.assertIn('d=2',client.calls[1][0]);self.assertEqual(json.loads(client.calls[1][2])['params'][:3],[2,'all','new'])

    def test_official_genres_are_read_from_page(self):
        client=Client([(200,'<ul class="kat-kino"><li><a href="/premium/filmy-polskie?d=2">Filmy polskie</a></li><a href="/premium/komedie">Komedie</a></ul>')])
        values=catalogue.categories(client,{'access':'2','catalogue':'filmy'})
        self.assertEqual([v['category'] for v in values],['','filmy-polskie','komedie'])

    def test_search_keeps_long_video_links_and_pagination(self):
        body='<div class="video-clip-wrapper"><a class="link-title-visit" href="/video/123ab/vfilm">Film</a><img src="//icdn.2cda.pl/a.jpg"></div><a class="sbmBigNext" href="/video/show/film/p2">dalej</a>'
        client=Client([(200,body)]);values=catalogue.browse(client,{'action':'search_results','query':'film test'})
        self.assertIn('duration=dlugie',client.calls[0][0]);self.assertEqual(values[0]['url'],'https://www.cda.pl/video/123ab')
        self.assertEqual(values[-1]['action'],'search_page')

    def test_auto_quality_fetches_only_highest_variant_and_keeps_headers(self):
        initial={'file':'https://v.cda.pl/low.mp4','quality':'360','qualities':{'360p':'360','1080p':'1080','720p':'720'},'height':360}
        highest={'file':'https://v.cda.pl/high.mp4','height':1080,'width':1920}
        client=Client([(200,player(initial)),(200,player(highest))])
        values=cda.options(client,{'url':'https://www.cda.pl/video/123','auto_quality':True})
        self.assertEqual(len(client.calls),2);self.assertIn('wersja=1080p',client.calls[1][0])
        self.assertEqual(len(values),1);self.assertEqual(values[0]['height'],1080)
        self.assertEqual(values[0]['url'].meta['User-Agent'],cda.PLAYER_UA)

    def test_manual_quality_and_hls_manifest_paths(self):
        video={'file':'https://v.cda.pl/high.mp4','quality':'1080','qualities':{'1080p':'1080','720p':'720'},'height':1080}
        client=Client([(200,player(video)),(200,player({'file':'https://v.cda.pl/low.mp4','height':720}))])
        values=cda.options(client,{'url':'https://www.cda.pl/video/123'})
        self.assertEqual([v['height'] for v in values],[1080,720])
        client=Client([(200,player({'manifest_apple':'https://v.cda.pl/master.m3u8'})),(200,'#EXTM3U\n#EXTINF:5\nsegment.ts\n')])
        self.assertEqual(cda.options(client,{'url':'https://www.cda.pl/video/123'})[0]['name'],'HLS')

    def test_decoder_matches_known_obfuscated_link_and_never_executes_page_code(self):
        # A fixed public-format vector: reverse of CDA's printable-character rotation.
        plain='video.cda.pl/movie'
        alphabet=''.join(chr(x) for x in range(33,127))
        encoded=''.join(alphabet[(ord(char)-33-47)%94] for char in plain)
        self.assertEqual(cda.decode_file(encoded+'_CDA'),'https://'+plain+'.mp4')
        self.assertEqual(cda.player_data("<script>evil()</script>"),{})

    def test_payment_drm_rate_limit_and_verification_are_distinguished(self):
        cases=[(200,'premiumAccess(1)','cda_premium_required'),(200,player({'manifest_drm_proxy':'license'}),'cda_drm_required'),(429,'','cda_rate_limited'),(403,'Forbidden','cda_access_denied'),(404,'','cda_video_removed')]
        for status,body,reason in cases:
            with self.subTest(reason=reason),self.assertRaisesRegex(resolver.ResolveError,reason):
                cda.options(Client([(status,body)]),{'url':'https://www.cda.pl/video/123'})

    def test_urls_and_poster_redirect_targets_are_restricted(self):
        for url in ('https://evil.example/video/123','https://www.cda.pl.evil.example/video/123','http://www.cda.pl/video/123'):
            with self.assertRaises(resolver.ResolveError):cda.video_url(url)
        self.assertEqual(poster.valid_url('https://icdn.2cda.pl/vid/a.webp'),'https://icdn.2cda.pl/vid/a.webp')
        for url in ('https://2cda.pl.evil.example/a.jpg','https://127.0.0.1/a.jpg'):
            with self.assertRaises(ValueError):poster.valid_url(url)

    def test_login_uses_hidden_fields_and_stores_only_private_session_state(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(account,'STATE',Path(directory)/'account.json'),patch.object(resolver,'SESSION',Path(directory)/'cookies'):
            client=Client([(200,'<form action="/login"><input type="hidden" name="r" value="/premium"></form>'),(200,'<a href="https://www.cda.pl/logout">Wyloguj</a>')])
            account.login(client,'example-user','example-secret')
            self.assertEqual(client.calls[1][2]['r'],'/premium')
            self.assertEqual(client.calls[1][2]['password'],'example-secret')
            self.assertTrue(account.status())
            for path in Path(directory).iterdir():
                self.assertEqual(path.stat().st_mode&0o777,0o600)
                self.assertNotIn('example-secret',path.read_text());self.assertNotIn('example-user',path.read_text())
            account.logout();self.assertFalse(account.status());self.assertEqual(list(Path(directory).iterdir()),[])

    def test_login_stops_for_captcha_without_posting_credentials(self):
        client=Client([(200,'<form action="/login"><div data-sitekey="sitekey"></div></form>')])
        with self.assertRaisesRegex(resolver.ResolveError,'cda_login_verification_required'):account.login(client,'user','secret')
        self.assertEqual(len(client.calls),1)

    def test_login_worker_deletes_request_and_never_prints_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);request=root/'request.json';request.write_text(json.dumps({'item':{'action':'account_login','username':'example-user','password':'example-secret'}}))
            client=Client([(200,'<form action="/login"><input type="hidden" name="r" value=""></form>'),(200,'<a href="/logout">Wyloguj</a>')])
            output=io.StringIO()
            with patch.object(sys,'argv',['worker','--request',str(request),'--result',str(root/'result.json'),'--control',str(root/'control.json')]),patch.object(worker.resolver,'Http',return_value=client),patch.object(account,'STATE',root/'account.json'),patch.object(resolver,'SESSION',root/'cookies'),patch('sys.stdout',output):
                self.assertEqual(worker.main(),0)
            self.assertFalse(request.exists());self.assertIn('account_ready',output.getvalue())
            self.assertNotIn('example-secret',output.getvalue());self.assertNotIn('example-user',output.getvalue())

    def test_favourites_progress_and_invalid_external_url(self):
        entry=catalogue.film_items(cover(),'2')[0]
        with tempfile.TemporaryDirectory() as directory:
            library=watchstate.Library(Path(directory)/'library.json');library.toggle(entry);library.record(entry,125,3600)
            self.assertEqual(library.favourites()[0]['url'],entry['url']);self.assertEqual(library.continuing()[0]['url'],entry['url'])
            self.assertFalse(library.toggle(dict(entry,url='https://example.org/video/123')))


if __name__=='__main__':unittest.main()
