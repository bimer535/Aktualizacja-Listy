# SPDX-License-Identifier: GPL-3.0-only
"""CDA free/premium catalogue. No account is needed for browsing."""
import html
import json
import re
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit,urlencode,quote,parse_qsl
import resolver
import cda

BASE='https://www.cda.pl/'
ORDERS=[('Nowo dodane','new'),('Najlepiej oceniane na IMDb','best'),('Najnowsze premiery','release'),('Najpopularniejsze w tygodniu','views7'),('Alfabetycznie','alpha')]


def clean(value):return ' '.join(html.unescape(re.sub('<[^>]+>',' ',str(value or ''))).split())


class Node:
    def __init__(self,tag='',attrs=(),parent=None):self.tag=tag;self.attrs=dict(attrs);self.children=[];self.parent=parent;self.parts=[]
    def all(self,tag=None,cls=None):
        result=[]
        for child in self.children:
            if (tag is None or child.tag==tag) and (cls is None or cls in child.attrs.get('class','').split()):result.append(child)
            result.extend(child.all(tag,cls))
        return result
    def text(self):return clean(' '.join(self.parts))


class Document(HTMLParser):
    VOID={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self,text):
        super().__init__(convert_charrefs=True);self.root=Node();self.current=self.root;self.feed(text)
    def handle_starttag(self,tag,attrs):
        node=Node(tag,attrs,self.current);self.current.children.append(node)
        if tag not in self.VOID:self.current=node
    def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs);self.handle_endtag(tag)
    def handle_endtag(self,tag):
        node=self.current
        while node.parent is not None:
            if node.tag==tag:self.current=node.parent;break
            node=node.parent
    def handle_data(self,data):
        node=self.current
        if node.tag in ('script','style'):return
        while node is not None:node.parts.append(data);node=node.parent


def page(client,url,post=None):
    parsed=urlsplit(url)
    if parsed.scheme!='https' or parsed.netloc!='www.cda.pl':raise ValueError('invalid_catalogue_url')
    headers={'Referer':BASE,'Accept':'text/html,application/json'}
    if post is not None:headers.update({'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest','Referer':url})
    ok,body=client.getPage(url,{'header':headers},json.dumps(post) if post is not None else None)
    if client.meta.get('status_code')==429:raise ValueError('cda_rate_limited')
    if client.meta.get('status_code')==403 or 'cf-chl-' in body or '<title>Just a moment' in body:raise ValueError('cda_access_denied')
    if not ok:raise ValueError('catalogue_http_error')
    return body


def item(title,action,**values):return dict(title=title,action=action,**values)


def menu():
    return [item('Filmy za darmo','categories',access='2',catalogue='filmy'),
            item('Polskie filmy za darmo','categories',access='2',catalogue='polskie'),
            item('Katalog CDA Premium','categories',access='1',catalogue='filmy'),
            item('Wszystkie filmy — darmowe i Premium','categories',access='',catalogue='filmy'),
            item('Seriale — katalog CDA','categories',access='',catalogue='seriale'),
            item('Wyszukaj film w CDA','search'),item('Ulubione','favourites'),item('Kontynuuj oglądanie','continue'),
            item('Historia wyszukiwania','history'),item('Konto CDA — logowanie / wylogowanie','account')]


def root_url(current):
    category=current.get('category','')
    if category and not re.fullmatch('[a-z0-9-]{1,100}',category):raise ValueError('invalid_category')
    base=BASE+'premium'+('/'+category if category else '')
    query={}
    access=current.get('access','2')
    if access not in ('','1','2'):raise ValueError('invalid_access_filter')
    if access:query['d']=access
    order=current.get('order','new')
    if order not in dict(ORDERS).values():raise ValueError('invalid_sort')
    query['sort']=order
    return base+'?'+urlencode(query)


def cover_url(value):
    value=urljoin(BASE,html.unescape(value or ''));parsed=urlsplit(value)
    host=parsed.hostname or ''
    if parsed.scheme=='http':value='https:'+value[5:]
    if not (host=='cda.pl' or host.endswith('.cda.pl') or host=='2cda.pl' or host.endswith('.2cda.pl')):return ''
    return value


def film_items(body,access=''):
    result=[];seen=set()
    # Each cover carries its full description; parse it independently to
    # tolerate invalid surrounding div/span nesting on the service's page.
    for block in re.split(r'''<span\s+class=['"]cover-area['"]\s*>''',body)[1:]:
        tree=Document(block).root
        titles=tree.all('a','kino-title');images=tree.all('img','cover-img')
        if not titles or not images:continue
        title=titles[0].text();source=urljoin(BASE,titles[0].attrs.get('href',''))
        try:source=cda.video_url(source)
        except resolver.ResolveError:continue
        if not title or source in seen:continue
        badges=tree.all('span','cloud-gray');badge=badges[0].text() if badges else ''
        # Preserve the free filter even if a later page contains paid rows.
        if access=='2' and 'darmo' not in badge.lower():continue
        seen.add(source)
        plot=tree.all('span','description-cover-container');description=plot[0].text().replace(' (...)','') if plot else ''
        year=re.search(r'\b((?:19|20)\d{2})\b',title);year=year[1] if year else ''
        lang=next((value for value in ('Lektor PL','Dubbing PL','Napisy PL','Cały film PL') if value.lower() in title.lower()),'')
        result.append(item(title,'sources',url=source,icon=cover_url(images[0].attrs.get('src','')),year=year,language_version=lang,
                           access_label=badge,desc=badge+'\n'+description,synopsis=description))
    return result


def categories(client,current):
    body=page(client,root_url(current));tree=Document(body).root
    result=[dict(current,title='Wszystkie gatunki',action='sort',category='')];seen=set()
    for group in tree.all('ul','kat-kino'):
        for anchor in group.all('a'):
            parsed=urlsplit(urljoin(BASE,anchor.attrs.get('href','')))
            match=re.fullmatch('/premium/([a-z0-9-]+)',parsed.path)
            if match and match[1] not in seen:
                seen.add(match[1]);result.append(dict(current,title=anchor.text(),action='sort',category=match[1]))
    mode=current.get('catalogue')
    if mode in ('polskie','seriale'):
        choices=[value for value in result if (('polskie' in value['title'].lower()) if mode=='polskie' else ('seriale' in value['title'].lower()))]
        if choices:return [dict(value,title='Wszystkie sposoby sortowania',action='sort') for value in choices[:1]]
    return result


def browse(client,current):
    action=current.get('action','main')
    if action=='main':return menu()
    if action=='categories':return categories(client,current)
    if action=='sort':return [dict(current,title=title,action='movies',order=value,page=1) for title,value in ORDERS]
    if action in ('movies','page'):
        number=max(1,int(current.get('page',1)));url=root_url(current)
        if number==1:
            body=page(client,url)
            more=re.search(r'''katalogLoadMore\([^,]+,\s*"([^"]+)"\s*,\s*"([^"]+)"''',body)
            next_fields={'load_category':more[1],'load_sort':more[2]} if more else {}
            has_next=bool(more and re.search(r'''id=['"]loadMore''',body))
        else:
            if not re.fullmatch('[a-z0-9_-]{1,100}',current.get('load_category','')):raise ValueError('invalid_pagination')
            request={'jsonrpc':'2.0','method':'katalogLoadMore','params':[number,current['load_category'],current.get('load_sort','new'),{}],'id':number}
            try:data=json.loads(page(client,url,request))['result']
            except (ValueError,KeyError,TypeError):raise ValueError('invalid_catalogue_response')
            body=data.get('html','');has_next=data.get('status')=='continue';next_fields={key:current[key] for key in ('load_category','load_sort')}
        result=film_items(body,current.get('access','2'))
        if has_next:result.append(dict(current,**next_fields,title='Następna strona',action='page',page=number+1))
        return result
    if action=='sources':
        return [dict(current,title='CDA — wybierz jakość i odtwarzaj',movie_title=current.get('title','Film'),action='resolve',provider='cda')]
    if action in ('search_results','search_page'):
        url=current.get('next_url') if action=='search_page' else BASE+'info/'+quote(current['query'].strip(),safe='')+'?s=best&duration=dlugie'
        body=page(client,url);tree=Document(body).root;result=[];seen=set()
        for block in tree.all('div','video-clip-wrapper') or tree.all('div','videoInfo'):
            anchors=block.all('a','link-title-visit');images=block.all('img')
            if not anchors:continue
            anchor=anchors[0]
            try:source=cda.video_url(urljoin(BASE,anchor.attrs.get('href','')))
            except resolver.ResolveError:continue
            if source in seen:continue
            seen.add(source);title=anchor.text() or (images[0].attrs.get('alt','') if images else '')
            if title:result.append(item(title,'sources',url=source,icon=cover_url(images[0].attrs.get('src','')) if images else '',desc=block.text()[:1000]))
        for anchor in tree.all('a'):
            if 'sbmBigNext' in anchor.attrs.get('class','').split():
                next_url=urljoin(BASE,anchor.attrs.get('href',''))
                if urlsplit(next_url).netloc=='www.cda.pl':result.append(dict(current,title='Następna strona',action='search_page',next_url=next_url))
                break
        return result
    raise ValueError('unknown_catalogue_action')
