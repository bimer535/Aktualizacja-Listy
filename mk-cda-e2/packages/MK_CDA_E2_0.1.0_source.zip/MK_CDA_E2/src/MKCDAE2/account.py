# SPDX-License-Identifier: GPL-3.0-only
"""Optional user-owned CDA web session. Passwords are never saved."""
import http.cookiejar
import json
import os
from pathlib import Path
import re
import tempfile
import time
from html.parser import HTMLParser
try:
    from . import resolver
except ImportError:
    import resolver

STATE=Path('/etc/mk-cda-e2/account.json')


class Form(HTMLParser):
    def __init__(self):super().__init__();self.fields={};self.in_form=False;self.forms=[];self.captcha=False
    def handle_starttag(self,tag,attrs):
        values=dict(attrs)
        if tag=='form':self.in_form='login' in values.get('action','');self.fields={}
        if self.in_form and tag=='input' and values.get('name') and values.get('type')=='hidden':self.fields[values['name']]=values.get('value','')
        if self.in_form and values.get('data-sitekey'):self.captcha=True
    def handle_endtag(self,tag):
        if tag=='form' and self.in_form:self.forms.append(dict(self.fields));self.in_form=False


def private_json(path,data):
    path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='account-',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as out:json.dump(data,out)
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def save_session(client):
    resolver.SESSION.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='session-',dir=resolver.SESSION.parent);os.close(fd)
    try:
        jar=http.cookiejar.LWPCookieJar(name)
        for cookie in client.jar:
            domain=cookie.domain.lstrip('.').lower()
            if domain=='cda.pl' or domain.endswith('.cda.pl') or domain=='2cda.pl' or domain.endswith('.2cda.pl'):
                jar.set_cookie(cookie)
        jar.save(ignore_discard=True,ignore_expires=False);os.chmod(name,0o600);os.replace(name,resolver.SESSION)
    finally:
        if os.path.exists(name):os.unlink(name)


def status():
    try:return json.loads(STATE.read_text()).get('logged_in') is True and resolver.SESSION.is_file()
    except (OSError,ValueError,AttributeError):return False


def logout():
    for path in (resolver.SESSION,STATE):
        try:path.unlink()
        except FileNotFoundError:pass


def login(client,username,password):
    if not isinstance(username,str) or not isinstance(password,str) or not username.strip() or not password:raise resolver.ResolveError('cda_credentials_missing')
    # A new login uses a fresh session; never attach another account's cookies.
    client.jar.clear()
    url='https://www.cda.pl/login';headers={'Referer':url}
    ok,body=client.getPage(url,{'header':headers})
    if not ok:raise resolver.ResolveError('cda_login_unavailable')
    form=Form();form.feed(body)
    if form.captcha or 'cf-chl-' in body:raise resolver.ResolveError('cda_login_verification_required')
    fields=next((value for value in reversed(form.forms) if 'r' in value),{})
    fields.update(username=username.strip(),password=password,login='zaloguj')
    ok,body=client.getPage(url,{'header':headers},fields)
    if 'data-sitekey' in body or 'cf-chl-' in body:raise resolver.ResolveError('cda_login_verification_required')
    if not ok or not re.search(r'''href\s*=\s*['"][^'"]*/logout(?:[/?'"])''',body,re.I):raise resolver.ResolveError('cda_login_failed')
    save_session(client);private_json(STATE,{'logged_in':True,'updated':int(time.time())})
