# SPDX-License-Identifier: GPL-3.0-only
"""Bounded HTTPS client and HLS parser, adapted from MK components."""
import argparse
import base64
from binascii import hexlify
import hashlib
from hashlib import sha256
import html as html_lib
import http.cookiejar
import ipaddress
import json
import os
from os import urandom
from pathlib import Path
from random import uniform
import re
import ssl
import tempfile
import time
import urllib.error
import urllib.parse
from urllib.parse import urlsplit as urlparse
import urllib.request
import xml.etree.ElementTree as ET

BASE = 'https://www.cda.pl/'
SESSION = Path('/etc/mk-cda-e2/session.cookies')
MAX_PAGE = 2 * 1024 * 1024
DEFAULT_UA = ('Mozilla/5.0 (X11; Linux x86_64; rv:128.0) '
              'Gecko/20100101 Firefox/128.0')


class ResolveError(Exception):
    pass


class URL(str):
    def __new__(cls, value, meta=None):
        result = str.__new__(cls, value)
        result.meta = dict(meta if meta is not None else getattr(value, 'meta', {}))
        return result


class Body(str):
    pass


def b64urlEncode(value, strip=False):
    value = value.encode() if isinstance(value, str) else value
    out = base64.urlsafe_b64encode(value).decode('ascii')
    return out.rstrip('=') if strip else out


def json_dumps(value):
    return json.dumps(value, separators=(',', ':'))


def json_loads(value):
    return json.loads(value)


def printDBG(*args, **kwargs):
    # Original debug messages may contain temporary source URLs: discard them.
    pass


def _(value):
    return value


LAST_HOST_ERROR = False


def SetIPTVPlayerLastHostError(*args):
    global LAST_HOST_ERROR
    LAST_HOST_ERROR = True


class Notify:
    last = 0
    def setStatus(self, text):
        now = time.monotonic()
        if now - self.last > 5:
            self.last = now
            print(json.dumps({'stage': 'source_access_work',
                              'account_files_read': False}), flush=True)


NOTIFY = Notify()


def GetIPTVNotify():
    return NOTIFY


def checked_url(url):
    value = str(url)
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or '').lower()
    if (parsed.scheme != 'https' or not host or parsed.username or parsed.password
            or parsed.port not in (None, 443) or '.' not in host
            or host.endswith(('.local', '.localhost', '.internal'))):
        raise ResolveError('unsupported_source_address')
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ResolveError('source_address_not_public')
    return value


class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Http:
    def __init__(self):
        self.jar = http.cookiejar.LWPCookieJar(str(SESSION))
        try:self.jar.load(ignore_discard=True,ignore_expires=False)
        except (OSError,http.cookiejar.LoadError):pass
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=ssl.create_default_context()),
            urllib.request.HTTPCookieProcessor(self.jar), PublicRedirect())
        self.meta = {}
        self.steps = []

    @staticmethod
    def isValidUrl(value):
        try:
            checked_url(value)
            return True
        except (ResolveError,ValueError):
            return False

    def getDefaultHeader(self):
        return {'User-Agent': DEFAULT_UA, 'Accept-Encoding': 'identity', 'Accept': '*/*'}

    def getPage(self, url, params=None, post_data=None):
        params = params or {}
        headers = self.getDefaultHeader()
        headers.update(params.get('header', {}))
        payload = post_data.encode('utf-8') if isinstance(post_data, str) else post_data
        if isinstance(payload, dict):
            payload = urllib.parse.urlencode(payload).encode()
        request = urllib.request.Request(checked_url(url), data=payload, headers=headers)
        started = time.monotonic()
        try:
            response = self.opener.open(request, timeout=min(params.get('timeout', 25), 40))
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read(MAX_PAGE + 1)
            if len(raw) > MAX_PAGE:
                raise ResolveError('source_response_too_large')
            body = Body(raw.decode('utf-8-sig', 'replace'))
            content_type = response.headers.get('Content-Type', '')
            self.meta = {'url': response.geturl(), 'status_code': response.code,
                         'content-type': content_type}
            body.meta = dict(self.meta)
            step = {'hostname': urllib.parse.urlsplit(response.geturl()).hostname,
                    'http_status': response.code, 'bytes_read': len(raw),
                    'request': 'POST' if payload is not None else 'GET',
                    'elapsed_ms': round((time.monotonic()-started)*1000)}
            # Endpoint categories, not video IDs, tokens, bodies or stream URLs.
            path = urllib.parse.urlsplit(str(url)).path
            for kind in ['captcha/verify', 'access/challenge', 'access/attest',
                         'playback', 'settings', 'details', 'captcha']:
                if path.endswith('/' + kind):
                    step['endpoint'] = kind
                    break
            if len(self.steps) < 40:
                self.steps.append(step)
            allowed = any(low <= response.code <= high
                          for low, high in params.get('ignore_http_code_ranges', []))
            return response.code == 200 or allowed, body


class urlparser:
    @staticmethod
    def getDomain(url, onlyDomain=True):
        parsed = urllib.parse.urlsplit(str(url))
        return parsed.netloc if onlyDomain else parsed.scheme + '://' + parsed.netloc + '/'

    @staticmethod
    def decorateUrl(url, meta):
        return URL(url, meta)


def attrs(line):
    return {k: quoted or unquoted for k, quoted, unquoted in re.findall(
        r'([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))(?:,|$)', line)}


def hls_options(client, url):
    # URL metadata also contains subtitle lists and playback options. Only
    # actual HTTP headers belong in the request; preserve the rest below.
    headers = {key: value for key, value in getattr(url, 'meta', {}).items()
               if key in ('User-Agent', 'Referer', 'Origin', 'Accept')
               and isinstance(value, str)}
    ok, body = client.getPage(url, {'header': headers})
    if not ok:
        raise ResolveError('manifest_http_error')
    if not body.lstrip().startswith('#EXTM3U'):
        raise ResolveError('manifest_not_hls')
    lines = body.splitlines()
    audio = {}
    for line in lines:
        if line.startswith('#EXT-X-MEDIA:'):
            item = attrs(line.split(':', 1)[1])
            if item.get('TYPE') == 'AUDIO':
                audio.setdefault(item.get('GROUP-ID', ''), []).append(item)
    result = []
    for i, line in enumerate(lines):
        if not line.startswith('#EXT-X-STREAM-INF:'):
            continue
        a = attrs(line.split(':', 1)[1])
        res = re.fullmatch(r'(\d+)x(\d+)', a.get('RESOLUTION', ''))
        resolution = (int(res[1]), int(res[2])) if res else (0, 0)
        bandwidth = int(a.get('BANDWIDTH', '0')) if a.get('BANDWIDTH', '0').isdigit() else 0
        video_uri = next((v.strip() for v in lines[i + 1:] if v.strip() and not v.startswith('#')), None)
        if not video_uri:
            continue
        renditions = audio.get(a.get('AUDIO', ''), []) or [{}]
        for track in renditions:
            language = track.get('LANGUAGE', '')
            if not re.fullmatch(r'[A-Za-z0-9_-]{0,16}', language):
                language = 'other'
            codec = a.get('CODECS', '')
            if not re.fullmatch(r'[A-Za-z0-9., _-]{0,120}', codec):
                codec = 'other'
            meta = dict(getattr(url, 'meta', {}))
            meta.update(language=language, video_url=urllib.parse.urljoin(url, video_uri),
                        audio_url=urllib.parse.urljoin(url, track['URI']) if track.get('URI') else '')
            result.append({'name': 'HLS', 'url': URL(url, meta),
                           'width': resolution[0], 'height': resolution[1],
                           'bitrate': bandwidth, 'language': language, 'codecs': codec})
    return result or [{'name': 'HLS', 'url': url, 'width': 0, 'height': 0,
                       'bitrate': 0, 'language': '', 'codecs': ''}]


ACTIVE_HTTP = None


def getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999, **kwargs):
    return hls_options(ACTIVE_HTTP, url)
