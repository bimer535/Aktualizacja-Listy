# SPDX-License-Identifier: GPL-3.0-only
"""Standalone CDA player-data reader, based on public IPTVPlayer parserCDA."""
import html
import json
import re
from urllib.parse import unquote
import resolver

PLAYER_UA='Mozilla/5.0 (PlayStation 4 4.71) AppleWebKit/601.2 (KHTML, like Gecko)'


def video_url(value):
    match=re.fullmatch(r'https://(?:www\.)?cda\.pl/video/([0-9A-Za-z]+)(?:/vfilm)?/?(?:\?[^\s]*)?',str(value))
    if not match:raise resolver.ResolveError('invalid_cda_video')
    return 'https://www.cda.pl/video/'+match[1]


def player_data(body):
    match=re.search(r'''\bplayer_data\s*=\s*(['"])(.*?)\1''',body,re.S)
    if not match:return {}
    try:value=json.loads(html.unescape(match[2]))
    except ValueError:return {}
    video=value.get('video') if isinstance(value,dict) else None
    return video if isinstance(video,dict) else {}


def decode_file(value):
    if not isinstance(value,str) or not value:return ''
    if value.startswith('https://'):return resolver.checked_url(value)
    for marker in ('_XDDD','_CDA','_ADC','_CXD','_QWE','_Q5','_IKSDE'):value=value.replace(marker,'')
    value=''.join(chr(33+(ord(char)+14)%94) if 32<ord(char)<127 else char for char in unquote(value))
    value=value.replace('.cda.mp4','').replace('.2cda.pl','.cda.pl').replace('.3cda.pl','.cda.pl')
    value=value.replace('/upstream','.mp4/upstream') if '/upstream' in value else value+'.mp4'
    return resolver.checked_url('https://'+value)


def options(client,item):
    url=video_url(item['url']);identifier=url.rsplit('/',1)[-1]
    embed='https://ebd.cda.pl/620x368/'+identifier
    headers={'User-Agent':PLAYER_UA,'Referer':url}
    def page(address):
        ok,body=client.getPage(address,{'header':headers})
        code=client.meta.get('status_code',0)
        if code==429:raise resolver.ResolveError('cda_rate_limited')
        if code==404:raise resolver.ResolveError('cda_video_removed')
        if code==403 or 'cf-chl-' in body or '<title>Just a moment' in body:raise resolver.ResolveError('cda_access_denied')
        if not ok:raise resolver.ResolveError('cda_source_unavailable')
        return body
    body=page(embed);video=player_data(body)
    if not video:
        if 'premiumAccess(' in body or 'pakietu premium' in body:raise resolver.ResolveError('cda_premium_required')
        if re.search(r'geoblok|niedostępn[^<\n]{0,70}(?:kraju|region)',body,re.I):raise resolver.ResolveError('cda_geoblocked')
        raise resolver.ResolveError('cda_player_missing')
    if not video.get('file') and (video.get('manifest_drm_proxy') or video.get('manifest_drm_header')):
        raise resolver.ResolveError('cda_drm_required')
    result=[]
    qualities=video.get('qualities') or {}
    if video.get('file'):
        values=list(qualities.items()) if isinstance(qualities,dict) else []
        # Highest quality first; additional pages are queried only for this selected film.
        values.sort(key=lambda pair:int(re.search(r'\d+',str(pair[0]))[0]) if re.search(r'\d+',str(pair[0])) else 0,reverse=True)
        for name,code in values[:12] or [('', '')]:
            if name=='auto':continue
            address=embed;selected=video
            if name and str(code)!=str(video.get('quality')):
                address=embed+'/vfilm?wersja='+str(name)+'&a=1&t=0'
                selected=player_data(page(address))
            source=decode_file(selected.get('file',''))
            if not source or any(str(option['url'])==source for option in result):continue
            height=re.search(r'(\d+)p',str(name))
            result.append({'name':'CDA '+str(name),'height':int(height[1]) if height else int(selected.get('height') or 0),
                           'width':int(selected.get('width') or 0),'language':'',
                           'url':resolver.URL(source,{'User-Agent':PLAYER_UA,'Referer':address})})
            if item.get('auto_quality'):break
    if not result and video.get('manifest_apple'):
        result=resolver.hls_options(client,resolver.URL(resolver.checked_url(video['manifest_apple']),headers))
    if not result:raise resolver.ResolveError('cda_no_playable_variants')
    return result
