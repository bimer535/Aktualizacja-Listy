.class public Lpl/mk/ekino/tv/PlayerActivity;
.super Landroid/app/Activity;
.source "PlayerActivity.java"


# instance fields
.field private buffering:Landroid/widget/TextView;

.field private centerToggles:Z

.field private ended:Z

.field private entry:Lorg/json/JSONObject;

.field private fillScreen:Z

.field private lastDuration:J

.field private lastPosition:J

.field private leaving:Z

.field private player:Landroidx/media3/exoplayer/ExoPlayer;

.field private final saveTick:Ljava/lang/Runnable;

.field private screenMode:Landroid/widget/Button;

.field private final timer:Landroid/os/Handler;

.field private view:Landroidx/media3/ui/PlayerView;


# direct methods
.method public static synthetic $r8$lambda$BU_jRFEJ9hp8vUQebYlDQoyMdgc(Lpl/mk/ekino/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$onCreate$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$KvO34mWYz6rnCn1nP9fUgP9D6s8(Lpl/mk/ekino/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$onCreate$1(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$NPS-4q_zfhibpDCIYfMmnOntmvg(Lpl/mk/ekino/tv/PlayerActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$tracks$5(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$umJ2WpZrM7mJ9l7cGnqAc5ilo3U(Lpl/mk/ekino/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$onCreate$3(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$z0PLvk4zxCxP5cnYRChX26Ayhr4(Lpl/mk/ekino/tv/PlayerActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$onCreate$2(Landroid/view/View;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetbuffering(Lpl/mk/ekino/tv/PlayerActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetentry(Lpl/mk/ekino/tv/PlayerActivity;)Lorg/json/JSONObject;
    .locals 0

    iget-object p0, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetplayer(Lpl/mk/ekino/tv/PlayerActivity;)Landroidx/media3/exoplayer/ExoPlayer;
    .locals 0

    iget-object p0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettimer(Lpl/mk/ekino/tv/PlayerActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lpl/mk/ekino/tv/PlayerActivity;->timer:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputended(Lpl/mk/ekino/tv/PlayerActivity;Z)V
    .locals 0

    iput-boolean p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->ended:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$mleave(Lpl/mk/ekino/tv/PlayerActivity;Z)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msave(Lpl/mk/ekino/tv/PlayerActivity;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->save()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 39
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 46
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->timer:Landroid/os/Handler;

    .line 49
    new-instance v0, Lpl/mk/ekino/tv/PlayerActivity$1;

    invoke-direct {v0, p0}, Lpl/mk/ekino/tv/PlayerActivity$1;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    iput-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->saveTick:Ljava/lang/Runnable;

    return-void
.end method

.method private applyScreenMode()V
    .locals 2

    .line 109
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    iget-boolean v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 110
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->screenMode:Landroid/widget/Button;

    iget-boolean v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    if-eqz v1, :cond_1

    const-string v1, "Obraz: wype\u0142nij"

    goto :goto_1

    :cond_1
    const-string v1, "Obraz: dopasuj"

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private synthetic lambda$onCreate$0(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x0

    .line 61
    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/view/View;)V
    .locals 0

    .line 64
    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->toggleScreenMode()V

    return-void
.end method

.method private synthetic lambda$onCreate$2(Landroid/view/View;)V
    .locals 0

    .line 65
    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->tracks()V

    return-void
.end method

.method private synthetic lambda$onCreate$3(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    .line 67
    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method static synthetic lambda$onCreate$4(Landroid/widget/LinearLayout;I)V
    .locals 0

    .line 83
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void
.end method

.method private synthetic lambda$tracks$5(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 119
    :try_start_0
    new-instance p1, Landroidx/media3/ui/TrackSelectionDialogBuilder;

    if-nez p2, :cond_0

    const-string v0, "Audio"

    goto :goto_0

    :cond_0
    const-string v0, "Napisy"

    :goto_0
    iget-object v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-nez p2, :cond_1

    const/4 p2, 0x1

    goto :goto_1

    :cond_1
    const/4 p2, 0x3

    :goto_1
    invoke-direct {p1, p0, v0, v1, p2}, Landroidx/media3/ui/TrackSelectionDialogBuilder;-><init>(Landroid/content/Context;Ljava/lang/CharSequence;Landroidx/media3/common/Player;I)V

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/media3/ui/TrackSelectionDialogBuilder;->setAllowAdaptiveSelections(Z)Landroidx/media3/ui/TrackSelectionDialogBuilder;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/media3/ui/TrackSelectionDialogBuilder;->build()Landroid/app/Dialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 120
    :catch_0
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string p2, "Brak dodatkowych \u015bcie\u017cek w tym \u017ar\u00f3dle."

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "OK"

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private leave(Z)V
    .locals 2

    .line 128
    iget-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->leaving:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->leaving:Z

    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->save()V

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "next"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "entry"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 p1, -0x1

    invoke-virtual {p0, p1, v0}, Lpl/mk/ekino/tv/PlayerActivity;->setResult(ILandroid/content/Intent;)V

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->finish()V

    return-void
.end method

.method private save()V
    .locals 15

    .line 124
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v3

    const-wide/16 v5, 0x3e8

    div-long/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    iput-wide v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastPosition:J

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getDuration()J

    move-result-wide v3

    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v0, v3, v7

    if-nez v0, :cond_0

    move-wide v3, v1

    goto :goto_0

    :cond_0
    div-long/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    :goto_0
    iput-wide v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastDuration:J

    .line 125
    :cond_1
    iget-object v8, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    if-eqz v8, :cond_4

    iget-wide v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastPosition:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    iget-wide v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastDuration:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    iget-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->ended:Z

    if-nez v0, :cond_3

    iget-wide v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastDuration:J

    cmp-long v0, v3, v1

    if-lez v0, :cond_2

    iget-wide v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->lastPosition:J

    long-to-double v0, v0

    long-to-double v2, v3

    const-wide v4, 0x3feccccccccccccdL    # 0.90

    mul-double/2addr v2, v4

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_2

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v0, 0x1

    :goto_2
    if-eqz v0, :not_auto_watched
    invoke-static {p0, v8}, Lpl/mk/ekino/tv/WatchMarks;->mark(Landroid/content/Context;Lorg/json/JSONObject;)V
    :not_auto_watched
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    const-string v5, "op"

    const-string v6, "record"

    const-string v7, "item"

    const-string v9, "position"

    const-string v11, "duration"

    const-string v13, "completed"

    filled-new-array/range {v5 .. v14}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lpl/mk/ekino/tv/AppRuntime;->object([Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lpl/mk/ekino/tv/AppRuntime;->submit(Lorg/json/JSONObject;Lpl/mk/ekino/tv/AppRuntime$Callback;)V

    :cond_4
    return-void
.end method

.method private toggleScreenMode()V
    .locals 4

    .line 113
    iget-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->applyScreenMode()V

    .line 114
    const-string v0, "playback"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lpl/mk/ekino/tv/PlayerActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "fill_screen"

    iget-boolean v3, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 115
    iget-boolean v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    if-eqz v0, :cond_0

    const-string v0, "Wype\u0142nij ekran \u2014 boki obrazu mog\u0105 by\u0107 przyci\u0119te"

    goto :goto_0

    :cond_0
    const-string v0, "Dopasuj \u2014 ca\u0142y obraz w oryginalnych proporcjach"

    :goto_0
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private tracks()V
    .locals 4

    .line 118
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u015acie\u017cki filmu"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "Audio"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "Napisy"

    aput-object v3, v1, v2

    new-instance v2, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda5;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 121
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 6

    .line 131
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    const/16 v1, 0x17

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    if-ne v0, v1, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    move-result v0

    if-nez v0, :cond_0

    .line 132
    iput-boolean v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->centerToggles:Z

    return v2

    .line 134
    :cond_0
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_9

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-ne v0, v2, :cond_9

    .line 135
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v3, 0x55

    const/4 v4, 0x0

    if-eq v0, v3, :cond_7

    if-ne v0, v1, :cond_1

    .line 136
    iget-boolean v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->centerToggles:Z

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    const/16 v1, 0xb9

    if-ne v0, v1, :cond_2

    .line 137
    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->toggleScreenMode()V

    return v2

    :cond_2
    const/16 v1, 0x56

    if-ne v0, v1, :cond_3

    .line 138
    invoke-direct {p0, v4}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return v2

    :cond_3
    const/16 v1, 0xba

    if-ne v0, v1, :cond_4

    .line 139
    iget-object v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v3, "episode"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-direct {p0, v2}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return v2

    .line 140
    :cond_4
    iget-object v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v1}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    move-result v1

    if-nez v1, :cond_9

    const/16 v1, 0x15

    const/16 v3, 0x16

    if-eq v0, v1, :cond_5

    if-ne v0, v3, :cond_9

    .line 141
    :cond_5
    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v4

    if-ne v0, v3, :cond_6

    const/16 v0, 0x3a98

    goto :goto_0

    :cond_6
    const/16 v0, -0x3a98

    :goto_0
    int-to-long v0, v0

    add-long/2addr v4, v0

    const-wide/16 v0, 0x0

    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    invoke-interface {p1, v0, v1}, Landroidx/media3/exoplayer/ExoPlayer;->seekTo(J)V

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->showController()V

    return v2

    .line 136
    :cond_7
    :goto_1
    iput-boolean v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->centerToggles:Z

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_8

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->pause()V

    goto :goto_2

    :cond_8
    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->play()V

    :goto_2
    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->showController()V

    return v2

    .line 144
    :cond_9
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public onBackPressed()V
    .locals 1

    const/4 v0, 0x0

    .line 146
    invoke-direct {p0, v0}, Lpl/mk/ekino/tv/PlayerActivity;->leave(Z)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 13

    .line 51
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    const/high16 v0, -0x1000000
    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V
    invoke-virtual {p1, v0}, Landroid/view/Window;->setNavigationBarColor(I)V
    new-instance v1, Landroid/graphics/drawable/ColorDrawable;
    invoke-direct {v1, v0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V
    invoke-virtual {p1, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x1706

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 52
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "entry"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 54
    :try_start_1
    new-instance p1, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "stream"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 55
    const-string v0, "url"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 56
    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v2

    const-string v3, "https"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a

    invoke-virtual {v1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_a

    invoke-virtual {v1}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    goto/16 :goto_4

    .line 57
    :cond_0
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/high16 v3, -0x1000000
    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    new-instance v4, Landroidx/media3/ui/PlayerView;

    invoke-direct {v4, p0}, Landroidx/media3/ui/PlayerView;-><init>(Landroid/content/Context;)V

    const/high16 v3, -0x1000000
    invoke-virtual {v4, v3}, Landroidx/media3/ui/PlayerView;->setBackgroundColor(I)V
    invoke-virtual {v4, v3}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V

    iput-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0, v2}, Lpl/mk/ekino/tv/PlayerActivity;->setContentView(Landroid/view/View;)V

    .line 58
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const-string v5, "Buforowanie\u2026"

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/high16 v5, 0x41b00000    # 22.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/high16 v5, -0x50000000

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    const/16 v5, 0x18

    const/16 v6, 0x10

    invoke-virtual {v4, v5, v6, v5, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->buffering:Landroid/widget/TextView;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v7, 0x11

    const/4 v8, -0x2

    invoke-direct {v5, v8, v8, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 59
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v5, 0xc

    invoke-virtual {v4, v6, v5, v6, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 60
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const v6, 0x800035

    invoke-direct {v5, v8, v8, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 61
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Wr\u00f3\u0107"

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda0;

    invoke-direct {v5, p0}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda0;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 62
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->screenMode:Landroid/widget/Button;

    .line 63
    const-string v2, "playback"

    const/4 v5, 0x0

    invoke-virtual {p0, v2, v5}, Lpl/mk/ekino/tv/PlayerActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v6, "fill_screen"

    const/4 v7, 0x1

    invoke-interface {v2, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    iput-boolean v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->fillScreen:Z

    .line 64
    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->applyScreenMode()V

    iget-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->screenMode:Landroid/widget/Button;

    new-instance v6, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda1;

    invoke-direct {v6, p0}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda1;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->screenMode:Landroid/widget/Button;

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 65
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v6, "Audio / napisy"

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v6, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda2;

    invoke-direct {v6, p0}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda2;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 66
    iget-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v6, "episode"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 67
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v6, "Nast\u0119pny odcinek"

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v6, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda3;

    invoke-direct {v6, p0}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda3;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 69
    :cond_1
    new-instance v2, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;

    invoke-direct {v2, p0}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;-><init>(Landroid/content/Context;)V

    .line 70
    invoke-virtual {v2}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->buildUponParameters()Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v6

    .line 71
    const-string v8, "language"

    const-string v9, "pl"

    invoke-virtual {p1, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setPreferredAudioLanguage(Ljava/lang/String;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v6

    invoke-virtual {v6, v9}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v6

    const-string v9, "adaptive"

    .line 72
    invoke-virtual {p1, v9, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v9

    xor-int/2addr v9, v7

    invoke-virtual {v6, v9}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setForceHighestSupportedBitrate(Z)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v6

    .line 73
    invoke-virtual {v6, v5}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setExceedVideoConstraintsIfNecessary(Z)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v6

    .line 74
    const-string v9, "width"

    invoke-virtual {p1, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    const-string v10, "height"

    invoke-virtual {p1, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v10

    if-lez v10, :cond_3

    if-lez v9, :cond_2

    goto :goto_0

    :cond_2
    const v9, 0x7fffffff

    .line 75
    :goto_0
    invoke-virtual {v6, v9, v10}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->setMaxVideoSize(II)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    .line 76
    :cond_3
    invoke-virtual {v2, v6}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->setParameters(Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;)V

    .line 77
    new-instance v6, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    invoke-direct {v6}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;-><init>()V

    const v9, 0x15f90

    const/16 v10, 0x1770

    const/16 v11, 0x7530

    const/16 v12, 0xbb8

    .line 78
    invoke-virtual {v6, v11, v9, v12, v10}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBufferDurationsMs(IIII)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    move-result-object v6

    const/high16 v9, 0x4000000

    invoke-virtual {v6, v9}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setTargetBufferBytes(I)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->build()Landroidx/media3/exoplayer/DefaultLoadControl;

    move-result-object v6

    .line 79
    new-instance v9, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    new-instance v10, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    invoke-direct {v10, p0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    invoke-virtual {v10, v7}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setEnableDecoderFallback(Z)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object v7

    invoke-direct {v9, p0, v7}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;Landroidx/media3/exoplayer/RenderersFactory;)V

    .line 80
    invoke-virtual {v9, v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setTrackSelector(Landroidx/media3/exoplayer/trackselection/TrackSelector;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    invoke-virtual {v2, v6}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setLoadControl(Landroidx/media3/exoplayer/LoadControl;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    new-instance v6, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 81
    invoke-static {p1}, Lpl/mk/ekino/tv/NativeSource;->factory(Lorg/json/JSONObject;)Landroidx/media3/datasource/okhttp/OkHttpDataSource$Factory;

    move-result-object v7

    invoke-direct {v6, v7}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    invoke-virtual {v2, v6}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v2

    iput-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    .line 82
    iget-object v6, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v6, v2}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    iget-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v2, v12}, Landroidx/media3/ui/PlayerView;->setControllerShowTimeoutMs(I)V

    .line 83
    iget-object v2, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    new-instance v6, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda4;

    invoke-direct {v6, v4}, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda4;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual {v2, v6}, Landroidx/media3/ui/PlayerView;->setControllerVisibilityListener(Landroidx/media3/ui/PlayerView$ControllerVisibilityListener;)V

    .line 84
    new-instance v2, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {v2}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    invoke-virtual {v2, v1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v1

    new-instance v2, Landroidx/media3/common/MediaMetadata$Builder;

    invoke-direct {v2}, Landroidx/media3/common/MediaMetadata$Builder;-><init>()V

    iget-object v4, p0, Lpl/mk/ekino/tv/PlayerActivity;->entry:Lorg/json/JSONObject;

    const-string v6, "Film"

    const-string v7, "title"

    invoke-virtual {v4, v7, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v9, "movie_title"

    invoke-virtual {v4, v9, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroidx/media3/common/MediaMetadata$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/MediaMetadata$Builder;->build()Landroidx/media3/common/MediaMetadata;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setMediaMetadata(Landroidx/media3/common/MediaMetadata;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v1

    .line 85
    const-string v2, "mime_type"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "application/x-mpegURL"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {v1, v4}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 87
    :cond_4
    :try_start_2
    const-string v2, "subtitles"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    if-nez p1, :cond_5

    .line 88
    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    .line 89
    :cond_5
    :goto_1
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v5, v4, :cond_9

    .line 90
    invoke-virtual {p1, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    .line 91
    invoke-virtual {v6}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    invoke-virtual {v6}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_6

    goto :goto_3

    .line 92
    :cond_6
    new-instance v9, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    invoke-direct {v9, v6}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;-><init>(Landroid/net/Uri;)V

    const-string v6, "format"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v10, "srt"

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    const-string v6, "application/x-subrip"

    goto :goto_2

    :cond_7
    const-string v6, "text/vtt"

    :goto_2
    invoke-virtual {v9, v6}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v6

    const-string v9, "und"

    invoke-virtual {v4, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLanguage(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v6

    const-string v9, "Napisy"

    invoke-virtual {v4, v7, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLabel(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    :goto_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 94
    :cond_9
    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setSubtitleConfigurations(Ljava/util/List;)Landroidx/media3/common/MediaItem$Builder;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 96
    :catch_0
    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    new-instance v0, Lpl/mk/ekino/tv/PlayerActivity$2;

    invoke-direct {v0, p0}, Lpl/mk/ekino/tv/PlayerActivity$2;-><init>(Lpl/mk/ekino/tv/PlayerActivity;)V

    invoke-interface {p1, v0}, Landroidx/media3/exoplayer/ExoPlayer;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 106
    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-virtual {v1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object v0

    invoke-interface {p1, v0}, Landroidx/media3/exoplayer/ExoPlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "position"

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const-wide/16 v2, 0x3e8

    mul-long/2addr v0, v2

    invoke-interface {p1, v0, v1}, Landroidx/media3/exoplayer/ExoPlayer;->seekTo(J)V

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->prepare()V

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->play()V

    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->getWindow()Landroid/view/Window;
    move-result-object p1
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;
    move-result-object p1
    invoke-static {p1}, Lpl/mk/ekino/tv/PlayerFocus;->apply(Landroid/view/View;)V

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->requestFocus()Z

    iget-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity;->timer:Landroid/os/Handler;

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->saveTick:Ljava/lang/Runnable;

    const-wide/16 v1, 0x1388

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 56
    :cond_a
    :goto_4
    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->finish()V

    return-void

    .line 54
    :catch_1
    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->finish()V

    return-void

    .line 52
    :catch_2
    invoke-virtual {p0}, Lpl/mk/ekino/tv/PlayerActivity;->finish()V

    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 148
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->timer:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->save()V

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->view:Landroidx/media3/ui/PlayerView;

    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    iput-object v1, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 147
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    invoke-direct {p0}, Lpl/mk/ekino/tv/PlayerActivity;->save()V

    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity;->player:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->pause()V

    :cond_0
    return-void
.end method
