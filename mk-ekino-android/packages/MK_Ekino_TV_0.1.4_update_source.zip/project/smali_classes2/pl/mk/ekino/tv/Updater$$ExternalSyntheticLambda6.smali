.class public final synthetic Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lpl/mk/ekino/tv/UpdatePlan$Progress;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/Updater;

.field public final synthetic f$1:Lpl/mk/ekino/tv/UpdatePlan;

.field public final synthetic f$2:[I


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;[I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$0:Lpl/mk/ekino/tv/Updater;

    iput-object p2, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$1:Lpl/mk/ekino/tv/UpdatePlan;

    iput-object p3, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$2:[I

    return-void
.end method


# virtual methods
.method public final changed(J)V
    .locals 3

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$0:Lpl/mk/ekino/tv/Updater;

    iget-object v1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$1:Lpl/mk/ekino/tv/UpdatePlan;

    iget-object v2, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;->f$2:[I

    invoke-static {v0, v1, v2, p1, p2}, Lpl/mk/ekino/tv/Updater;->$r8$lambda$oUpei03DHPU5ppCzYS5yE92ISo8(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;[IJ)V

    return-void
.end method
