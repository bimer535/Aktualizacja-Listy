.class public final synthetic Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Landroid/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Landroid/app/AlertDialog;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda23;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda23;->f$1:Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda23;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda23;->f$1:Landroid/app/AlertDialog;

    invoke-static {v0, v1, p1}, Lpl/mk/ekino/tv/MainActivity;->lambda$search$14(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/content/DialogInterface;)V

    return-void
.end method
