.class public final Lpl/mk/ekino/tv/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lpl/mk/ekino/tv/R$drawable;,
        Lpl/mk/ekino/tv/R$style;,
        Lpl/mk/ekino/tv/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
