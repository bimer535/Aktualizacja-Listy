.class public final synthetic Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lpl/mk/ekino/tv/AppRuntime$Callback;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/MainActivity;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/MainActivity;ZLorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iput-boolean p2, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$1:Z

    iput-object p3, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$2:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final done(Lorg/json/JSONObject;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iget-boolean v1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$1:Z

    iget-object v2, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda8;->f$2:Lorg/json/JSONObject;

    invoke-static {v0, v1, v2, p1}, Lpl/mk/ekino/tv/MainActivity;->$r8$lambda$kKlNaGW4HpEkLY8dZ95_5LBWlyc(Lpl/mk/ekino/tv/MainActivity;ZLorg/json/JSONObject;Lorg/json/JSONObject;)V

    return-void
.end method
