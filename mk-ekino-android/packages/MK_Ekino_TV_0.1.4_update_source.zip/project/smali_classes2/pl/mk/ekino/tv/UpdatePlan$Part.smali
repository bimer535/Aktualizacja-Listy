.class final Lpl/mk/ekino/tv/UpdatePlan$Part;
.super Ljava/lang/Object;
.source "UpdatePlan.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/ekino/tv/UpdatePlan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Part"
.end annotation


# instance fields
.field final sha256:Ljava/lang/String;

.field final size:J

.field final url:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;JLjava/lang/String;)V
    .locals 0

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/UpdatePlan$Part;->url:Ljava/lang/String;

    iput-wide p2, p0, Lpl/mk/ekino/tv/UpdatePlan$Part;->size:J

    iput-object p4, p0, Lpl/mk/ekino/tv/UpdatePlan$Part;->sha256:Ljava/lang/String;

    return-void
.end method
