.class interface abstract Lpl/mk/ekino/tv/AppRuntime$Callback;
.super Ljava/lang/Object;
.source "AppRuntime.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/ekino/tv/AppRuntime;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Callback"
.end annotation


# virtual methods
.method public abstract done(Lorg/json/JSONObject;)V
.end method
