.class final Lpl/mk/ekino/tv/UpdatePlan;
.super Ljava/lang/Object;
.source "UpdatePlan.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lpl/mk/ekino/tv/UpdatePlan$Part;,
        Lpl/mk/ekino/tv/UpdatePlan$Progress;
    }
.end annotation


# static fields
.field static final BASE:Ljava/lang/String; = "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/"

.field static final MAX_SIZE:J = 0x6400000L


# instance fields
.field final code:J

.field final notes:Ljava/lang/String;

.field final parts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lpl/mk/ekino/tv/UpdatePlan$Part;",
            ">;"
        }
    .end annotation
.end field

.field final sha256:Ljava/lang/String;

.field final size:J

.field final version:Ljava/lang/String;


# direct methods
.method private constructor <init>(JLjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/lang/String;",
            "J",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lpl/mk/ekino/tv/UpdatePlan$Part;",
            ">;)V"
        }
    .end annotation

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 26
    iput-wide p1, p0, Lpl/mk/ekino/tv/UpdatePlan;->code:J

    iput-object p3, p0, Lpl/mk/ekino/tv/UpdatePlan;->version:Ljava/lang/String;

    iput-wide p4, p0, Lpl/mk/ekino/tv/UpdatePlan;->size:J

    iput-object p6, p0, Lpl/mk/ekino/tv/UpdatePlan;->sha256:Ljava/lang/String;

    iput-object p7, p0, Lpl/mk/ekino/tv/UpdatePlan;->notes:Ljava/lang/String;

    .line 27
    invoke-static {p8}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lpl/mk/ekino/tv/UpdatePlan;->parts:Ljava/util/List;

    return-void
.end method

.method static copyPart(Ljava/io/InputStream;Ljava/io/OutputStream;Lpl/mk/ekino/tv/UpdatePlan$Part;Ljava/security/MessageDigest;JLpl/mk/ekino/tv/UpdatePlan$Progress;)J
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 53
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const v1, 0x8000

    new-array v1, v1, [B

    const-wide/16 v2, 0x0

    .line 54
    :cond_0
    :goto_0
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_2

    int-to-long v5, v4

    add-long/2addr v2, v5

    .line 55
    iget-wide v5, p2, Lpl/mk/ekino/tv/UpdatePlan$Part;->size:J

    cmp-long v5, v2, v5

    if-gtz v5, :cond_1

    const/4 v5, 0x0

    .line 56
    invoke-virtual {v0, v1, v5, v4}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {p3, v1, v5, v4}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {p1, v1, v5, v4}, Ljava/io/OutputStream;->write([BII)V

    if-eqz p6, :cond_0

    add-long v4, p4, v2

    .line 57
    invoke-interface {p6, v4, v5}, Lpl/mk/ekino/tv/UpdatePlan$Progress;->changed(J)V

    goto :goto_0

    .line 55
    :cond_1
    new-instance p0, Ljava/lang/Exception;

    const-string p1, "part_size"

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    .line 59
    :cond_2
    iget-wide p0, p2, Lpl/mk/ekino/tv/UpdatePlan$Part;->size:J

    cmp-long p0, v2, p0

    if-nez p0, :cond_3

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    invoke-static {p0}, Lpl/mk/ekino/tv/UpdatePlan;->hex([B)Ljava/lang/String;

    move-result-object p0

    iget-object p1, p2, Lpl/mk/ekino/tv/UpdatePlan$Part;->sha256:Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    return-wide v2

    :cond_3
    new-instance p0, Ljava/lang/Exception;

    const-string p1, "part_checksum"

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static hex([B)Ljava/lang/String;
    .locals 6

    .line 51
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%02x"

    invoke-static {v4, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static parse(Lorg/json/JSONObject;)Lpl/mk/ekino/tv/UpdatePlan;
    .locals 30
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v0, p0

    .line 30
    const-string v1, "version"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v1, "sha256"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 31
    const-string v2, "versionCode"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    const-string v2, "size"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v6

    .line 32
    const-string v9, "applicationId"

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "pl.mk.ekino.tv"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_7

    const-string v9, "[0-9]+\\.[0-9]+\\.[0-9]+"

    invoke-virtual {v5, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_7

    const-wide/16 v9, 0x1

    cmp-long v11, v3, v9

    if-ltz v11, :cond_7

    const-wide/32 v11, 0x7fffffff

    cmp-long v11, v3, v11

    if-gtz v11, :cond_7

    const-wide/16 v11, 0x3e8

    cmp-long v11, v6, v11

    if-ltz v11, :cond_7

    const-wide/32 v11, 0x6400000

    cmp-long v11, v6, v11

    if-gtz v11, :cond_7

    const-string v11, "[0-9a-f]{64}"

    invoke-virtual {v8, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_7

    .line 33
    new-instance v12, Ljava/lang/StringBuilder;

    const-string v13, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/packages/MK_Ekino_TV_"

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ".apk"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    .line 34
    const-string v13, "url"

    invoke-virtual {v0, v13}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_6

    move-wide v14, v9

    .line 35
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 36
    const-string v9, "parts"

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v16

    if-eqz v16, :cond_5

    .line 37
    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    move-wide/from16 v16, v14

    .line 38
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v14

    const/4 v15, 0x1

    if-lt v14, v15, :cond_4

    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v14

    const/16 v15, 0x80

    if-gt v14, v15, :cond_4

    const-wide/16 v14, 0x0

    const/16 v18, 0x0

    move-wide/from16 v28, v3

    move/from16 v3, v18

    move-wide/from16 v18, v28

    .line 40
    :goto_0
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v4

    move-object/from16 v20, v5

    const-string v5, "part_size"

    if-ge v3, v4, :cond_2

    .line 41
    invoke-virtual {v9, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    move-wide/from16 v21, v14

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v14

    move-object/from16 v23, v2

    invoke-virtual {v4, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v24, v1

    .line 42
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move/from16 v25, v3

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    add-int/lit8 v25, v25, 0x1

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v26

    move-object/from16 v27, v9

    filled-new-array/range {v26 .. v26}, [Ljava/lang/Object;

    move-result-object v9

    const-string v0, ".part%03d"

    invoke-static {v3, v0, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 43
    invoke-virtual {v4, v13}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    cmp-long v1, v14, v16

    if-ltz v1, :cond_1

    const-wide/32 v3, 0x100000

    cmp-long v1, v14, v3

    if-gtz v1, :cond_1

    invoke-virtual {v2, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    add-long v3, v21, v14

    cmp-long v1, v3, v6

    if-gtz v1, :cond_0

    .line 45
    new-instance v1, Lpl/mk/ekino/tv/UpdatePlan$Part;

    invoke-direct {v1, v0, v14, v15, v2}, Lpl/mk/ekino/tv/UpdatePlan$Part;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-interface {v10, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, p0

    move-wide v14, v3

    move-object/from16 v5, v20

    move-object/from16 v2, v23

    move-object/from16 v1, v24

    move/from16 v3, v25

    move-object/from16 v9, v27

    goto :goto_0

    .line 44
    :cond_0
    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    .line 43
    :cond_1
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "part_manifest"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    move-wide/from16 v21, v14

    cmp-long v0, v21, v6

    if-nez v0, :cond_3

    goto :goto_1

    .line 47
    :cond_3
    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    .line 38
    :cond_4
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "part_count"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    move-wide/from16 v18, v3

    move-object/from16 v20, v5

    .line 48
    new-instance v0, Lpl/mk/ekino/tv/UpdatePlan$Part;

    invoke-direct {v0, v12, v6, v7, v8}, Lpl/mk/ekino/tv/UpdatePlan$Part;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-interface {v10, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 49
    :goto_1
    new-instance v2, Lpl/mk/ekino/tv/UpdatePlan;

    const-string v0, "notes"

    const-string v1, "Pobra\u0107 now\u0105 wersj\u0119?"

    move-object/from16 v3, p0

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-wide/from16 v3, v18

    move-object/from16 v5, v20

    invoke-direct/range {v2 .. v10}, Lpl/mk/ekino/tv/UpdatePlan;-><init>(JLjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    return-object v2

    .line 34
    :cond_6
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "manifest_address"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    .line 32
    :cond_7
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "manifest"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method verify(JLjava/security/MessageDigest;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 63
    iget-wide v0, p0, Lpl/mk/ekino/tv/UpdatePlan;->size:J

    cmp-long p1, p1, v0

    if-nez p1, :cond_0

    invoke-virtual {p3}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p1

    invoke-static {p1}, Lpl/mk/ekino/tv/UpdatePlan;->hex([B)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lpl/mk/ekino/tv/UpdatePlan;->sha256:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    return-void

    :cond_0
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "checksum"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method
