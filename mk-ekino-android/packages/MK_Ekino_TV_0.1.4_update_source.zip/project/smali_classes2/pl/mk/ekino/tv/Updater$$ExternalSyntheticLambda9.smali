.class public final synthetic Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/Updater;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/Updater;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;->f$0:Lpl/mk/ekino/tv/Updater;

    iput p2, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;->f$0:Lpl/mk/ekino/tv/Updater;

    iget v1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;->f$1:I

    invoke-static {v0, v1}, Lpl/mk/ekino/tv/Updater;->$r8$lambda$UAmsPFhOg23rj8W7A6VpySxUj74(Lpl/mk/ekino/tv/Updater;I)V

    return-void
.end method
