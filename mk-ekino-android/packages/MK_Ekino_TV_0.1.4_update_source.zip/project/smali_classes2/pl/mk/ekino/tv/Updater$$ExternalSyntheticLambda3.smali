.class public final synthetic Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/Updater;

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Lpl/mk/ekino/tv/UpdatePlan;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/Updater;JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$0:Lpl/mk/ekino/tv/Updater;

    iput-wide p2, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$1:J

    iput-object p4, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iput-object p5, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$3:Lpl/mk/ekino/tv/UpdatePlan;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$0:Lpl/mk/ekino/tv/Updater;

    iget-wide v1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$1:J

    iget-object v3, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iget-object v4, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;->f$3:Lpl/mk/ekino/tv/UpdatePlan;

    invoke-static {v0, v1, v2, v3, v4}, Lpl/mk/ekino/tv/Updater;->$r8$lambda$xpm23z2uEJ4zS-IXO1Hmpq0g2gE(Lpl/mk/ekino/tv/Updater;JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V

    return-void
.end method
