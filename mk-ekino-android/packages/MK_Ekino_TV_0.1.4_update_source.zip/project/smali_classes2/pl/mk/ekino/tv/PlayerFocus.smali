.class public final Lpl/mk/ekino/tv/PlayerFocus;
.super Ljava/lang/Object;

.method public static apply(Landroid/view/View;)V
    .locals 4
    instance-of v0, p0, Landroid/widget/Button;
    if-nez v0, :button
    instance-of v0, p0, Landroid/widget/ImageButton;
    if-eqz v0, :children
    :button
    const v0, 0x7f050052
    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundResource(I)V
    const/4 v0, 0x0
    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    const/4 v0, 0x1
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V
    instance-of v0, p0, Landroid/widget/TextView;
    if-eqz v0, :children
    move-object v0, p0
    check-cast v0, Landroid/widget/TextView;
    const/4 v1, -0x1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V
    :children
    instance-of v0, p0, Landroid/view/ViewGroup;
    if-eqz v0, :done
    check-cast p0, Landroid/view/ViewGroup;
    const/4 v0, 0x0
    :loop
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I
    move-result v1
    if-ge v0, v1, :done
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    move-result-object v2
    invoke-static {v2}, Lpl/mk/ekino/tv/PlayerFocus;->apply(Landroid/view/View;)V
    add-int/lit8 v0, v0, 0x1
    goto :loop
    :done
    return-void
.end method
