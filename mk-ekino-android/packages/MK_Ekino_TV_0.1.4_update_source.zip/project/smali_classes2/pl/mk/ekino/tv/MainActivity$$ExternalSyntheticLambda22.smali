.class public final synthetic Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/MainActivity;

.field public final synthetic f$1:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/MainActivity;Landroid/widget/EditText;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda22;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iput-object p2, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda22;->f$1:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda22;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iget-object v1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda22;->f$1:Landroid/widget/EditText;

    invoke-static {v0, v1, p1, p2}, Lpl/mk/ekino/tv/MainActivity;->$r8$lambda$hqCI88H74l89-JI3MS-Yk8HTndo(Lpl/mk/ekino/tv/MainActivity;Landroid/widget/EditText;Landroid/content/DialogInterface;I)V

    return-void
.end method
