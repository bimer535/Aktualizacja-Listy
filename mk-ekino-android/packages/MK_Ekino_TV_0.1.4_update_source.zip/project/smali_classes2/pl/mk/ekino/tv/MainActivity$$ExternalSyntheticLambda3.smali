.class public final synthetic Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/MainActivity;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/MainActivity;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda3;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iput-object p2, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda3;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda3;->f$0:Lpl/mk/ekino/tv/MainActivity;

    iget-object v1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda3;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1, p1}, Lpl/mk/ekino/tv/MainActivity;->$r8$lambda$i7YLkozTL9UlDICiQvoe38VG_04(Lpl/mk/ekino/tv/MainActivity;Lorg/json/JSONObject;Landroid/view/View;)Z

    move-result p1

    return p1
.end method
