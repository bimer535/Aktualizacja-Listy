.class public final synthetic Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/Updater;

.field public final synthetic f$1:Lpl/mk/ekino/tv/UpdatePlan;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;->f$0:Lpl/mk/ekino/tv/Updater;

    iput-object p2, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;->f$1:Lpl/mk/ekino/tv/UpdatePlan;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;->f$0:Lpl/mk/ekino/tv/Updater;

    iget-object v1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;->f$1:Lpl/mk/ekino/tv/UpdatePlan;

    invoke-static {v0, v1, p1, p2}, Lpl/mk/ekino/tv/Updater;->$r8$lambda$FE1_lOy3gwuqmgjuRCPGX0zTThA(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;Landroid/content/DialogInterface;I)V

    return-void
.end method
