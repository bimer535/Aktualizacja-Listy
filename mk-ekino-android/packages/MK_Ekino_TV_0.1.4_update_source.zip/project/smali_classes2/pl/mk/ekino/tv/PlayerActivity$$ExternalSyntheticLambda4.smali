.class public final synthetic Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/media3/ui/PlayerView$ControllerVisibilityListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda4;->f$0:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public final onVisibilityChanged(I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/PlayerActivity$$ExternalSyntheticLambda4;->f$0:Landroid/widget/LinearLayout;

    invoke-static {v0, p1}, Lpl/mk/ekino/tv/PlayerActivity;->lambda$onCreate$4(Landroid/widget/LinearLayout;I)V

    return-void
.end method
