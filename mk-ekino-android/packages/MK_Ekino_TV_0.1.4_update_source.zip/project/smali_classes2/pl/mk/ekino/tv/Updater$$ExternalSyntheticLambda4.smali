.class public final synthetic Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/Updater;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/Updater;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda4;->f$0:Lpl/mk/ekino/tv/Updater;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda4;->f$0:Lpl/mk/ekino/tv/Updater;

    invoke-static {v0}, Lpl/mk/ekino/tv/Updater;->$r8$lambda$-1tTUnNOf1It3zy1Y1nLAcn8dC0(Lpl/mk/ekino/tv/Updater;)V

    return-void
.end method
