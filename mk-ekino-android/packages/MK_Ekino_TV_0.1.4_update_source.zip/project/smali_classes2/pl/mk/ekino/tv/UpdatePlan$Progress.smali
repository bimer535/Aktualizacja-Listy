.class interface abstract Lpl/mk/ekino/tv/UpdatePlan$Progress;
.super Ljava/lang/Object;
.source "UpdatePlan.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpl/mk/ekino/tv/UpdatePlan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Progress"
.end annotation


# virtual methods
.method public abstract changed(J)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation
.end method
