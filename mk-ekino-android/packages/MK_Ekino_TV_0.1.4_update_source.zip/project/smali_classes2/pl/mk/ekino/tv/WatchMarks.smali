.class public final Lpl/mk/ekino/tv/WatchMarks;
.super Ljava/lang/Object;

.method private static key(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 3
    const-string v0, ""
    if-eqz p0, :done
    const-string v1, "action"
    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    const-string v2, "sources"
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, :valid
    const-string v2, "resolve"
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :done
    :valid
    const-string v1, "url"
    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v1
    invoke-virtual {v1}, Landroid/net/Uri;->getPath()Ljava/lang/String;
    move-result-object v1
    if-eqz v1, :done
    const-string v2, "/movie/show/"
    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v2
    if-nez v2, :path_ok
    const-string v2, "/serie/watch/"
    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, :done
    :path_ok
    return-object v1
    :done
    return-object v0
.end method

.method private static prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 2
    const-string v0, "mk_watched_v1"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    return-object v0
.end method

.method public static watched(Landroid/content/Context;Lorg/json/JSONObject;)Z
    .locals 3
    invoke-static {p1}, Lpl/mk/ekino/tv/WatchMarks;->key(Lorg/json/JSONObject;)Ljava/lang/String;
    move-result-object v0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    move-result v1
    if-eqz v1, :valid
    const/4 v0, 0x0
    return v0
    :valid
    invoke-static {p0}, Lpl/mk/ekino/tv/WatchMarks;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;
    move-result-object v1
    const-string v2, "watched"
    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z
    move-result v2
    invoke-interface {v1, v0, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v0
    return v0
.end method

.method private static set(Landroid/content/Context;Lorg/json/JSONObject;Z)V
    .locals 2
    invoke-static {p1}, Lpl/mk/ekino/tv/WatchMarks;->key(Lorg/json/JSONObject;)Ljava/lang/String;
    move-result-object v0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    move-result v1
    if-nez v1, :done
    invoke-static {p0}, Lpl/mk/ekino/tv/WatchMarks;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;
    move-result-object v1
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    invoke-interface {v1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :done
    return-void
.end method

.method public static mark(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 1
    const/4 v0, 0x1
    invoke-static {p0, p1, v0}, Lpl/mk/ekino/tv/WatchMarks;->set(Landroid/content/Context;Lorg/json/JSONObject;Z)V
    return-void
.end method

.method public static decorate(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 2
    if-eqz p1, :done
    :try_start
    invoke-static {p0, p1}, Lpl/mk/ekino/tv/WatchMarks;->watched(Landroid/content/Context;Lorg/json/JSONObject;)Z
    move-result v0
    if-eqz v0, :decorate_put
    invoke-static {p0, p1}, Lpl/mk/ekino/tv/WatchMarks;->mark(Landroid/content/Context;Lorg/json/JSONObject;)V
    :decorate_put
    const-string v1, "watched"
    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end
    .catch Lorg/json/JSONException; {:try_start .. :try_end} :done
    :done
    return-void
.end method

.method public static info(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    invoke-static {p0, p1}, Lpl/mk/ekino/tv/WatchMarks;->watched(Landroid/content/Context;Lorg/json/JSONObject;)Z
    move-result v0
    if-eqz v0, :done
    const-string v0, "\u2713 Obejrzany  \u2022  "
    invoke-virtual {v0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2
    :done
    return-object p2
.end method

.method public static toggle(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 2
    invoke-static {p1}, Lpl/mk/ekino/tv/WatchMarks;->key(Lorg/json/JSONObject;)Ljava/lang/String;
    move-result-object v0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    move-result v0
    if-eqz v0, :valid
    const-string v0, "Najpierw wybierz film lub odcinek"
    goto :toast
    :valid
    invoke-static {p0, p1}, Lpl/mk/ekino/tv/WatchMarks;->watched(Landroid/content/Context;Lorg/json/JSONObject;)Z
    move-result v0
    xor-int/lit8 v0, v0, 0x1
    invoke-static {p0, p1, v0}, Lpl/mk/ekino/tv/WatchMarks;->set(Landroid/content/Context;Lorg/json/JSONObject;Z)V
    if-eqz v0, :unwatched
    const-string v0, "Oznaczono jako obejrzany"
    goto :toast
    :unwatched
    const-string v0, "Cofni\u0119to oznaczenie obejrzany"
    :toast
    const/4 v1, 0x0
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    move-result-object v0
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    return-void
.end method
