.class public final synthetic Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lpl/mk/ekino/tv/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lpl/mk/ekino/tv/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda13;->f$0:Lpl/mk/ekino/tv/MainActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lpl/mk/ekino/tv/MainActivity$$ExternalSyntheticLambda13;->f$0:Lpl/mk/ekino/tv/MainActivity;

    invoke-static {v0}, Lpl/mk/ekino/tv/MainActivity;->$r8$lambda$DDdA7kGbQeuCifZ51F5sKB8BKtA(Lpl/mk/ekino/tv/MainActivity;)V

    return-void
.end method
