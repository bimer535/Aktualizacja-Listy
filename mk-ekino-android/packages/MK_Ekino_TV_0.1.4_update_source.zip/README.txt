Na poprzedni projekt odkodowany Apktool 2.12.1 nałóż project/. Buduj z -j 1. Biblioteki i assets bez zmian. Kod zmian w smali. Pełny projekt udostępniony oddzielnie w wydaniu 0.1.4.
