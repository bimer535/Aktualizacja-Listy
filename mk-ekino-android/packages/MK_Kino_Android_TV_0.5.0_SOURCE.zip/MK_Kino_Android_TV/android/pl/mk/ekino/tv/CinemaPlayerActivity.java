package pl.mk.ekino.tv;

import android.os.Bundle;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;

/** TV controls over the existing, unchanged Media3 playback and progress engine. */
public final class CinemaPlayerActivity extends PlayerActivity {
    private final Handler timer=new Handler(Looper.getMainLooper());
    private Object player, playerView;
    private Class<?> playerType,viewType;
    private LinearLayout controls, titleBar;
    private TextView movieTitle, positionLabel, durationLabel, preview;
    private SeekBar timeline;
    private Button pause,speedButton,stepButton;
    private int jumpSeconds=30;
    private float playbackSpeed=1f;
    private boolean dialogOpen;
    private JSONObject item;
    private boolean active,seeking,resumePlayback;
    private long target,lastInput;
    private int seekDirection;
    private final Runnable commitSeek=()->commit();
    private final Runnable tick=new Runnable(){public void run(){if(!active||player==null)return;refresh();timer.postDelayed(this,400);}};
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable box(int color,int border){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(60));d.setStroke(dp(2),border);return d;}
    private Button button(String label,Runnable click){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(20);b.setPadding(0,0,0,0);b.setMinWidth(0);b.setMinimumWidth(0);b.setContentDescription(label);b.setTextColor(Color.WHITE);StateListDrawable bg=new StateListDrawable();bg.addState(new int[]{android.R.attr.state_focused},box(0xff1d626c,0xff63eee0));bg.addState(new int[]{},box(0xc91a3043,0x5554778c));b.setBackground(bg);b.setOnClickListener(v->{lastInput=SystemClock.elapsedRealtime();click.run();});return b;}
    @Override public void onCreate(Bundle state){super.onCreate(state);if(isFinishing())return;try{
        Field pf=PlayerActivity.class.getDeclaredField("player");pf.setAccessible(true);player=pf.get(this);
        Field vf=PlayerActivity.class.getDeclaredField("view");vf.setAccessible(true);playerView=vf.get(this);
        playerType=Class.forName("androidx.media3.common.Player");viewType=Class.forName("androidx.media3.ui.PlayerView");
        item=new JSONObject(getIntent().getStringExtra("entry"));
        FrameLayout root=(FrameLayout)((ViewGroup)findViewById(android.R.id.content)).getChildAt(0);
        viewType.getMethod("setUseController",boolean.class).invoke(playerView,false);
        for(int i=0;i<root.getChildCount();i++)if(root.getChildAt(i) instanceof LinearLayout)root.getChildAt(i).setVisibility(View.GONE);
        jumpSeconds=getSharedPreferences("playback",MODE_PRIVATE).getInt("jump_seconds",30);if(jumpSeconds!=10&&jumpSeconds!=30&&jumpSeconds!=60)jumpSeconds=30;build(root);stepButton.setText(jumpSeconds+" s");lastInput=SystemClock.elapsedRealtime();
    }catch(Exception error){player=null;}}
    private void build(FrameLayout root){
        titleBar=new LinearLayout(this);titleBar.setOrientation(LinearLayout.VERTICAL);titleBar.setPadding(dp(26),dp(20),dp(26),dp(24));titleBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xe6091422,0x00091422}));
        movieTitle=text(item.optString("movie_title",item.optString("title","Film")),23,Color.WHITE);movieTitle.setTypeface(null,Typeface.BOLD);titleBar.addView(movieTitle);TextView sub=text("MK Kino  ·  "+item.optString("year")+"  "+item.optString("language_version"),12,0xffb1c7d6);sub.setPadding(0,dp(5),0,0);titleBar.addView(sub);root.addView(titleBar,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
        controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(dp(26),dp(28),dp(26),dp(16));controls.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00091422,0xee091422,0xfa091422}));
        preview=text("",18,0xff68e8df);preview.setGravity(Gravity.CENTER);preview.setPadding(0,0,0,dp(6));controls.addView(preview);
        LinearLayout times=new LinearLayout(this);positionLabel=text("0:00",13,Color.WHITE);durationLabel=text("",13,0xffb3c8d8);durationLabel.setGravity(Gravity.END);times.addView(positionLabel,new LinearLayout.LayoutParams(0,-2,1));times.addView(durationLabel,new LinearLayout.LayoutParams(0,-2,1));controls.addView(times);
        timeline=new SeekBar(this);timeline.setMax(10000);timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(0xff43d7d0));timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(0xff9bfff2));timeline.setSecondaryProgressTintList(android.content.res.ColorStateList.valueOf(0xff37576d));timeline.setPadding(dp(5),0,dp(5),0);controls.addView(timeline,new LinearLayout.LayoutParams(-1,dp(34)));
        timeline.setOnKeyListener((v,key,event)->{if(key!=KeyEvent.KEYCODE_DPAD_LEFT&&key!=KeyEvent.KEYCODE_DPAD_RIGHT)return false;if(event.getAction()==KeyEvent.ACTION_DOWN)jump(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:-1,event.getRepeatCount());else scheduleCommit();return true;});
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){seeking=true;target=duration()*progress/10000;preview.setText("Przewiń do "+stamp(target));lastInput=SystemClock.elapsedRealtime();}}public void onStartTrackingTouch(SeekBar b){seeking=true;timer.removeCallbacks(commitSeek);}public void onStopTrackingTouch(SeekBar b){commit();}});
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);
        pause=button("▶",this::toggle);addButton(buttons,pause,"Odtwarzanie");
        speedButton=button("1×",this::speed);addButton(buttons,speedButton,"Prędkość");
        addButton(buttons,button("♪",this::volume),"Głośność");
        addButton(buttons,button("↶",this::restart),"Od początku");
        stepButton=button("30 s",this::step);stepButton.setTextSize(15);addButton(buttons,stepButton,"Przeskok");
        addButton(buttons,button("CC",()->tracks(3)),"Napisy");
        addButton(buttons,button("♫",()->tracks(1)),"Audio");
        addButton(buttons,button("⛶",()->invokeParent("toggleScreenMode")),"Obraz");
        if(item.has("episode"))addButton(buttons,button("▶|",()->leave(true)),"Następny");
        // Controls precede the timeline, matching their visual and focus order.
        controls.addView(buttons,1);TextView help=text("← →  przewijaj   ·   przytrzymaj strzałkę, aby przewijać szybciej   ·   OK  sterowanie",11,0xff8aa7bb);help.setGravity(Gravity.CENTER);help.setPadding(0,dp(8),0,0);controls.addView(help);
        root.addView(controls,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));hide();
    }
    private void addButton(LinearLayout row,Button button,String label){LinearLayout group=new LinearLayout(this);group.setOrientation(LinearLayout.VERTICAL);group.setGravity(Gravity.CENTER);group.addView(button,new LinearLayout.LayoutParams(dp(52),dp(52)));TextView caption=text(label,10,Color.WHITE);caption.setGravity(Gravity.CENTER);caption.setPadding(0,dp(5),0,0);group.addView(caption);button.setContentDescription(label);row.addView(group,new LinearLayout.LayoutParams(0,-2,1));}
    private void showDialog(AlertDialog dialog){dialogOpen=true;dialog.setOnDismissListener(d->{dialogOpen=false;lastInput=SystemClock.elapsedRealtime();});dialog.show();}
    private void speed(){float[] rates={0.5f,0.75f,1f,1.25f,1.5f,1.75f,2f};String[] labels={"0,5×","0,75×","1×","1,25×","1,5×","1,75×","2×"};int checked=2;for(int i=0;i<rates.length;i++)if(rates[i]==playbackSpeed)checked=i;
        showDialog(new AlertDialog.Builder(this).setTitle("Prędkość odtwarzania").setSingleChoiceItems(labels,checked,(d,index)->{Object result=call("setPlaybackSpeed",new Class<?>[]{float.class},rates[index]);playbackSpeed=rates[index];speedButton.setText(labels[index]);d.dismiss();}).setNegativeButton("Wróć",null).create());}
    private void volume(){LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(24),dp(10),dp(24),dp(10));Object saved=call("getVolume",new Class<?>[0]);int value=saved instanceof Number?Math.round(((Number)saved).floatValue()*100):100;TextView label=text(value+"%",18,Color.WHITE);panel.addView(label);SeekBar bar=new SeekBar(this);bar.setMax(100);bar.setProgress(value);panel.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){if(user){call("setVolume",new Class<?>[]{float.class},p/100f);label.setText(p+"%");}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});showDialog(new AlertDialog.Builder(this).setTitle("Głośność filmu").setView(panel).setPositiveButton("Gotowe",null).create());bar.requestFocus();}
    private void restart(){showDialog(new AlertDialog.Builder(this).setTitle("Odtworzyć od początku?").setPositiveButton("Od początku",(d,w)->{seeking=false;timer.removeCallbacks(commitSeek);call("seekTo",new Class<?>[]{long.class},0L);preview.setText("");refresh();}).setNegativeButton("Wróć",null).create());}
    private void step(){int[] values={10,30,60};String[] labels={"10 sekund","30 sekund","60 sekund"};int checked=jumpSeconds==10?0:jumpSeconds==30?1:2;showDialog(new AlertDialog.Builder(this).setTitle("Długość przeskoku").setSingleChoiceItems(labels,checked,(d,n)->{jumpSeconds=values[n];getSharedPreferences("playback",MODE_PRIVATE).edit().putInt("jump_seconds",jumpSeconds).apply();stepButton.setText(jumpSeconds+" s");d.dismiss();}).setNegativeButton("Wróć",null).create());}
    private void tracks(int type){try{Class<?> builder=Class.forName("androidx.media3.ui.TrackSelectionDialogBuilder");Object instance=builder.getConstructor(Context.class,CharSequence.class,playerType,int.class).newInstance(this,type==1?"Audio":"Napisy",player,type);builder.getMethod("setAllowAdaptiveSelections",boolean.class).invoke(instance,false);Dialog dialog=(Dialog)builder.getMethod("build").invoke(instance);dialogOpen=true;dialog.setOnDismissListener(d->{dialogOpen=false;lastInput=SystemClock.elapsedRealtime();});dialog.show();}catch(Exception error){showDialog(new AlertDialog.Builder(this).setMessage("Brak dodatkowych ścieżek w tym źródle.").setPositiveButton("OK",null).create());}}
    private Object call(String method,Class<?>[] types,Object... args){try{return playerType.getMethod(method,types).invoke(player,args);}catch(Exception e){return null;}}
    private long number(String name){Object value=call(name,new Class<?>[0]);return value instanceof Number?Math.max(0,((Number)value).longValue()):0;}
    private long duration(){return number("getDuration");}
    private boolean playing(){return Boolean.TRUE.equals(call("isPlaying",new Class<?>[0]));}
    private String stamp(long milliseconds){long t=Math.max(0,milliseconds/1000);return t>=3600?String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60):String.format(Locale.ROOT,"%d:%02d",t/60,t%60);}
    private void show(boolean focusSeek){if(controls==null)return;lastInput=SystemClock.elapsedRealtime();controls.setVisibility(View.VISIBLE);titleBar.setVisibility(View.VISIBLE);if(focusSeek)timeline.requestFocus();else pause.requestFocus();refresh();}
    private void hide(){if(controls!=null){controls.setVisibility(View.GONE);titleBar.setVisibility(View.GONE);}}
    private void toggle(){if(player==null)return;call(playing()?"pause":"play",new Class<?>[0]);show(false);}
    private void jump(int direction,int repeats){long length=duration();if(length<=0){show(false);return;}if(!seeking){target=number("getCurrentPosition");seeking=true;}seekDirection=direction;long step=jumpSeconds*1000L*(repeats>=15?6:repeats>=5?3:1);target=SeekMath.clamp(target+direction*step,length);timer.removeCallbacks(commitSeek);show(true);preview.setText("Przewiń do "+stamp(target)+(direction>0?"  →":"  ←"));timeline.setProgress((int)(target*10000/Math.max(1,length)));}
    private void scheduleCommit(){if(seeking){timer.removeCallbacks(commitSeek);timer.postDelayed(commitSeek,300);}}
    private void commit(){if(!seeking||player==null)return;seeking=false;call("seekTo",new Class<?>[]{long.class},SeekMath.clamp(target,duration()));if(preview!=null)preview.setText("");lastInput=SystemClock.elapsedRealtime();refresh();}
    private void refresh(){if(controls==null||player==null)return;long length=duration(),position=seeking?target:number("getCurrentPosition");positionLabel.setText(stamp(position));durationLabel.setText(stamp(length));if(!seeking)timeline.setProgress((int)(position*10000/Math.max(1,length)));timeline.setSecondaryProgress((int)(number("getBufferedPosition")*10000/Math.max(1,length)));pause.setText(playing()?"Ⅱ":"▶");pause.setContentDescription(playing()?"Pauza":"Odtwórz");if(!dialogOpen&&!seeking&&playing()&&SystemClock.elapsedRealtime()-lastInput>5000)hide();}
    private void invokeParent(String name){try{Method m=PlayerActivity.class.getDeclaredMethod(name);m.setAccessible(true);m.invoke(this);}catch(Exception ignored){}}
    private void leave(boolean next){commit();try{Method m=PlayerActivity.class.getDeclaredMethod("leave",boolean.class);m.setAccessible(true);m.invoke(this,next);}catch(Exception ignored){finish();}}
    @Override public boolean dispatchKeyEvent(KeyEvent e){if(player==null||controls==null)return super.dispatchKeyEvent(e);int key=e.getKeyCode();boolean down=e.getAction()==KeyEvent.ACTION_DOWN;boolean up=e.getAction()==KeyEvent.ACTION_UP;lastInput=SystemClock.elapsedRealtime();
        if(key==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD||key==KeyEvent.KEYCODE_MEDIA_REWIND){if(down)jump(key==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD?1:-1,e.getRepeatCount());if(up)scheduleCommit();return true;}
        if((key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT)&&(controls.getVisibility()!=View.VISIBLE||seeking)){if(down)jump(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:-1,e.getRepeatCount());if(up)scheduleCommit();return true;}
        if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){if(controls.getVisibility()!=View.VISIBLE){if(up)toggle();return true;}if(getCurrentFocus()==timeline){if(up)toggle();return true;}return getWindow().superDispatchKeyEvent(e);}
        if((key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN)&&controls.getVisibility()!=View.VISIBLE){if(up)show(false);return true;}
        if(up&&key==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){toggle();return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_PLAY){call("play",new Class<?>[0]);show(false);return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_PAUSE){call("pause",new Class<?>[0]);show(false);return true;}
        if(up&&key==KeyEvent.KEYCODE_PROG_YELLOW){invokeParent("toggleScreenMode");return true;}if(up&&key==KeyEvent.KEYCODE_PROG_BLUE&&item.has("episode")){leave(true);return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_STOP){leave(false);return true;}
        if(key==KeyEvent.KEYCODE_BACK){if(up)onBackPressed();return true;}
        return getWindow().superDispatchKeyEvent(e);
    }
    @Override public void onBackPressed(){if(seeking){seeking=false;timer.removeCallbacks(commitSeek);if(preview!=null)preview.setText("");hide();return;}if(controls!=null&&controls.getVisibility()==View.VISIBLE&&!seeking){hide();return;}commit();super.onBackPressed();}
    @Override protected void onResume(){super.onResume();active=true;timer.removeCallbacks(tick);timer.post(tick);if(resumePlayback&&player!=null){call("play",new Class<?>[0]);resumePlayback=false;}}
    @Override protected void onStop(){resumePlayback=player!=null&&playing();commit();active=false;timer.removeCallbacks(tick);super.onStop();}
    @Override protected void onDestroy(){active=false;timer.removeCallbacksAndMessages(null);super.onDestroy();}
}
