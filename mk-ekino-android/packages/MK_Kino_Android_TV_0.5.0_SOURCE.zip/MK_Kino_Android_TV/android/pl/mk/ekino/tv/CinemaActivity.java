package pl.mk.ekino.tv;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Original MK TV interface: poster shelves, persistent navigation and focus-safe updates. */
public final class CinemaActivity extends MainActivity {
    private static final int INK=0xff0a101c, PANEL=0xe61a2c3e, ACCENT=0xff43d7d0, MUTED=0xff9db3c7;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ArrayDeque<State> history=new ArrayDeque<>();
    private final Map<String,TextView> scores=new HashMap<>();
    private final Map<String,View> cards=new LinkedHashMap<>();
    private final Map<String,HorizontalScrollView> rails=new HashMap<>();
    private final Button[] filters=new Button[4];
    private final String[] filterKeys={"genre","language","year","sort"};
    private final String[] filterNames={"Gatunek","Język","Rok","Sortowanie"};
    private JSONObject current=new JSONObject(), settings=new JSONObject(), model=new JSONObject();
    private JSONArray entries=new JSONArray();
    private LinearLayout content,side,filterBar;
    private ScrollView scroller;
    private TextView heading,heroTitle,heroMeta,heroDescription,status;
    private ImageView heroPoster;
    private ProgressBar spinner;
    private Updater updates;
    private StartupUpdates startupUpdates;
    private LinearLayout heroPanel;
    private ImageView backdrop;
    private boolean detailedHero;
    private final BannerRotation bannerRotation=new BannerRotation();
    private final List<JSONObject> featured=new ArrayList<>();
    private int featuredIndex;
    private String backdropUrl="";
    private boolean ready,busy,active,polling,board=true,firstFocus=true,ratingsPending=true;
    private int generation, selected;
    private String kind="home", layoutSignature="", focusKey="", currentShelf="";
    private Button activeNav;
    private static final class State {
        final JSONObject item;final JSONArray entries;final boolean board;final String kind,focus;
        State(JSONObject i,JSONArray e,boolean b,String k,String f){item=i;entries=e;board=b;kind=k;focus=f;}
    }
    private final Runnable tick=new Runnable(){public void run(){if(!active)return;if(startupUpdates!=null)startupUpdates.maybeOffer(!busy&&board);rotateBanner();poll();ui.postDelayed(this,1000);}};
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private StateListDrawable surface(int normal){StateListDrawable d=new StateListDrawable();d.addState(new int[]{android.R.attr.state_focused},shape(0xee20565f,ACCENT,13));d.addState(new int[]{android.R.attr.state_pressed},shape(0xff277079,ACCENT,13));d.addState(new int[]{},shape(normal,0x334e8299,13));return d;}
    private Button button(String title,Runnable action){Button b=new Button(this);b.setId(View.generateViewId());b.setText(title);b.setAllCaps(false);b.setTextSize(12);b.setSingleLine(true);b.setEllipsize(TextUtils.TruncateAt.END);b.setTextColor(Color.WHITE);b.setPadding(dp(11),0,dp(11),0);b.setBackground(surface(PANEL));b.setOnClickListener(v->action.run());return b;}
    private static JSONObject obj(Object... values){JSONObject o=new JSONObject();try{for(int i=0;i<values.length;i+=2)o.put((String)values[i],values[i+1]);}catch(Exception e){throw new IllegalArgumentException(e);}return o;}
    private static JSONObject copy(JSONObject value){try{return new JSONObject(value.toString());}catch(Exception e){return new JSONObject();}}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);updates=new Updater(this);startupUpdates=new StartupUpdates(this,updates);build();startupUpdates.check();
        AppRuntime.submit(obj("op","state"),answer->{if(isDestroyed())return;ready=answer.optBoolean("ok");settings=answer.optJSONObject("settings");if(settings==null)settings=new JSONObject();if(ready){loadFilters();openBoard("home",true);}else error(answer);});
    }
    private void build(){
        FrameLayout stage=new FrameLayout(this);stage.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff08111d,0xff102c3d,0xff102b38}));setContentView(stage);
        backdrop=new ImageView(this);backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);backdrop.setAlpha(0.28f);backdrop.setVisibility(View.GONE);stage.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xf9081422,0xc80b1a2a,0x44112d3b}));stage.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout main=new LinearLayout(this);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(24),dp(13),dp(24),dp(9));stage.addView(main,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);ImageView logo=new ImageView(this);logo.setImageDrawable(getApplicationInfo().loadIcon(getPackageManager()));top.addView(logo,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView brand=text("MK KINO",16,Color.WHITE);brand.setTypeface(null,Typeface.BOLD);brand.setPadding(dp(7),0,dp(15),0);top.addView(brand);
        side=new LinearLayout(this);side.setGravity(Gravity.CENTER);side.setPadding(dp(5),dp(3),dp(5),dp(3));side.setBackground(shape(0xb82a4558,0x8873a2b1,24));
        nav("Główna",()->openBoard("home",true));nav("Filmy",()->openBoard("movies",true));nav("Seriale",()->openBoard("series",true));nav("Szukaj",this::search);nav("Ulubione",()->openLibrary("favourites","Ulubione"));nav("Oglądaj dalej",()->openLibrary("continue","Oglądaj dalej"));nav("Opcje",this::options);
        top.addView(side,new LinearLayout.LayoutParams(0,dp(43),1));TextView version=text("0.5.0",11,MUTED);version.setPadding(dp(15),0,0,0);top.addView(version);main.addView(top,new LinearLayout.LayoutParams(-1,dp(47)));
        LinearLayout headingRow=new LinearLayout(this);headingRow.setGravity(Gravity.CENTER_VERTICAL);heading=text("Filmy",22,Color.WHITE);heading.setTypeface(null,Typeface.BOLD);headingRow.addView(heading,new LinearLayout.LayoutParams(0,dp(42),0.65f));
        filterBar=new LinearLayout(this);filterBar.setGravity(Gravity.CENTER_VERTICAL);for(int i=0;i<4;i++){final int index=i;filters[i]=button(filterNames[i],()->chooseFilter(index));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(34),1);p.setMargins(dp(6),0,0,0);filterBar.addView(filters[i],p);}headingRow.addView(filterBar,new LinearLayout.LayoutParams(0,dp(42),3.35f));main.addView(headingRow);
        heroPanel=new LinearLayout(this);heroPanel.setPadding(dp(3),dp(3),dp(5),dp(5));heroPoster=new ImageView(this);heroPoster.setScaleType(ImageView.ScaleType.FIT_CENTER);heroPoster.setVisibility(View.GONE);heroPanel.addView(heroPoster,new LinearLayout.LayoutParams(dp(126),-1));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(6),0,0,0);heroPanel.addView(words,new LinearLayout.LayoutParams(0,-1,1));heroTitle=text("Wybierz film lub serial",24,Color.WHITE);heroTitle.setTypeface(null,Typeface.BOLD);heroTitle.setMaxLines(1);heroTitle.setEllipsize(TextUtils.TruncateAt.END);words.addView(heroTitle);heroMeta=text("",12,ACCENT);heroMeta.setMaxLines(2);heroMeta.setPadding(0,dp(5),0,dp(6));words.addView(heroMeta);heroDescription=text("",14,0xffd1dce7);heroDescription.setMaxLines(6);heroDescription.setEllipsize(TextUtils.TruncateAt.END);heroDescription.setVisibility(View.GONE);words.addView(heroDescription);main.addView(heroPanel,new LinearLayout.LayoutParams(-1,dp(67)));
        scroller=new ScrollView(this);scroller.setClipToPadding(false);scroller.setVerticalScrollBarEnabled(false);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(9),0,dp(18));scroller.addView(content,new ScrollView.LayoutParams(-1,-2));main.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER_VERTICAL);spinner=new ProgressBar(this);spinner.setVisibility(View.GONE);footer.addView(spinner,new LinearLayout.LayoutParams(dp(17),dp(17)));status=text("OK: otwórz   ·   Przytrzymaj OK: ulubione   ·   Wstecz: wróć",11,MUTED);status.setPadding(dp(7),0,0,0);footer.addView(status);main.addView(footer,new LinearLayout.LayoutParams(-1,dp(24)));
    }
    private void nav(String label,Runnable action){Button b=button(label,()->{if(!ready||busy)return;action.run();});b.setId(View.generateViewId());b.setPadding(dp(8),0,dp(8),0);b.setTextSize(11);b.setOnFocusChangeListener((v,has)->{if(has)activeNav=b;});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(35),1);p.setMargins(dp(2),0,dp(2),0);side.addView(b,p);if(activeNav==null)activeNav=b;}
    private void heroMode(boolean details){detailedHero=details;bannerRotation.reset();heroPanel.setFocusable(false);heroPanel.setClickable(false);heroPanel.setBackground(null);heroTitle.setTextSize(24);heroDescription.setMaxLines(6);heroPoster.setVisibility(details?View.VISIBLE:View.GONE);heroDescription.setVisibility(details?View.VISIBLE:View.GONE);backdrop.setVisibility(details?View.VISIBLE:View.GONE);ViewGroup.LayoutParams p=heroPanel.getLayoutParams();p.height=dp(details?214:67);heroPanel.setLayoutParams(p);}
    private void homeHero(){
        detailedHero=true;heroPoster.setVisibility(View.GONE);heroDescription.setVisibility(View.VISIBLE);backdrop.setVisibility(View.VISIBLE);heroTitle.setTextSize(32);heroDescription.setMaxLines(3);
        ViewGroup.LayoutParams p=heroPanel.getLayoutParams();p.height=dp(175);heroPanel.setLayoutParams(p);heroPanel.setFocusable(true);heroPanel.setClickable(true);heroPanel.setBackground(surface(0x00102030));
        heroPanel.setOnClickListener(v->{if(!featured.isEmpty())select(featured.get(featuredIndex));});
        heroPanel.setOnKeyListener((v,key,event)->{if(key!=KeyEvent.KEYCODE_DPAD_LEFT&&key!=KeyEvent.KEYCODE_DPAD_RIGHT)return false;if(event.getAction()==KeyEvent.ACTION_UP&&!featured.isEmpty()){featuredIndex=(featuredIndex+(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:featured.size()-1))%featured.size();showDetail(featured.get(featuredIndex));bannerRotation.reset();}return true;});
        heroPanel.setOnFocusChangeListener((v,has)->{bannerRotation.reset();if(has&&!featured.isEmpty())showDetail(featured.get(featuredIndex));});
    }
    private boolean bannerFocus(){View v=getCurrentFocus();return v==heroPanel||(v!=null&&isInside(v,side));}
    private void refreshFeatured(JSONArray groups){
        String old=featured.isEmpty()?"":featured.get(featuredIndex).optString("url");featured.clear();Set<String> seen=new HashSet<>();
        // Interleave the newest film and series entries from both catalogues.
        for(int index=0;index<4;index++)for(int row=0;row<groups.length();row++){JSONArray items=groups.optJSONObject(row).optJSONArray("items");JSONObject item=items==null?null:items.optJSONObject(index);if(item!=null&&seen.add(item.optString("url")))featured.add(item);}
        featuredIndex=0;for(int i=0;i<featured.size();i++)if(featured.get(i).optString("url").equals(old)){featuredIndex=i;break;}
        if(!featured.isEmpty()&&bannerFocus())showDetail(featured.get(featuredIndex));
    }
    private void rotateBanner(){
        boolean allowed=active&&ready&&!busy&&board&&kind.equals("home")&&hasWindowFocus()&&bannerFocus();
        if(bannerRotation.advance(SystemClock.elapsedRealtime(),allowed,featured.size())){featuredIndex=(featuredIndex+1)%featured.size();showDetail(featured.get(featuredIndex));}
    }
    private void setBusy(boolean value,String label){busy=value;spinner.setVisibility(value?View.VISIBLE:View.GONE);status.setText(label.isEmpty()?"OK: otwórz   ·   Przytrzymaj OK: ulubione   ·   Wstecz: wróć":label);}
    private void request(JSONObject query,String label,AppRuntime.Callback callback){if(!ready)return;final int token=++generation;setBusy(true,label);AppRuntime.submit(query,result->{if(isDestroyed()||token!=generation)return;setBusy(false,"");if(!result.optBoolean("ok")){error(result);return;}callback.done(result);});}
    private void openBoard(String value,boolean clear){if(!ready||busy)return;if(clear)history.clear();kind=value;board=true;heroMode(false);featured.clear();featuredIndex=0;if(kind.equals("home"))homeHero();current=obj("action","tv_board","kind",kind);heading.setText(kind.equals("home")?"Ostatnio dodane":kind.equals("series")?"Seriale":"Filmy");filterBar.setVisibility(kind.equals("movies")?View.VISIBLE:View.GONE);layoutSignature="";model=new JSONObject();focusKey="";firstFocus=!kind.equals("home");content.removeAllViews();if(kind.equals("home"))side.getChildAt(0).requestFocus();
        request(obj("op","shelves_start","kind",kind),"Pobieranie katalogu…",answer->{model=answer;renderBoard();});}
    private void openLibrary(String action,String label){history.clear();load(obj("action",action,"title",label),false);}
    private void push(){history.push(new State(copy(current),entries,board,kind,focusKey));}
    private void load(JSONObject item,boolean addHistory){if(!ready||busy)return;if(addHistory)push();board=false;ratingsPending=true;AppRuntime.submit(obj("op","shelves_cancel"),null);current=copy(item);heroMode(Arrays.asList("sources","seasons","episodes").contains(item.optString("action")));filterBar.setVisibility(View.GONE);heading.setText(item.optString("title","Katalog"));
        request(obj("op","browse","item",item),"Pobieranie…",answer->{entries=answer.optJSONArray("items");if(entries==null)entries=new JSONArray();selected=0;focusKey="";renderEntries();});}
    private String cardKey(String row,JSONObject item,int index){return row+"|"+item.optString("url",item.optString("action"))+"|"+index;}
    private void showDetail(JSONObject entry){heroTitle.setText(entry.optString("movie_title",entry.optString("title","")));String info=entry.optString("rating_label");for(String k:new String[]{"year","language_version","progress_label"})if(!entry.optString(k).isEmpty())info+=(info.isEmpty()?"":"  ·  ")+entry.optString(k);heroMeta.setText(info);heroDescription.setText(entry.optString("synopsis",entry.optString("desc","")));if(detailedHero){Images.load(heroPoster,entry.optString("icon"));String image=entry.optString("backdrop").isEmpty()?entry.optString("icon"):entry.optString("backdrop");if(!image.equals(backdropUrl)){backdropUrl=image;Images.load(backdrop,image);}}}
    private boolean hasPoster(JSONArray items){for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);if(x!=null&&!x.optString("icon").isEmpty())return true;}return false;}
    private void clearViews(){scores.clear();cards.clear();rails.clear();content.removeAllViews();}
    private void renderBoard(){JSONArray groups=model.optJSONArray("shelves");if(groups==null)return;// Rating text changes are applied in place; they do not rebuild poster views.
        if(kind.equals("home"))refreshFeatured(groups);String nextSignature=structuralSignature(groups);if(nextSignature.equals(layoutSignature)){updateBoardScores(groups);return;}layoutSignature=nextSignature;
        String restore=focusKey;View focused=getCurrentFocus();boolean sideFocus=focused!=null&&isInside(focused,side);Map<String,Integer> positions=new HashMap<>();for(Map.Entry<String,HorizontalScrollView> e:rails.entrySet())positions.put(e.getKey(),e.getValue().getScrollX());int top=scroller.getScrollY();clearViews();
        for(int i=0;i<groups.length();i++){JSONObject group=groups.optJSONObject(i);if(group==null)continue;JSONArray items=group.optJSONArray("items");if(items==null)items=new JSONArray();if(kind.equals("home"))addShelf(group.optString("id"),group.optString("title"),items,group.optJSONObject("next"),group.optBoolean("loading"),group.optBoolean("error"),true);else addGrid(group.optString("id"),items,group.optJSONObject("next"),group.optBoolean("loading"),group.optBoolean("error"),true);}
        for(Map.Entry<String,Integer> e:positions.entrySet()){HorizontalScrollView rail=rails.get(e.getKey());if(rail!=null)rail.post(()->rail.scrollTo(e.getValue(),0));}scroller.post(()->scroller.scrollTo(0,top));
        if(cards.containsKey(restore)&&!sideFocus)cards.get(restore).requestFocus();else if(firstFocus&&!cards.isEmpty()){View first=cards.values().iterator().next();first.requestFocus();firstFocus=false;}else if(sideFocus&&activeNav!=null)activeNav.requestFocus();
        boolean loading=false;for(int i=0;i<groups.length();i++)loading|=groups.optJSONObject(i).optBoolean("loading");spinner.setVisibility(loading?View.VISIBLE:View.GONE);
    }
    private static boolean isInside(View view,ViewGroup parent){for(android.view.ViewParent p=view.getParent();p!=null;p=p.getParent())if(p==parent)return true;return false;}
    private String structuralSignature(JSONArray groups){StringBuilder b=new StringBuilder();for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);b.append(s.optString("id")).append(s.optBoolean("loading")).append(s.optBoolean("error"));JSONArray xs=s.optJSONArray("items");if(xs!=null)for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);b.append(x.optString("url")).append(x.optString("title")).append(x.optBoolean("watched"));}b.append(s.has("next")&&!s.isNull("next"));}return b.toString();}
    private void updateBoardScores(JSONArray groups){for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);JSONArray xs=s.optJSONArray("items");if(xs==null)continue;for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);String k=cardKey(s.optString("id"),x,j);TextView score=scores.get(k);if(score!=null)score.setText("compact".equals(score.getTag())?compactScore(x):x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey)&&(!board||!kind.equals("home")||!bannerFocus()))showDetail(x);}}}
    private void renderEntries(){clearViews();if(entries.length()==0){TextView empty=text("Brak pozycji. Wróć lub zmień filtr.",18,MUTED);empty.setPadding(dp(12),dp(24),0,0);content.addView(empty);return;}
        boolean posters=hasPoster(entries)&&!current.optString("action").equals("sources");if(posters){addGrid("entries",entries,null,false,false,false);View restore=cards.get(focusKey);if(restore!=null)restore.requestFocus();else if(!cards.isEmpty())cards.values().iterator().next().requestFocus();}
        else for(int i=0;i<entries.length();i++){final int index=i;JSONObject entry=entries.optJSONObject(i);if(entry==null)continue;Button b=button(entry.optString("title"),()->select(entry));b.setTextSize(16);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setOnFocusChangeListener((v,has)->{if(has){selected=index;showDetail(entry);}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,0,0,dp(8));content.addView(b,p);if(i==selected)b.requestFocus();}}
    private String compactScore(JSONObject item){if(item.has("rating"))return "Filmweb ★ "+String.format(Locale.ROOT,"%.1f",item.optDouble("rating")).replace('.',',');return item.optString("rating_label").contains("sprawdzanie")?"Filmweb …":"";}
    private void addGrid(String id,JSONArray items,JSONObject next,boolean loading,boolean failed,boolean remote){
        if(items.length()==0){Button retry=button(loading?"Ładowanie katalogu…":failed?"Spróbuj ponownie":"Brak pozycji",()->more(id));retry.setEnabled(!loading&&failed);content.addView(retry,new LinearLayout.LayoutParams(-1,dp(75)));return;}
        GridLayout grid=new GridLayout(this);grid.setColumnCount(5);grid.setClipChildren(false);grid.setClipToPadding(false);grid.setPadding(dp(3),dp(4),dp(3),dp(6));content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        List<View> cells=new ArrayList<>();int screen=(int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density);int posterHeight=Math.max(150,Math.min(270,(int)(((screen-48)/5f-23)*1.48f)));
        for(int i=0;i<items.length();i++){final int index=i;JSONObject item=items.optJSONObject(i);if(item==null)continue;String key=cardKey(id,item,i);LinearLayout card=new LinearLayout(this);card.setTag(item);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(5),dp(5),dp(5),dp(8));card.setFocusable(true);card.setClickable(true);card.setBackground(surface(0x52203447));card.setId(View.generateViewId());
            FrameLayout artwork=new FrameLayout(this);artwork.setBackground(shape(0xff172a3b,0,12));artwork.setClipToOutline(true);ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);artwork.addView(poster,new FrameLayout.LayoutParams(-1,-1));Images.load(poster,item.optString("icon"));
            if(!item.optString("year").isEmpty()){TextView year=text(item.optString("year"),10,Color.WHITE);year.setTypeface(null,Typeface.BOLD);year.setPadding(dp(7),dp(3),dp(7),dp(3));year.setBackground(shape(0xb5203548,0x887f9da9,14));FrameLayout.LayoutParams yp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);yp.setMargins(dp(6),dp(6),0,0);artwork.addView(year,yp);}card.addView(artwork,new LinearLayout.LayoutParams(-1,dp(posterHeight)));
            LinearLayout details=new LinearLayout(this);details.setPadding(dp(3),dp(6),dp(2),0);TextView type=text(item.optString("action").equals("seasons")?"Serial":"Film",10,MUTED);details.addView(type,new LinearLayout.LayoutParams(0,-2,1));TextView rating=text(compactScore(item),10,ACCENT);rating.setTag("compact");rating.setSingleLine();rating.setEllipsize(TextUtils.TruncateAt.END);details.addView(rating);card.addView(details);scores.put(key,rating);
            TextView title=text((item.optBoolean("watched")?"✓ ":"")+item.optString("title"),13,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setMaxLines(2);title.setMinHeight(dp(36));title.setEllipsize(TextUtils.TruncateAt.END);title.setPadding(dp(3),dp(3),dp(3),0);card.addView(title);TextView language=text(item.optString("language_version"),11,0xffb9cfdd);language.setMaxLines(1);language.setPadding(dp(3),dp(3),0,0);card.addView(language);
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(i/5),GridLayout.spec(i%5,1f));gp.width=0;gp.height=-2;gp.setMargins(0,0,dp(10),dp(15));grid.addView(card,gp);cards.put(key,card);cells.add(card);
            card.setOnFocusChangeListener((v,has)->{card.animate().scaleX(has?1.035f:1).scaleY(has?1.035f:1).setDuration(120).start();card.setElevation(has?dp(12):0);if(has){focusKey=key;currentShelf=id;selected=index;showDetail((JSONObject)card.getTag());if(remote&&next!=null&&!loading&&index>=items.length()-5)more(id);}});card.setOnClickListener(v->select((JSONObject)card.getTag()));card.setOnLongClickListener(v->{favourite((JSONObject)card.getTag());return true;});
        }
        for(int i=0;i<cells.size();i++){View cell=cells.get(i);cell.setNextFocusLeftId((i%5>0?cells.get(i-1):cell).getId());cell.setNextFocusRightId((i%5<4&&i+1<cells.size()?cells.get(i+1):cell).getId());cell.setNextFocusUpId(i>=5?cells.get(i-5).getId():(filterBar.getVisibility()==View.VISIBLE?filters[Math.min(i,3)].getId():activeNav.getId()));if(i+5<cells.size())cell.setNextFocusDownId(cells.get(i+5).getId());else if(i/5<(cells.size()-1)/5)cell.setNextFocusDownId(cells.get(cells.size()-1).getId());}
        if(next!=null||loading||failed){Button more=button(loading?"Pobieranie kolejnych pozycji…":failed?"Ponów pobieranie":"Pokaż więcej",()->{if(remote)more(id);else select(next);});more.setEnabled(!loading);content.addView(more,new LinearLayout.LayoutParams(-1,dp(42)));}
    }
    private void addShelf(String id,String label,JSONArray items,JSONObject next,boolean loading,boolean failed,boolean remote){TextView title=text(label,17,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(3),dp(8),0,dp(9));content.addView(title);
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);scroll.setClipToPadding(false);scroll.setPadding(dp(3),dp(3),dp(6),dp(6));LinearLayout row=new LinearLayout(this);row.setPadding(0,dp(3),dp(4),dp(4));scroll.addView(row,new HorizontalScrollView.LayoutParams(-2,-2));rails.put(id,scroll);content.addView(scroll,new LinearLayout.LayoutParams(-1,-2));
        if(items.length()==0){Button retry=button(loading?"Ładowanie…":failed?"Spróbuj ponownie":"Brak pozycji",()->more(id));retry.setEnabled(!loading&&failed);row.addView(retry,new LinearLayout.LayoutParams(dp(200),dp(92)));return;}
        for(int i=0;i<items.length();i++){final int index=i;JSONObject item=items.optJSONObject(i);if(item==null)continue;String key=cardKey(id,item,i);LinearLayout card=new LinearLayout(this);card.setTag(item);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(6),dp(6),dp(6),dp(8));card.setFocusable(true);card.setClickable(true);card.setBackground(surface(0x90203447));card.setId(View.generateViewId());
            ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackground(shape(0xff172a3b,0,8));card.addView(poster,new LinearLayout.LayoutParams(-1,dp(174)));Images.load(poster,item.optString("icon"));
            TextView name=text((item.optBoolean("watched")?"✓ ":"")+item.optString("title"),13,Color.WHITE);name.setTypeface(null,Typeface.BOLD);name.setMaxLines(2);name.setMinHeight(dp(36));name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(dp(3),dp(6),dp(3),0);card.addView(name,new LinearLayout.LayoutParams(-1,-2));TextView score=text(item.optString("rating_label"),10,ACCENT);score.setMaxLines(1);score.setEllipsize(TextUtils.TruncateAt.END);score.setPadding(dp(3),dp(3),0,0);card.addView(score);scores.put(key,score);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(130),-2);p.setMargins(0,0,dp(11),0);row.addView(card,p);cards.put(key,card);
            card.setOnFocusChangeListener((v,has)->{card.animate().scaleX(has?1.035f:1).scaleY(has?1.035f:1).setDuration(110).start();if(has){focusKey=key;currentShelf=id;selected=index;showDetail((JSONObject)card.getTag());scroll.post(()->scroll.smoothScrollTo(Math.max(0,card.getLeft()-dp(12)),0));}});
            card.setOnClickListener(v->select((JSONObject)card.getTag()));card.setOnLongClickListener(v->{favourite((JSONObject)card.getTag());return true;});
            if(i==0&&activeNav!=null)card.setNextFocusLeftId(activeNav.getId());
        }
        if(next!=null||loading||failed){Button more=button(loading?"Pobieranie…":failed?"Ponów":"Więcej  →",()->{if(remote)more(id);else select(next);});more.setEnabled(!loading);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(125),dp(174));p.setMargins(0,dp(6),0,0);row.addView(more,p);}
    }
    private void more(String shelf){if(busy||!board)return;final int token=generation;AppRuntime.submit(obj("op","shelves_more","shelf",shelf),r->{if(isDestroyed()||!board||token!=generation)return;model=r;renderBoard();});}
    private void poll(){if(!ready||busy||polling)return;if(board&&model.has("shelves")&&!model.optBoolean("pending",true))return;if(!board&&!ratingsPending)return;polling=true;final int token=generation;final boolean wasBoard=board;JSONObject query=board?obj("op","shelves_poll"):obj("op","filmweb_ratings","items",entries);
        AppRuntime.submit(query,r->{polling=false;if(!active||isDestroyed()||token!=generation||wasBoard!=board||!r.optBoolean("ok"))return;if(board){model=r;renderBoard();}else{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()!=entries.length())return;ratingsPending=r.optBoolean("pending");entries=xs;for(int i=0;i<xs.length();i++){JSONObject x=xs.optJSONObject(i);String k=cardKey("entries",x,i);TextView score=scores.get(k);if(score!=null)score.setText("compact".equals(score.getTag())?compactScore(x):x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey)&&(!board||!kind.equals("home")||!bannerFocus()))showDetail(x);}}});}
    private void select(JSONObject item){if(item==null||busy)return;String action=item.optString("action");if(action.equals("search")){search();return;}if(action.equals("resolve")){resolve(item);return;}load(item,true);}
    private void favourite(JSONObject item){if(busy||item==null)return;String action=item.optString("action");if(!Arrays.asList("sources","seasons","resolve").contains(action))return;request(obj("op","favourite","item",item),"Zapisywanie…",r->{Toast.makeText(this,r.optBoolean("added")?"Dodano do ulubionych":"Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(current.optString("action").equals("favourites"))load(current,false);});}
    private JSONObject selectedItem(){View view=cards.get(focusKey);if(view!=null&&view.getTag() instanceof JSONObject)return (JSONObject)view.getTag();JSONObject row=entries.optJSONObject(selected);return row==null?new JSONObject():row;}
    private void loadFilters(){AppRuntime.submit(obj("op","movie_filter_state"),r->{JSONObject labels=r.optJSONObject("filter_labels");if(labels!=null)for(int i=0;i<4;i++)filters[i].setText(filterNames[i]+": "+labels.optString(filterKeys[i]));});}
    private void chooseFilter(int index){if(busy||!board||!kind.equals("movies"))return;request(obj("op","movie_filter_options","filter",filterKeys[index]),"Otwieranie filtra…",r->{JSONArray xs=r.optJSONArray("choices");if(xs==null)return;String[] labels=new String[xs.length()];for(int i=0;i<labels.length;i++)labels[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle(filterNames[index]).setItems(labels,(dialog,n)->request(obj("op","movie_filter_set","filter",filterKeys[index],"value",xs.optJSONObject(n).optString("id")),"Zapisywanie…",answer->{loadFilters();openBoard("movies",true);})).setNegativeButton("Wróć",null).show();});}
    private void search(){if(busy)return;EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Tytuł filmu lub serialu");AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Szukaj w filmach i serialach").setView(input).setPositiveButton("Szukaj",(d,w)->{String term=input.getText().toString().trim();if(!term.isEmpty())load(obj("action","search_results","query",term,"title","Szukaj: "+term),true);}).setNegativeButton("Wróć",null).create();dialog.setOnShowListener(d->{input.requestFocus();dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});dialog.show();}
    private void options(){if(busy)return;String[] labels={"Dodaj / usuń z ulubionych","Odśwież katalog","Jakość: "+(settings.optBoolean("auto_play",true)?"automatyczna":"wybór ręczny"),"Sprawdź aktualizację","Aktualizacje przy starcie: "+(startupUpdates.enabled()?"włączone":"wyłączone"),"Autor i kontakt"};new AlertDialog.Builder(this).setTitle("Ustawienia MK Kino").setItems(labels,(d,n)->{if(n==0)favourite(selectedItem());if(n==1){if(board){AppRuntime.submit(obj("op","shelves_invalidate"),null);openBoard(kind,true);}else load(current,false);}if(n==2)request(obj("op","settings","key","auto_play","value",!settings.optBoolean("auto_play",true)),"Zapisywanie…",r->settings=r.optJSONObject("settings"));if(n==3)updates.check();if(n==4){startupUpdates.toggle();Toast.makeText(this,startupUpdates.enabled()?"Sprawdzanie przy starcie włączone":"Sprawdzanie przy starcie wyłączone",Toast.LENGTH_SHORT).show();}if(n==5)new AlertDialog.Builder(this).setTitle("MK Kino 0.5.0").setMessage("Projekt i rozwój: MK\nKontakt: bimer535@wp.pl\nGPL-3.0").setPositiveButton("OK",null).show();}).show();}
    private void resolve(JSONObject item){request(obj("op","resolve","item",item),"Pobieranie źródła… Wstecz: anuluj",r->{JSONArray xs=r.optJSONArray("variants");if(xs==null||xs.length()==0){error(obj("message","Brak dostępnego wariantu. Wybierz inne źródło."));return;}if(settings.optBoolean("auto_play",true)){play(item,r.optInt("preferred",0));return;}String[] names=new String[xs.length()];for(int i=0;i<names.length;i++)names[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle("Jakość filmu").setItems(names,(d,n)->play(item,n)).setNegativeButton("Wróć",null).show();});}
    private void play(JSONObject item,int index){request(obj("op","play","item",item,"index",index),"Uruchamianie…",r->{JSONObject progress=r.optJSONObject("progress");long position=progress==null?0:progress.optLong("position");if(position>=15&&!progress.optBoolean("completed"))new AlertDialog.Builder(this).setTitle("Kontynuować oglądanie?").setMessage("Wznowić od "+stamp(position)+"?").setPositiveButton("Wznów",(d,w)->launch(item,r,position)).setNegativeButton("Od początku",(d,w)->launch(item,r,0)).show();else launch(item,r,0);});}
    private void launch(JSONObject item,JSONObject stream,long position){Intent intent=new Intent(this,CinemaPlayerActivity.class);intent.putExtra("entry",item.toString());intent.putExtra("stream",stream.toString());intent.putExtra("position",position);startActivityForResult(intent,200);}
    private String stamp(long t){return String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60);}
    private void error(JSONObject answer){new AlertDialog.Builder(this).setTitle("Nie udało się otworzyć").setMessage(answer.optString("message","Spróbuj ponownie później.")).setPositiveButton("OK",null).show();}
    @Override public void onBackPressed(){if(busy){try{Class.forName("pl.mk.ekino.tv.Pow").getDeclaredMethod("cancel").invoke(null);}catch(Exception ignored){}generation++;setBusy(false,"");return;}if(!history.isEmpty()){State old=history.pop();if(old.board){String target=old.focus;openBoard(old.kind,false);focusKey=target;firstFocus=false;}else{board=false;current=old.item;entries=old.entries;kind=old.kind;focusKey=old.focus;heroMode(Arrays.asList("sources","seasons","episodes").contains(current.optString("action")));heading.setText(current.optString("title"));filterBar.setVisibility(View.GONE);renderEntries();}}else if(!board)openBoard("movies",true);else new AlertDialog.Builder(this).setTitle("Zamknąć MK Kino?").setPositiveButton("Wyjdź",(d,w)->finish()).setNegativeButton("Zostań",null).show();}
    @Override public boolean dispatchKeyEvent(KeyEvent event){if(event.getAction()==KeyEvent.ACTION_UP){if(event.getKeyCode()==KeyEvent.KEYCODE_MENU){options();return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_YELLOW){if(board&&kind.equals("movies"))chooseFilter(0);return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_BLUE){if(!busy)updates.check();return true;}}return super.dispatchKeyEvent(event);}
    @Override protected void onActivityResult(int code,int result,Intent data){if(code==210){updates.installPending();return;}if(code!=200){super.onActivityResult(code,result,data);return;}AppRuntime.submit(obj("op","stop"),null);if(data!=null&&data.getBooleanExtra("next",false)){try{JSONObject item=new JSONObject(data.getStringExtra("entry"));item.put("action","next_episode");request(obj("op","browse","item",item),"Następny odcinek…",r->{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()==0){Toast.makeText(this,"Brak następnego odcinka",Toast.LENGTH_SHORT).show();return;}load(xs.optJSONObject(0),true);});}catch(Exception ignored){}}else if(current.optString("action").equals("continue"))load(current,false);}
    @Override protected void onResume(){super.onResume();active=true;ui.removeCallbacks(tick);ui.postDelayed(tick,600);}
    @Override protected void onPause(){active=false;bannerRotation.reset();ui.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){active=false;ui.removeCallbacksAndMessages(null);if(startupUpdates!=null)startupUpdates.close();super.onDestroy();}
}
