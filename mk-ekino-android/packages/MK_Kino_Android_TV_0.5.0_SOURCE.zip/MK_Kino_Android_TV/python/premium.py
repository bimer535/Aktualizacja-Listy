# SPDX-License-Identifier: GPL-3.0-only
"""Premium Smart public catalogue and native Media3 descriptors."""
import base64
from html.parser import HTMLParser
import json
import re
from urllib.parse import quote, urlencode, urljoin, urlsplit

import access_cache
import catalogue
import resolver
from other_sources import OtherSources
from source_adapter import source_options as ekino_options

BASE = 'https://premiumsmart.eu/'
API = BASE + 'api/v1/'
TITLE_PATH = r'titles/[1-9][0-9]{0,11}'
EPISODE_PATH = TITLE_PATH + r'/seasons/[0-9]{1,4}/episodes/[0-9]{1,5}'
ITEM_URL = re.compile(re.escape(API) + r'(?:' + TITLE_PATH + '|' + EPISODE_PATH + r')\Z')
API_URL = re.compile(re.escape(API) + r'(?:channel/(?:filmy|seriale)|search/[^/?#]+|' +
                     TITLE_PATH + r'(?:/seasons(?:/[0-9]{1,4}/episodes(?:/[0-9]{1,5})?)?)?)\Z')
BYSE_HOST = re.compile(r'(?:mfw09\.org|mvw09\.org|n1mwq\.org|byse\.sx|byse[a-z0-9-]*\.(?:com|net|org)|streamlyplayero?\.online|boosteradx\.online)\Z')
BYSE_WRAPPERS = {'streamlyplayer.online', 'streamlyplayero.online', 'boosteradx.online', 'byse.sx'}
BYSE_VIDEO = re.compile(r'/(?:e|d|download)/[A-Za-z0-9]+(?:/|$)')


def public_url(value, base):
    if not isinstance(value, str) or not value.strip():
        return ''
    try:
        url = urljoin(base, value.strip())
        if any(ord(char) < 32 for char in url):
            return ''
        return resolver.checked_url(url)
    except (ValueError, resolver.ResolveError):
        return ''


def _api(client, path, query=None):
    url = API + path
    if not API_URL.fullmatch(url):
        raise ValueError('invalid_catalogue_address')
    address = url + ('?' + urlencode(query) if query else '')
    params = {'header': {'Accept': 'application/json', 'Referer': BASE}, 'timeout': 8}
    for attempt in range(2):
        ok, body = client.getPage(address, params)
        final = client.meta.get('url', address).split('?', 1)[0]
        if final != url:
            raise ValueError('premium_catalogue_unavailable')
        if ok:
            try:
                data = json.loads(body)
            except ValueError:
                data = None
            if isinstance(data, dict):
                return data
        status = client.meta.get('status_code')
        if attempt or (not ok and status != 401):
            break
        client.getPage(BASE, {'timeout': 8})
    raise ValueError('premium_catalogue_unavailable')


def _text(value):
    return catalogue.clean(str(value or ''))


def _poster(value):
    url = public_url(value, BASE)
    return url.replace('/original/', '/w500/', 1) if url.startswith('https://image.tmdb.org/t/p/original/') else url


def _entry(value):
    if not isinstance(value, dict):
        return None
    identifier = str(value.get('id', ''))
    title = _text(value.get('name'))
    if not title or not re.fullmatch(r'[1-9][0-9]{0,11}', identifier):
        return None
    year = str(value.get('year') or value.get('release_date') or '')[:4]
    video = value.get('primary_video')
    language = _text(video.get('language_type')) if isinstance(video, dict) else ''
    synopsis = _text(value.get('description'))
    item = catalogue.item(title, 'seasons' if value.get('is_series') else 'sources',
                          url=API + 'titles/' + identifier, icon=_poster(value.get('poster')),
                          series_title=title, year=year, language_version=language,
                          synopsis=synopsis, backdrop=public_url(value.get('backdrop'), BASE), desc=' · '.join(filter(None, (year, language))) + '\n' + synopsis)
    return item


def normal(value):
    return ' '.join(re.findall(r'[^\W_]+', str(value).casefold(), flags=re.UNICODE))


def language_kind(value):
    value = normal(value)
    if value in {'pl', 'polski', 'film polski', 'film pl', 'wersja pl', 'polski film'}:
        return 'pl'
    return value.removesuffix(' pl')


def _matches(value, current):
    year = str(current.get('year') or '')
    if year and value['year'] != year:
        return False
    version = language_kind(current.get('version_label', ''))
    lang = language_kind(value['language_version'])
    if version and lang and (lang != 'pl' if version == 'pl' else not lang.startswith(version)):
        return False
    # eKino names are carried through its filter wizard, including the kids preset.
    categories = current.get('category_labels') or []
    genres = value.get('genres') or []
    names = {normal(g.get('display_name') or g.get('name') or '') if isinstance(g, dict) else normal(g)
             for g in genres}
    return not categories or bool(names.intersection(normal(g) for g in categories))


def channel(client, current, page, series=False):
    if not page:
        return [], None
    result = []
    visited = set()
    filtered = bool(current.get('version_label') or current.get('category_labels'))
    for _ in range(3 if filtered else 1):
        if isinstance(page, str) and re.fullmatch(r'[0-9]{1,5}', page):
            page = int(page)
        if type(page) is not int or not 1 <= page <= 10000 or page in visited:
            return result, None
        visited.add(page)
        query = {'perPage': 60 if filtered else 20, 'order': 'created_at:desc', 'page': page}
        year = str(current.get('year') or '')
        if re.fullmatch(r'[0-9]{4}', year):
            dates = {'start': year + '-01-01T00:00:00.000Z', 'end': year + '-12-31T23:59:59.999Z'}
            rule = [{'key': 'release_date', 'operator': 'between', 'value': dates}]
            encoded = base64.b64encode(json.dumps(rule, separators=(',', ':')).encode()).decode()
            query['filters'] = quote(encoded, safe='')
        data = _api(client, 'channel/seriale' if series else 'channel/filmy', query)
        content = (data.get('channel') or {}).get('content') or {}
        for value in content.get('data') or []:
            item = _entry(value)
            if item and (item['action'] == 'seasons') == series and _matches(dict(item, genres=value.get('genres')), current):
                result.append(item)
        page = content.get('next_page')
        if not filtered or not page or len(result) >= 12:
            break
    return result, page


def search(client, term):
    data = _api(client, 'search/' + quote(term, safe=''), {'limit': 50})
    return [item for value in data.get('results') or []
            if isinstance(value, dict) and value.get('model_type', 'title') == 'title'
            and (item := _entry(value))]


def _pages(client, path):
    page = 1
    for _ in range(25):
        data = _api(client, path, {'perPage': 60, 'page': page})
        pagination = data.get('pagination') or {}
        yield from (v for v in pagination.get('data') or [] if isinstance(v, dict))
        following = pagination.get('next_page')
        if isinstance(following, str) and re.fullmatch(r'[0-9]{1,5}', following):
            following = int(following)
        if type(following) is not int or following <= page:
            break
        page = following


def seasons(client, current):
    url = current['url']
    rows = _pages(client, url[len(API):] + '/seasons')
    numbers = sorted({int(s['number']) for s in rows if str(s.get('number')).isdigit()
                      and s.get('available_episodes_count', 1)})
    return [dict(current, title='Sezon ' + str(number), action='episodes', season=str(number),
                 series_url=url) for number in numbers]


def episodes(client, current):
    season = int(current['season'])
    url = current['series_url']
    path = url[len(API):] + '/seasons/' + str(season) + '/episodes'
    rows = _pages(client, path)
    result = []
    for row in rows:
        number = row.get('episode_number')
        if not str(number).isdigit() or row.get('has_sources') is False:
            continue
        number = int(number)
        title = 'S%02dE%02d' % (season, number)
        if row.get('name'):
            title += ' — ' + _text(row['name'])
        result.append(dict(current, title=title, action='sources', episode=number,
                           url=API + path + '/' + str(number),
                           icon=_poster(row.get('poster')) or current.get('icon', ''),
                           synopsis=_text(row.get('description'))))
    return sorted(result, key=lambda item: item['episode'])


def next_episode(client, current):
    current_number = (int(current['season']), int(current['episode']))
    for season in seasons(client, dict(current, url=current['series_url'])):
        if int(season['season']) < current_number[0]:
            continue
        for item in episodes(client, season):
            if (int(item['season']), item['episode']) > current_number:
                return [item]
    return []


def _videos(client, url):
    if not ITEM_URL.fullmatch(url):
        raise ValueError('invalid_catalogue_address')
    data = _api(client, url[len(API):])
    item = data.get('episode') or data.get('title') or {}
    return item.get('videos') or []


def _provider(video):
    name = _text(video.get('name')).casefold()
    source = public_url(video.get('src'), BASE)
    host = urlsplit(source).hostname or ''
    if not source or 'upzone' in name or 'upzone' in host:
        return '', ''
    if BYSE_HOST.fullmatch(host):
        return 'byse', source
    if re.fullmatch(r'(?:[a-z0-9-]+\.)?vidara\.[a-z]+', host):
        return 'vidara', source
    if host == 'flyfile.app':
        return 'flyfile', source
    if host == 'vids.st':
        return 'vidsst', source
    if 'voe' in name or host == 'voe.sx':
        return 'voe', source
    if 'mix' in name or 'mixdrop' in host or 'mxdrop' in host:
        return 'mix', source
    if 'streamtape' in host:
        return 'streamtape', source
    if re.search(r'\.(m3u8|mp4)$', urlsplit(source).path, re.I):
        return 'direct', source
    return '', ''


def source_rows(client, current, url):
    rows = []
    seen = set()
    for index, video in enumerate(_videos(client, url)):
        if not isinstance(video, dict) or video.get('category') not in (None, '', 'full'):
            continue
        provider, source = _provider(video)
        if not provider or source in seen:
            continue
        seen.add(source)
        label = ' · '.join(filter(None, (_text(video.get('name')) or provider,
                                         _text(video.get('language_type')), _text(video.get('quality')))))
        rows.append(dict(current, title=label, movie_title=current['title'], action='resolve',
                         premium_detail=url, video_id=video.get('id'), provider_index=index,
                         video_source=source if video.get('id') is None else '', provider=provider))
    return rows


def _json_request(client, url, headers, payload=None):
    params = {'header': {'Accept': 'application/json', **headers}, 'timeout': 12}
    if payload is not None:
        params['header']['Content-Type'] = 'application/json'
    ok, body = client.getPage(url, params, json.dumps(payload) if payload is not None else None)
    if not ok or client.meta.get('url', url) != url:
        raise resolver.ResolveError('premium_source_unavailable')
    try:
        data = json.loads(body)
    except ValueError as error:
        raise resolver.ResolveError('premium_source_unavailable') from error
    if not isinstance(data, dict):
        raise resolver.ResolveError('premium_source_unavailable')
    return data


def _media(client, source, referer, label, origin=None, hls=False, tracks=()):
    path = urlsplit(source).path.lower()
    meta = {'Referer': referer, 'User-Agent': client.getDefaultHeader()['User-Agent']}
    if origin:
        meta['Origin'] = origin
    if tracks:
        meta['external_sub_tracks'] = tracks
    if hls or path.endswith('.m3u8'):
        meta['iptv_proto'] = 'm3u8'
    return [{'name': label, 'url': resolver.URL(resolver.checked_url(source), meta)}]


def _vidara(client, source):
    address = urlsplit(source)
    match = re.fullmatch(r'/(?:e/|v/)?([A-Za-z0-9]+)/?', address.path)
    if not match:
        return []
    origin = 'https://' + address.hostname
    data = _json_request(client, origin + '/api/stream', {'Origin': origin, 'Referer': source},
                         {'filecode': match[1], 'device': 'web'})
    media = public_url(data.get('streaming_url'), source)
    tracks = []
    for row in data.get('subtitles') or []:
        if isinstance(row, dict) and (url := public_url(row.get('file_path'), source)):
            tracks.append({'url': url, 'title': _text(row.get('language')), 'lang': _text(row.get('language'))})
    return _media(client, media, origin + '/', 'Vidara', origin, tracks=tracks) if media else []


def _flyfile(client, source):
    match = re.fullmatch(r'/(?:e|embed|v)/([A-Za-z0-9_-]{1,120})/?', urlsplit(source).path)
    if not match:
        return []
    origin = 'https://flyfile.app'
    headers = {'Origin': origin, 'Referer': source, 'X-FlyFile-Host': 'flyfile.app'}
    api = 'https://api.flyfile.app/api/'
    detail = _json_request(client, api + 'public/file/' + match[1], headers)
    if not str(detail.get('mimeType', '')).startswith('video/'):
        return []
    qualities = (detail.get('videoAsset') or {}).get('qualities')
    if isinstance(qualities, str):
        try:
            qualities = json.loads(qualities)
        except ValueError:
            qualities = []
    hls = isinstance(qualities, list) and any(isinstance(q, dict) and q.get('status') == 'READY'
                                               for q in qualities)
    stream = _json_request(client, api + 'streaming/assign/' + match[1], headers)
    host = urlsplit(public_url(stream.get('url'), source)).hostname or ''
    token = stream.get('token')
    if not re.fullmatch(r'[a-z0-9-]+\.flyfile\.app', host) or not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9._~-]{1,4096}', token):
        return []
    url = 'https://' + host + ('/hls/' + token + '/master.m3u8' if hls else '/raw/' + token)
    return _media(client, url, source, 'FlyFile', origin, hls=hls)


class _Embeds(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'iframe':
            self.links.append(attrs.get('src'))
        elif tag == 'a' and 'target' in attrs:
            self.links.append(attrs.get('href'))


def _byse_link(body, address):
    parser = _Embeds()
    parser.feed(body)
    for link in parser.links:
        url = public_url(link, address)
        if BYSE_HOST.fullmatch(urlsplit(url).hostname or ''):
            return url
    return ''


class _ByseTransport:
    """Use the existing solver with current hosts and ASCII-safe embed URLs."""
    def __init__(self, client):
        self.client = client

    def getDefaultHeader(self):
        return self.client.getDefaultHeader()

    def getPage(self, url, params=None, post_data=None):
        host = urlsplit(url).hostname or ''
        if not BYSE_HOST.fullmatch(host):
            raise resolver.ResolveError('source_not_supported')
        params = dict(params or {})
        headers = dict(params.get('header', {}))
        if 'X-Embed-Parent' in headers:
            embed = headers['X-Embed-Parent']
            if not BYSE_HOST.fullmatch(urlsplit(embed).hostname or ''):
                raise resolver.ResolveError('source_not_supported')
            headers['X-Embed-Parent'] = quote(embed, safe=':/?#[]@!$&\'()*+,;=%')
        params['header'] = headers
        result = self.client.getPage(url, params, post_data)
        final = self.client.meta.get('url', url)
        if not BYSE_HOST.fullmatch(urlsplit(final).hostname or ''):
            raise resolver.ResolveError('source_not_supported')
        return result


def _byse(client, source, parent):
    seen = set()
    for _ in range(5):
        parsed = urlsplit(source)
        if source in seen or not BYSE_HOST.fullmatch(parsed.hostname or ''):
            return []
        seen.add(source)
        if parsed.hostname not in BYSE_WRAPPERS and BYSE_VIDEO.match(parsed.path):
            engine = resolver.Byse(_ByseTransport(client))
            engine.BYSE_ACCESS = access_cache.load()
            try:
                return engine.parserBYSE(resolver.URL(source, {'Referer': parent}))
            finally:
                try:
                    access_cache.save(engine.BYSE_ACCESS)
                except OSError:
                    pass
        ok, body = client.getPage(source, {'header': {'Referer': parent}, 'timeout': 10})
        if not ok:
            return []
        final = client.meta.get('url', source)
        if final != source and BYSE_HOST.fullmatch(urlsplit(final).hostname or ''):
            source = final
        else:
            source = _byse_link(body, final)
        if not source:
            return []
    return []


def _ekino_player(client, item):
    title = item.get('source_title_url') or item['url']
    page = catalogue.fetch(client, title)
    keys = list(dict.fromkeys(re.findall(r"""ShowPlayer\(['"]player['"],\s*['"]([^'"]+)['"]\)""", page)))
    index = item.get('provider_index', 0)
    if type(index) is not int or not 0 <= index < len(keys):
        raise resolver.ResolveError('player_source_not_found')
    address = catalogue.BASE + 'watch/f/player/' + quote(keys[index], safe='')
    parent = title
    seen = set()
    for _ in range(6):
        if address in seen:
            break
        seen.add(address)
        if BYSE_HOST.fullmatch(urlsplit(address).hostname or ''):
            return _byse(client, address, parent)
        host = urlsplit(address).hostname or ''
        if host not in {'ekino.ws', 'ekino.link'} and not host.endswith('.ekino.link'):
            break
        ok, body = client.getPage(address, {'header': {'Referer': parent}, 'timeout': 12})
        if not ok:
            if client.meta.get('status_code') in (401, 403):
                raise resolver.ResolveError('source_access_denied')
            break
        final = client.meta.get('url', address)
        if BYSE_HOST.fullmatch(urlsplit(final).hostname or ''):
            return _byse(client, final, parent)
        link = _byse_link(body, final)
        if link:
            return _byse(client, link, final)
        embeds = _Embeds()
        embeds.feed(body)
        address = next((url for link in embeds.links if (url := public_url(link, final)) and
                        (urlsplit(url).hostname or '') in {'ekino.ws', 'ekino.link'}), '')
        if not address:
            break
        parent = final
    return None


def resolve(client, item):
    detail = item.get('premium_detail')
    resolver.ACTIVE_HTTP = client
    if not detail:
        if item.get('provider') == 'player':
            options = _ekino_player(client, item)
            if options is not None:
                if not options:
                    raise resolver.ResolveError('source_returned_no_variants')
                return options
        # The original adapter retains support for legacy paths and saved entries.
        return ekino_options(client, dict(item, url=item.get('source_title_url') or item['url']))
    videos = _videos(client, detail)
    wanted = item.get('video_id')
    index = item.get('provider_index')
    if wanted is None:
        video = videos[index] if type(index) is int and 0 <= index < len(videos) else None
        if isinstance(video, dict) and public_url(video.get('src'), BASE) != item.get('video_source'):
            video = None
    else:
        video = next((v for v in videos if isinstance(v, dict) and v.get('id') == wanted), None)
    if not isinstance(video, dict) or video.get('category') not in (None, '', 'full'):
        raise resolver.ResolveError('premium_source_unavailable')
    provider, source = _provider(video)
    if provider == 'vidara':
        options = _vidara(client, source)
    elif provider == 'flyfile':
        options = _flyfile(client, source)
    elif provider == 'byse':
        options = _byse(client, source, BASE)
    elif provider == 'direct':
        options = _media(client, source, BASE, 'Auto')
    else:
        method = {'voe': 'parserVOESX', 'mix': 'parserMIXDROP', 'streamtape': 'parserSTREAMTAPE'}.get(provider)
        if provider == 'vidsst':
            ok, body = client.getPage(source, {'header': {'Referer': BASE}, 'timeout': 10})
            match = re.search(r"""\bconst\s+url\s*=\s*["']([^"']+)["']""", body) if ok else None
            media = public_url(match[1], source) if match else ''
            options = _media(client, media, source, 'VidsST', 'https://vids.st') if media else []
        else:
            parser = OtherSources(client)
            run = getattr(parser, method, None) if method else None
            options = run(resolver.URL(source, {'Referer': BASE})) if run else []
    if not options:
        raise resolver.ResolveError('source_returned_no_variants')
    return options
