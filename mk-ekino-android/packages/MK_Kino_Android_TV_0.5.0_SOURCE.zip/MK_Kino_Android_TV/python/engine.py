# SPDX-License-Identifier: GPL-3.0-only
"""Add the second catalogue to the original Android bridge."""
import json
import engine_ekino as original
import combined
import premium
import movie_filters
import filmweb_ratings
import shelves

original.catalogue.browse = combined.browse
original.source_options = premium.resolve
original.watchstate.entry_copy = combined.saved_entry
# Scores from the catalogue must never be presented as Filmweb scores.
original.catalogue.card_rating = lambda part: {}
original.watchstate.FIELDS = tuple(dict.fromkeys(original.watchstate.FIELDS + ('original_title',)))
original.MESSAGES.update({
    'premium_catalogue_unavailable': 'Katalog jest chwilowo niedostępny. Spróbuj odświeżyć.',
    'premium_source_unavailable': 'To źródło jest chwilowo niedostępne. Wybierz inne źródło.',
    'source_returned_no_variants': 'Brak strumienia z tego źródła. Wybierz inne źródło.',
})
def init(files, cache):
    movie_filters.init(files)
    result = original.init(files, cache)
    filmweb_ratings.init(cache)
    shelves.init(original.backend.library)
    return result


def request(data):
    value = json.loads(data)
    operation = value.get('op')
    if operation in ('shelves_start', 'shelves_poll', 'shelves_more', 'shelves_cancel', 'shelves_invalidate'):
        service = shelves.SERVICE
        if operation == 'shelves_start':
            result = service.start(value.get('kind'), movie_filters.state())
        elif operation == 'shelves_more':
            result = service.more(value.get('shelf'))
        elif operation == 'shelves_cancel':
            result = service.cancel()
        elif operation == 'shelves_invalidate':
            result = service.invalidate()
        else:
            result = service.snapshot()
        return json.dumps(dict(result, ok=True), ensure_ascii=False)
    if operation == 'filmweb_ratings':
        items = value.get('items', [])
        if not isinstance(items, list):
            items = []
        items = filmweb_ratings.prepare(items[:200])
        return json.dumps({'ok': True, 'items': items,
                           'pending': bool(filmweb_ratings.SERVICE and filmweb_ratings.SERVICE.has_pending())},
                          ensure_ascii=False)
    if operation in ('movie_filter_state', 'movie_filter_options', 'movie_filter_set'):
        try:
            with original.backend.mutex:
                if operation == 'movie_filter_set':
                    state = movie_filters.update(value.get('filter'), value.get('value'))
                else:
                    state = movie_filters.state()
                result = {'ok': True, 'filters': state, 'filter_labels': movie_filters.labels(state)}
                if operation == 'movie_filter_options':
                    result['choices'] = movie_filters.options(value.get('filter'))
                return json.dumps(result, ensure_ascii=False)
        except (TypeError, ValueError, OSError):
            return json.dumps({'ok': False, 'reason': 'movie_filter_error',
                               'message': 'Nie udało się zapisać lub odczytać filtrów. Spróbuj ponownie.'},
                              ensure_ascii=False)
    result = json.loads(original.request(data))
    if result.get('ok') and isinstance(result.get('items'), list):
        result['items'] = filmweb_ratings.prepare(result['items'])
    return json.dumps(result, ensure_ascii=False)
