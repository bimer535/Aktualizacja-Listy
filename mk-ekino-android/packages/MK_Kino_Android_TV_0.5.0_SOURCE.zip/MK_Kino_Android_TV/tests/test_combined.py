# SPDX-License-Identifier: GPL-3.0-only
import importlib.util
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from urllib.parse import parse_qs, urlsplit
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = Path(os.environ.get('MK_ORIGINAL_PYTHON') or
                (ROOT / 'reference/legacy_python'))
sys.path[:0] = [str(ROOT / 'python'), str(ORIGINAL)]
spec = importlib.util.spec_from_file_location('engine_ekino', ORIGINAL / 'engine.py')
original = importlib.util.module_from_spec(spec)
sys.modules['engine_ekino'] = original
spec.loader.exec_module(original)

import engine
import premium
import resolver

EKINO = 'https://ekino.ws/'
SHARED = EKINO + 'movie/show/Wspolny/12'
NEXT = EKINO + 'movie/cat/strona[2]+'
SMART = premium.API + 'titles/'
VIDARA = 'https://vidara.example/e/Fx1'
BYSE = 'https://n1mwq.org/e/Bx1'
FLYFILE = 'https://flyfile.app/e/Cx1'


def html_card(url, title, year=2025):
    return (f'<div class="movies-list-item"><div class="title"><a href="{url}">{title}</a></div>'
            f'<div class="cates">{year}</div><img src="https://covers.example/a.jpg"></div>')


class FakeHttp:
    def __init__(self):
        self.meta = {}
        self.steps = []
        self.jar = []
        self.calls = []
        self.fail_ekino = False
        self.fail_smart = False
        self.reordered = False

    def getDefaultHeader(self):
        return {'User-Agent': 'MK test'}

    def getPage(self, url, params=None, post_data=None):
        parsed = urlsplit(url)
        host, route = parsed.hostname, parsed.path
        headers = (params or {}).get('header', {})
        self.calls.append((url, headers, post_data))
        self.meta = {'url': url, 'status_code': 200}
        if host == 'ekino.ws':
            if self.fail_ekino:
                self.meta['status_code'] = 503
                return False, ''
            if url == SHARED:
                return True, """<script>ShowPlayer('player','abc');ShowPlayer('upzone','bad')</script>"""
            if route.startswith('/watch/'):
                return True, '<a href="https://ads.example/go" target="_blank">Ad</a><iframe src="' + BYSE + '"></iframe>'
            if 'strona[2]' in route:
                return True, html_card(EKINO + 'movie/show/Inny/13', 'Inny')
            if route == '/movie/cat/+':
                return True, ('<ul class="movieCategories"><li><a href="kategoria[8]">Dramat</a></li></ul>'
                              '<ul class="quality"><li data-id="PL">Film polski</li></ul>')
            return True, html_card(SHARED, 'Wspólny - HD') + f'<a title="Następna strona" href="{NEXT}">Następna</a>'
        if host == 'premiumsmart.eu':
            if self.fail_smart:
                self.meta['status_code'] = 503
                return False, ''
            return True, json.dumps(self.smart_response(route, parse_qs(parsed.query)))
        if host == 'vidara.example':
            assert post_data and json.loads(post_data)['filecode'] == 'Fx1'
            return True, '{"streaming_url":"https://cdn.example/stream.m3u8"}'
        if host == 'n1mwq.org':
            if route.endswith('/details'):
                return True, '{}'
            if route.endswith('/settings'):
                return True, '{"captcha_required":false}'
            if route.endswith('/playback'):
                return True, '{"sources":[{"url":"https://cdn.example/byse.mp4","label":"HD"}]}'
        if host == 'api.flyfile.app':
            if route.startswith('/api/public/file'):
                return True, '{"mimeType":"video/mp4","videoAsset":{"qualities":[{"status":"READY"}]}}'
            return True, '{"url":"https://cdn.flyfile.app","token":"test-token"}'
        raise AssertionError('Unexpected request: ' + url)

    def smart_response(self, route, query):
        pl = {'language_type': 'PL'}
        film = {'id': 471, 'name': 'Dom dobry', 'year': 2025, 'primary_video': pl,
                'poster': 'https://image.tmdb.org/t/p/original/sample.jpg',
                'backdrop': 'https://image.tmdb.org/t/p/w1280/wide.jpg', 'description':'Opis filmu', 'genres': [{'name':'Dramat'}]}
        shared = dict(film, id=42, name='Wspólny')
        videos = [{'id': 1, 'src': VIDARA, 'name': 'Vidara', 'language_type': 'PL', 'quality': '1080p'},
                  {'id': 2, 'src': BYSE, 'name': 'Byse', 'language_type': 'PL'},
                  {'id': 3, 'src': 'https://upzone.cc/e/X', 'name': 'Upzone'},
                  {'id': 4, 'src': FLYFILE, 'name': 'FlyFile', 'category': 'full'}]
        if route.endswith('/titles/42') or route.endswith('/titles/471'):
            return {'title': {'videos': videos[::-1] if self.reordered else videos}}
        if '/search/' in route:
            return {'results': [film, shared]}
        page = int(query.get('page', ['1'])[0])
        rows = [film, shared] if page == 1 else [dict(film, id=500, name='Druga strona')]
        return {'channel': {'content': {'data': rows, 'next_page': '2' if page == 1 else None}}}


class CombinedTests(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        original.backend = None
        engine.init(tmp.name + '/files', tmp.name + '/cache')
        import filmweb_ratings
        filmweb_ratings.SERVICE.closed = True
        filmweb_ratings.SERVICE = filmweb_ratings.Ratings(tmp.name + '/cache', start=False)
        self.addCleanup(lambda: setattr(filmweb_ratings.SERVICE, 'closed', True))
        self.http = FakeHttp()
        original.backend.client = self.http

    def call(self, op='browse', **data):
        result = json.loads(engine.request(json.dumps(dict(data, op=op))))
        self.assertTrue(result['ok'], result)
        return result

    def rows(self, item):
        return self.call(item=item)['items']

    def test_filmweb_background_poll_does_not_return_catalogue_scores(self):
        row = {'action': 'sources', 'title': 'Test', 'year': '2025', 'url': SHARED,
               'rating': 9.5, 'rating_label': 'Ekino: 9,5/10', 'desc': 'Ekino: 9,5/10 | 2025'}
        result = self.call('filmweb_ratings', items=[row])
        self.assertNotIn('rating', result['items'][0])
        self.assertNotIn('Ekino:', json.dumps(result))
        self.assertTrue(result['pending'])

    def test_one_filtered_catalogue_and_independent_pagination(self):
        category = self.rows({'action': 'categories'})[1]
        version = self.rows(category)[1]
        year = next(row for row in self.rows(version) if row['title'] == '2025')
        rows = self.rows(year)
        self.assertEqual([row['title'] for row in rows], ['Wspólny - HD', 'Dom dobry', 'Druga strona', 'Następna strona'])
        self.assertEqual(rows[0]['premium_url'], SMART + '42')
        self.assertEqual(rows[0]['backdrop'], 'https://image.tmdb.org/t/p/w1280/wide.jpg')
        self.assertEqual(rows[0]['synopsis'], 'Opis filmu')
        self.assertIn('/w500/', rows[1]['icon'])
        self.assertEqual([row['title'] for row in self.rows(rows[-1])], ['Inny'])
        unfiltered = self.rows({'action': 'movies'})
        self.assertEqual([row['title'] for row in self.rows(unfiltered[-1])], ['Inny', 'Druga strona'])

    def test_search_and_available_catalogue_fallback(self):
        rows = self.rows({'action': 'search_results', 'query': 'Dom dobry'})
        self.assertIn('Dom dobry', [row['title'] for row in rows])
        self.http.fail_ekino = True
        self.assertEqual(self.rows({'action': 'movies'})[0]['title'], 'Dom dobry')
        self.http.fail_ekino = False
        self.http.fail_smart = True
        self.assertEqual(self.rows({'action': 'movies'})[0]['title'], 'Wspólny - HD')

    def test_shared_title_uses_one_source_list_and_stable_playback_id(self):
        film = self.rows({'action': 'movies'})[0]
        rows = self.rows(film)
        self.assertEqual([r['provider'] for r in rows], ['player', 'vidara', 'byse', 'flyfile'])
        self.assertTrue(all(r['url'] == SHARED for r in rows))
        self.http.reordered = True
        for row, url, expected_mime in zip(
                rows, ['https://cdn.example/byse.mp4', 'https://cdn.example/stream.m3u8',
                       'https://cdn.example/byse.mp4', 'https://cdn.flyfile.app/hls/test-token/master.m3u8'],
                ['', 'application/x-mpegURL', '', 'application/x-mpegURL']):
            index = self.call('resolve', item=row)['preferred']
            answer = self.call('play', item=row, index=index)
            self.assertEqual(answer['url'], url)
            self.assertEqual(answer['mime_type'], expected_mime)
        self.assertFalse(any(urlsplit(url).hostname == 'ads.example' for url, _, _ in self.http.calls))

    def test_saved_progress_keeps_legacy_records_and_supports_second_catalogue(self):
        old = {'action': 'sources', 'title': 'Wspólny', 'url': SHARED, 'year': '2025'}
        self.call('record', item=old, position=42, duration=300)
        film = self.rows({'action': 'movies'})[1]
        source = self.rows(film)[0]
        self.assertTrue(self.call('favourite', item=source)['added'])
        self.call('record', item=source, position=50, duration=300)
        self.assertEqual(self.call('progress', item=old)['progress']['position'], 42)
        self.assertEqual(self.call('progress', item=film)['progress']['position'], 50)
        self.assertEqual(self.rows({'action':'favourites'})[0]['title'], 'Dom dobry')
        library = original.backend.library.read()
        self.assertNotIn('stream.m3u8', json.dumps(library))
        self.assertNotIn('vidara.example', json.dumps(library))

    def test_movie_filters_open_directly_and_do_not_request_catalogue_options(self):
        main = self.rows({'action': 'main'})
        movies = next(row for row in main if row['title'] == 'Filmy')
        self.assertEqual(movies['action'], 'movies')
        self.assertTrue(movies['modern_filters'])
        for key in ('genre', 'language', 'year', 'sort'):
            result = self.call('movie_filter_options', filter=key)
            self.assertTrue(result['choices'])
        self.assertEqual(self.http.calls, [])

    def test_independent_filters_persist_and_apply_to_both_catalogues(self):
        initial_calls = len(self.http.calls)
        for key, value in [('genre', 'drama'), ('language', 'pl'), ('year', '2025'), ('sort', 'title')]:
            self.call('movie_filter_set', filter=key, value=value)
        state = self.call('movie_filter_state')['filters']
        self.assertEqual(state, {'genre': 'drama', 'language': 'pl', 'year': '2025', 'sort': 'title'})
        self.assertEqual(len(self.http.calls), initial_calls)
        rows = self.rows({'action': 'movies', 'modern_filters': True})
        names = [row['title'] for row in rows if row['action'] != 'page']
        self.assertEqual(names, ['Dom dobry', 'Druga strona', 'Wspólny - HD'])
        url = next(url for url, _, _ in self.http.calls if 'strona[1]' in url)
        self.assertIn('kategoria[9]', url)
        self.assertIn('wersja[PL]', url)
        self.assertIn('rok[2025]', url)
        files, cache = original.backend.files, original.backend.cache
        original.backend = None
        engine.init(str(files), str(cache))
        original.backend.client = self.http
        self.assertEqual(self.call('movie_filter_state')['filters'], state)
        self.call('movie_filter_set', filter='year', value='2024')
        new_state = self.call('movie_filter_state')['filters']
        self.assertEqual(new_state, dict(state, year='2024'))

    def test_invalid_filter_choice_does_not_change_saved_settings(self):
        before = self.call('movie_filter_state')['filters']
        answer = json.loads(engine.request(json.dumps(
            {'op': 'movie_filter_set', 'filter': 'year', 'value': '../secret'})))
        self.assertFalse(answer['ok'])
        self.assertEqual(self.call('movie_filter_state')['filters'], before)

    def test_non_public_and_upzone_urls_are_hidden(self):
        for url in ('https://127.0.0.1/a.mp4', 'http://cdn.example/a.mp4',
                    'https://someone@cdn.example/a.mp4', 'https://upzone.cc/e/X'):
            self.assertEqual(premium._provider({'src': url}), ('', ''))


if __name__ == '__main__':
    unittest.main()
