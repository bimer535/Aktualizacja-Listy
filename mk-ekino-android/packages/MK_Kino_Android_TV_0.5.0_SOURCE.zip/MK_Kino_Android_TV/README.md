# MK Kino 0.5.0 na Android TV

Pakiet `pl.mk.ekino.tv`, numer kompilacji 12, dotychczasowy certyfikat. Instalacja na obecną aplikację zachowuje ustawienia, ulubione i postęp.

## Menu i wygląd

- Górne menu: Główna, Filmy, Seriale, Szukaj, Ulubione, Oglądaj dalej i Opcje.
- Strona główna: duży baner ostatnio dodanych filmów i seriali, zmiana co 5 sekund. Rotacja zatrzymuje się podczas przeglądania kafelków, w dialogach i po opuszczeniu aplikacji. Po powrocie odlicza pełne 5 sekund.
- Baner można zaznaczyć pilotem: lewo/prawo zmienia pozycję, OK otwiera film lub serial.
- Szerokie grafiki tła są wykorzystywane, gdy katalog je udostępnia. W pozostałych przypadkach wyświetlana jest okładka.
- Pod banerem poziome rzędy ostatnio dodanych filmów i seriali. W katalogach duże plakaty w siatce po 5 kolumn, rok na okładce, tytuł, wersja językowa i ocena Filmweb.
- Ciemny turkusowy motyw, zaokrąglone panele i wyraźne zaznaczenie pilota.
- Niezależne filtry filmów: gatunek, język, rok, sortowanie. Łączony katalog obu dostawców; pobieranie i dopisywanie kolejnych stron w tle.
- Szczegóły filmu z opisem i grafiką tła. Oceny Filmweb uzupełniają się bez odbierania zaznaczenia pilotowi.

## Odtwarzacz

Silnik Media3 i zapis postępu pozostają zgodne z poprzednią wersją.

- Okrągłe przyciski: odtwarzanie/pauza, prędkość 0,5–2×, głośność filmu, od początku, długość przeskoku, napisy, audio i proporcje obrazu. Dla serialu także następny odcinek.
- Domyślny przeskok 30 sekund; można wybrać 10, 30 lub 60 sekund, ustawienie jest zapamiętywane.
- Lewo/prawo przy ukrytym sterowaniu lub na osi czasu wybiera pozycję. Przytrzymanie przyspiesza przewijanie; puszczenie zatwierdza po krótkiej chwili. Wstecz anuluje niezatwierdzone przewijanie.
- OK przy ukrytym sterowaniu przełącza pauzę. Góra/dół pokazuje panel. Wstecz ukrywa panel, kolejny wraca do źródeł.
- Audio i napisy zależą od ścieżek dostępnych w wybranym źródle. Przycisk Obraz przełącza dopasowanie i wypełnienie ekranu.

## Aktualizacje

- Przy uruchomieniu aplikacja automatycznie sprawdza publiczny plik aktualizacji. Jeśli dostępna jest nowsza wersja, pokazuje opis oraz przyciski Aktualizuj / Później.
- Pobieranie rozpoczyna się dopiero po wybraniu Aktualizuj. Instalację nadal potwierdza system Android.
- Brak internetu lub brak nowej wersji nie powoduje komunikatów błędu. Pytanie pojawia się najwyżej raz w danym uruchomieniu i czeka na zakończenie bieżącej operacji.
- Opcje pozwalają wyłączyć sprawdzanie przy starcie. Ręczne sprawdzanie pozostaje dostępne w MENU lub pod niebieskim przyciskiem katalogu.
- Sprawdzanie porównuje numery wersji: nie proponuje instalowania starszej wersji z serwera.

## Instalacja i walidacja

Zainstaluj APK jako aktualizację, bez odinstalowywania poprzedniej wersji. Wydanie APK i publiczny plik aktualizacji są odrębnymi etapami; samo zbudowanie APK nie zmienia wersji dostępnej w aplikacji.

36 testów katalogu, filtrów, ocen Filmweb, zapisów, paginacji, rotacji banera i stanu aktualizacji. Sprawdzono zgodność wymaganych metod Media3 z bibliotekami APK, kompilację Android API 35, podpis oraz zgodność pozostałych plików pakietu. Testy nie zastępują sprawdzenia układu i pilota na fizycznym Android TV.

```sh
python3 -m unittest discover -s tests -v
sh tools/compile_filters.sh /sciezka/android.jar /sciezka/r8lib.jar
python3 tools/build_filters.py MK_Kino_Android_TV_0.4.0.apk MK_Ekino_TV_private_signing_backup.zip MK_Kino_Android_TV_0.5.0.apk
```

Wymagane: Python 3 z cryptography, JDK z kompilatorem, Android API 35 i D8/R8. Nakładki w `python/`, interfejs w `android/pl/mk/ekino/tv/`. Źródła w `reference/legacy_python/` służą do testów. Klucz podpisujący jest przechowywany oddzielnie i nie wchodzi w skład źródeł.

Kontakt: bimer535@wp.pl. GPL-3.0-only.
