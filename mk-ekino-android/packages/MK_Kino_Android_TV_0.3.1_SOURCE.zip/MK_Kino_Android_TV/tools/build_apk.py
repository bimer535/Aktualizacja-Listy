# SPDX-License-Identifier: GPL-3.0-only
"""Build the in-place MK Kino update from the verified MK eKino TV 0.1.5 APK."""
import argparse
from copy import copy
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile
import zlib

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.serialization.pkcs12 import load_key_and_certificates
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
BASE_SHA = '894d73f065c2b42328ca719d9cc8d7fd3b3e39793029d92f277fe5a4dcf67c6d'
VERSION = '0.2.0'
VERSION_CODE = 7
APK_MAGIC = b'APK Sig Block 42'
V2_ID = 0x7109871A
RSA_SHA256 = 0x0103


def get32(data, offset=0):
    return struct.unpack_from('<I', data, offset)[0]


def u32(value):
    return struct.pack('<I', value)


def u64(value):
    return struct.pack('<Q', value)


def length_prefixed(value):
    return u32(len(value)) + value


def take(data, offset=0):
    length = get32(data, offset)
    start = offset + 4
    end = start + length
    if end > len(data):
        raise ValueError('Truncated signature')
    return data[start:end], end


def zip_offsets(data):
    eocd = data.rfind(b'PK\x05\x06', max(0, len(data) - 65557))
    if eocd < 0 or eocd + 22 + struct.unpack_from('<H', data, eocd + 20)[0] != len(data):
        raise ValueError('Invalid APK central directory')
    return get32(data, eocd + 16), eocd


def content_digest(apk, block_start, central, eocd):
    zip_end = apk[eocd:eocd + 16] + u32(block_start) + apk[eocd + 20:]
    digests = []
    for part in (memoryview(apk)[:block_start], memoryview(apk)[central:eocd], zip_end):
        for start in range(0, len(part), 1024 * 1024):
            chunk = part[start:start + 1024 * 1024]
            check = sha256(b'\xa5' + u32(len(chunk)))
            check.update(chunk)
            digests.append(check.digest())
    return sha256(b'\x5a' + u32(len(digests)) + b''.join(digests)).digest()


def sign(apk, key, cert):
    central, eocd = zip_offsets(apk)
    digest = content_digest(apk, central, central, eocd)
    algorithm = u32(RSA_SHA256)
    certificate = cert.public_bytes(serialization.Encoding.DER)
    signed = (length_prefixed(length_prefixed(algorithm + length_prefixed(digest))) +
              length_prefixed(length_prefixed(certificate)) + u32(0))
    signature = key.sign(signed, padding.PKCS1v15(), hashes.SHA256())
    public_key = key.public_key().public_bytes(serialization.Encoding.DER,
                                               serialization.PublicFormat.SubjectPublicKeyInfo)
    signer = (length_prefixed(signed) +
              length_prefixed(length_prefixed(algorithm + length_prefixed(signature))) +
              length_prefixed(public_key))
    payload = length_prefixed(length_prefixed(signer))
    pair = u64(4 + len(payload)) + u32(V2_ID) + payload
    size = u64(len(pair) + 24)
    block = size + pair + size + APK_MAGIC
    return (apk[:central] + block + apk[central:eocd + 16] +
            u32(central + len(block)) + apk[eocd + 20:])


def verify(apk):
    central, eocd = zip_offsets(apk)
    if apk[central - 16:central] != APK_MAGIC:
        raise ValueError('APK signing block missing')
    size = struct.unpack_from('<Q', apk, central - 24)[0]
    block = central - size - 8
    if block < 0 or struct.unpack_from('<Q', apk, block)[0] != size:
        raise ValueError('APK signing block size mismatch')
    cursor = block + 8
    while cursor < central - 24:
        length, identifier = struct.unpack_from('<QI', apk, cursor)
        end = cursor + 8 + length
        if end > central - 24 or length < 4:
            raise ValueError('Malformed APK signature')
        if identifier == V2_ID:
            sequence, _ = take(apk[cursor + 12:end])
            signer, _ = take(sequence)
            signed, after_signed = take(signer)
            signatures, after_signatures = take(signer, after_signed)
            public_key, _ = take(signer, after_signatures)
            sig, _ = take(signatures)
            if get32(sig) != RSA_SHA256:
                raise ValueError('Unexpected APK signature algorithm')
            signature, _ = take(sig, 4)
            digests, after_digests = take(signed)
            certificates, _ = take(signed, after_digests)
            digest, _ = take(digests)
            expected, _ = take(digest, 4)
            if get32(digest) != RSA_SHA256 or expected != content_digest(apk, block, central, eocd):
                raise ValueError('Invalid signed APK content digest')
            certificate, _ = take(certificates)
            cert = x509.load_der_x509_certificate(certificate)
            key = cert.public_key()
            if key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) != public_key:
                raise ValueError('APK certificate public key mismatch')
            key.verify(signature, signed, padding.PKCS1v15(), hashes.SHA256())
            return certificate
        cursor = end
    raise ValueError('APK v2 signature missing')


def manifest(data, *, previous_version='0.1.5', previous_code=6,
             version=VERSION, version_code=VERSION_CODE, rebrand=True, activity_name=None):
    contents = []
    offset = 8
    changes = 0
    strings = []
    while offset < len(data):
        kind, header_size, size = struct.unpack_from('<HHI', data, offset)
        chunk = bytearray(data[offset:offset + size])
        if kind == 1:
            count, styles, flags, start, _ = struct.unpack_from('<IIIII', chunk, 8)
            if styles or flags or header_size != 28:
                raise ValueError('Unexpected manifest string pool format')
            prefix = bytearray(chunk[:start])
            encoded = bytearray()
            for i in range(count):
                pos = start + get32(chunk, 28 + 4 * i)
                units = struct.unpack_from('<H', chunk, pos)[0]
                if units >= 32768:
                    raise ValueError('Unexpected long manifest string')
                text = chunk[pos + 2:pos + 2 + 2 * units].decode('utf-16-le')
                if rebrand and text == 'MK Ekino TV':
                    text = 'MK Kino'
                    changes += 1
                elif text == previous_version:
                    text = version
                    changes += 1
                if activity_name and text == 'pl.mk.ekino.tv.MainActivity':
                    text = activity_name
                    changes += 1
                strings.append(text)
                value = text.encode('utf-16-le')
                struct.pack_into('<I', prefix, 28 + 4 * i, len(encoded))
                encoded.extend(struct.pack('<H', len(value) // 2) + value + b'\0\0')
            chunk = prefix + encoded + bytes((-len(encoded)) % 4)
            struct.pack_into('<I', chunk, 4, len(chunk))
        elif kind == 0x102 and strings[get32(chunk, 20)] == 'manifest':
            attr_start, attr_size, attr_count = struct.unpack_from('<HHH', chunk, 24)
            for i in range(attr_count):
                pos = 16 + attr_start + i * attr_size
                if strings[get32(chunk, pos + 4)] == 'versionCode':
                    if get32(chunk, pos + 16) != previous_code or chunk[pos + 15] != 0x10:
                        raise ValueError('Unexpected previous manifest version')
                    struct.pack_into('<I', chunk, pos + 16, version_code)
                    changes += 1
        contents.append(chunk)
        offset += size
    if changes != (3 if rebrand else 2) + bool(activity_name) or offset != len(data):
        raise ValueError('Expected manifest fields missing')
    payload = b''.join(contents)
    return data[:4] + u32(len(payload) + 8) + payload


def uleb(data, offset):
    value = 0
    for i in range(5):
        byte = data[offset + i]
        value |= (byte & 127) << (7 * i)
        if not byte & 128:
            return value, offset + i + 1
    raise ValueError('Invalid DEX ULEB128')


def pack_uleb(value):
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    return bytes(result) + bytes([value])


def code_items(data, class_data):
    counts = []
    for _ in range(4):
        count, class_data = uleb(data, class_data)
        counts.append(count)
    for _ in range(counts[0] + counts[1]):
        _, class_data = uleb(data, class_data)
        _, class_data = uleb(data, class_data)
    for count in counts[2:]:
        index = 0
        for _ in range(count):
            delta, class_data = uleb(data, class_data)
            index += delta
            _, class_data = uleb(data, class_data)
            code, class_data = uleb(data, class_data)
            if code:
                start = code + 16
                end = start + 2 * get32(data, code + 12)
                yield index, start, end


def dex(data, *, previous_version='0.1.5', previous_code=6,
        version=VERSION, version_code=VERSION_CODE, rebrand=True):
    out = bytearray(data)
    count, off = struct.unpack_from('<II', data, 0x38)
    offsets = struct.unpack_from('<%dI' % count, data, off)
    spans = []
    original = []
    for pos in offsets:
        _, start = uleb(data, pos)
        end = data.index(0, start)
        spans.append((start, end))
        original.append(data[start:end])

    brand = {
        previous_version.encode(): version.encode(),
        f'Wersja {previous_version} jest aktualna'.encode(): f'Wersja {version} jest aktualna'.encode(),
    }
    if rebrand:
        brand.update({b'MK Ekino TV': b'MK Kino', b'Ekino': b'Ekran', b'Ekino  /  ': b'Ekran  /  '})
    replacements = {}
    for index, old in enumerate(original):
        new = brand.get(old)
        if rebrand and old.startswith(b'Android wymaga jednorazowego zezwolenia dla MK Ekino TV.'):
            new = old.replace(b'MK Ekino TV', b'MK Kino')
        elif rebrand and old.startswith(b'Samodzielna aplikacja MK na bazie MK Ekino E2'):
            new = ('Samodzielna aplikacja MK Kino łączy filmy i źródła z dwóch katalogów.\n'
                   'Odtwarzacz AndroidX Media3 i Chaquopy. GPL-3.0.\n'
                   'Dostępność filmu zależy od źródła.').encode()
        elif not rebrand and old.startswith(b'Projekt i ') and ('Wersja ' + previous_version).encode() in old:
            new = old.replace(('Wersja ' + previous_version).encode(), ('Wersja ' + version).encode(), 1)
        elif not rebrand and b'bimer55@wp.pl' in old:
            if old.startswith(b'Projekt i '):
                new = old.replace(b'bimer55@wp.pl\n\n', b'bimer535@wp.pl\n', 1)
                new = new.replace(b'Wersja 0.1.5', f'Wersja {version}'.encode(), 1)
            elif old.endswith(b'bimer55@wp.pl.'):
                new = old.replace(b'bimer55@wp.pl.', b'bimer535@wp.pl', 1)
            else:
                raise ValueError('Unexpected contact text')
            if b'bimer535@wp.pl' not in new:
                raise ValueError('Contact replacement failed')
        if new is not None:
            pos = offsets[index]
            start, end = spans[index]
            if len(new) > len(old):
                raise ValueError('New DEX string is too long')
            new = new.ljust(len(old), b' ')
            units = len(new.decode().encode('utf-16-le')) // 2
            prefix = pack_uleb(units)
            if len(prefix) != start - pos:
                raise ValueError('Cannot resize DEX string item')
            replacements[index] = new
            out[pos:end] = prefix + new
    if len(replacements) != (7 if rebrand else (4 if any(b'bimer55@wp.pl' in row for row in original) else 3)):
        raise ValueError('Expected Android UI text missing')
    for index, value in replacements.items():
        if not (replacements.get(index - 1, original[index - 1]) < value <
                replacements.get(index + 1, original[index + 1])):
            raise ValueError('Replacement would break DEX string ordering')

    _, types = struct.unpack_from('<II', data, 0x40)
    _, methods = struct.unpack_from('<II', data, 0x58)
    class_count, classes = struct.unpack_from('<II', data, 0x60)
    updater = b'Lpl/mk/ekino/tv/Updater;'
    build_config = b'Lpl/mk/ekino/tv/BuildConfig;'
    watch_marks = b'Lpl/mk/ekino/tv/WatchMarks;'
    found = set()
    for pos in range(classes, classes + 32 * class_count, 32):
        name = original[get32(data, types + 4 * get32(data, pos))]
        if name in (updater, watch_marks):
            for index, start, end in code_items(data, get32(data, pos + 24)):
                method = original[get32(data, methods + 8 * index + 4)]
                if name == updater and method == b'lambda$check$1':
                    instructions = data[start:end]
                    previous = bytes((0x16, 0, previous_code, 0, 0x31))
                    at = instructions.find(previous)
                    if at < 0 or at % 2 or instructions.count(previous) != 1:
                        raise ValueError('Updater version check did not match')
                    out[start + at + 2] = version_code
                    found.add(name)
                elif rebrand and name == watch_marks and method == b'key':
                    # Existing code first checks action and a non-null path. Drop its
                    # final prefix rejection so Premium titles can use their own paths.
                    previous = b'\x0a\x02\x38\x02\x03\x00\x11\x01\x11\x00'
                    if data[end - len(previous):end] != previous:
                        raise ValueError('Watched film key did not match')
                    out[end - 8:end - 4] = bytes(4)
                    found.add(name)
        elif name == build_config:
            fields_offset = get32(data, 0x54)
            cursor = get32(data, pos + 24)
            fields_count, cursor = uleb(data, cursor)
            for _ in range(3):
                _, cursor = uleb(data, cursor)
            values_count, value_pos = uleb(data, get32(data, pos + 28))
            index = 0
            for _ in range(min(fields_count, values_count)):
                delta, cursor = uleb(data, cursor)
                index += delta
                _, cursor = uleb(data, cursor)
                field = original[get32(data, fields_offset + 8 * index + 4)]
                tag = data[value_pos]
                length = 0 if (tag & 31) in (30, 31) else (tag >> 5) + 1
                if field == b'VERSION_CODE':
                    if tag != 4 or data[value_pos + 1] != previous_code:
                        raise ValueError('Unexpected BuildConfig version')
                    out[value_pos + 1] = version_code
                    found.add(name)
                value_pos += 1 + length
    if found != ({updater, build_config, watch_marks} if rebrand else {updater, build_config}):
        raise ValueError('DEX version fields missing')
    out[12:32] = sha1(out[32:]).digest()
    out[8:12] = u32(zlib.adler32(out[12:]))
    return bytes(out)


def app_asset(data):
    result = BytesIO()
    with ZipFile(BytesIO(data)) as original, ZipFile(result, 'w', ZIP_DEFLATED) as out:
        if original.testzip() is not None:
            raise ValueError('Corrupted Android Python bundle')
        for item in original.infolist():
            copy_info = copy(item)
            if item.filename == 'engine.pyc':
                copy_info.filename = 'engine_ekino.pyc'
                copy_info.orig_filename = copy_info.filename
            out.writestr(copy_info, original.read(item))
        for path in sorted((ROOT / 'python').glob('*.py')):
            out.write(path, path.name)
    return result.getvalue()


def icon_assets():
    original = Image.open(ROOT / 'icon.png').convert('RGB')
    icon = original.resize((512, 512), Image.Resampling.LANCZOS)
    banner = Image.new('RGB', (640, 360), (0, 10, 24))
    logo = original.resize((360, 360), Image.Resampling.LANCZOS)
    banner.paste(logo, (140, 0))
    assets = {}
    for resource, image in [('app_icon', icon), ('mk_launcher_icon', icon), ('mk_tv_launcher_banner', banner)]:
        encoded = BytesIO()
        image.save(encoded, format='PNG', optimize=True)
        assets[resource] = encoded.getvalue()
    return assets


def repack(original):
    result = BytesIO()
    with ZipFile(BytesIO(original)) as src, ZipFile(result, 'w') as dst:
        assets = icon_assets()
        app = app_asset(src.read('assets/chaquopy/app.imy'))
        config = json.loads(src.read('assets/chaquopy/build.json'))
        config['assets']['app.imy'] = sha1(app).hexdigest()
        replacements = {
            'AndroidManifest.xml': manifest(src.read('AndroidManifest.xml')),
            'classes2.dex': dex(src.read('classes2.dex')),
            'assets/chaquopy/app.imy': app,
            'assets/chaquopy/build.json': json.dumps(config).encode(),
        }
        for info in src.infolist():
            name = info.filename
            upper = name.upper()
            if upper.startswith('META-INF/') and upper.endswith(('.SF', '.RSA', '.DSA', '.EC', 'MANIFEST.MF')):
                continue
            item = copy(info)
            item.extra = b''
            if info.compress_type == ZIP_STORED and not info.is_dir():
                alignment = 16384 if name.startswith('lib/') and name.endswith('.so') else 4
                start = result.tell() + 30 + len(name.encode())
                if start % alignment:
                    padding_size = (-(start + 4)) % alignment
                    item.extra = struct.pack('<HH', 0xA11E, padding_size) + bytes(padding_size)
            resource = Path(name).stem
            if name.startswith('res/') and name.endswith('.png') and resource in assets:
                content = assets[resource]
            else:
                content = replacements[name] if name in replacements else src.read(info)
            dst.writestr(item, content)
    return result.getvalue()


def verify_zip(apk):
    with ZipFile(BytesIO(apk)) as z:
        if z.testzip() is not None:
            raise ValueError('APK ZIP integrity failed')
        for info in z.infolist():
            if info.compress_type != ZIP_STORED or info.is_dir():
                continue
            alignment = 16384 if info.filename.startswith('lib/') and info.filename.endswith('.so') else 4
            name, extra = struct.unpack_from('<HH', apk, info.header_offset + 26)
            if (info.header_offset + 30 + name + extra) % alignment:
                raise ValueError('Misaligned APK member: ' + info.filename)
        config = json.loads(z.read('assets/chaquopy/build.json'))
        app = z.read('assets/chaquopy/app.imy')
        if sha1(app).hexdigest() != config['assets']['app.imy']:
            raise ValueError('Embedded Python bundle hash mismatch')
        with ZipFile(BytesIO(app)) as inner:
            if inner.testzip() is not None or not {'engine.py', 'engine_ekino.pyc', 'combined.py', 'premium.py'} <= set(inner.namelist()):
                raise ValueError('Embedded Python modules missing')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('original', type=Path)
    parser.add_argument('signing_backup', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    original = args.original.read_bytes()
    if sha256(original).hexdigest() != BASE_SHA:
        raise ValueError('APK must be the published Android 0.1.5')
    expected_cert = verify(original)
    with ZipFile(args.signing_backup) as backup:
        key, cert, _ = load_key_and_certificates(backup.read('mk-ekino-release.p12'),
                                                backup.read('password.txt').strip())
    if not isinstance(key, rsa.RSAPrivateKey) or cert.public_bytes(serialization.Encoding.DER) != expected_cert:
        raise ValueError('Signing certificate differs from installed MK eKino TV')
    apk = sign(repack(original), key, cert)
    if verify(apk) != expected_cert:
        raise ValueError('Signed output certificate mismatch')
    verify_zip(apk)
    args.output.write_bytes(apk)
    print('APK:', args.output.name)
    print('SHA-256:', sha256(apk).hexdigest())
    print('Certyfikat SHA-256:', sha256(expected_cert).hexdigest())


if __name__ == '__main__':
    main()
