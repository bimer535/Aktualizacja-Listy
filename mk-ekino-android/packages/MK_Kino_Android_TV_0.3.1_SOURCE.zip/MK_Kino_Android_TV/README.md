# MK Kino 0.3.1 na Android TV

Pakiet `pl.mk.ekino.tv`, numer kompilacji 10, dotychczasowy certyfikat. Instalacja na obecną aplikację zachowuje ustawienia, ulubione i postęp oglądania.

## Oceny Filmweb

Oceny eKino nie są pobierane ani wyświetlane. Także stare oceny w ulubionych i historii są usuwane z danych przekazywanych do ekranu. Jedynym źródłem nowych ocen jest Filmweb.

Dopasowanie wymaga zgodnego tytułu lub oryginalnego tytułu, dokładnego roku i typu produkcji. Niejednoznaczne wyniki pozostają bez oceny. Wyświetlana jest średnia użytkowników i liczba głosów z etykietą Filmweb.

Osobny wątek pobiera dane bez blokowania katalogu lub odtwarzacza. Widoczne kafelki oraz panel szczegółów otrzymują oceny bez przeładowania strony i bez zmiany zaznaczenia pilota. Wyniki są zapisywane lokalnie na dobę; brak dopasowania na 6 godzin, błąd połączenia na 15 minut. Dobra poprzednia ocena może pozostać widoczna podczas ponownego pobierania. Przejście na inną listę wycofuje niepotrzebne zapytania.

Filmweb udostępnia te dane we własnym interfejsie strony, ale nie gwarantuje jego zgodności dla aplikacji zewnętrznych. Błąd Filmwebu nie blokuje katalogu. W takim przypadku widoczny jest napis „Filmweb: brak oceny”.

## Filtry filmów

Gatunek, Język, Rok i Sortowanie działają niezależnie i są zapamiętywane. Gatunek, język i rok dotyczą obu katalogów. Sortowanie A–Z i według rocznika porządkuje pobraną stronę; filtr Rok zawęża cały katalog.

## Instalacja i aktualizacja

W MK Kino wybierz MENU → Sprawdź aktualizację lub naciśnij niebieski przycisk pilota. Potwierdź instalację w Androidzie. Nie odinstalowuj aplikacji przed aktualizacją.

Kontakt: bimer535@wp.pl.

## Budowanie i testy

Wymagane: Python 3, cryptography, bazowy APK 0.3.0, prywatna kopia dotychczasowego klucza oraz, przy kompilacji zmienionego interfejsu, JDK, Android API 35 i D8/R8 8.3.37.

```sh
python3 -m unittest discover -s tests -v
sh tools/compile_filters.sh /sciezka/android.jar /sciezka/r8lib.jar
python3 tools/build_filters.py MK_Kino_Android_TV_0.3.0.apk MK_Ekino_TV_private_signing_backup.zip MK_Kino_Android_TV_0.3.1.apk
```

Testy obejmują niezależność filtrów, katalogi, zapisy użytkownika, brak ocen eKino w wynikach, dopasowanie roku i typu produkcji, niejednoznaczne tytuły, walidację ocen, cache, błędy połączenia i wycofywanie zapytań. Budowanie sprawdza podpis, sumy i nienaruszone biblioteki odtwarzania. Testy na komputerze nie zastępują sprawdzenia ekranu i pilota na fizycznym Android TV.

Klucza podpisującego ani jego hasła nie należy umieszczać w repozytorium lub archiwum źródłowym. GPL-3.0-only. Moduły `python/` są nakładką na bazowy APK. `reference/legacy_python/` zawiera historyczne źródła do uruchamiania testów na komputerze; wywołanie odczytu ocen eKino jest wyłączane przez nową nakładkę.
