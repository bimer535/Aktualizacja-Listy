# SPDX-License-Identifier: GPL-3.0-only
"""One Android catalogue, with existing screen and saved-film identifiers."""
from collections import Counter
from datetime import date
from itertools import zip_longest
import re
import unicodedata
from urllib.error import URLError

import catalogue
import premium
import resolver
import watchstate
import movie_filters

EKINO_BROWSE = catalogue.browse
EKINO_SAVED_ENTRY = watchstate.entry_copy
PROVIDER_ERRORS = (ValueError, TimeoutError, URLError, resolver.ResolveError)
QUALITY = re.compile(r'\s*[-–·]\s*(?:HD|FHD|UHD|4K|1080p|720p)\s*$', re.I)
YEAR = re.compile(r'\s*\([0-9]{4}\)\s*$')
KIDS = ['Animacja', 'Animowany', 'Dla dzieci', 'Familijny', 'Komedia', 'Przygodowy']


def _title(item):
    title = str(item.get('title') or '')
    return YEAR.sub('', QUALITY.sub('', title)).strip()


def _key(item):
    year = str(item.get('year') or '')
    title = premium.normal(unicodedata.normalize('NFKC', _title(item)))
    if title and re.fullmatch('[0-9]{4}', year) and item.get('action') == 'sources' and not item.get('episode'):
        return title, year
    return None


def _is_premium(url):
    return isinstance(url, str) and premium.ITEM_URL.fullmatch(url) is not None


def saved_entry(entry):
    url = entry.get('url', '')
    if _is_premium(url) and entry.get('action') in ('sources', 'seasons'):
        saved = {k: v for k, v in entry.items() if k in watchstate.FIELDS and
                 isinstance(v, (str, int, float)) and not isinstance(v, bool)}
    else:
        saved = EKINO_SAVED_ENTRY(entry)
    if saved is not None and _is_premium(entry.get('premium_url')):
        saved['premium_url'] = entry['premium_url']
    return saved


def _unique(items):
    seen = set()
    result = []
    for item in items:
        url = item.get('url')
        if url and url not in seen:
            seen.add(url)
            result.append(item)
    return result


def merge(ekino, smart):
    ekino = _unique(ekino)
    smart = _unique(smart)
    ekino_count = Counter(_key(item) for item in ekino)
    smart_count = Counter(_key(item) for item in smart)
    matches = {key: item for item in smart if (key := _key(item)) and smart_count[key] == 1}
    matched_urls = set()
    for i, item in enumerate(ekino):
        key = _key(item)
        other = matches.get(key) if ekino_count[key] == 1 else None
        if other:
            matched_urls.add(other['url'])
            ekino[i] = dict(item, premium_url=other['url'], icon=item.get('icon') or other.get('icon', ''))
    smart = [item for item in smart if item['url'] not in matched_urls]
    return [item for pair in zip_longest(ekino, smart) for item in pair if item is not None]


def _try(request):
    try:
        return request(), None
    except PROVIDER_ERRORS as error:
        return None, error


def _pair(first, second):
    a, first_error = _try(first) if first else (None, None)
    b, second_error = _try(second) if second else (None, None)
    if a is None and b is None and (first_error or second_error):
        raise first_error or second_error
    return a, b


def _movie_rows(client, current):
    first = current['action'] == 'movies'
    if first:
        ekino_item = current
        smart_page = 1
    else:
        ekino_next = current.get('ekino_next')
        ekino_item = dict(current, action='page', url=ekino_next) if ekino_next else None
        smart_page = current.get('smart_page')
    ekino, smart = _pair(
        (lambda: EKINO_BROWSE(client, ekino_item)) if ekino_item else None,
        (lambda: premium.channel(client, current, smart_page)) if smart_page else None,
    )
    next_ekino = next((row['url'] for row in ekino or [] if row['action'] == 'page'), None)
    smart_rows, next_smart = smart or ([], None)
    rows = merge([row for row in ekino or [] if row['action'] != 'page'], smart_rows)
    rows = movie_filters.order_rows(rows, current.get('movie_sort', 'added'))
    if next_ekino or next_smart:
        rows.append(dict(current, action='page', merged_page=True, title='Następna strona',
                         ekino_next=next_ekino, smart_page=next_smart))
    return rows


def _search_rows(client, current):
    ekino, smart = _pair(lambda: EKINO_BROWSE(client, current),
                         lambda: premium.search(client, current['query']))
    # Only the eKino search has a continuation link.
    results = merge([row for row in ekino or [] if row['action'] != 'page'], smart or [])
    results.extend(row for row in ekino or [] if row['action'] == 'page')
    return results


def _match_other(client, item, search):
    key = _key(item)
    if key is None:
        return None
    matches, error = _try(lambda: [row for row in search(client, _title(item)) if _key(row) == key])
    return matches[0] if not error and len(matches) == 1 else None


def _ekino_search(client, term):
    return EKINO_BROWSE(client, {'action': 'search_results', 'query': term})


def _sources(client, current):
    url = current['url']
    smart_url = url if _is_premium(url) else current.get('premium_url')
    ekino_item = None if _is_premium(url) else current
    if not current.get('episode'):
        if smart_url and ekino_item is None:
            ekino_item = _match_other(client, current, _ekino_search)
        elif not smart_url:
            match = _match_other(client, current, premium.search)
            smart_url = match and match['url']
    ekino, smart = _pair((lambda: EKINO_BROWSE(client, ekino_item)) if ekino_item else None,
                         (lambda: premium.source_rows(client, current, smart_url)) if smart_url else None)
    result = []
    for source in ekino or []:
        if source.get('provider') != 'upzone':
            result.append(dict(source, url=url, source_title_url=source['url'],
                               premium_url=smart_url, movie_title=current['title']))
    result.extend(smart or [])
    return result


def _filters(client, current):
    action = current['action']
    if action == 'years':
        # The eKino rocznik parameter is stable, so a catalogue outage does not block the selector.
        fields = dict(current)
        return [dict(fields, title='Wszystkie roczniki', action='movies', year='')] + [
            dict(fields, title=str(year), action='movies', year=str(year))
            for year in range(date.today().year + 1, 1894, -1)]
    result, error = _try(lambda: EKINO_BROWSE(client, current))
    if error:
        if action == 'categories':
            result = [catalogue.item('Wszystkie gatunki', 'versions')]
        else:
            result = [dict(current, title='Wszystkie wersje', action='years', version='')]
    if action == 'categories':
        return [dict(row, category_labels=[row['title']] if row.get('cat') else []) for row in result]
    category = current.get('category_labels') or (KIDS if current.get('cat') == '2,3,5,6' else [])
    rows = [dict(row, category_labels=category, version_label=row['title'] if row.get('version') else '')
            for row in result]
    if error:
        rows.extend(dict(rows[0], title=label, version_label=label)
                    for label in ('Lektor', 'Film polski', 'Dubbing', 'Napisy'))
    return rows


def _series_rows(client, current):
    page = current.get('smart_page', 1)
    rows, following = premium.channel(client, {}, page, series=True)
    if following:
        rows.append(catalogue.item('Następna strona', 'combined_series', smart_page=following))
    return rows


def browse(client, current):
    action = current.get('action', 'main')
    if action in ('categories', 'versions', 'years'):
        return _filters(client, current)
    if action == 'main':
        rows = EKINO_BROWSE(client, current)
        return [dict(row, action='movies', title='Filmy', modern_filters=True)
                if row.get('action') == 'categories' and row.get('title') == 'Filmy' else row
                for row in rows]
    if action == 'movies' or (action == 'page' and current.get('merged_page')):
        if current.get('modern_filters'):
            state = current.get('filter_state') or movie_filters.state()
            current = dict(current, **movie_filters.query(state))
            if action == 'page':
                current['action'] = 'page'
        return _movie_rows(client, current)
    if action == 'search_results':
        return _search_rows(client, current)
    if action == 'sources':
        return _sources(client, current)
    if action == 'series':
        sections, _ = _try(lambda: EKINO_BROWSE(client, current))
        return [catalogue.item('Pozostałe seriale', 'combined_series')] + (sections or [])
    if action == 'combined_series':
        return _series_rows(client, current)
    if _is_premium(current.get('url')):
        method = {'seasons': premium.seasons, 'episodes': premium.episodes,
                  'next_episode': premium.next_episode}.get(action)
        if method:
            return method(client, current)
    return EKINO_BROWSE(client, current)
