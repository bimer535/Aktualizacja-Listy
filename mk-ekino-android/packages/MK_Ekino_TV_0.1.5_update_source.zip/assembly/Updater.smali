.class final Lpl/mk/ekino/tv/Updater;
.super Ljava/lang/Object;
.source "Updater.java"


# static fields
.field private static final BASE:Ljava/lang/String; = "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/"

.field private static final jobs:Ljava/util/concurrent/ExecutorService;


# instance fields
.field private final activity:Lpl/mk/ekino/tv/MainActivity;

.field private volatile cancelled:Z

.field private pending:Ljava/io/File;

.field private progress:Landroid/app/ProgressDialog;

.field private running:Z


# direct methods
.method public static synthetic $r8$lambda$-1tTUnNOf1It3zy1Y1nLAcn8dC0(Lpl/mk/ekino/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->lambda$check$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$1ffybia_xp0TRS3TZ55mB1ViqDo(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/Updater;->lambda$download$7(Lpl/mk/ekino/tv/UpdatePlan;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9br8VRohrfH16Mvgaqx5FWQZyYI(Lpl/mk/ekino/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->lambda$check$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$FE1_lOy3gwuqmgjuRCPGX0zTThA(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lpl/mk/ekino/tv/Updater;->lambda$check$0(Lpl/mk/ekino/tv/UpdatePlan;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$UAmsPFhOg23rj8W7A6VpySxUj74(Lpl/mk/ekino/tv/Updater;I)V
    .locals 0

    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/Updater;->lambda$downloadFile$8(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$bgJnAxLwAozEek1RKJkBWtiMAQU(Lpl/mk/ekino/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->lambda$download$5()V

    return-void
.end method

.method public static synthetic $r8$lambda$eLEVKg5UsZxC9N-Rr7uCTmLuHDo(Lpl/mk/ekino/tv/Updater;)V
    .locals 0

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->lambda$download$6()V

    return-void
.end method

.method public static synthetic $r8$lambda$gzpXld-FkWpHsp7WwJGxQ4Ak04Q(Lpl/mk/ekino/tv/Updater;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/ekino/tv/Updater;->lambda$download$4(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$oUpei03DHPU5ppCzYS5yE92ISo8(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;[IJ)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/ekino/tv/Updater;->lambda$downloadFile$9(Lpl/mk/ekino/tv/UpdatePlan;[IJ)V

    return-void
.end method

.method public static synthetic $r8$lambda$rCH2apJBEKOaNmhsDZS4kJEm3AE(Lpl/mk/ekino/tv/Updater;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lpl/mk/ekino/tv/Updater;->lambda$installPending$10(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$xpm23z2uEJ4zS-IXO1Hmpq0g2gE(Lpl/mk/ekino/tv/Updater;JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Lpl/mk/ekino/tv/Updater;->lambda$check$1(JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 32
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lpl/mk/ekino/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method constructor <init>(Lpl/mk/ekino/tv/MainActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    return-void
.end method

.method private dismissProgress()V
    .locals 1

    .line 71
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    :cond_1
    return-void
.end method

.method private download(Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 5

    .line 57
    iget-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    .line 58
    new-instance v2, Landroid/app/ProgressDialog;

    iget-object v3, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-direct {v2, v3}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Aktualizacja "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p1, Lpl/mk/ekino/tv/UpdatePlan;->version:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/ProgressDialog;->setTitle(Ljava/lang/CharSequence;)V

    iget-object v2, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    const-string v3, "Pobieranie aktualizacji\u2026"

    invoke-virtual {v2, v3}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 59
    iget-object v2, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    invoke-virtual {v2, v0}, Landroid/app/ProgressDialog;->setProgressStyle(I)V

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    const/16 v2, 0x64

    invoke-virtual {v0, v2}, Landroid/app/ProgressDialog;->setMax(I)V

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    .line 60
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    new-instance v1, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda0;-><init>(Lpl/mk/ekino/tv/Updater;)V

    const/4 v2, -0x2

    const-string v3, "Anuluj"

    invoke-virtual {v0, v2, v3, v1}, Landroid/app/ProgressDialog;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V

    .line 61
    sget-object v0, Lpl/mk/ekino/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda2;-><init>(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private downloadFile(Lpl/mk/ekino/tv/UpdatePlan;Ljava/io/File;)V
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, -0x1

    .line 85
    filled-new-array {v0}, [I

    move-result-object v0

    .line 87
    :try_start_0
    const-string v1, "SHA-256"

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v5

    .line 88
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_5

    .line 89
    :try_start_1
    iget-object v1, p1, Lpl/mk/ekino/tv/UpdatePlan;->parts:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-wide/16 v6, 0x0

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Lpl/mk/ekino/tv/UpdatePlan$Part;

    .line 90
    iget-boolean v2, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    if-nez v2, :cond_3

    .line 91
    new-instance v2, Ljava/net/URL;

    iget-object v8, v4, Lpl/mk/ekino/tv/UpdatePlan$Part;->url:Ljava/lang/String;

    invoke-direct {v2, v8}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Ljava/net/HttpURLConnection;

    const/16 v2, 0x3a98

    .line 92
    invoke-virtual {v9, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v2, 0x7530

    invoke-virtual {v9, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v2, 0x0

    invoke-virtual {v9, v2}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 94
    :try_start_2
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    const/16 v8, 0xc8

    if-ne v2, v8, :cond_2

    .line 95
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 96
    :try_start_3
    new-instance v8, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;

    invoke-direct {v8, p0, p1, v0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda6;-><init>(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;[I)V

    invoke-static/range {v2 .. v8}, Lpl/mk/ekino/tv/UpdatePlan;->copyPart(Ljava/io/InputStream;Ljava/io/OutputStream;Lpl/mk/ekino/tv/UpdatePlan$Part;Ljava/security/MessageDigest;JLpl/mk/ekino/tv/UpdatePlan$Progress;)J

    move-result-wide v10
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    add-long/2addr v6, v10

    if-eqz v2, :cond_0

    .line 101
    :try_start_4
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 102
    :cond_0
    :try_start_5
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    goto :goto_0

    :catchall_0
    move-exception v0

    move-object p1, v0

    if-eqz v2, :cond_1

    .line 95
    :try_start_6
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    :try_start_7
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    throw p1

    .line 94
    :cond_2
    new-instance p1, Ljava/lang/Exception;

    const-string v0, "http"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :catchall_2
    move-exception v0

    move-object p1, v0

    .line 102
    :try_start_8
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p1

    .line 90
    :cond_3
    new-instance p1, Ljava/lang/Exception;

    const-string v0, "cancelled"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 104
    :cond_4
    :try_start_9
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    .line 105
    invoke-virtual {p1, v6, v7, v5}, Lpl/mk/ekino/tv/UpdatePlan;->verify(JLjava/security/MessageDigest;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    return-void

    :catchall_3
    move-exception v0

    move-object p1, v0

    .line 88
    :try_start_a
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    goto :goto_2

    :catchall_4
    move-exception v0

    :try_start_b
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p1
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    :catchall_5
    move-exception v0

    move-object p1, v0

    .line 106
    invoke-virtual {p2}, Ljava/io/File;->delete()Z

    throw p1
.end method

.method private fetch(Ljava/lang/String;I)[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 35
    const-string v0, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 36
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/16 v0, 0x3a98

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v0, 0x7530

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 37
    const-string v1, "Cache-Control"

    const-string v2, "no-cache"

    invoke-virtual {p1, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 39
    :try_start_0
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    const/16 v2, 0xc8

    if-ne v1, v2, :cond_4

    .line 40
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    :try_start_1
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const v3, 0x8000

    .line 41
    :try_start_2
    new-array v3, v3, [B

    .line 42
    :goto_0
    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_1

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v5

    add-int/2addr v5, v4

    if-gt v5, p2, :cond_0

    invoke-virtual {v2, v3, v0, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    new-instance p2, Ljava/lang/Exception;

    const-string v0, "limit"

    invoke-direct {p2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 43
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v1, :cond_2

    :try_start_4
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 44
    :cond_2
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object p2

    :catchall_0
    move-exception p2

    .line 40
    :try_start_5
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    :try_start_6
    invoke-virtual {p2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    move-exception p2

    if-eqz v1, :cond_3

    :try_start_7
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception v0

    :try_start_8
    invoke-virtual {p2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_2
    throw p2

    .line 39
    :cond_4
    new-instance p2, Ljava/lang/Exception;

    const-string v0, "http"

    invoke-direct {p2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :catchall_4
    move-exception p2

    .line 44
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p2

    .line 35
    :cond_5
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "address"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private synthetic lambda$check$0(Lpl/mk/ekino/tv/UpdatePlan;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 52
    invoke-direct {p0, p1}, Lpl/mk/ekino/tv/Updater;->download(Lpl/mk/ekino/tv/UpdatePlan;)V

    return-void
.end method

.method private synthetic lambda$check$1(JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 2

    const/4 v0, 0x0

    .line 52
    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const-wide/16 v0, 0x6

    cmp-long p1, p1, v0

    if-gtz p1, :cond_1

    iget-object p1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    const-string p2, "Wersja 0.1.5 jest aktualna"

    const/4 p3, 0x1

    invoke-static {p1, p2, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_1
    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object p2, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-direct {p1, p2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Aktualizacja "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    iget-object p2, p4, Lpl/mk/ekino/tv/UpdatePlan;->notes:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p2, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;

    invoke-direct {p2, p0, p4}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda10;-><init>(Lpl/mk/ekino/tv/Updater;Lpl/mk/ekino/tv/UpdatePlan;)V

    const-string p3, "Pobierz"

    invoke-virtual {p1, p3, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string p2, "P\u00f3\u017aniej"

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private synthetic lambda$check$2()V
    .locals 3

    const/4 v0, 0x0

    .line 53
    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    const-string v1, "Nie uda\u0142o si\u0119 sprawdzi\u0107 aktualizacji. Spr\u00f3buj p\u00f3\u017aniej."

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method private synthetic lambda$check$3()V
    .locals 10

    const-string v0, "https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/update.json?t="

    .line 50
    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/high16 v3, 0x10000

    invoke-direct {p0, v0, v3}, Lpl/mk/ekino/tv/Updater;->fetch(Ljava/lang/String;I)[B

    move-result-object v0

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Lpl/mk/ekino/tv/UpdatePlan;->parse(Lorg/json/JSONObject;)Lpl/mk/ekino/tv/UpdatePlan;

    move-result-object v9

    .line 51
    iget-wide v6, v9, Lpl/mk/ekino/tv/UpdatePlan;->code:J

    iget-object v8, v9, Lpl/mk/ekino/tv/UpdatePlan;->version:Ljava/lang/String;

    .line 52
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance v4, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v5, p0

    :try_start_1
    invoke-direct/range {v4 .. v9}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda3;-><init>(Lpl/mk/ekino/tv/Updater;JLjava/lang/String;Lpl/mk/ekino/tv/UpdatePlan;)V

    invoke-virtual {v0, v4}, Lpl/mk/ekino/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-object v5, p0

    .line 53
    :catch_1
    iget-object v0, v5, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance v1, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda4;-><init>(Lpl/mk/ekino/tv/Updater;)V

    invoke-virtual {v0, v1}, Lpl/mk/ekino/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private synthetic lambda$download$4(Landroid/content/DialogInterface;I)V
    .locals 0

    const/4 p1, 0x1

    .line 60
    iput-boolean p1, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    return-void
.end method

.method private synthetic lambda$download$5()V
    .locals 1

    const/4 v0, 0x0

    .line 67
    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->dismissProgress()V

    invoke-virtual {p0}, Lpl/mk/ekino/tv/Updater;->installPending()V

    return-void
.end method

.method private synthetic lambda$download$6()V
    .locals 3

    const/4 v0, 0x0

    .line 68
    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    invoke-direct {p0}, Lpl/mk/ekino/tv/Updater;->dismissProgress()V

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    iget-boolean v1, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    if-eqz v1, :cond_0

    const-string v1, "Anulowano pobieranie"

    goto :goto_0

    :cond_0
    const-string v1, "Nie uda\u0142o si\u0119 pobra\u0107 lub zweryfikowa\u0107 aktualizacji."

    :goto_0
    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method private synthetic lambda$download$7(Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 3

    .line 63
    :try_start_0
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v1}, Lpl/mk/ekino/tv/MainActivity;->getCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "updates"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/Exception;

    const-string v0, "cache"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    .line 64
    :cond_1
    :goto_0
    new-instance v1, Ljava/io/File;

    const-string v2, "update.apk"

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {p0, p1, v1}, Lpl/mk/ekino/tv/Updater;->downloadFile(Lpl/mk/ekino/tv/UpdatePlan;Ljava/io/File;)V

    .line 65
    invoke-direct {p0, v1, p1}, Lpl/mk/ekino/tv/Updater;->verifyArchive(Ljava/io/File;Lpl/mk/ekino/tv/UpdatePlan;)V

    .line 66
    iget-boolean p1, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    if-nez p1, :cond_2

    .line 67
    iput-object v1, p0, Lpl/mk/ekino/tv/Updater;->pending:Ljava/io/File;

    iget-object p1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance v0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda7;

    invoke-direct {v0, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda7;-><init>(Lpl/mk/ekino/tv/Updater;)V

    invoke-virtual {p1, v0}, Lpl/mk/ekino/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    .line 66
    :cond_2
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    new-instance p1, Ljava/lang/Exception;

    const-string v0, "cancelled"

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    :catch_0
    iget-object p1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance v0, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda8;-><init>(Lpl/mk/ekino/tv/Updater;)V

    invoke-virtual {p1, v0}, Lpl/mk/ekino/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private synthetic lambda$downloadFile$8(I)V
    .locals 1

    .line 99
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->progress:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/app/ProgressDialog;->setProgress(I)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$downloadFile$9(Lpl/mk/ekino/tv/UpdatePlan;[IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 97
    iget-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->cancelled:Z

    if-nez v0, :cond_1

    const-wide/16 v0, 0x64

    mul-long/2addr p3, v0

    .line 98
    iget-wide v0, p1, Lpl/mk/ekino/tv/UpdatePlan;->size:J

    div-long/2addr p3, v0

    long-to-int p1, p3

    const/4 p3, 0x0

    .line 99
    aget p4, p2, p3

    if-eq p1, p4, :cond_0

    aput p1, p2, p3

    iget-object p2, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance p3, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;

    invoke-direct {p3, p0, p1}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda9;-><init>(Lpl/mk/ekino/tv/Updater;I)V

    invoke-virtual {p2, p3}, Lpl/mk/ekino/tv/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_0
    return-void

    .line 97
    :cond_1
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "cancelled"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private synthetic lambda$installPending$10(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 111
    iget-object p1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    new-instance p2, Landroid/content/Intent;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "package:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v1}, Lpl/mk/ekino/tv/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    invoke-direct {p2, v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/16 v0, 0xd2

    invoke-virtual {p1, p2, v0}, Lpl/mk/ekino/tv/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private verifyArchive(Ljava/io/File;Lpl/mk/ekino/tv/UpdatePlan;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 73
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    const/high16 v0, 0x8000000

    goto :goto_0

    :cond_0
    const/16 v0, 0x40

    .line 74
    :goto_0
    iget-object v2, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v2}, Lpl/mk/ekino/tv/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1, v0}, Landroid/content/pm/PackageManager;->getPackageArchiveInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    .line 75
    iget-object v2, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v2}, Lpl/mk/ekino/tv/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    iget-object v3, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v3}, Lpl/mk/ekino/tv/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    if-eqz p1, :cond_5

    .line 76
    iget-object v2, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v2}, Lpl/mk/ekino/tv/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p1, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v1, :cond_1

    invoke-virtual {p1}, Landroid/content/pm/PackageInfo;->getLongVersionCode()J

    move-result-wide v2

    goto :goto_1

    :cond_1
    iget v2, p1, Landroid/content/pm/PackageInfo;->versionCode:I

    int-to-long v2, v2

    :goto_1
    iget-wide v4, p2, Lpl/mk/ekino/tv/UpdatePlan;->code:J

    cmp-long p2, v2, v4

    if-nez p2, :cond_5

    .line 78
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v2, "signature"

    if-lt p2, v1, :cond_3

    .line 79
    iget-object p2, p1, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    if-eqz p2, :cond_2

    iget-object p2, v0, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    if-eqz p2, :cond_2

    .line 80
    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    invoke-virtual {p1}, Landroid/content/pm/SigningInfo;->getApkContentsSigners()[Landroid/content/pm/Signature;

    move-result-object p1

    iget-object p2, v0, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    invoke-virtual {p2}, Landroid/content/pm/SigningInfo;->getApkContentsSigners()[Landroid/content/pm/Signature;

    move-result-object p2

    goto :goto_2

    .line 79
    :cond_2
    new-instance p1, Ljava/lang/Exception;

    invoke-direct {p1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    .line 81
    :cond_3
    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    iget-object p2, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    :goto_2
    if-eqz p1, :cond_4

    if-eqz p2, :cond_4

    .line 82
    array-length v0, p1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    array-length v0, p2

    if-ne v0, v1, :cond_4

    const/4 v0, 0x0

    aget-object p1, p1, v0

    aget-object p2, p2, v0

    invoke-virtual {p1, p2}, Landroid/content/pm/Signature;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    return-void

    :cond_4
    new-instance p1, Ljava/lang/Exception;

    invoke-direct {p1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    .line 76
    :cond_5
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "package"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method check()V
    .locals 3

    .line 47
    iget-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lpl/mk/ekino/tv/Updater;->running:Z

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    const-string v1, "Sprawdzanie aktualizacji\u2026"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 48
    sget-object v0, Lpl/mk/ekino/tv/Updater;->jobs:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda1;-><init>(Lpl/mk/ekino/tv/Updater;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method installPending()V
    .locals 4

    .line 109
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->pending:Ljava/io/File;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 110
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v2, 0x0

    if-lt v0, v1, :cond_1

    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v0}, Lpl/mk/ekino/tv/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/pm/PackageManager;->canRequestPackageInstalls()Z

    move-result v0

    if-nez v0, :cond_1

    .line 111
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Zezw\u00f3l na instalacj\u0119 aktualizacji"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Android wymaga jednorazowego zezwolenia dla MK Ekino TV. Po jego w\u0142\u0105czeniu wr\u00f3\u0107 do aplikacji."

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lpl/mk/ekino/tv/Updater$$ExternalSyntheticLambda5;-><init>(Lpl/mk/ekino/tv/Updater;)V

    const-string v3, "Ustawienia"

    invoke-virtual {v0, v3, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "P\u00f3\u017aniej"

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 113
    :cond_1
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    const-string v1, "pl.mk.ekino.tv.files"

    iget-object v3, p0, Lpl/mk/ekino/tv/Updater;->pending:Ljava/io/File;

    invoke-static {v0, v1, v3}, Landroidx/core/content/FileProvider;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0

    .line 114
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v3, "application/vnd.android.package-archive"

    invoke-virtual {v1, v0, v3}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 115
    :try_start_0
    iget-object v3, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    invoke-virtual {v3, v0}, Lpl/mk/ekino/tv/MainActivity;->startActivity(Landroid/content/Intent;)V

    iput-object v2, p0, Lpl/mk/ekino/tv/Updater;->pending:Ljava/io/File;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    iget-object v0, p0, Lpl/mk/ekino/tv/Updater;->activity:Lpl/mk/ekino/tv/MainActivity;

    const-string v2, "Brak instalatora APK na urz\u0105dzeniu."

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_0
    return-void
.end method
