# SPDX-License-Identifier: GPL-3.0-only
"""Filmweb-only ratings, conservative title/year matching and a background cache."""
import json
import math
from pathlib import Path
import queue
import re
import threading
import time
import unicodedata
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import watchstate

API = 'https://www.filmweb.pl/api/v1'
FIELDS = ('rating', 'rating_votes', 'rating_label', 'rating_source', 'filmweb_id')
TTL = 86400
MISS_TTL = 21600
ERROR_TTL = 900
SERVICE = None


def normal(text):
    text = unicodedata.normalize('NFKD', str(text or '').casefold().replace('ł', 'l'))
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', ''.join(
        c for c in text if not unicodedata.combining(c))).split())


def identity(item):
    action = item.get('action')
    if action not in ('sources', 'seasons', 'resolve'):
        return None
    title = item.get('series_title') if item.get('episode') else item.get('movie_title') or item.get('title')
    title = re.sub(r'\s*[-–·]\s*(?:HD|FHD|UHD|4K|1080p|720p)\s*$', '', str(title or ''), flags=re.I)
    title = re.sub(r'\s*\([0-9]{4}\)\s*$', '', title).strip()
    year = str(item.get('year') or '')
    if not normal(title) or not re.fullmatch(r'(?:18|19|20|21)[0-9]{2}', year):
        return None
    kind = 'serial' if action == 'seasons' or item.get('episode') or item.get('series_url') else 'film'
    original = str(item.get('original_title') or '').strip()
    return {'title': title, 'original': original, 'year': int(year), 'type': kind}


def key(value):
    return json.dumps([normal(value['title']), normal(value['original']), value['year'], value['type']],
                      ensure_ascii=False, separators=(',', ':'))


def get_json(path):
    # Separate connection from the catalogue client: no shared cookies or mutable HTTP state.
    request = Request(API + path, headers={'User-Agent': 'MK-Kino/0.3.1', 'Accept': 'application/json'})
    with urlopen(request, timeout=12) as response:
        data = response.read(512 * 1024 + 1)
        if len(data) > 512 * 1024:
            raise ValueError('filmweb_response_too_large')
        value = json.loads(data)
        if not isinstance(value, dict):
            raise ValueError('filmweb_invalid_response')
        return value


def lookup(value, fetch=get_json, wanted=lambda: True):
    """Accept one unique exact title/alias + exact year + exact content type."""
    names = {normal(value['title']), normal(value['original'])} - {''}
    queries = list(dict.fromkeys(x for x in (value['title'], value['original']) if x))
    candidates = {}
    verified = {}
    for query in queries:
        if not wanted():
            return None
        search = fetch('/live/search?' + urlencode({'query': query}))
        hits = search.get('searchHits')
        if not isinstance(hits, list):
            raise ValueError('filmweb_invalid_search')
        exact = [h for h in hits if isinstance(h, dict) and h.get('type') == value['type']
                 and normal(h.get('matchedTitle')) in names and type(h.get('id')) is int and h['id'] > 0]
        # A common title with too many exact candidates is safer left unmatched.
        if len({h['id'] for h in exact}) > 12:
            return None
        for hit in exact:
            if not wanted():
                return None
            film_id = hit['id']
            if film_id not in verified:
                verified[film_id] = fetch('/title/%d/info' % film_id)
            info = verified[film_id]
            aliases = {normal(info.get('title')), normal(info.get('originalTitle')), normal(hit.get('matchedTitle'))}
            if (info.get('id') == film_id and info.get('type') == value['type']
                    and str(info.get('year')) == str(value['year']) and names & aliases):
                candidates[film_id] = info
    if len(candidates) != 1 or not wanted():
        return None
    film_id = next(iter(candidates))
    data = fetch('/film/%d/rating' % film_id)
    score, count = data.get('rate'), data.get('count')
    if (data.get('id') != film_id or type(score) not in (float, int) or not math.isfinite(score)
            or not 0 <= score <= 10 or type(count) is not int or not 0 < count < 10**10):
        return None
    return {'filmweb_id': film_id, 'rating': round(score, 1), 'rating_votes': count,
            'rating_source': 'filmweb',
            'rating_label': 'Filmweb: %.1f/10 · głosów: %s' % (score, format(count, ',').replace(',', ' '))}


def clean(item):
    result = dict(item)
    for name in FIELDS:
        result.pop(name, None)
    # Older favourites may contain an eKino score in the first metadata line.
    if isinstance(result.get('desc'), str):
        result['desc'] = re.sub(r'^(?:e?kino|filmweb):[^|\n]*(?:\s*\|\s*)?', '',
                                result['desc'], flags=re.I).lstrip()
    return result


def valid_cached(rating):
    return (isinstance(rating, dict) and rating.get('rating_source') == 'filmweb'
            and type(rating.get('rating')) in (int, float) and math.isfinite(rating['rating'])
            and 0 <= rating['rating'] <= 10 and type(rating.get('rating_votes')) is int
            and 0 < rating['rating_votes'] < 10**10 and type(rating.get('filmweb_id')) is int
            and rating['filmweb_id'] > 0 and isinstance(rating.get('rating_label'), str)
            and rating['rating_label'].startswith('Filmweb:'))


class Ratings:
    def __init__(self, directory, fetch=get_json, clock=time.time, start=True):
        self.store = watchstate.Library(Path(directory) / 'filmweb-ratings.json')
        self.fetch, self.clock = fetch, clock
        self.lock = threading.RLock()
        self.cache = {k: v for k, v in self.store.read().items()
                      if isinstance(k, str) and isinstance(v, dict)
                      and type(v.get('updated', 0)) in (int, float)}
        self.pending, self.visible = set(), set()
        self.responses = {}
        self.jobs = queue.Queue(maxsize=100)
        self.closed = False
        if start:
            threading.Thread(target=self._worker, name='filmweb-ratings', daemon=True).start()

    def prepare(self, items):
        values = [(item, identity(item)) for item in items if isinstance(item, dict)]
        with self.lock:
            self.visible = {key(v) for _, v in values if v}
            result = []
            for item, value in values:
                row = clean(item)
                if value:
                    cache_key = key(value)
                    cached = self.cache.get(cache_key, {})
                    rating = cached.get('rating') if isinstance(cached, dict) else None
                    if not valid_cached(rating):
                        rating = None
                    if rating:
                        row.update({k: rating[k] for k in FIELDS if k in rating})
                        row['rating_label'] = row['rating_label'].replace('.', ',', 1)
                    else:
                        row['rating_label'] = 'Filmweb: brak oceny'
                    expiry = cached.get('expires', 0) if isinstance(cached, dict) else 0
                    if not isinstance(expiry, (float, int)):
                        expiry = 0
                    if self.clock() >= expiry and cache_key not in self.pending and not self.closed:
                        try:
                            self.jobs.put_nowait((cache_key, value))
                            self.pending.add(cache_key)
                        except queue.Full:
                            pass
                    if cache_key in self.pending and not rating:
                        row['rating_label'] = 'Filmweb: sprawdzanie…'
                result.append(row)
            return result

    def has_pending(self):
        with self.lock:
            return bool(self.visible & self.pending)

    def _fetch(self, path):
        # Reuse search/title metadata across remakes and duplicate catalogue titles.
        cached = self.responses.get(path)
        if cached and cached[0] > self.clock():
            return cached[1]
        value = self.fetch(path)
        self.responses[path] = (self.clock() + 1800, value)
        if len(self.responses) > 500:
            self.responses = dict(list(self.responses.items())[-400:])
        return value

    def process_one(self):
        try:
            cache_key, value = self.jobs.get_nowait()
        except queue.Empty:
            return False
        try:
            with self.lock:
                wanted = cache_key in self.visible and not self.closed
            if not wanted:
                return True
            def still_wanted():
                with self.lock:
                    return cache_key in self.visible and not self.closed
            try:
                rating = lookup(value, self._fetch, still_wanted)
                ttl = TTL if rating else MISS_TTL
            except Exception:
                with self.lock:
                    rating = self.cache.get(cache_key, {}).get('rating')
                if not valid_cached(rating):
                    rating = None
                ttl = ERROR_TTL
            if not still_wanted():
                return True
            with self.lock:
                self.cache[cache_key] = {'rating': rating, 'expires': self.clock() + ttl,
                                         'updated': self.clock()}
                self.cache = dict(sorted(self.cache.items(), key=lambda pair: pair[1].get('updated', 0),
                                         reverse=True)[:2000])
                try:
                    self.store.write(self.cache)
                except OSError:
                    pass
        finally:
            with self.lock:
                self.pending.discard(cache_key)
            self.jobs.task_done()
        return True

    def _worker(self):
        while not self.closed:
            if self.process_one():
                time.sleep(0.3)
            else:
                time.sleep(0.1)


def init(directory):
    global SERVICE
    if SERVICE:
        SERVICE.closed = True
    SERVICE = Ratings(directory)


def prepare(items):
    return SERVICE.prepare(items) if SERVICE else [clean(item) for item in items]
