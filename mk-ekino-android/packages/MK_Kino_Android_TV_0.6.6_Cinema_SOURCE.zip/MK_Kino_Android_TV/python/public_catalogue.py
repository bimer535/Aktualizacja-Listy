# SPDX-License-Identifier: GPL-3.0-only
"""Isolated, memory-only anonymous requests to the public catalogue."""
import http.cookiejar
import re
import ssl
from urllib.parse import parse_qs, urlsplit
import urllib.request
import resolver

BASE = 'https://premiumsmart.eu/'
API = BASE + 'api/v1/'
TITLE = r'titles/[1-9][0-9]{0,11}'
API_URL = re.compile(re.escape(API) + r'(?:channel/(?:filmy|seriale)|search/[^/?#]+|' +
                     TITLE + r'(?:/seasons(?:/[0-9]{1,4}/episodes(?:/[0-9]{1,5})?)?)?)\Z')
QUERY_KEYS = {'perPage', 'order', 'page', 'filters', 'limit'}
HEADER_KEYS = {'accept', 'accept-encoding', 'user-agent', 'referer'}


def checked_request(url, params=None, post_data=None):
    url = resolver.checked_url(url)
    parsed = urlsplit(url)
    address = url.split('?', 1)[0]
    if parsed.fragment or (address != BASE and not API_URL.fullmatch(address)):
        raise ValueError('public_catalogue_request_only')
    if post_data is not None or not set(parse_qs(parsed.query, keep_blank_values=True)).issubset(QUERY_KEYS):
        raise ValueError('public_catalogue_request_only')
    params = params or {}
    if set(params) - {'header', 'timeout'}:
        raise ValueError('public_catalogue_request_only')
    if any(str(key).lower() not in HEADER_KEYS for key in params.get('header', {})):
        raise ValueError('public_catalogue_request_only')
    return url


class CatalogueRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_request(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Session(resolver.Http):
    def __init__(self):
        # Never inherit a caller's cookie jar, headers, saved profile or opener.
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=ssl.create_default_context()),
            urllib.request.HTTPCookieProcessor(self.jar), CatalogueRedirect())
        self.meta = {}
        self.steps = []

    def getPage(self, url, params=None, post_data=None):
        checked_request(url, params, post_data)
        return super().getPage(url, params, None)


def for_client(owner):
    session = getattr(owner, '_mk_public_catalogue', None)
    if session is None:
        session = Session()
        owner._mk_public_catalogue = session
    return session
