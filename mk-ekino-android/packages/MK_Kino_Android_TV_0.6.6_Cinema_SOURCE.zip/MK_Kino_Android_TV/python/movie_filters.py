# SPDX-License-Identifier: GPL-3.0-only
"""Independent filters shared by the two public movie catalogues."""
from datetime import date
from pathlib import Path
import re
import unicodedata
import watchstate

GENRES = [
    ('', 'Wszystkie', '', ()),
    ('action', 'Akcja', '1', ('Akcja', 'Action')),
    ('comedy', 'Komedia', '17', ('Komedia', 'Comedy')),
    ('drama', 'Dramat', '9', ('Dramat', 'Drama')),
    ('thriller', 'Thriller', '31', ('Thriller',)),
    ('horror', 'Horror', '15', ('Horror',)),
    ('crime', 'Kryminał', '19', ('Kryminał', 'Crime')),
    ('adventure', 'Przygodowy', '23', ('Przygodowy', 'Adventure')),
    ('animation', 'Animacja', '2', ('Animacja', 'Animowany', 'Animation')),
    ('family', 'Familijny', '12', ('Familijny', 'Family', 'Dla dzieci')),
    ('scifi', 'Science fiction', '28', ('Sci-fi', 'Science Fiction', 'Science-fiction')),
    ('fantasy', 'Fantasy', '13', ('Fantasy',)),
    ('documentary', 'Dokumentalny', '8', ('Dokumentalny', 'Documentary')),
    ('romance', 'Romans', '26', ('Romans', 'Romance')),
    ('biography', 'Biograficzny', '4', ('Biograficzny', 'Biography')),
    ('history', 'Historyczny', '14', ('Historyczny', 'History')),
    ('war', 'Wojenny', '33', ('Wojenny', 'War')),
    ('western', 'Western', '32', ('Western',)),
    ('music', 'Muzyczny', '22', ('Muzyczny', 'Music')),
]
LANGUAGES = [
    ('', 'Wszystkie', ''), ('lektor', 'Lektor', 'Lektor'),
    ('dubbing', 'Dubbing', 'Dubbing'), ('napisy', 'Napisy', 'Napisy'),
    ('pl', 'Polski (PL)', 'PL'), ('original', 'Oryginał', 'ENG'),
]
ORDERS = [('added', 'Ostatnio dodane'), ('year', 'Rocznik (na stronie)'), ('title', 'A–Z (na stronie)')]
DEFAULT = {'genre': '', 'language': '', 'year': '', 'sort': 'added'}
STORE = None


def init(directory):
    global STORE
    STORE = watchstate.Library(Path(directory) / 'movie-filters.json')


def options(key):
    if key == 'genre':
        choices = [(code, label) for code, label, _, _ in GENRES]
    elif key == 'language':
        choices = [(code, label) for code, label, _ in LANGUAGES]
    elif key == 'year':
        choices = [('', 'Wszystkie')] + [(str(year), str(year)) for year in range(date.today().year, 1894, -1)]
    elif key == 'sort':
        choices = ORDERS
    else:
        raise ValueError('invalid_movie_filter')
    return [{'id': code, 'label': label} for code, label in choices]


def normalize(value):
    value = value if isinstance(value, dict) else {}
    clean = dict(DEFAULT)
    for key in clean:
        selected = value.get(key)
        if isinstance(selected, str) and selected in {choice['id'] for choice in options(key)}:
            clean[key] = selected
    return clean


def state():
    return normalize(STORE.read() if STORE is not None else {})


def labels(value=None):
    value = state() if value is None else normalize(value)
    return {key: next(choice['label'] for choice in options(key) if choice['id'] == selected)
            for key, selected in value.items()}


def update(key, value):
    if key not in DEFAULT or not isinstance(value, str) or value not in {choice['id'] for choice in options(key)}:
        raise ValueError('invalid_movie_filter')
    current = state()
    current[key] = value
    if STORE is None:
        raise ValueError('movie_filters_not_ready')
    STORE.write(current)
    return current


def query(value):
    value = normalize(value)
    genre = next(row for row in GENRES if row[0] == value['genre'])
    language = next(row for row in LANGUAGES if row[0] == value['language'])
    return dict(action='movies', title='Filmy', modern_filters=True,
                filter_state=value, cat=genre[2], category_labels=list(genre[3]),
                version=language[2], version_label=language[2],
                year=value['year'], movie_sort=value['sort'])


def title_key(item):
    title = re.sub(r'\s*[-–·]\s*(?:HD|FHD|UHD|4K|1080p|720p)\s*$', '', str(item.get('title') or ''), flags=re.I)
    title = title.casefold().replace('ł', 'l')
    return ''.join(char for char in unicodedata.normalize('NFKD', title) if not unicodedata.combining(char))


def order_rows(rows, order):
    if order == 'title':
        return sorted(rows, key=lambda row: (title_key(row), str(row.get('year') or '')))
    if order == 'year':
        return sorted(rows, key=lambda row: (-int(row['year']) if re.fullmatch(r'[0-9]{4}', str(row.get('year'))) else 0,
                                            title_key(row)))
    return rows
