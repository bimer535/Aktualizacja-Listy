# SPDX-License-Identifier: GPL-3.0-only
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'python'),str(ROOT/'reference/legacy_python')]
import shelves,filmweb_ratings,movie_filters


def film(n):return {'url':'https://catalogue.example/'+str(n),'title':'Film '+str(n),'year':'2025','action':'sources'}

class ShelfTests(unittest.TestCase):
 def setUp(self):
  self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  old=filmweb_ratings.SERVICE
  filmweb_ratings.SERVICE=filmweb_ratings.Ratings(self.temp.name,start=False)
  self.addCleanup(lambda:setattr(filmweb_ratings,'SERVICE',old))
  self.calls=[];self.fail=False
  def fetch(client,query):
   self.assertEqual(client,'isolated-client');self.calls.append(query)
   if self.fail:raise TimeoutError()
   if query.get('action')=='page':return [film(2),film(3)],None
   return [film(1),film(2)],{'action':'page','url':'https://catalogue.example/page2'}
  self.service=shelves.ShelfService(fetch,lambda:'isolated-client',start=False)
 def test_start_returns_placeholders_without_network(self):
  model=self.service.start('movies',{})
  self.assertEqual(self.calls,[]);self.assertEqual(len(model['shelves']),1)
  self.assertTrue(model['pending']);self.service.process_one()
  model=self.service.snapshot();self.assertEqual(len(model['shelves'][0]['items']),2)
 def test_grid_preserves_all_independent_filters(self):
  state=dict(movie_filters.DEFAULT,language='lektor',year='2025',sort='year')
  queries=shelves.row_queries('movies',state)
  self.assertEqual(len(queries),1)
  for _,_,q in queries:
   self.assertEqual(q['filter_state']['language'],'lektor');self.assertEqual(q['year'],'2025');self.assertEqual(q['movie_sort'],'year')
  self.assertEqual(len(shelves.row_queries('movies',dict(state,genre='horror'))),1)
 def test_home_has_latest_movies_and_series_independent_of_saved_filters(self):
  state=dict(movie_filters.DEFAULT,genre='horror',year='2020',language='lektor')
  self.service.start('home',state);self.drain()
  model=self.service.snapshot();self.assertEqual(model['kind'],'home')
  self.assertEqual([row['id'] for row in model['shelves']],['latest-movies','latest-series','genre-action','genre-comedy','genre-animation','genre-thriller','genre-horror'])
  self.assertEqual(self.calls[0]['filter_state'],movie_filters.DEFAULT)
  self.assertEqual(self.calls[1]['action'],'tv_series')
  for row, query in zip(model['shelves'][2:], self.calls[2:]):
   self.assertEqual(query['filter_state']['genre'],row['id'][6:])
   self.assertEqual(query['filter_state']['year'],'')
  count=len(self.calls);self.service.start('home',dict(state,year='2021'));self.drain()
  self.assertEqual(len(self.calls),count)
 def drain(self):
  while self.service.process_one():pass
 def test_more_appends_and_deduplicates_without_resetting_row(self):
  self.service.start('movies',{});self.drain()
  self.service.more('new-movies');self.drain()
  row=self.service.snapshot()['shelves'][0]
  self.assertEqual([x['url'] for x in row['items']],[film(i)['url'] for i in [1,2,3]])
  self.assertIsNone(row['next'])
 def test_failed_more_retains_cards_and_retries_next_page(self):
  self.service.start('movies',{});self.drain();self.fail=True
  self.service.more('new-movies');self.drain()
  self.assertEqual(len(self.service.snapshot()['shelves'][0]['items']),2)
  self.fail=False;self.service.more('new-movies');self.drain()
  self.assertEqual(len(self.service.snapshot()['shelves'][0]['items']),3)
 def test_cancel_and_kind_change_ignore_obsolete_jobs(self):
  self.service.start('movies',{});self.service.cancel();self.service.start('series',{});self.drain()
  self.assertTrue(self.calls);self.assertTrue(all(x['action'].startswith('tv_') for x in self.calls))
  self.assertEqual(self.service.snapshot()['kind'],'series')
 def test_back_to_cached_shelves_does_not_refetch(self):
  self.service.start('movies',{});self.drain();count=len(self.calls)
  self.service.cancel();model=self.service.start('movies',{});self.drain()
  self.assertEqual(len(self.calls),count);self.assertEqual(len(model['shelves'][0]['items']),2)
 def test_invalidate_refreshes_catalogue(self):
  self.service.start('movies',{});self.drain();count=len(self.calls)
  self.service.invalidate();self.service.start('movies',{});self.drain();self.assertGreater(len(self.calls),count)
 def test_completed_mark_is_read_from_existing_library(self):
  class Library:
   def read(self):return {'progress':{film(1)['url']:{'completed':True}}}
  self.service.library=Library();self.service.start('movies',{});self.drain()
  rows=self.service.snapshot()['shelves'][0]['items'];self.assertTrue(rows[0]['watched']);self.assertFalse(rows[1]['watched'])
 def test_episode_rows_become_full_series_cards(self):
  episode=dict(film(1),episode=4,season='2',series_url='https://catalogue.example/show',series_title='Serial')
  def browse(client,item):return [{'action':'series_section','section':0}] if item['action']=='series' else [episode,episode]
  with patch.object(shelves.combined,'EKINO_BROWSE',browse):
   rows=shelves._ekino_series(None)
  self.assertEqual(len(rows),1);self.assertEqual(rows[0]['action'],'seasons');self.assertEqual(rows[0]['url'],episode['series_url']);self.assertNotIn('episode',rows[0])

if __name__=='__main__':unittest.main()
