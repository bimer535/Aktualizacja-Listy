import subprocess
import tempfile
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class NativeStateTests(unittest.TestCase):
 def test_banner_update_and_seek_user_journeys(self):
  with tempfile.TemporaryDirectory() as output:
   sources=[str(ROOT/'android/pl/mk/ekino/tv'/name) for name in ('BannerRotation.java','StartupUpdateState.java','SeekMath.java','CinemaLayout.java')]
   subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-d',output,*sources,str(ROOT/'tests/NativeStateTest.java')],check=True,capture_output=True,text=True)
   result=subprocess.run(['java','-cp',output,'pl.mk.ekino.tv.NativeStateTest'],check=True,capture_output=True,text=True)
   self.assertIn('scenarios passed',result.stdout)
