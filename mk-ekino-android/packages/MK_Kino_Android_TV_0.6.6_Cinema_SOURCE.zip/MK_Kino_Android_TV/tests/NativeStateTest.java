package pl.mk.ekino.tv;
public final class NativeStateTest {
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        check(CinemaLayout.featuredMovie("2026","sources"),"2026 movie eligible");
        check(!CinemaLayout.featuredMovie("2025","sources")&&!CinemaLayout.featuredMovie("2026","seasons")&&!CinemaLayout.featuredMovie("","sources"),"exclude old, series and unknown year from panorama");
        check(!CinemaLayout.featuredPanorama("2026","sources",""),"poster-only movie must not enter panorama");
        check(CinemaLayout.featuredPanorama("2026","sources","https://image.tmdb.org/t/p/original/scene.jpg"),"2026 movie with scene is eligible");
        BannerRotation banner=new BannerRotation();
        check(!banner.advance(0,true,8),"first banner stays visible");
        check(!banner.advance(4999,true,8),"wait full five seconds");
        check(banner.advance(5000,true,8),"rotate at five seconds");
        check(!banner.advance(9999,true,8),"wait for next interval");
        check(!banner.advance(10000,false,8),"pause while browsing cards");
        check(!banner.advance(60000,true,8),"resume without skipping banners");
        check(!banner.advance(64999,true,8),"full interval after resuming");
        check(banner.advance(65000,true,8),"resume rotation");
        check(!banner.advance(70000,true,1),"single item never rotates");
        banner.reset();check(!banner.advance(80000,true,8),"manual selection restarts timer");
        StartupUpdateState<String> updates=new StartupUpdateState<>(true);
        check(updates.begin()&&!updates.begin(),"one request at startup");
        updates.completed(12,11,"old");check(updates.take(true)==null,"ignore older version");
        updates.completed(12,12,"same");check(updates.take(true)==null,"ignore installed version");
        updates.completed(12,13,"new");check(updates.take(false)==null,"defer while background or busy");
        check("new".equals(updates.take(true)),"offer newer version when ready");
        check(updates.take(true)==null,"later means no repeat notice");
        updates.completed(12,13,"duplicate");check(updates.take(true)==null,"late result cannot repeat notice");
        StartupUpdateState<String> disabled=new StartupUpdateState<>(false);
        check(!disabled.begin(),"disabled startup has no request");disabled.setEnabled(true);check(disabled.begin(),"enable checks once");
        disabled.setEnabled(false);disabled.completed(12,13,"new");check(disabled.take(true)==null,"disabled in-flight result ignored");
        disabled.setEnabled(true);check(disabled.begin(),"re-enable permits check");disabled.completed(12,13,"new");disabled.close();
        check(disabled.take(true)==null&&!disabled.begin(),"destroyed activity cannot offer or check");
        check(SeekMath.clamp(-100,1000)==0&&SeekMath.clamp(2000,1000)==1000,"seek bounds");
        for(int viewport:new int[]{640,960,1280,1920,3840}){
            int width=CinemaLayout.cellWidth(viewport,5,12,10);
            check(width<viewport/4,"a single result must not fill the screen");
            for(int count:new int[]{1,2,4,5,6,11})for(int i=0;i<count;i++){
                int left=12+(i%5)*(width+10);
                check(left>=12&&left+width<=viewport-12,"all cards and labels stay inside the viewport");
            }
            check(CinemaLayout.homeTextWidth(viewport)<viewport/2,"leave room for the whole banner image");
        }
        check(CinemaLayout.homeHeight(540)==270,"banner limited to the upper half of a TV screen");
        check(CinemaLayout.imageSample(1920,1080,1920,1080)==1,"keep Full HD banner detail instead of poster-thumbnail sampling");
        check(CinemaLayout.imageSample(3840,2160,1920,1080)==2,"bound 4K bitmap memory without changing its proportions");
        check(CinemaLayout.imageSample(500,750,1920,1080)==1,"do not degrade a portrait fallback");
        check("Sezon".equals(CinemaLayout.itemType("seasons","episodes")),"a season is not labelled Film");
        check("Odcinek".equals(CinemaLayout.itemType("episodes","sources")),"episodes have their own type");
        check("Serial".equals(CinemaLayout.itemType("","seasons")),"catalogue series stay labelled Serial");
        System.out.println("Native banner, update and seek scenarios passed; layout and banner-image regressions passed");
    }
}
