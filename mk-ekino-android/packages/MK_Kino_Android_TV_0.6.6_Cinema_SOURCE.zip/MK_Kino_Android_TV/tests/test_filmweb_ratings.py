# SPDX-License-Identifier: GPL-3.0-only
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'python'), str(ROOT / 'reference/legacy_python')]
import filmweb_ratings as fw


def movie(title='Diuna', year='2021', **fields):
    return dict(title=title, year=year, action='sources', url='https://catalogue.example/one', **fields)


class Api:
    def __init__(self):
        self.calls = []
        self.error = False
        self.hits = [dict(id=1, type='film', matchedTitle='Diuna'),
                     dict(id=2, type='film', matchedTitle='Diuna'),
                     dict(id=3, type='serial', matchedTitle='Diuna')]
        self.info = {1: dict(id=1, title='Diuna', originalTitle='Dune', year=2021, type='film'),
                     2: dict(id=2, title='Diuna', originalTitle='Dune', year=1984, type='film'),
                     3: dict(id=3, title='Diuna', originalTitle='Dune', year=2000, type='serial')}
        self.rating = dict(id=1, rate=7.63, count=123456)

    def __call__(self, path):
        self.calls.append(path)
        if self.error:
            raise TimeoutError()
        if path.startswith('/live/search?'):
            return dict(searchHits=self.hits)
        if path.endswith('/info'):
            return self.info[int(path.split('/')[2])]
        if path.endswith('/rating'):
            return self.rating
        raise AssertionError(path)


class MatchingTests(unittest.TestCase):
    def setUp(self):
        self.api = Api()

    def test_remake_matches_exact_year_and_film_not_serial(self):
        r = fw.lookup(fw.identity(movie()), self.api)
        self.assertEqual((r['filmweb_id'], r['rating'], r['rating_votes']), (1, 7.6, 123456))
        self.assertIn('Filmweb:', r['rating_label'])
        self.assertNotIn('/title/3/info', self.api.calls)

    def test_wrong_year_and_ambiguous_same_year_have_no_rating(self):
        self.assertIsNone(fw.lookup(fw.identity(movie(year='2020')), self.api))
        self.api.info[2]['year'] = 2021
        self.assertIsNone(fw.lookup(fw.identity(movie()), self.api))
        self.assertFalse(any(p.endswith('/rating') for p in self.api.calls))

    def test_original_title_alias_and_polish_diacritics(self):
        self.api.hits = [dict(id=1, type='film', matchedTitle='Zażółć gęślą jaźń')]
        self.api.info[1].update(title='Zażółć gęślą jaźń', originalTitle='Original title')
        r = fw.lookup(fw.identity(movie('Zazolc gesla jazn')), self.api)
        self.assertEqual(r['filmweb_id'], 1)
        self.api.hits[0]['matchedTitle'] = 'Original title'
        r = fw.lookup(fw.identity(movie('Inny tytuł', original_title='Original title')), self.api)
        self.assertEqual(r['filmweb_id'], 1)

    def test_fuzzy_title_is_not_accepted(self):
        self.api.hits = [dict(id=1, type='film', matchedTitle='Diuna: Część druga')]
        self.assertIsNone(fw.lookup(fw.identity(movie()), self.api))

    def test_ten_identical_titles_are_resolved_by_year(self):
        self.api.hits = [dict(id=i, type='film', matchedTitle='Diuna') for i in range(1, 11)]
        for i in range(2, 11):
            self.api.info[i] = dict(id=i, title='Diuna', originalTitle='Dune', year=1900+i, type='film')
        self.assertEqual(fw.lookup(fw.identity(movie()), self.api)['filmweb_id'], 1)

    def test_missing_year_and_navigation_do_not_issue_requests(self):
        self.assertIsNone(fw.identity(movie(year='')))
        self.assertIsNone(fw.identity(dict(action='page', title='Następna strona', year='2021')))

    def test_serial_is_checked_separately(self):
        item = dict(title='Diuna', year='2000', action='seasons')
        self.api.rating.update(id=3)
        self.assertEqual(fw.lookup(fw.identity(item), self.api)['filmweb_id'], 3)
        self.assertNotIn('/title/1/info', self.api.calls)

    def test_invalid_score_zero_votes_and_wrong_id_are_not_shown(self):
        for patch in [dict(rate=99), dict(rate=float('nan')), dict(rate=True), dict(count=0), dict(id=999)]:
            self.api.rating = dict(id=1, rate=7.6, count=100, **{})
            self.api.rating.update(patch)
            self.assertIsNone(fw.lookup(fw.identity(movie()), self.api), patch)

    def test_cancelled_lookup_does_no_network(self):
        self.assertIsNone(fw.lookup(fw.identity(movie()), self.api, lambda: False))
        self.assertEqual(self.api.calls, [])


class CacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.api = Api()
        self.now = 1000000
        self.service = fw.Ratings(self.tmp.name, self.api, lambda: self.now, start=False)

    def test_nonblocking_prepare_removes_ekino_and_old_favourite_description(self):
        old = movie(rating=9.9, rating_votes=10, rating_label='Ekino: 9,9/10',
                    desc='Ekino: 9,9/10 · głosów: 10 | Dune | 2021\nOpis filmu')
        row = self.service.prepare([old])[0]
        self.assertEqual(self.api.calls, [])
        self.assertNotIn('rating', row)
        self.assertNotIn('Ekino:', row['desc'])
        self.assertIn('Opis filmu', row['desc'])
        self.assertEqual(row['rating_label'], 'Filmweb: sprawdzanie…')
        self.assertTrue(self.service.has_pending())
        self.service.process_one()
        result = self.service.prepare([old])[0]
        self.assertEqual(result['rating'], 7.6)
        self.assertIn('7,6/10', result['rating_label'])
        self.assertFalse(self.service.has_pending())

    def test_persistent_cache_and_deduplication_do_not_repeat_fetch(self):
        self.service.prepare([movie(), movie()])
        self.assertEqual(self.service.jobs.qsize(), 1)
        self.service.process_one()
        calls = len(self.api.calls)
        other = fw.Ratings(self.tmp.name, self.api, lambda: self.now, start=False)
        self.assertEqual(other.prepare([movie()])[0]['rating'], 7.6)
        self.assertEqual(len(self.api.calls), calls)
        self.assertFalse(other.has_pending())

    def test_negative_cache_timeout_and_stale_good_rating(self):
        self.service.prepare([movie()]); self.service.process_one()
        self.now += fw.TTL + 1
        self.api.error = True
        self.assertEqual(self.service.prepare([movie()])[0]['rating'], 7.6)
        self.service.process_one()
        self.assertEqual(self.service.prepare([movie()])[0]['rating'], 7.6)
        self.assertFalse(self.service.has_pending())
        self.now += fw.ERROR_TTL + 1
        self.service.prepare([movie()])
        self.assertTrue(self.service.has_pending())

    def test_no_match_is_not_replaced_with_catalogue_rating(self):
        old = movie(year='2020', rating=9, rating_label='Ekino: 9/10')
        self.service.prepare([old]); self.service.process_one()
        result = self.service.prepare([old])[0]
        self.assertNotIn('rating', result)
        self.assertEqual(result['rating_label'], 'Filmweb: brak oceny')
        self.assertFalse(self.service.has_pending())

    def test_navigation_cancels_obsolete_jobs(self):
        self.service.prepare([movie()])
        self.service.prepare([dict(title='Menu', action='main')])
        self.service.process_one()
        self.assertEqual(self.api.calls, [])
        self.assertFalse(self.service.has_pending())

    def test_malformed_cache_is_ignored(self):
        Path(self.tmp.name, 'filmweb-ratings.json').write_text('{"bad":123,"other":null}')
        other = fw.Ratings(self.tmp.name, self.api, start=False)
        self.assertEqual(other.cache, {})
        self.assertTrue(other.prepare([movie()]))

    def test_incomplete_cached_score_cannot_break_catalogue(self):
        value = fw.identity(movie())
        self.service.cache[fw.key(value)] = {'rating': {'rating_source': 'filmweb'}, 'expires': 0}
        row = self.service.prepare([movie()])[0]
        self.assertNotIn('rating', row)
        self.assertEqual(row['rating_label'], 'Filmweb: sprawdzanie…')


if __name__ == '__main__':
    unittest.main()
