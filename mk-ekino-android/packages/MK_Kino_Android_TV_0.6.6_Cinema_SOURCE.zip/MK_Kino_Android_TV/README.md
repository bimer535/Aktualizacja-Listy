# MK Kino Android TV 0.6.6 — Cinema

Autorski wariant wizualny na bazie MK Kino Android TV 0.6.5.

## Wygląd

- Grafitowe tło i stonowane akcenty w kolorze lodowego błękitu.
- Proste menu; aktywna sekcja zaznaczona niezależnie od pozycji kursora.
- Panorama z gradientem poprawiającym czytelność tekstu.
- Pełne plakaty bez przycinania obrazu.
- Jasna ramka i krótkie powiększenie zaznaczonej okładki.
- Łagodna animacja tekstu przy zmianie filmu w panoramie.
- Kontrolki odtwarzacza dopasowane do nowego interfejsu.

## Instalacja

Ten sam pakiet i certyfikat co w 0.6.5. Instalować jako aktualizację,
bez odinstalowywania aplikacji. Wersja 0.6.6, versionCode 20, Android 7.0+.
Udostępniono do ręcznej instalacji, bez publikacji w kanale aktualizacji.

Zmiana obejmuje interfejs. Nie naprawia zmian domen ani dostępności
zewnętrznych serwisów. Silnik katalogu, sieci, odtwarzania i zapisów pochodzi
z wersji 0.6.5.

## Budowanie

Wymagane: JDK, Android SDK android.jar, D8/R8, Python 3 i cryptography.

```sh
sh tools/compile_filters.sh /path/android.jar /path/r8.jar
python3 tools/build_filters.py MK_Kino_Android_TV_0.6.5.apk /private/MK_Ekino_TV_private_signing_backup.zip MK_Kino_Android_TV_0.6.6_Cinema.apk
python3 -m unittest discover -s tests -v
```

Klucz podpisu nie jest częścią źródeł. Paczka bazowa musi być dokładną
wersją 0.6.5 o sumie SHA-256 zapisanej w tools/build_filters.py.

## Weryfikacja

Kompilacja Java/D8 i 36 testów automatycznych zakończone pomyślnie.
Zweryfikowano podpis APK oraz zgodność certyfikatu z 0.6.5.
Kod Pythona i biblioteki natywne zachowano bez zmian.
Wygląd i odtwarzanie wymagają końcowego sprawdzenia na fizycznym telewizorze;
nie przeprowadzono testu na urządzeniu ani emulatorze.

Licencja GPL-3.0-only; tekst w LICENSE.
