package pl.mk.ekino.tv;
/** One optional notice per launch; network results never trigger installation. */
final class StartupUpdateState<T> {
    private boolean enabled,checked,closed,offered;
    private T pending;
    StartupUpdateState(boolean enabled){this.enabled=enabled;}
    synchronized boolean begin(){if(!enabled||checked||closed)return false;checked=true;return true;}
    synchronized void completed(long installed,long available,T plan){if(!closed&&!offered&&enabled&&available>installed)pending=plan;}
    synchronized T take(boolean foregroundReady){if(closed||!enabled||!foregroundReady)return null;T result=pending;pending=null;if(result!=null)offered=true;return result;}
    synchronized void setEnabled(boolean value){if(enabled!=value){enabled=value;pending=null;if(value)checked=false;}}
    synchronized boolean isEnabled(){return enabled;}
    synchronized void close(){closed=true;pending=null;}
}
