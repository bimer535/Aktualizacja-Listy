package pl.mk.ekino.tv;
final class SeekMath {
    static long clamp(long target,long duration){return Math.max(0,Math.min(target,Math.max(0,duration)));}
}
