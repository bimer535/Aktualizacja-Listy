package pl.mk.ekino.tv;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Original MK TV interface: poster shelves, persistent navigation and focus-safe updates. */
public final class CinemaActivity extends MainActivity {
    private static final int INK=0xff0c1017, PANEL=0xff1b2532, ACCENT=0xff7cdde8, MUTED=0xffa2aebd;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ArrayDeque<State> history=new ArrayDeque<>();
    private final Map<String,TextView> scores=new HashMap<>();
    private final Map<String,View> cards=new LinkedHashMap<>();
    private final Map<String,HorizontalScrollView> rails=new HashMap<>();
    private final Button[] filters=new Button[4];
    private final String[] filterKeys={"genre","language","year","sort"};
    private final String[] filterNames={"Gatunek","Język","Rok","Sortowanie"};
    private JSONObject current=new JSONObject(), settings=new JSONObject(), model=new JSONObject();
    private JSONArray entries=new JSONArray();
    private LinearLayout content,side,filterBar, page, headingRow, heroActions, metaBadges;
    private TextView heroCounter;
    private Button watchButton, detailButton;
    private ScrollView scroller;
    private TextView heading,heroTitle,heroMeta,heroDescription,status;
    private ImageView heroPoster;
    private ProgressBar spinner;
    private Updater updates;
    private StartupUpdates startupUpdates;
    private LinearLayout heroPanel,heroWords,slideControls;
    private FrameLayout heroFrame;
    private ImageView backdrop;
    private boolean detailedHero;
    private final BannerRotation bannerRotation=new BannerRotation();
    private final List<JSONObject> featured=new ArrayList<>();
    private int featuredIndex;
    private String backdropUrl="";
    private boolean ready,busy,active,polling,board=true,firstFocus=true,ratingsPending=true;
    private int generation, selected;
    private String kind="home", layoutSignature="", focusKey="", currentShelf="";
    private Button activeNav;
    private List<View> previousRail=new ArrayList<>();
    private static final class State {
        final JSONObject item;final JSONArray entries;final boolean board;final String kind,focus;
        State(JSONObject i,JSONArray e,boolean b,String k,String f){item=i;entries=e;board=b;kind=k;focus=f;}
    }
    private final Runnable tick=new Runnable(){public void run(){if(!active)return;if(startupUpdates!=null)startupUpdates.maybeOffer(!busy&&board);rotateBanner();poll();ui.postDelayed(this,1000);}};
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    /** Crisp focus ring, drawn without software blur or repeated broad strokes. */
    private final class CinemaGlow extends android.graphics.drawable.Drawable {
        private final android.graphics.Paint paint=new android.graphics.Paint(3);
        private final int fill,radius; private final boolean focused;
        CinemaGlow(int fill,boolean focused,int radius){this.fill=fill;this.focused=focused;this.radius=radius;}
        public void draw(android.graphics.Canvas c){
            android.graphics.RectF r=new android.graphics.RectF(getBounds());r.inset(dp(5),dp(5));
            paint.setStyle(android.graphics.Paint.Style.FILL);paint.setColor(fill);c.drawRoundRect(r,dp(radius),dp(radius),paint);
            if(focused){paint.setStyle(android.graphics.Paint.Style.STROKE);paint.setStrokeWidth(dp(7));paint.setColor(0x307cdde8);c.drawRoundRect(r,dp(radius),dp(radius),paint);paint.setStrokeWidth(dp(2.5f));paint.setColor(0xfff3fcff);c.drawRoundRect(r,dp(radius),dp(radius),paint);}
        }
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
    }
    private StateListDrawable surface(int normal){StateListDrawable d=new StateListDrawable();d.addState(new int[]{android.R.attr.state_focused},new CinemaGlow(0xff334959,true,10));d.addState(new int[]{android.R.attr.state_pressed},new CinemaGlow(0xff42606e,true,10));d.addState(new int[]{},new CinemaGlow(normal,false,10));return d;}
    private Button button(String title,Runnable action){Button b=new Button(this);b.setId(View.generateViewId());b.setText(title);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setStateListAnimator(null);b.setTextSize(12);b.setSingleLine(true);b.setEllipsize(TextUtils.TruncateAt.END);b.setTextColor(Color.WHITE);b.setPadding(dp(14),0,dp(14),0);b.setBackground(surface(PANEL));b.setOnClickListener(v->action.run());return b;}
    private static JSONObject obj(Object... values){JSONObject o=new JSONObject();try{for(int i=0;i<values.length;i+=2)o.put((String)values[i],values[i+1]);}catch(Exception e){throw new IllegalArgumentException(e);}return o;}
    private static JSONObject copy(JSONObject value){try{return new JSONObject(value.toString());}catch(Exception e){return new JSONObject();}}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);updates=new Updater(this);startupUpdates=new StartupUpdates(this,updates);build();startupUpdates.check();
        AppRuntime.submit(obj("op","state"),answer->{if(isDestroyed())return;ready=answer.optBoolean("ok");settings=answer.optJSONObject("settings");if(settings==null)settings=new JSONObject();if(ready){loadFilters();openBoard("home",true);}else error(answer);});
    }
    private void build(){
        FrameLayout stage=new FrameLayout(this);stage.setBackgroundColor(INK);setContentView(stage);
        backdrop=new ImageView(this);backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);backdrop.setAlpha(1f);backdrop.setVisibility(View.GONE);backdrop.setPadding(0,0,0,0);stage.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xfa0c1017,0xc90c1017,0x180c1017}));stage.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        View fade=new View(this);fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x300c1017,0x150c1017,0xd90c1017,0xff0c1017}));stage.addView(fade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout main=new LinearLayout(this);main.setClipChildren(true);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(32),dp(24),dp(32),dp(12));stage.addView(main,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("MK",23,Color.WHITE);brand.setTypeface(null,Typeface.BOLD);brand.setLetterSpacing(0.10f);top.addView(brand);
        TextView cinema=text("KINO",10,ACCENT);cinema.setLetterSpacing(0.14f);cinema.setPadding(dp(5),dp(8),dp(26),0);top.addView(cinema);
        side=new LinearLayout(this);side.setGravity(Gravity.CENTER_VERTICAL);side.setClipChildren(false);
        nav("Główna",()->openBoard("home",true));nav("Filmy",()->openBoard("movies",true));nav("Seriale",()->openBoard("series",true));nav("Szukaj",this::search);nav("Ulubione",()->openLibrary("favourites","Ulubione"));nav("Oglądaj dalej",()->openLibrary("continue","Oglądaj dalej"));nav("Opcje",this::options);
        top.addView(side,new LinearLayout.LayoutParams(0,dp(44),1));main.addView(top,new LinearLayout.LayoutParams(-1,dp(52)));
        headingRow=new LinearLayout(this);headingRow.setGravity(Gravity.CENTER_VERTICAL);heading=text("Filmy",22,Color.WHITE);heading.setTypeface(null,Typeface.BOLD);headingRow.addView(heading,new LinearLayout.LayoutParams(0,dp(42),0.65f));
        filterBar=new LinearLayout(this);filterBar.setGravity(Gravity.CENTER_VERTICAL);for(int i=0;i<4;i++){final int index=i;filters[i]=button(filterNames[i],()->chooseFilter(index));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(34),1);p.setMargins(dp(6),0,0,0);filterBar.addView(filters[i],p);}headingRow.addView(filterBar,new LinearLayout.LayoutParams(0,dp(42),3.35f));main.addView(headingRow);
        heroFrame=new FrameLayout(this);heroFrame.setClipChildren(true);
        heroPanel=new LinearLayout(this);heroPanel.setPadding(dp(12),dp(22),dp(12),dp(12));heroPanel.setClipChildren(true);heroPoster=new ImageView(this);heroPoster.setScaleType(ImageView.ScaleType.FIT_CENTER);heroPoster.setVisibility(View.GONE);heroPanel.addView(heroPoster,new LinearLayout.LayoutParams(dp(126),-1));
        heroWords=new LinearLayout(this);LinearLayout words=heroWords;words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(6),0,0,0);heroPanel.addView(words,new LinearLayout.LayoutParams(0,-1,1));heroTitle=text("Wybierz film lub serial",28,Color.WHITE);heroTitle.setTypeface(null,Typeface.BOLD);heroTitle.setMaxLines(2);heroTitle.setEllipsize(TextUtils.TruncateAt.END);heroTitle.setLetterSpacing(-0.025f);words.addView(heroTitle);heroMeta=text("",12,ACCENT);heroMeta.setMaxLines(2);heroMeta.setPadding(0,dp(5),0,dp(6));heroMeta.setVisibility(View.GONE);words.addView(heroMeta);metaBadges=new LinearLayout(this);metaBadges.setPadding(0,0,0,dp(12));words.addView(metaBadges,0);heroDescription=text("",14,0xffc6cfda);heroDescription.setId(View.generateViewId());heroDescription.setOnClickListener(v->{if(board&&kind.equals("home"))return;TextView full=text(heroDescription.getText().toString(),17,Color.WHITE);full.setPadding(dp(20),dp(16),dp(20),dp(16));ScrollView scroll=new ScrollView(this);scroll.addView(full);new AlertDialog.Builder(this).setTitle(heroTitle.getText()).setView(scroll).setPositiveButton("Zamknij",null).show();});heroDescription.setMaxLines(6);heroDescription.setEllipsize(TextUtils.TruncateAt.END);heroDescription.setVisibility(View.GONE);words.addView(heroDescription);
        heroActions=new LinearLayout(this);heroActions.setClipChildren(false);heroActions.setGravity(Gravity.CENTER_VERTICAL);heroActions.setPadding(0,dp(12),0,dp(10));
        watchButton=button("▶  Oglądaj teraz",()->{if(!featured.isEmpty())select(featured.get(featuredIndex));});
        watchButton.setTypeface(null,Typeface.BOLD);watchButton.setTextColor(0xffe6fcff);
        detailButton=button("Szczegóły",()->{if(!featured.isEmpty())select(featured.get(featuredIndex));});
        heroActions.addView(watchButton,new LinearLayout.LayoutParams(dp(156),dp(46)));LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(dp(112),dp(46));detailParams.setMargins(dp(10),0,0,0);heroActions.addView(detailButton,detailParams);
        slideControls=new LinearLayout(this);slideControls.setGravity(Gravity.CENTER_VERTICAL);slideControls.setPadding(dp(4),0,dp(4),0);
        Button prev=button("‹",()->stepFeatured(-1)),next=button("›",()->stepFeatured(1));slideControls.addView(prev,new LinearLayout.LayoutParams(dp(36),dp(34)));
        heroCounter=text("01 / 01",12,MUTED);heroCounter.setGravity(Gravity.CENTER);slideControls.addView(heroCounter,new LinearLayout.LayoutParams(dp(70),dp(34)));slideControls.addView(next,new LinearLayout.LayoutParams(dp(36),dp(34)));words.addView(heroActions);
        heroFrame.addView(heroPanel,new FrameLayout.LayoutParams(-1,-1));FrameLayout.LayoutParams controls=new FrameLayout.LayoutParams(-2,dp(40),Gravity.END|Gravity.BOTTOM);controls.setMargins(0,0,dp(12),0);heroFrame.addView(slideControls,controls);heroFrame.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,orr,ob)->{if(r-l!=orr-ol)adjustHeroWidths();});

        scroller=new ScrollView(this);scroller.setClipChildren(true);scroller.setClipToPadding(true);scroller.setVerticalScrollBarEnabled(false);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(9),0,dp(18));content.setClipChildren(false);page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setClipChildren(false);page.addView(heroFrame,new LinearLayout.LayoutParams(-1,dp(67)));page.addView(content,new LinearLayout.LayoutParams(-1,-2));scroller.addView(page,new ScrollView.LayoutParams(-1,-2));main.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER_VERTICAL);spinner=new ProgressBar(this);spinner.setVisibility(View.GONE);footer.addView(spinner,new LinearLayout.LayoutParams(dp(17),dp(17)));status=text("OK  Wybierz     /     Przytrzymaj OK  Ulubione     /     Wstecz  Powrót",10,MUTED);status.setPadding(dp(7),0,0,0);footer.addView(status);main.addView(footer,new LinearLayout.LayoutParams(-1,dp(24)));
    }
    private void nav(String label,Runnable action){Button b=button(label,()->{if(!ready||busy)return;action.run();});b.setId(View.generateViewId());b.setPadding(dp(8),0,dp(8),0);b.setTextSize(12);b.setTypeface(null,Typeface.BOLD);b.setBackground(surface(Color.TRANSPARENT));b.setOnFocusChangeListener((v,has)->{if(has)activeNav=b;});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.setMargins(dp(2),0,dp(2),0);side.addView(b,p);if(activeNav==null)activeNav=b;}
    private void adjustHeroWidths(){
        int width=heroFrame.getWidth();if(width<=0)width=getResources().getDisplayMetrics().widthPixels-dp(48);
        boolean home=board&&kind.equals("home");int wordsWidth=home?Math.round(Math.max(1,width-dp(24))*0.57f):Math.round(width*0.70f)-dp(150);
        LinearLayout.LayoutParams words=(LinearLayout.LayoutParams)heroWords.getLayoutParams();
        if(words.width!=wordsWidth||words.weight!=0){words.width=wordsWidth;words.weight=0;heroWords.setLayoutParams(words);}

    }
    private void heroMode(boolean details){
        detailedHero=details;heroFrame.setVisibility(details?View.VISIBLE:View.GONE);heroPanel.setVisibility(View.VISIBLE);heroPanel.setGravity(Gravity.TOP);heroPanel.setPadding(dp(12),dp(12),dp(12),dp(12));heroWords.setGravity(Gravity.TOP);heroWords.getLayoutParams().height=ViewGroup.LayoutParams.WRAP_CONTENT;heroPanel.setMinimumHeight(dp(220));heroPanel.getLayoutParams().height=ViewGroup.LayoutParams.WRAP_CONTENT;heroDescription.setFocusable(details);heroDescription.setFocusableInTouchMode(false);heroDescription.setPadding(0,0,dp(8),dp(12));
        heroDescription.setMaxWidth(Integer.MAX_VALUE);heroActions.setVisibility(View.GONE);slideControls.setVisibility(View.GONE);headingRow.setVisibility(View.VISIBLE);bannerRotation.reset();heroPanel.setFocusable(false);heroPanel.setClickable(false);heroPanel.setBackground(null);heroTitle.setTextSize(28);heroDescription.setMaxLines(Integer.MAX_VALUE);heroDescription.setEllipsize(null);heroDescription.setTextColor(Color.WHITE);heroDescription.setShadowLayer(dp(2),0,dp(1),Color.BLACK);heroPoster.setVisibility(details?View.VISIBLE:View.GONE);heroPoster.getLayoutParams().height=dp(200);heroDescription.setVisibility(details?View.VISIBLE:View.GONE);heroMeta.setVisibility(View.GONE);metaBadges.setVisibility(View.VISIBLE);backdrop.setVisibility(View.GONE);backdrop.setTag(null);backdropUrl="";
        ViewGroup.LayoutParams p=heroFrame.getLayoutParams();p.height=details?ViewGroup.LayoutParams.WRAP_CONTENT:0;heroFrame.setLayoutParams(p);adjustHeroWidths();
    }
    private void homeHero(){
        detailedHero=true;heroPanel.getLayoutParams().height=ViewGroup.LayoutParams.MATCH_PARENT;heroWords.getLayoutParams().height=ViewGroup.LayoutParams.MATCH_PARENT;heroPanel.setMinimumHeight(0);heroDescription.setFocusable(false);heroDescription.setEllipsize(TextUtils.TruncateAt.END);heroFrame.setVisibility(View.VISIBLE);heroPanel.setVisibility(View.VISIBLE);heroPoster.setVisibility(View.GONE);heroDescription.setVisibility(View.VISIBLE);backdrop.setVisibility(View.VISIBLE);heroTitle.setTextSize(34);heroDescription.setMaxLines(3);heroDescription.setMaxWidth(Integer.MAX_VALUE);heroMeta.setVisibility(View.GONE);metaBadges.setVisibility(View.VISIBLE);heroActions.setVisibility(View.VISIBLE);slideControls.setVisibility(View.VISIBLE);headingRow.setVisibility(View.GONE);heroWords.setGravity(Gravity.BOTTOM);
        int screenHeight=Math.round(getResources().getDisplayMetrics().heightPixels/getResources().getDisplayMetrics().density);ViewGroup.LayoutParams p=heroFrame.getLayoutParams();p.height=dp(Math.round(screenHeight*0.53f));heroFrame.setLayoutParams(p);heroPanel.setGravity(Gravity.BOTTOM);heroPanel.setFocusable(false);heroPanel.setClickable(false);heroPanel.setBackground(null);adjustHeroWidths();
    }
    private void stepFeatured(int direction){if(featured.isEmpty())return;featuredIndex=(featuredIndex+direction+featured.size())%featured.size();showFeatured();bannerRotation.reset();}
    private void showFeatured(){if(featured.isEmpty())return;heroWords.animate().cancel();heroWords.setAlpha(0.5f);heroWords.animate().alpha(1f).setDuration(220).start();showDetail(featured.get(featuredIndex));heroCounter.setText(String.format(Locale.ROOT,"%02d / %02d",featuredIndex+1,featured.size()));}
    private boolean bannerFocus(){View v=getCurrentFocus();return v!=null&&(isInside(v,heroFrame)||isInside(v,side));}
    private void refreshFeatured(JSONArray groups){
        String old=featured.isEmpty()?"":featured.get(featuredIndex).optString("url");featured.clear();Set<String> seen=new HashSet<>();
        for(int pass=0;pass<1;pass++){
            for(int index=0;index<256;index++)for(int row=0;row<groups.length();row++){
                JSONArray items=groups.optJSONObject(row).optJSONArray("items");JSONObject item=items==null?null:items.optJSONObject(index);
                if(item==null||featured.size()>=12||!CinemaLayout.featuredPanorama(item.optString("year"),item.optString("action"),item.optString("backdrop")))continue;
                boolean wide=!item.optString("backdrop").isEmpty();
                if((pass==0&&!wide)||(pass==1&&wide))continue;
                if(seen.add(item.optString("url")))featured.add(item);
            }
            if(featured.size()>=12)break;
        }
        featuredIndex=0;for(int i=0;i<featured.size();i++)if(featured.get(i).optString("url").equals(old)){featuredIndex=i;break;}
        if(featured.isEmpty()){heroTitle.setText("Filmy 2026");heroDescription.setText("Brak panoram filmów z 2026 roku w aktualnie pobranych pozycjach.");metaBadges.removeAllViews();heroCounter.setText("00 / 00");backdrop.setVisibility(View.GONE);backdrop.setTag(null);backdropUrl="";}else if(bannerFocus()){backdrop.setVisibility(View.VISIBLE);showFeatured();}
    }
    private void rotateBanner(){
        boolean allowed=active&&ready&&!busy&&board&&kind.equals("home")&&hasWindowFocus()&&bannerFocus();
        if(bannerRotation.advance(SystemClock.elapsedRealtime(),allowed,featured.size())){featuredIndex=(featuredIndex+1)%featured.size();showFeatured();}
    }
    private void setBusy(boolean value,String label){busy=value;spinner.setVisibility(value?View.VISIBLE:View.GONE);status.setText(label.isEmpty()?"OK  Wybierz     /     Przytrzymaj OK  Ulubione     /     Wstecz  Powrót":label);}
    private void request(JSONObject query,String label,AppRuntime.Callback callback){if(!ready)return;final int token=++generation;setBusy(true,label);AppRuntime.submit(query,result->{if(isDestroyed()||token!=generation)return;setBusy(false,"");if(!result.optBoolean("ok")){error(result);return;}callback.done(result);});}
    private void markSection(String value){for(int i=0;i<side.getChildCount();i++){Button tab=(Button)side.getChildAt(i);boolean chosen=(i==0&&value.equals("home"))||(i==1&&value.equals("movies"))||(i==2&&value.equals("series"))||(i==4&&value.equals("favourites"))||(i==5&&value.equals("continue"));tab.setTextColor(chosen?ACCENT:0xffc0c9d3);tab.setBackground(surface(chosen?0xb3223543:Color.TRANSPARENT));}}
    private void openBoard(String value,boolean clear){if(!ready||busy)return;if(clear)history.clear();kind=value;markSection(value);board=true;heroMode(false);featured.clear();featuredIndex=0;if(kind.equals("home"))homeHero();current=obj("action","tv_board","kind",kind);heading.setText(kind.equals("home")?"Ostatnio dodane":kind.equals("series")?"Seriale":"Filmy");filterBar.setVisibility(kind.equals("movies")?View.VISIBLE:View.GONE);layoutSignature="";model=new JSONObject();focusKey="";firstFocus=!kind.equals("home");content.removeAllViews();scroller.scrollTo(0,0);if(kind.equals("home"))side.getChildAt(0).requestFocus();
        request(obj("op","shelves_start","kind",kind),"Pobieranie katalogu…",answer->{model=answer;renderBoard();});}
    private void openLibrary(String action,String label){markSection(action);history.clear();load(obj("action",action,"title",label),false);}
    private void push(){history.push(new State(copy(current),entries,board,kind,focusKey));}
    private void load(JSONObject item,boolean addHistory){if(!ready||busy)return;if(addHistory)push();board=false;ratingsPending=true;AppRuntime.submit(obj("op","shelves_cancel"),null);current=copy(item);heroMode(Arrays.asList("sources","seasons","episodes").contains(item.optString("action")));filterBar.setVisibility(View.GONE);heading.setText(item.optString("title","Katalog"));
        request(obj("op","browse","item",item),"Pobieranie…",answer->{entries=answer.optJSONArray("items");if(entries==null)entries=new JSONArray();selected=0;focusKey="";renderEntries();if(detailedHero){JSONObject details=copy(current);if(entries.length()>0&&!entries.optJSONObject(0).optString("premium_url").isEmpty())try{details.put("premium_url",entries.optJSONObject(0).optString("premium_url"));}catch(Exception ignored){}final int token=generation;AppRuntime.submit(obj("op","movie_description","item",details),r->{if(isDestroyed()||board||generation!=token)return;String full=r.optString("synopsis");if(!full.isEmpty()){try{current.put("synopsis",full);}catch(Exception ignored){}heroDescription.setText(full);}});}});}
    private String cardKey(String row,JSONObject item,int index){return row+"|"+item.optString("url",item.optString("action"))+"|"+index;}
    private void showDetail(JSONObject entry){if(!detailedHero)return;heroTitle.setText(entry.optString("movie_title",entry.optString("title","")));String info=entry.optString("rating_label");for(String k:new String[]{"year","language_version","progress_label"})if(!entry.optString(k).isEmpty())info+=(info.isEmpty()?"":"  ·  ")+entry.optString(k);heroMeta.setText(info);metaBadges.removeAllViews();for(String value:info.split("  ·  ")){if(value.trim().isEmpty())continue;TextView badge=text(value,11,value.contains("Lektor")||value.contains("Dubbing")?ACCENT:Color.WHITE);badge.setPadding(dp(9),dp(4),dp(9),dp(4));badge.setBackground(shape(0xa61c2935,0,6));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,-2);bp.setMargins(0,0,dp(7),0);metaBadges.addView(badge,bp);}heroDescription.setText(entry.optString("synopsis",entry.optString("desc","")));if(board&&kind.equals("home")){String image=entry.optString("backdrop");if(!image.equals(backdropUrl)){backdropUrl=image;CinemaImages.load(backdrop,image);}}else if(detailedHero){Images.load(heroPoster,entry.optString("icon"));String image=entry.optString("backdrop");if(!image.isEmpty()&&!image.equals(backdropUrl)){backdropUrl=image;backdrop.setVisibility(View.VISIBLE);CinemaImages.load(backdrop,image);}}}
    private boolean hasPoster(JSONArray items){for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);if(x!=null&&!x.optString("icon").isEmpty())return true;}return false;}
    private void clearViews(){previousRail.clear();scores.clear();cards.clear();rails.clear();content.removeAllViews();}
    private void renderBoard(){JSONArray groups=model.optJSONArray("shelves");if(groups==null)return;// Rating text changes are applied in place; they do not rebuild poster views.
        if(kind.equals("home"))refreshFeatured(groups);String nextSignature=structuralSignature(groups);if(nextSignature.equals(layoutSignature)){updateBoardScores(groups);return;}layoutSignature=nextSignature;
        String restore=focusKey;View focused=getCurrentFocus();boolean sideFocus=focused!=null&&isInside(focused,side);boolean heroFocus=focused!=null&&isInside(focused,heroFrame);Map<String,Integer> positions=new HashMap<>();for(Map.Entry<String,HorizontalScrollView> e:rails.entrySet())positions.put(e.getKey(),e.getValue().getScrollX());int top=scroller.getScrollY();clearViews();
        for(int i=0;i<groups.length();i++){JSONObject group=groups.optJSONObject(i);if(group==null)continue;JSONArray items=group.optJSONArray("items");if(items==null)items=new JSONArray();if(kind.equals("home"))addShelf(group.optString("id"),group.optString("title"),items,group.optJSONObject("next"),group.optBoolean("loading"),group.optBoolean("error"),true);else addGrid(group.optString("id"),items,group.optJSONObject("next"),group.optBoolean("loading"),group.optBoolean("error"),true);}
        for(Map.Entry<String,Integer> e:positions.entrySet()){HorizontalScrollView rail=rails.get(e.getKey());if(rail!=null)rail.post(()->rail.scrollTo(e.getValue(),0));}scroller.post(()->scroller.scrollTo(0,top));
        if(cards.containsKey(restore)&&!sideFocus&&!heroFocus)cards.get(restore).requestFocus();else if(firstFocus&&!cards.isEmpty()){View first=cards.values().iterator().next();first.requestFocus();firstFocus=false;}else if(sideFocus&&activeNav!=null)activeNav.requestFocus();
        boolean loading=false;for(int i=0;i<groups.length();i++)loading|=groups.optJSONObject(i).optBoolean("loading");spinner.setVisibility(loading?View.VISIBLE:View.GONE);
    }
    private static boolean isInside(View view,ViewGroup parent){for(android.view.ViewParent p=view.getParent();p!=null;p=p.getParent())if(p==parent)return true;return false;}
    private String structuralSignature(JSONArray groups){StringBuilder b=new StringBuilder();for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);b.append(s.optString("id")).append(s.optBoolean("loading")).append(s.optBoolean("error"));JSONArray xs=s.optJSONArray("items");if(xs!=null)for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);b.append(x.optString("url")).append(x.optString("title")).append(x.optBoolean("watched"));}b.append(s.has("next")&&!s.isNull("next"));}return b.toString();}
    private void updateBoardScores(JSONArray groups){for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);JSONArray xs=s.optJSONArray("items");if(xs==null)continue;for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);String k=cardKey(s.optString("id"),x,j);TextView score=scores.get(k);if(score!=null)score.setText("compact".equals(score.getTag())?compactScore(x):x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey)&&!(board&&kind.equals("home")))showDetail(x);}}}
    private void renderEntries(){clearViews();if(detailedHero)showDetail(current);if(current.optString("action").equals("sources")&&entries.length()>0){sourceShelf();return;}if(entries.length()==0){TextView empty=text("Brak pozycji. Wróć lub zmień filtr.",18,MUTED);empty.setPadding(dp(12),dp(24),0,0);content.addView(empty);return;}
        if(current.optString("action").equals("seasons")){seriesEntries();return;}
        boolean posters=(hasPoster(entries)||current.optString("action").equals("episodes"))&&!current.optString("action").equals("sources");if(posters){addGrid("entries",entries,null,false,false,false);View restore=cards.get(focusKey);if(restore!=null)restore.requestFocus();else if(!cards.isEmpty())cards.values().iterator().next().requestFocus();}
        else for(int i=0;i<entries.length();i++){final int index=i;JSONObject entry=entries.optJSONObject(i);if(entry==null)continue;Button b=button(entry.optString("title"),()->select(entry));b.setTextSize(16);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setOnFocusChangeListener((v,has)->{if(has){selected=index;showDetail(entry);}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,0,0,dp(8));content.addView(b,p);if(i==selected)b.requestFocus();}}
    private void seriesEntries(){
        boolean seasons=current.optString("action").equals("seasons");List<View> rows=new ArrayList<>();
        int viewport=content.getWidth();if(viewport<=0)viewport=getResources().getDisplayMetrics().widthPixels-dp(48);
        for(int i=0;i<entries.length();i++){
            final int index=i;JSONObject entry=entries.optJSONObject(i);if(entry==null)continue;String key=cardKey("entries",entry,i);
            LinearLayout tile=new LinearLayout(this);tile.setId(View.generateViewId());tile.setTag(entry);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER_VERTICAL);tile.setPadding(dp(20),dp(12),dp(20),dp(12));tile.setBackground(surface(PANEL));tile.setFocusable(true);tile.setClickable(true);
            TextView title=text(entry.optString("title"),17,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);tile.addView(title,new LinearLayout.LayoutParams(-1,-2));
            String info=entry.optString("language_version");String progress=entry.optString("progress_label");if(!progress.isEmpty())info+=(info.isEmpty()?"":"  ·  ")+progress;
            if(!info.isEmpty()){TextView meta=text(info,12,MUTED);meta.setSingleLine(true);meta.setEllipsize(TextUtils.TruncateAt.END);tile.addView(meta,new LinearLayout.LayoutParams(-1,-2));}
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(seasons?Math.min(dp(300),viewport-dp(24)):viewport-dp(24),dp(84));params.setMargins(dp(12),0,dp(12),dp(8));content.addView(tile,params);cards.put(key,tile);rows.add(tile);
            tile.setOnClickListener(v->select((JSONObject)tile.getTag()));tile.setOnFocusChangeListener((v,has)->{title.setTextColor(has?ACCENT:Color.WHITE);if(has){selected=index;focusKey=key;}});
        }
        for(int i=0;i<rows.size();i++){View tile=rows.get(i);tile.setNextFocusUpId(i>0?rows.get(i-1).getId():activeNav.getId());if(i+1<rows.size())tile.setNextFocusDownId(rows.get(i+1).getId());}
        View restore=cards.get(focusKey);if(restore!=null)restore.requestFocus();else if(!rows.isEmpty())rows.get(0).requestFocus();
    }
    private String compactScore(JSONObject item){if(item.has("rating"))return "★ "+String.format(Locale.ROOT,"%.1f",item.optDouble("rating")).replace('.',',');return item.optString("rating_label").contains("sprawdzanie")?"Filmweb …":"";}
    private void addGrid(String id,JSONArray items,JSONObject next,boolean loading,boolean failed,boolean remote){
        if(items.length()==0){Button retry=button(loading?"Ładowanie katalogu…":failed?"Spróbuj ponownie":"Brak pozycji",()->more(id));retry.setEnabled(!loading&&failed);content.addView(retry,new LinearLayout.LayoutParams(-1,dp(75)));return;}
        GridLayout grid=new GridLayout(this);grid.setColumnCount(5);grid.setClipChildren(false);grid.setClipToPadding(false);grid.setPadding(dp(12),dp(12),dp(12),dp(12));content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        List<View> cells=new ArrayList<>();int viewport=content.getWidth();if(viewport<=0)viewport=getResources().getDisplayMetrics().widthPixels-dp(48);int cellWidth=CinemaLayout.cellWidth(viewport,5,dp(12),dp(10));int posterHeight=Math.max(90,Math.min(270,Math.round((cellWidth/getResources().getDisplayMetrics().density-10)*1.48f)));
        for(int i=0;i<items.length();i++){final int index=i;JSONObject item=items.optJSONObject(i);if(item==null)continue;String key=cardKey(id,item,i);LinearLayout card=new LinearLayout(this);card.setTag(item);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(5),dp(5),dp(5),dp(8));card.setFocusable(true);card.setClickable(true);card.setBackgroundColor(Color.TRANSPARENT);card.setClipChildren(false);card.setId(View.generateViewId());
            FrameLayout artwork=posterArtwork(item,posterHeight);
            card.addView(artwork,new LinearLayout.LayoutParams(-1,dp(posterHeight)));
            LinearLayout details=new LinearLayout(this);details.setPadding(dp(3),dp(6),dp(2),0);TextView type=text(CinemaLayout.itemType(board?"":current.optString("action"),item.optString("action")),10,MUTED);details.addView(type,new LinearLayout.LayoutParams(0,-2,1));TextView rating=text(compactScore(item),10,ACCENT);rating.setTag("compact");rating.setSingleLine();rating.setEllipsize(TextUtils.TruncateAt.END);details.addView(rating);card.addView(details);scores.put(key,rating);
            TextView title=text((item.optBoolean("watched")?"✓ ":"")+item.optString("title"),13,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setMaxLines(2);title.setMinHeight(dp(36));title.setEllipsize(TextUtils.TruncateAt.END);title.setPadding(dp(3),dp(3),dp(3),0);card.addView(title);TextView language=text(item.optString("language_version"),11,0xffb9cfdd);language.setMaxLines(1);language.setPadding(dp(3),dp(3),0,0);card.addView(language);
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(i/5),GridLayout.spec(i%5));gp.width=cellWidth;gp.height=-2;gp.setMargins(0,0,i%5<4?dp(10):0,dp(15));grid.addView(card,gp);cards.put(key,card);cells.add(card);
            card.setOnFocusChangeListener((v,has)->{card.animate().scaleX(has?1.035f:1).scaleY(has?1.035f:1).setDuration(160).start();artwork.setForeground(new CinemaGlow(0,has,9));title.setTextColor(has?ACCENT:Color.WHITE);if(has){focusKey=key;currentShelf=id;selected=index;if(!(board&&kind.equals("home")))showDetail((JSONObject)card.getTag());if(remote&&next!=null&&!loading&&index>=items.length()-5)more(id);}});card.setOnClickListener(v->select((JSONObject)card.getTag()));card.setOnLongClickListener(v->{favourite((JSONObject)card.getTag());return true;});
        }
        for(int i=0;i<cells.size();i++){View cell=cells.get(i);cell.setNextFocusLeftId((i%5>0?cells.get(i-1):cell).getId());cell.setNextFocusRightId((i%5<4&&i+1<cells.size()?cells.get(i+1):cell).getId());cell.setNextFocusUpId(i>=5?cells.get(i-5).getId():(filterBar.getVisibility()==View.VISIBLE?filters[Math.min(i,3)].getId():activeNav.getId()));if(i+5<cells.size())cell.setNextFocusDownId(cells.get(i+5).getId());else if(i/5<(cells.size()-1)/5)cell.setNextFocusDownId(cells.get(cells.size()-1).getId());}
        if(next!=null||loading||failed){Button more=button(loading?"Pobieranie kolejnych pozycji…":failed?"Ponów pobieranie":"Pokaż więcej",()->{if(remote)more(id);else select(next);});more.setEnabled(!loading);content.addView(more,new LinearLayout.LayoutParams(-1,dp(42)));}
    }
    private FrameLayout posterArtwork(JSONObject item,int height){
        FrameLayout outer=new FrameLayout(this);outer.setClipChildren(true);outer.setClipToPadding(true);outer.setPadding(dp(7),dp(7),dp(7),dp(7));
        FrameLayout art=new FrameLayout(this);art.setBackground(shape(0xff141d28,0,9));art.setClipToOutline(true);outer.addView(art,new FrameLayout.LayoutParams(-1,-1));
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);art.addView(image,new FrameLayout.LayoutParams(-1,-1));Images.load(image,item.optString("icon"));
        if(!item.optString("year").isEmpty()){TextView year=text(item.optString("year"),12,Color.WHITE);year.setTypeface(null,Typeface.BOLD);year.setPadding(dp(8),dp(3),dp(8),dp(3));year.setBackground(shape(0xd90c1017,0,5));FrameLayout.LayoutParams yp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);yp.setMargins(dp(9),dp(8),0,0);art.addView(year,yp);}
        outer.setForeground(new CinemaGlow(0,false,16));return outer;
    }
    private void addShelf(String id,String label,JSONArray items,JSONObject next,boolean loading,boolean failed,boolean remote){
        TextView title=text(label,17,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(12),dp(12),0,dp(2));content.addView(title);
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);scroll.setClipToPadding(false);scroll.setClipChildren(false);
        LinearLayout row=new LinearLayout(this);row.setClipChildren(false);row.setClipToPadding(false);row.setPadding(dp(12),dp(18),dp(18),dp(18));scroll.addView(row,new HorizontalScrollView.LayoutParams(-2,-2));rails.put(id,scroll);content.addView(scroll,new LinearLayout.LayoutParams(-1,-2));
        List<View> railCards=new ArrayList<>();int width=Math.max(140,Math.round(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density/6.3f));
        for(int i=0;i<items.length();i++){final int index=i;JSONObject item=items.optJSONObject(i);if(item==null)continue;String key=cardKey(id,item,i);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setClipChildren(false);card.setClipToPadding(false);card.setTag(item);card.setFocusable(true);card.setClickable(true);card.setId(View.generateViewId());
            FrameLayout art=posterArtwork(item,width*3/2);card.addView(art,new LinearLayout.LayoutParams(-1,dp(width*3/2)));
            LinearLayout meta=new LinearLayout(this);meta.setPadding(0,dp(7),0,0);TextView type=text(CinemaLayout.itemType(board?"":current.optString("action"),item.optString("action")),11,MUTED);meta.addView(type,new LinearLayout.LayoutParams(0,-2,1));TextView score=text(compactScore(item),11,ACCENT);score.setTag("compact");meta.addView(score);card.addView(meta);scores.put(key,score);
            TextView name=text((item.optBoolean("watched")?"✓ ":"")+item.optString("title"),14,Color.WHITE);name.setTypeface(null,Typeface.BOLD);name.setMaxLines(2);name.setMinHeight(dp(38));name.setEllipsize(TextUtils.TruncateAt.END);card.addView(name);
            TextView lang=text(item.optString("language_version"),11,0xffdfdbea);lang.setSingleLine(true);card.addView(lang);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(width),-2);cp.setMargins(0,0,dp(18),0);row.addView(card,cp);cards.put(key,card);railCards.add(card);
            card.setOnFocusChangeListener((v,has)->{art.setForeground(new CinemaGlow(0,has,9));name.setTextColor(has?ACCENT:Color.WHITE);card.animate().scaleX(has?1.045f:1).scaleY(has?1.045f:1).setDuration(160).start();if(has){focusKey=key;currentShelf=id;selected=index;scroll.post(()->scroll.smoothScrollTo(Math.max(0,card.getLeft()-dp(16)),0));}});
            card.setOnClickListener(v->select((JSONObject)card.getTag()));card.setOnLongClickListener(v->{favourite((JSONObject)card.getTag());return true;});
        }
        for(int j=0;j<railCards.size();j++){View tile=railCards.get(j);tile.setNextFocusLeftId(railCards.get(Math.max(0,j-1)).getId());if(j+1<railCards.size())tile.setNextFocusRightId(railCards.get(j+1).getId());tile.setNextFocusUpId(previousRail.isEmpty()?watchButton.getId():previousRail.get(Math.min(j,previousRail.size()-1)).getId());}
        if(!railCards.isEmpty()){for(int j=0;j<previousRail.size();j++)previousRail.get(j).setNextFocusDownId(railCards.get(Math.min(j,railCards.size()-1)).getId());if(previousRail.isEmpty()){watchButton.setNextFocusDownId(railCards.get(0).getId());detailButton.setNextFocusDownId(railCards.get(0).getId());}previousRail=railCards;}
        if(items.length()==0||next!=null||loading||failed){Button more=button(loading?"Ładowanie…":failed?"Ponów":"Więcej  →",()->{if(remote)more(id);else if(next!=null)select(next);});more.setEnabled(!loading);row.addView(more,new LinearLayout.LayoutParams(dp(130),dp(100)));}
    }
    private void sourceShelf(){
        TextView label=text("Wybierz hosting",20,Color.WHITE);label.setTypeface(null,Typeface.BOLD);label.setPadding(dp(12),dp(12),0,0);content.addView(label);
        HorizontalScrollView rail=new HorizontalScrollView(this);rail.setHorizontalScrollBarEnabled(false);rail.setClipChildren(false);rail.setClipToPadding(false);LinearLayout row=new LinearLayout(this);row.setClipChildren(false);row.setPadding(dp(14),dp(20),dp(14),dp(20));rail.addView(row);content.addView(rail);
        for(int i=0;i<entries.length();i++){JSONObject entry=entries.optJSONObject(i);if(entry==null)continue;final int index=i;
            LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER_VERTICAL);tile.setPadding(dp(18),dp(10),dp(18),dp(10));tile.setBackground(surface(PANEL));tile.setFocusable(true);tile.setClickable(true);
            String provider=entry.optString("provider");String title=entry.optString("title");if(provider.isEmpty())provider=title.split(" · ")[0];TextView name=text(provider,20,Color.WHITE);name.setTypeface(null,Typeface.BOLD);name.setSingleLine(true);tile.addView(name);TextView meta=text(title.equals(provider)?entry.optString("language_version"):title.replace(provider," ").trim(),13,ACCENT);meta.setMaxLines(2);tile.addView(meta);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(220),dp(78));lp.setMargins(0,0,dp(18),0);row.addView(tile,lp);tile.setOnClickListener(v->select(entry));tile.setOnFocusChangeListener((v,has)->{if(has){selected=index;showDetail(current);}});tile.setNextFocusUpId(heroDescription.getId());if(i==selected)tile.requestFocus();
        }
    }
    private void more(String shelf){if(busy||!board)return;final int token=generation;AppRuntime.submit(obj("op","shelves_more","shelf",shelf),r->{if(isDestroyed()||!board||token!=generation)return;model=r;renderBoard();});}
    private void poll(){if(!ready||busy||polling)return;if(board&&model.has("shelves")&&!model.optBoolean("pending",true))return;if(!board&&!ratingsPending)return;polling=true;final int token=generation;final boolean wasBoard=board;JSONObject query=board?obj("op","shelves_poll"):obj("op","filmweb_ratings","items",entries);
        AppRuntime.submit(query,r->{polling=false;if(!active||isDestroyed()||token!=generation||wasBoard!=board||!r.optBoolean("ok"))return;if(board){model=r;renderBoard();}else{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()!=entries.length())return;ratingsPending=r.optBoolean("pending");entries=xs;for(int i=0;i<xs.length();i++){JSONObject x=xs.optJSONObject(i);String k=cardKey("entries",x,i);TextView score=scores.get(k);if(score!=null)score.setText("compact".equals(score.getTag())?compactScore(x):x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey)&&!(board&&kind.equals("home")))showDetail(x);}}});}
    private void select(JSONObject item){if(item==null||busy)return;String action=item.optString("action");if(action.equals("search")){search();return;}if(action.equals("resolve")){resolve(item);return;}load(item,true);}
    private void favourite(JSONObject item){if(busy||item==null)return;String action=item.optString("action");if(!Arrays.asList("sources","seasons","resolve").contains(action))return;request(obj("op","favourite","item",item),"Zapisywanie…",r->{Toast.makeText(this,r.optBoolean("added")?"Dodano do ulubionych":"Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(current.optString("action").equals("favourites"))load(current,false);});}
    private JSONObject selectedItem(){View view=cards.get(focusKey);if(view!=null&&view.getTag() instanceof JSONObject)return (JSONObject)view.getTag();JSONObject row=entries.optJSONObject(selected);return row==null?new JSONObject():row;}
    private void loadFilters(){AppRuntime.submit(obj("op","movie_filter_state"),r->{JSONObject labels=r.optJSONObject("filter_labels");if(labels!=null)for(int i=0;i<4;i++)filters[i].setText(filterNames[i]+": "+labels.optString(filterKeys[i]));});}
    private void chooseFilter(int index){if(busy||!board||!kind.equals("movies"))return;request(obj("op","movie_filter_options","filter",filterKeys[index]),"Otwieranie filtra…",r->{JSONArray xs=r.optJSONArray("choices");if(xs==null)return;String[] labels=new String[xs.length()];for(int i=0;i<labels.length;i++)labels[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle(filterNames[index]).setItems(labels,(dialog,n)->request(obj("op","movie_filter_set","filter",filterKeys[index],"value",xs.optJSONObject(n).optString("id")),"Zapisywanie…",answer->{loadFilters();openBoard("movies",true);})).setNegativeButton("Wróć",null).show();});}
    private void search(){if(busy)return;EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Tytuł filmu lub serialu");AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Szukaj w filmach i serialach").setView(input).setPositiveButton("Szukaj",(d,w)->{String term=input.getText().toString().trim();if(!term.isEmpty())load(obj("action","search_results","query",term,"title","Szukaj: "+term),true);}).setNegativeButton("Wróć",null).create();dialog.setOnShowListener(d->{input.requestFocus();dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});dialog.show();}
    private void options(){if(busy)return;String[] labels={"Dodaj / usuń z ulubionych","Odśwież katalog","Jakość: "+(settings.optBoolean("auto_play",true)?"automatyczna":"wybór ręczny"),"Sprawdź aktualizację","Aktualizacje przy starcie: "+(startupUpdates.enabled()?"włączone":"wyłączone"),"Autor i kontakt"};new AlertDialog.Builder(this).setTitle("Ustawienia MK Kino").setItems(labels,(d,n)->{if(n==0)favourite(selectedItem());if(n==1){if(board){AppRuntime.submit(obj("op","shelves_invalidate"),null);openBoard(kind,true);}else load(current,false);}if(n==2)request(obj("op","settings","key","auto_play","value",!settings.optBoolean("auto_play",true)),"Zapisywanie…",r->settings=r.optJSONObject("settings"));if(n==3)updates.check();if(n==4){startupUpdates.toggle();Toast.makeText(this,startupUpdates.enabled()?"Sprawdzanie przy starcie włączone":"Sprawdzanie przy starcie wyłączone",Toast.LENGTH_SHORT).show();}if(n==5)new AlertDialog.Builder(this).setTitle("MK Kino 0.6.6 · Cinema").setMessage("Projekt i rozwój: MK\nKontakt: bimer535@wp.pl\nGPL-3.0").setPositiveButton("OK",null).show();}).show();}
    private void resolve(JSONObject item){request(obj("op","resolve","item",item),"Pobieranie źródła… Wstecz: anuluj",r->{JSONArray xs=r.optJSONArray("variants");if(xs==null||xs.length()==0){error(obj("message","Brak dostępnego wariantu. Wybierz inne źródło."));return;}if(settings.optBoolean("auto_play",true)){play(item,r.optInt("preferred",0));return;}String[] names=new String[xs.length()];for(int i=0;i<names.length;i++)names[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle("Jakość filmu").setItems(names,(d,n)->play(item,n)).setNegativeButton("Wróć",null).show();});}
    private void play(JSONObject item,int index){request(obj("op","play","item",item,"index",index),"Uruchamianie…",r->{JSONObject progress=r.optJSONObject("progress");long position=progress==null?0:progress.optLong("position");if(position>=15&&!progress.optBoolean("completed"))new AlertDialog.Builder(this).setTitle("Kontynuować oglądanie?").setMessage("Wznowić od "+stamp(position)+"?").setPositiveButton("Wznów",(d,w)->launch(item,r,position)).setNegativeButton("Od początku",(d,w)->launch(item,r,0)).show();else launch(item,r,0);});}
    private void launch(JSONObject item,JSONObject stream,long position){Intent intent=new Intent(this,CinemaPlayerActivity.class);intent.putExtra("entry",item.toString());intent.putExtra("stream",stream.toString());intent.putExtra("position",position);startActivityForResult(intent,200);}
    private String stamp(long t){return String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60);}
    private void error(JSONObject answer){new AlertDialog.Builder(this).setTitle("Nie udało się otworzyć").setMessage(answer.optString("message","Spróbuj ponownie później.")).setPositiveButton("OK",null).show();}
    @Override public void onBackPressed(){if(busy){try{Class.forName("pl.mk.ekino.tv.Pow").getDeclaredMethod("cancel").invoke(null);}catch(Exception ignored){}generation++;setBusy(false,"");return;}if(!history.isEmpty()){State old=history.pop();if(old.board){String target=old.focus;openBoard(old.kind,false);focusKey=target;firstFocus=false;}else{board=false;current=old.item;entries=old.entries;kind=old.kind;focusKey=old.focus;heroMode(Arrays.asList("sources","seasons","episodes").contains(current.optString("action")));heading.setText(current.optString("title"));filterBar.setVisibility(View.GONE);renderEntries();}}else if(!board)openBoard("movies",true);else new AlertDialog.Builder(this).setTitle("Zamknąć MK Kino?").setPositiveButton("Wyjdź",(d,w)->finish()).setNegativeButton("Zostań",null).show();}
    @Override public boolean dispatchKeyEvent(KeyEvent event){if(event.getAction()==KeyEvent.ACTION_UP){if(event.getKeyCode()==KeyEvent.KEYCODE_MENU){options();return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_YELLOW){if(board&&kind.equals("movies"))chooseFilter(0);return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_BLUE){if(!busy)updates.check();return true;}}return super.dispatchKeyEvent(event);}
    @Override protected void onActivityResult(int code,int result,Intent data){if(code==210){updates.installPending();return;}if(code!=200){super.onActivityResult(code,result,data);return;}AppRuntime.submit(obj("op","stop"),null);if(data!=null&&data.getBooleanExtra("next",false)){try{JSONObject item=new JSONObject(data.getStringExtra("entry"));item.put("action","next_episode");request(obj("op","browse","item",item),"Następny odcinek…",r->{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()==0){Toast.makeText(this,"Brak następnego odcinka",Toast.LENGTH_SHORT).show();return;}load(xs.optJSONObject(0),true);});}catch(Exception ignored){}}else if(current.optString("action").equals("continue"))load(current,false);}
    @Override protected void onResume(){super.onResume();active=true;ui.removeCallbacks(tick);ui.postDelayed(tick,600);}
    @Override protected void onPause(){active=false;bannerRotation.reset();ui.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){active=false;ui.removeCallbacksAndMessages(null);if(startupUpdates!=null)startupUpdates.close();backdrop.setTag(null);super.onDestroy();}
}
