package pl.mk.ekino.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Quiet startup discovery, with an explicit download confirmation. */
final class StartupUpdates {
    private static final String ADDRESS="https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/update.json";
    private static final ExecutorService NETWORK=Executors.newSingleThreadExecutor();
    private final Activity activity;
    private final Updater updater;
    private final SharedPreferences preferences;
    private final StartupUpdateState<UpdatePlan> state;
    private Future<?> job;
    private volatile boolean closed;
    private volatile HttpURLConnection connection;
    StartupUpdates(Activity activity,Updater updater){this.activity=activity;this.updater=updater;preferences=activity.getSharedPreferences("mk-update-options",Activity.MODE_PRIVATE);state=new StartupUpdateState<>(preferences.getBoolean("check_at_start",true));}
    boolean enabled(){return state.isEnabled();}
    void toggle(){boolean value=!state.isEnabled();preferences.edit().putBoolean("check_at_start",value).apply();state.setEnabled(value);if(value)check();}
    void check(){if(!state.begin())return;job=NETWORK.submit(()->{
        HttpURLConnection current=null;
        try{
            PackageInfo installed=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0);
            long code=Build.VERSION.SDK_INT>=28?installed.getLongVersionCode():installed.versionCode;
            current=(HttpURLConnection)new URL(ADDRESS+"?t="+System.currentTimeMillis()).openConnection();connection=current;
            current.setConnectTimeout(6000);current.setReadTimeout(6000);current.setInstanceFollowRedirects(false);current.setRequestProperty("Cache-Control","no-cache");
            if(current.getResponseCode()!=200)return;
            byte[] body;
            try(InputStream input=current.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int count;
                while(!closed&&(count=input.read(buffer))!=-1){if(output.size()+count>65536)return;output.write(buffer,0,count);}body=output.toByteArray();
            }
            if(closed)return;
            UpdatePlan plan=UpdatePlan.parse(new JSONObject(new String(body,StandardCharsets.UTF_8)));
            state.completed(code,plan.code,plan);
        }catch(Exception ignored){
            // A quiet check must not interrupt the catalogue when offline or up to date.
        }finally{if(current!=null)current.disconnect();connection=null;}
    });}
    void maybeOffer(boolean foregroundReady){if(closed||activity.isDestroyed()||activity.isFinishing()||!activity.hasWindowFocus())return;UpdatePlan plan=state.take(foregroundReady);if(plan==null)return;
        new AlertDialog.Builder(activity).setTitle("Dostępna aktualizacja "+plan.version).setMessage(plan.notes)
            .setPositiveButton("Aktualizuj",(dialog,which)->download(plan)).setNegativeButton("Później",null).show();
    }
    private void download(UpdatePlan plan){if(closed||activity.isDestroyed())return;try{
        Method method=Updater.class.getDeclaredMethod("download",UpdatePlan.class);method.setAccessible(true);method.invoke(updater,plan);
    }catch(Exception error){new AlertDialog.Builder(activity).setMessage("Nie udało się rozpocząć pobierania. Wybierz MENU → Sprawdź aktualizację.").setPositiveButton("OK",null).show();}}
    void close(){closed=true;state.close();if(job!=null)job.cancel(true);HttpURLConnection current=connection;if(current!=null)current.disconnect();}
}
