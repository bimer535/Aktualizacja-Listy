package pl.mk.ekino.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Banner images keep their native quality instead of using the poster thumbnail cache. */
final class CinemaImages {
    private static final ExecutorService jobs=Executors.newFixedThreadPool(2);
    private static final Handler main=new Handler(Looper.getMainLooper());
    private static final LruCache<String,Bitmap> cache=new LruCache<String,Bitmap>(24*1024*1024){
        protected int sizeOf(String key,Bitmap bitmap){return bitmap.getByteCount();}
    };
    static void load(ImageView view,String address){
        String tag="banner:"+address;view.setTag(tag);view.setImageDrawable(null);
        if(address.isEmpty())return;
        Bitmap found=cache.get(address);if(found!=null){view.setScaleType(found.getWidth()>found.getHeight()*1.3f?ImageView.ScaleType.CENTER_CROP:ImageView.ScaleType.FIT_CENTER);view.setImageBitmap(found);return;}
        WeakReference<ImageView> target=new WeakReference<>(view);
        jobs.execute(()->{
            HttpURLConnection connection=null;
            try{
                URL url=new URL(address);String host=url.getHost();
                if(!"https".equals(url.getProtocol())||url.getUserInfo()!=null||(url.getPort()!=-1&&url.getPort()!=443)||
                   !("image.tmdb.org".equals(host)||"ekino.ws".equals(host)||host.endsWith(".ekino.ws")))return;
                connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(8000);connection.setReadTimeout(8000);connection.setInstanceFollowRedirects(false);
                if(connection.getResponseCode()!=200)return;
                byte[] body;
                try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int count;
                    while((count=input.read(buffer))!=-1){if(output.size()+count>8*1024*1024)return;output.write(buffer,0,count);}body=output.toByteArray();
                }
                BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
                BitmapFactory.decodeByteArray(body,0,body.length,options);
                if(options.outWidth<1||options.outHeight<1||(long)options.outWidth*options.outHeight>32000000)return;
                options.inSampleSize=CinemaLayout.imageSample(options.outWidth,options.outHeight,1920,1080);
                options.inJustDecodeBounds=false;options.inScaled=false;options.inPreferredConfig=Bitmap.Config.ARGB_8888;
                Bitmap bitmap=BitmapFactory.decodeByteArray(body,0,body.length,options);if(bitmap==null)return;
                cache.put(address,bitmap);
                main.post(()->{ImageView current=target.get();if(current!=null&&tag.equals(current.getTag())){current.setScaleType(bitmap.getWidth()>bitmap.getHeight()*1.3f?ImageView.ScaleType.CENTER_CROP:ImageView.ScaleType.FIT_CENTER);current.setImageBitmap(bitmap);}});
            }catch(Exception ignored){}finally{if(connection!=null)connection.disconnect();}
        });
    }
}
