package pl.mk.ekino.tv;
/** Monotonic five-second rotation, restarted after any interruption. */
final class BannerRotation {
    static final long INTERVAL_MS=5000;
    private long next;
    private boolean running;
    boolean advance(long now,boolean allowed,int count){
        if(!allowed||count<2){running=false;return false;}
        if(!running){running=true;next=now+INTERVAL_MS;return false;}
        if(now<next)return false;
        next=now+INTERVAL_MS;return true;
    }
    void reset(){running=false;}
}
