package pl.mk.ekino.tv;

/** Layout measurements shared by the TV screens, independent of item count. */
final class CinemaLayout {
    static boolean featuredPanorama(String year,String action,String backdrop){return featuredMovie(year,action)&&backdrop!=null&&!backdrop.trim().isEmpty();}
    static boolean featuredMovie(String year,String action){return "2026".equals(year)&&"sources".equals(action);}
    static int cellWidth(int viewport,int columns,int inset,int gap){
        if(columns<1||viewport<1||inset<0||gap<0)throw new IllegalArgumentException();
        return Math.max(1,(viewport-2*inset-gap*(columns-1))/columns);
    }
    static int homeTextWidth(int viewport){return Math.max(1,Math.round(viewport*0.44f));}
    static int homeHeight(int heightDp){return Math.max(220,Math.min(280,Math.round(heightDp*0.50f)));}
    static int imageSample(int width,int height,int maxWidth,int maxHeight){
        if(width<1||height<1||maxWidth<1||maxHeight<1)throw new IllegalArgumentException();
        int sample=1;
        while(width/sample>maxWidth||height/sample>maxHeight)sample*=2;
        return sample;
    }
    static String itemType(String context,String action){
        if("seasons".equals(context))return "Sezon";
        if("episodes".equals(context))return "Odcinek";
        return "seasons".equals(action)?"Serial":"Film";
    }
}
