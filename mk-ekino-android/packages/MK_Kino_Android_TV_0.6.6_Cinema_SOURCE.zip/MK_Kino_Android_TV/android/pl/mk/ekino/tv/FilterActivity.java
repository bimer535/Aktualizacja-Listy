package pl.mk.ekino.tv;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.List;

/** Filter toolbar for the existing MK Kino activity and playback flow. */
public final class FilterActivity extends MainActivity {
    private static final String[] KEYS = {"genre", "language", "year", "sort"};
    private static final String[] NAMES = {"Gatunek", "Język", "Rok", "Sortowanie"};
    private final Button[] buttons = new Button[4];
    private Field currentField, busyField, readyField, rowsField, stackField;
    private Method requestMethod, loadMethod;
    private LinearLayout filterBar;
    private JSONObject filters = new JSONObject(), filterLabels = new JSONObject();
    private boolean stateRequested, stateLoaded;
    private int focusAfterLoad = -1;
    private ViewTreeObserver.OnGlobalLayoutListener layoutListener;
    private Field entriesField, selectedField;
    private Method detailMethod;
    private final Handler ratingsHandler = new Handler(Looper.getMainLooper());
    private JSONArray lastRatingsEntries;
    private boolean ratingsActive, ratingsRequested, ratingsPending = true;
    private final Runnable ratingsTick = new Runnable() {
        @Override public void run() {
            if (!ratingsActive || isDestroyed()) return;
            refreshRatings();
            ratingsHandler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        try {
            currentField = field(MainActivity.class, "current");
            busyField = field(MainActivity.class, "busy");
            readyField = field(MainActivity.class, "ready");
            rowsField = field(MainActivity.class, "rows");
            stackField = field(MainActivity.class, "stack");
            entriesField = field(MainActivity.class, "entries");
            selectedField = field(MainActivity.class, "selected");
            detailMethod = MainActivity.class.getDeclaredMethod("detail", JSONObject.class);
            detailMethod.setAccessible(true);
            requestMethod = MainActivity.class.getDeclaredMethod(
                    "request", JSONObject.class, String.class, AppRuntime.Callback.class);
            requestMethod.setAccessible(true);
            loadMethod = MainActivity.class.getDeclaredMethod("load", JSONObject.class, boolean.class);
            loadMethod.setAccessible(true);
            LinearLayout root = (LinearLayout) field(MainActivity.class, "root").get(this);
            filterBar = new LinearLayout(this);
            filterBar.setOrientation(LinearLayout.HORIZONTAL);
            filterBar.setPadding(0, dp(9), 0, dp(3));
            for (int i = 0; i < buttons.length; i++) {
                final int index = i;
                Button button = new Button(this);
                button.setId(View.generateViewId());
                button.setAllCaps(false);
                button.setTextSize(13);
                button.setTextColor(Color.WHITE);
                button.setTypeface(null, Typeface.BOLD);
                button.setSingleLine(true);
                button.setEllipsize(TextUtils.TruncateAt.END);
                button.setPadding(dp(7), 0, dp(7), 0);
                button.setBackground(background());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View view) { choose(index); }
                });
                button.setOnKeyListener(new View.OnKeyListener() {
                    @Override public boolean onKey(View view, int code, KeyEvent event) {
                        if (code != KeyEvent.KEYCODE_DPAD_DOWN) return false;
                        if (event.getAction() == KeyEvent.ACTION_UP) focusFirstFilm();
                        return true;
                    }
                });
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(42), 1);
                if (i < buttons.length - 1) params.setMargins(0, 0, dp(7), 0);
                filterBar.addView(button, params);
                buttons[i] = button;
            }
            for (int i = 0; i < buttons.length; i++) {
                buttons[i].setNextFocusLeftId(buttons[Math.max(0, i - 1)].getId());
                buttons[i].setNextFocusRightId(buttons[Math.min(buttons.length - 1, i + 1)].getId());
                View toolbar = root.getChildAt(2);
                if (toolbar instanceof LinearLayout) {
                    View above = ((LinearLayout) toolbar).getChildAt(i);
                    if (above.getId() == View.NO_ID) above.setId(View.generateViewId());
                    buttons[i].setNextFocusUpId(above.getId());
                }
            }
            filterBar.setVisibility(View.GONE);
            root.addView(filterBar, 3);
            updateLabels();
            layoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override public void onGlobalLayout() { syncScreen(); }
            };
            root.getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
        } catch (ReflectiveOperationException exception) {
            showError("Nie można otworzyć filtrów. Uruchom aplikację ponownie.");
        }
    }

    private static Field field(Class<?> type, String name) throws NoSuchFieldException {
        Field result = type.getDeclaredField(name);
        result.setAccessible(true);
        return result;
    }

    @SuppressWarnings("unchecked")
    private void refreshRatings() {
        try {
            if (entriesField == null || !readyField.getBoolean(this) || busy() || ratingsRequested) return;
            final JSONArray snapshot = (JSONArray) entriesField.get(this);
            if (snapshot == null || (snapshot == lastRatingsEntries && !ratingsPending)) return;
            ratingsRequested = true;
            AppRuntime.submit(object("op", "filmweb_ratings", "items", snapshot), new AppRuntime.Callback() {
                @Override public void done(JSONObject result) {
                    ratingsRequested = false;
                    if (!ratingsActive || isDestroyed()) return;
                    try {
                        if (entriesField.get(FilterActivity.this) != snapshot) return;
                        if (!result.optBoolean("ok")) return;
                        lastRatingsEntries = snapshot;
                        ratingsPending = result.optBoolean("pending");
                        JSONArray updates = result.optJSONArray("items");
                        if (updates == null || updates.length() != snapshot.length()) return;
                        List<View> rows = (List<View>) rowsField.get(FilterActivity.this);
                        int selected = selectedField.getInt(FilterActivity.this);
                        for (int i = 0; i < snapshot.length(); i++) {
                            JSONObject item = snapshot.optJSONObject(i), update = updates.optJSONObject(i);
                            if (item == null || update == null || !item.optString("url").equals(update.optString("url"))) continue;
                            String oldRatingLabel = item.optString("rating_label");
                            boolean changed = !oldRatingLabel.equals(update.optString("rating_label"))
                                    || !item.optString("desc").equals(update.optString("desc"));
                            for (String name : new String[]{"rating", "rating_votes", "rating_label", "rating_source", "filmweb_id", "desc"}) {
                                item.remove(name);
                                if (update.has(name)) item.put(name, update.get(name));
                            }
                            if (!changed) continue;
                            if (i < rows.size() && rows.get(i) instanceof LinearLayout) {
                                LinearLayout tile = (LinearLayout) rows.get(i);
                                // Keep tile views and focus; only replace the existing score text.
                                for (int child = 1; child < tile.getChildCount(); child++) {
                                    View view = tile.getChildAt(child);
                                    if (view instanceof TextView) {
                                        TextView text = (TextView) view;
                                        String label = text.getText().toString();
                                        if (!oldRatingLabel.isEmpty() && label.equals(oldRatingLabel)) {
                                            text.setText(item.optString("rating_label"));
                                        }
                                    }
                                }
                            }
                            if (i == selected) detailMethod.invoke(FilterActivity.this, item);
                        }
                    } catch (ReflectiveOperationException | org.json.JSONException ignored) {
                        ratingsPending = false;
                    }
                }
            });
        } catch (IllegalAccessException ignored) {
            ratingsRequested = false;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        ratingsActive = true;
        lastRatingsEntries = null;
        ratingsHandler.removeCallbacks(ratingsTick);
        ratingsHandler.post(ratingsTick);
    }

    @Override protected void onPause() {
        ratingsActive = false;
        ratingsHandler.removeCallbacks(ratingsTick);
        super.onPause();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int fill, int border, int width) {
        GradientDrawable value = new GradientDrawable();
        value.setColor(fill);
        value.setCornerRadius(dp(8));
        value.setStroke(dp(width), border);
        return value;
    }

    private StateListDrawable background() {
        StateListDrawable value = new StateListDrawable();
        value.addState(new int[]{android.R.attr.state_focused}, shape(0xff007f89, 0xffa8ffff, 3));
        value.addState(new int[]{android.R.attr.state_pressed}, shape(0xff007f89, 0xffa8ffff, 3));
        value.addState(new int[]{}, shape(0xff19354b, 0xff41657d, 1));
        return value;
    }

    private boolean busy() throws IllegalAccessException { return busyField.getBoolean(this); }

    private void syncScreen() {
        if (isDestroyed() || filterBar == null) return;
        try {
            JSONObject current = (JSONObject) currentField.get(this);
            boolean movies = current.optString("action").equals("movies")
                    || (current.optString("action").equals("page") && current.optBoolean("merged_page"));
            int visibility = movies ? View.VISIBLE : View.GONE;
            if (filterBar.getVisibility() != visibility) filterBar.setVisibility(visibility);
            if (!readyField.getBoolean(this) || busy()) return;
            if (!stateLoaded && !stateRequested) {
                stateRequested = true;
                AppRuntime.submit(object("op", "movie_filter_state"), new AppRuntime.Callback() {
                    @Override public void done(JSONObject value) {
                        stateRequested = false;
                        if (isDestroyed()) return;
                        if (value.optBoolean("ok")) {
                            applyState(value);
                            stateLoaded = true;
                        }
                    }
                });
            }
            if (movies) {
                linkFirstRow();
                if (focusAfterLoad >= 0) {
                    buttons[focusAfterLoad].requestFocus();
                    focusAfterLoad = -1;
                }
            }
        } catch (IllegalAccessException exception) {
            showError("Nie można odczytać ustawień filtrów.");
        }
    }

    @SuppressWarnings("unchecked")
    private void focusFirstFilm() {
        try {
            List<View> rows = (List<View>) rowsField.get(this);
            if (!rows.isEmpty()) rows.get(0).requestFocus();
        } catch (IllegalAccessException exception) {
            showError("Nie można przejść do listy filmów.");
        }
    }

    @SuppressWarnings("unchecked")
    private void linkFirstRow() throws IllegalAccessException {
        List<View> rows = (List<View>) rowsField.get(this);
        int columns = rows.isEmpty() ? 0 : ((GridLayout) rows.get(0).getParent()).getColumnCount();
        for (int i = 0; i < Math.min(columns, rows.size()); i++) {
            rows.get(i).setNextFocusUpId(buttons[Math.min(i, 3)].getId());
        }
    }

    private void applyState(JSONObject value) {
        JSONObject state = value.optJSONObject("filters");
        JSONObject labels = value.optJSONObject("filter_labels");
        if (state != null) filters = state;
        if (labels != null) filterLabels = labels;
        updateLabels();
    }

    private void updateLabels() {
        for (int i = 0; i < buttons.length; i++) {
            String label = NAMES[i] + ": " + filterLabels.optString(
                    KEYS[i], i == 3 ? "Ostatnio dodane" : "Wszystkie");
            if (!label.contentEquals(buttons[i].getText())) buttons[i].setText(label);
            buttons[i].setContentDescription(label);
        }
    }

    private void choose(final int index) {
        try {
            if (!readyField.getBoolean(this) || busy()) return;
            request(object("op", "movie_filter_options", "filter", KEYS[index]), "Otwieranie filtra…",
                    new AppRuntime.Callback() {
                @Override public void done(JSONObject value) {
                    applyState(value);
                    final JSONArray choices = value.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) return;
                    String[] labels = new String[choices.length()];
                    int selected = 0;
                    for (int i = 0; i < labels.length; i++) {
                        JSONObject option = choices.optJSONObject(i);
                        labels[i] = option.optString("label");
                        if (option.optString("id").equals(filters.optString(KEYS[index]))) selected = i;
                    }
                    AlertDialog dialog = new AlertDialog.Builder(FilterActivity.this)
                            .setTitle(NAMES[index])
                            .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface dialog, int position) {
                                    dialog.dismiss();
                                    String choice = choices.optJSONObject(position).optString("id");
                                    if (!choice.equals(filters.optString(KEYS[index]))) change(index, choice);
                                    else buttons[index].requestFocus();
                                }
                            })
                            .setNegativeButton("Wróć", null).create();
                    dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override public void onDismiss(DialogInterface ignored) { buttons[index].requestFocus(); }
                    });
                    dialog.show();
                }
            });
        } catch (IllegalAccessException exception) {
            showError("Nie można otworzyć filtra.");
        }
    }

    private void change(final int index, String value) {
        request(object("op", "movie_filter_set", "filter", KEYS[index], "value", value), "Zapisywanie filtra…",
                new AppRuntime.Callback() {
            @Override public void done(JSONObject result) {
                applyState(result);
                try {
                    discardMoviePages();
                    focusAfterLoad = index;
                    loadMethod.invoke(FilterActivity.this,
                            object("action", "movies", "title", "Filmy", "modern_filters", true), false);
                } catch (ReflectiveOperationException exception) {
                    focusAfterLoad = -1;
                    showError("Nie można odświeżyć listy filmów.");
                }
            }
        });
    }

    private void discardMoviePages() throws ReflectiveOperationException {
        ArrayDeque<?> stack = (ArrayDeque<?>) stackField.get(this);
        Iterator<?> iterator = stack.iterator();
        while (iterator.hasNext()) {
            Object saved = iterator.next();
            JSONObject item = (JSONObject) field(saved.getClass(), "item").get(saved);
            if (item.optString("action").equals("movies")
                    || (item.optString("action").equals("page") && item.optBoolean("merged_page"))) {
                iterator.remove();
            }
        }
    }

    private void request(JSONObject value, String message, AppRuntime.Callback callback) {
        try {
            requestMethod.invoke(this, value, message, callback);
        } catch (ReflectiveOperationException exception) {
            showError("Nie udało się wysłać ustawień filtra.");
        }
    }

    private static JSONObject object(Object... values) {
        JSONObject result = new JSONObject();
        try {
            for (int i = 0; i < values.length; i += 2) result.put((String) values[i], values[i + 1]);
        } catch (org.json.JSONException exception) {
            throw new IllegalArgumentException(exception);
        }
        return result;
    }

    private void showError(String message) {
        if (!isDestroyed()) new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show();
    }

    @Override protected void onDestroy() {
        ratingsActive = false;
        ratingsHandler.removeCallbacks(ratingsTick);
        if (filterBar != null && layoutListener != null && filterBar.getViewTreeObserver().isAlive()) {
            filterBar.getViewTreeObserver().removeOnGlobalLayoutListener(layoutListener);
        }
        super.onDestroy();
    }
}
