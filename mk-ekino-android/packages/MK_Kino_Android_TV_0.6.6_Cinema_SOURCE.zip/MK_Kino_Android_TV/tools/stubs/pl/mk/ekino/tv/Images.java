package pl.mk.ekino.tv;
final class Images { static void load(android.widget.ImageView view,String url){} }
