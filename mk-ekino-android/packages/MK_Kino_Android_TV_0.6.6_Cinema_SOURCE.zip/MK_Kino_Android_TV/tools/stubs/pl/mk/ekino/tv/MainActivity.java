package pl.mk.ekino.tv;
public class MainActivity extends android.app.Activity {}
