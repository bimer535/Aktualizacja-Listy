package pl.mk.ekino.tv;
final class Updater { Updater(MainActivity activity){} void check(){} void installPending(){} }
