package pl.mk.ekino.tv;
public class PlayerActivity extends android.app.Activity {}
