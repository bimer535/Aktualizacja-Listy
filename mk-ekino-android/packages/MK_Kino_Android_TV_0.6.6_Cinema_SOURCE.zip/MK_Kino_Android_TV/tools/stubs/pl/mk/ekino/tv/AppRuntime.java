package pl.mk.ekino.tv;
import org.json.JSONObject;
final class AppRuntime {
    interface Callback { void done(JSONObject value); }
    static void submit(JSONObject query, Callback callback) { throw new UnsupportedOperationException(); }
}
