package pl.mk.ekino.tv;
final class UpdatePlan { long code;String version,notes;static UpdatePlan parse(org.json.JSONObject value)throws Exception{throw new UnsupportedOperationException();} }
