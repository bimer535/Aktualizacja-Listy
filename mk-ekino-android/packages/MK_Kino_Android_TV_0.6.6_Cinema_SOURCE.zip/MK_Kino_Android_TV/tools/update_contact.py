# SPDX-License-Identifier: GPL-3.0-only
"""Build MK Kino 0.2.1 from the signed 0.2.0 APK."""
import argparse
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZipFile
import zlib

from build_apk import (APK_MAGIC, dex, manifest, rsa, serialization,
                       load_key_and_certificates, sign, verify, verify_zip, zip_offsets)

BASE_SHA = '110f1b452694dd2ed9b38f02735803c85a84e8775ee78e97636ecc8d808de94d'
OPTIONS = dict(previous_version='0.2.0', previous_code=7,
               version='0.2.1', version_code=8, rebrand=False)


def fit_deflate(data, budget):
    # Keep unchanged entries at the same offsets so their update chunks can
    # reuse the published Git objects. Padding goes in the local ZIP header.
    for level, window, memory in ((6, -15, 8), (9, -15, 8), (9, -15, 9), (7, -12, 6)):
        compressor = zlib.compressobj(level, zlib.DEFLATED, window, memory)
        encoded = compressor.compress(data) + compressor.flush()
        left = budget - len(encoded)
        if left == 0:
            return encoded, b''
        if 4 <= left <= 65535:
            return encoded, struct.pack('<HH', 0xA11E, left - 4) + bytes(left - 4)
    raise ValueError(f'DEFLATE replacement did not fit its {budget}-byte entry')


def update_entries(apk, replacement):
    central, end = zip_offsets(apk)
    if apk[central - 16:central] != APK_MAGIC:
        raise ValueError('Missing original signature')
    old_block = central - struct.unpack_from('<Q', apk, central - 24)[0] - 8
    unsigned = bytearray(apk[:old_block] + apk[central:])
    struct.pack_into('<I', unsigned, end - (central - old_block) + 16, old_block)
    central_item = old_block

    with ZipFile(BytesIO(apk)) as original:
        for item in original.infolist():
            if unsigned[central_item:central_item + 4] != b'PK\x01\x02':
                raise ValueError('Unexpected ZIP central entry')
            lengths = struct.unpack_from('<HHH', unsigned, central_item + 28)
            if item.filename in replacement:
                content = replacement[item.filename]
                local = item.header_offset
                name_size, extra_size = struct.unpack_from('<HH', unsigned, local + 26)
                if (unsigned[local:local + 4] != b'PK\x03\x04' or item.flag_bits
                        or extra_size or item.compress_type != ZIP_DEFLATED):
                    raise ValueError('Unexpected ZIP local entry: ' + item.filename)
                start = local + 30 + name_size
                encoded, extra = fit_deflate(content, item.compress_size)
                header = (zlib.crc32(content), len(encoded), len(content))
                struct.pack_into('<III', unsigned, local + 14, *header)
                struct.pack_into('<H', unsigned, local + 28, len(extra))
                struct.pack_into('<III', unsigned, central_item + 16, *header)
                unsigned[start:start + item.compress_size] = extra + encoded
            central_item += 46 + sum(lengths)
    return bytes(unsigned)


def build(original, signing_backup):
    if sha256(original).hexdigest() != BASE_SHA:
        raise ValueError('Expected published MK Kino 0.2.0 APK')
    cert_der = verify(original)
    with ZipFile(BytesIO(original)) as archive:
        notice = archive.read('assets/NOTICE.txt')
        first_line, separator, remainder = notice.partition(b'\n')
        if b'bimer55@wp.pl' not in first_line or not separator:
            raise ValueError('Expected previous contact in notice')
        replacements = {
            'classes2.dex': dex(archive.read('classes2.dex'), **OPTIONS),
            'AndroidManifest.xml': manifest(archive.read('AndroidManifest.xml'), **OPTIONS),
            'assets/NOTICE.txt': b'MK Kino 0.2.1. Contact: bimer535@wp.pl.' + separator + remainder,
        }
    with ZipFile(signing_backup) as backup:
        key, cert, _ = load_key_and_certificates(backup.read('mk-ekino-release.p12'),
                                                backup.read('password.txt').strip())
    if not isinstance(key, rsa.RSAPrivateKey) or cert.public_bytes(serialization.Encoding.DER) != cert_der:
        raise ValueError('Signing certificate differs from MK Kino 0.2.0')
    apk = sign(update_entries(original, replacements), key, cert)
    verify_zip(apk)
    if verify(apk) != cert_der:
        raise ValueError('APK signature verification failed')
    with ZipFile(BytesIO(apk)) as updated, ZipFile(BytesIO(original)) as old:
        if updated.namelist() != old.namelist():
            raise ValueError('APK entry list changed')
        for item in updated.infolist():
            data = updated.read(item)
            if data != (replacements[item.filename] if item.filename in replacements else old.read(item.filename)):
                raise ValueError('Unexpected APK content: ' + item.filename)
            if b'bimer55@wp.pl' in data:
                raise ValueError('Obsolete email address remains in ' + item.filename)
        if updated.read('classes2.dex').count(b'bimer535@wp.pl') != 2:
            raise ValueError('Updated Android contact strings missing')
    return apk


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('signing_backup', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    apk = build(args.original.read_bytes(), args.signing_backup)
    args.output.write_bytes(apk)
    print('SHA-256:', sha256(apk).hexdigest())


if __name__ == '__main__':
    main()
