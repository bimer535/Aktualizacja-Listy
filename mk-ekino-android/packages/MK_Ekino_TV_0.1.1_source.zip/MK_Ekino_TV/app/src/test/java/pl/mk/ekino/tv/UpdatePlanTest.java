package pl.mk.ekino.tv;

import org.junit.Test;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import static org.junit.Assert.*;

public class UpdatePlanTest {
    private String sha(byte[] bytes) throws Exception {return UpdatePlan.hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    private JSONObject release(byte[] bytes) throws Exception {
        return new JSONObject().put("applicationId","pl.mk.ekino.tv").put("version","0.1.1").put("versionCode",2)
            .put("url",UpdatePlan.BASE+"packages/MK_Ekino_TV_0.1.1.apk").put("size",bytes.length).put("sha256",sha(bytes));
    }
    private JSONObject part(byte[] bytes,int number) throws Exception {
        return new JSONObject().put("url",UpdatePlan.BASE+String.format(java.util.Locale.ROOT,"packages/MK_Ekino_TV_0.1.1.apk.part%03d",number))
            .put("size",bytes.length).put("sha256",sha(bytes));
    }
    private void rejected(JSONObject manifest) throws Exception {
        try{UpdatePlan.parse(manifest);fail("Manifest accepted");}catch(AssertionError e){throw e;}catch(Exception expected){}
    }
    @Test public void singleFileReleaseRemainsCompatible() throws Exception {
        byte[] bytes=new byte[1200];UpdatePlan p=UpdatePlan.parse(release(bytes));
        assertEquals(1,p.parts.size());assertEquals(1200,p.parts.get(0).size);assertEquals(2,p.code);
    }
    @Test public void partsAreReassembledWithPerPartAndWholeChecksums() throws Exception {
        byte[] bytes=new byte[1200];for(int i=0;i<bytes.length;i++)bytes[i]=(byte)i;
        byte[] first=java.util.Arrays.copyOfRange(bytes,0,700),second=java.util.Arrays.copyOfRange(bytes,700,1200);
        UpdatePlan p=UpdatePlan.parse(release(bytes).put("parts",new JSONArray().put(part(first,1)).put(part(second,2))));
        MessageDigest digest=MessageDigest.getInstance("SHA-256");ByteArrayOutputStream output=new ByteArrayOutputStream();
        long count=UpdatePlan.copyPart(new ByteArrayInputStream(first),output,p.parts.get(0),digest,0,null);
        count+=UpdatePlan.copyPart(new ByteArrayInputStream(second),output,p.parts.get(1),digest,count,null);
        p.verify(count,digest);assertArrayEquals(bytes,output.toByteArray());
    }
    @Test public void rejectsForeignPackageAddressAndInvalidSizes() throws Exception {
        byte[] bytes=new byte[1200];rejected(release(bytes).put("applicationId","other.app"));
        rejected(release(bytes).put("url","https://evil.example/update.apk"));
        rejected(release(bytes).put("size",UpdatePlan.MAX_SIZE+1));rejected(release(bytes).put("sha256","bad"));
        rejected(release(bytes).put("version","../0.1.1"));
    }
    @Test public void rejectsReorderedForeignOrMissingParts() throws Exception {
        byte[] bytes=new byte[1200],half=new byte[600];
        rejected(release(bytes).put("parts",new JSONArray().put(part(half,2)).put(part(half,1))));
        rejected(release(bytes).put("parts",new JSONArray().put(part(half,1))));
        rejected(release(bytes).put("parts",new JSONArray()));
        rejected(release(bytes).put("parts",new JSONArray().put(part(half,1).put("url","https://evil.example/p1")).put(part(half,2))));
    }
    @Test public void damagedTruncatedAndOversizedPartNeverPasses() throws Exception {
        byte[] bytes=new byte[1200];UpdatePlan p=UpdatePlan.parse(release(bytes));
        for(byte[] bad:new byte[][]{new byte[1199],new byte[1201],new byte[1200]}){
            if(bad.length==1200)bad[0]=1;
            try{UpdatePlan.copyPart(new ByteArrayInputStream(bad),new ByteArrayOutputStream(),p.parts.get(0),MessageDigest.getInstance("SHA-256"),0,null);fail("Bad bytes accepted");}
            catch(AssertionError e){throw e;}catch(Exception expected){}
        }
    }
    @Test public void wholeChecksumIsRequiredEvenWhenPartsAreValid() throws Exception {
        byte[] bytes=new byte[1200];UpdatePlan p=UpdatePlan.parse(release(bytes));
        MessageDigest digest=MessageDigest.getInstance("SHA-256");digest.update(new byte[1201]);
        try{p.verify(1200,digest);fail("Wrong complete APK accepted");}catch(AssertionError e){throw e;}catch(Exception expected){}
    }
    @Test public void cancellationStopsTransferBeforeAcceptingThePart() throws Exception {
        byte[] bytes=new byte[1200];UpdatePlan p=UpdatePlan.parse(release(bytes));
        try{UpdatePlan.copyPart(new ByteArrayInputStream(bytes),new ByteArrayOutputStream(),p.parts.get(0),MessageDigest.getInstance("SHA-256"),0,count->{throw new java.io.IOException("cancelled");});fail("Cancelled transfer accepted");}
        catch(java.io.IOException expected){assertEquals("cancelled",expected.getMessage());}
    }
}
