package pl.mk.ekino.tv;

import org.junit.Test;
import static org.junit.Assert.*;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collections;

public class NativeSourceTest {
    private static JSONObject cookie(String name,String domain,boolean hostOnly) throws Exception {
        return new JSONObject().put("name",name).put("value","opaque").put("domain",domain)
            .put("hostOnly",hostOnly).put("path","/media").put("secure",true);
    }
    @Test public void catalogueCookiesNeverReachUnrelatedCdn() throws Exception {
        CookieJar jar=NativeSource.cookieJar(new JSONArray().put(cookie("session","ekino.ws",true)));
        assertTrue(jar.loadForRequest(HttpUrl.get("https://cdn.example/media/v.mp4")).isEmpty());
        assertEquals(1,jar.loadForRequest(HttpUrl.get("https://ekino.ws/media/v.mp4")).size());
        assertTrue(jar.loadForRequest(HttpUrl.get("https://sub.ekino.ws/media/v.mp4")).isEmpty());
        assertTrue(jar.loadForRequest(HttpUrl.get("http://ekino.ws/media/v.mp4")).isEmpty());
        assertTrue(jar.loadForRequest(HttpUrl.get("https://ekino.ws/other/v.mp4")).isEmpty());
    }
    @Test public void domainCookieWorksAcrossSegmentHosts() throws Exception {
        CookieJar jar=NativeSource.cookieJar(new JSONArray().put(cookie("ticket","cdn.example",false)));
        assertEquals(1,jar.loadForRequest(HttpUrl.get("https://edge.cdn.example/media/001.ts")).size());
        assertTrue(jar.loadForRequest(HttpUrl.get("https://cdn.example.evil.test/media/001.ts")).isEmpty());
    }
    @Test public void responseRefreshReplacesPreviousCookie() throws Exception {
        CookieJar jar=NativeSource.cookieJar(new JSONArray().put(cookie("ticket","cdn.example",false)));
        Cookie refreshed=new Cookie.Builder().name("ticket").value("new").domain("cdn.example").path("/media").secure().build();
        HttpUrl url=HttpUrl.get("https://cdn.example/media/001.ts");
        jar.saveFromResponse(url,Collections.singletonList(refreshed));
        assertEquals(1,jar.loadForRequest(url).size());
        assertEquals("new",jar.loadForRequest(url).get(0).value());
        Cookie expired=new Cookie.Builder().name("ticket").value("deleted").domain("cdn.example").path("/media").expiresAt(1).build();
        jar.saveFromResponse(url,Collections.singletonList(expired));
        assertTrue(jar.loadForRequest(url).isEmpty());
    }
}
