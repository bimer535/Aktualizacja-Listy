# SPDX-License-Identifier: GPL-3.0-only
"""Native Media3 playback descriptors; media bytes never pass through Python."""
import time
import urllib.parse
import resolver


def descriptor(option, client, adaptive=True):
    url=resolver.checked_url(option['url'])
    meta=getattr(option['url'],'meta',{})
    hls=(meta.get('iptv_proto')=='m3u8' or bool(meta.get('video_url'))
         or str(option.get('name','')).upper().startswith('HLS')
         or urllib.parse.urlsplit(url).path.lower().endswith('.m3u8'))
    headers={key:value for key,value in meta.items()
             if key in ('User-Agent','Referer','Origin','Accept') and isinstance(value,str)}
    headers.setdefault('User-Agent',client.getDefaultHeader()['User-Agent'])
    cookies=[]
    for cookie in getattr(client,'jar',[]):
        if cookie.expires is not None and cookie.expires<=time.time():continue
        cookies.append({'name':cookie.name,'value':cookie.value,'domain':cookie.domain.lstrip('.'),
                        'path':cookie.path or '/','secure':cookie.secure,
                        'hostOnly':not cookie.domain_specified,'expires':cookie.expires or 0})
    subtitles=[]
    for track in meta.get('external_sub_tracks',[])[:20]:
        if not isinstance(track,dict):continue
        try:target=resolver.checked_url(track.get('url',''))
        except (ValueError,resolver.ResolveError):continue
        subtitles.append({'url':target,'language':str(track.get('lang') or 'und'),
                          'title':str(track.get('title') or track.get('lang') or 'Napisy'),
                          'format':'srt' if track.get('format')=='srt' or '.srt' in target else 'vtt'})
    return {'url':url,'mime_type':'application/x-mpegURL' if hls else '',
            'headers':headers,'cookies':cookies,'subtitles':subtitles,
            'height':int(option.get('height') or 0),'width':int(option.get('width') or 0),
            'language':str(option.get('language') or 'pl'),'adaptive':bool(adaptive)}
