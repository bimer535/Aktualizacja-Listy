# SPDX-License-Identifier: GPL-3.0-only
"""Source routing from MK Ekino E2 0.2.7, using Android-compatible adapters."""
import html
import re
import time
import urllib.parse
import catalogue, resolver, access_cache
from other_sources import OtherSources

def source_options(client,item):
    provider=item['provider']
    if provider not in ('player','voe','mix','wrzucaj','shvid','upzone'):raise resolver.ResolveError('source_not_supported')
    resolver.ACTIVE_HTTP=client
    title=item['url']
    body=catalogue.fetch(client,title)
    keys=list(dict.fromkeys(re.findall(r"ShowPlayer\(['\"]"+re.escape(provider)+r"['\"],\s*['\"]([^'\"]+)['\"]\)",body)))
    index=item.get('provider_index',0)
    if type(index) is not int or not 0<=index<len(keys):raise resolver.ResolveError('player_source_not_found')
    current=catalogue.BASE+'watch/f/'+provider+'/'+urllib.parse.quote(keys[index],safe='')
    parent=title;seen=set()
    for _ in range(6):
        if current in seen:raise resolver.ResolveError('embed_redirect_loop')
        seen.add(current)
        host=urllib.parse.urlsplit(current).hostname or ''
        wrapper=host=='ekino.ws' or host=='ekino.link' or host.endswith('.ekino.link')
        if provider in ('voe','mix','wrzucaj','shvid','upzone') and not wrapper:
            parser=OtherSources(client)
            method={'voe':parser.parserVOESX,'mix':parser.parserMIXDROP,'wrzucaj':parser.parserSST,'shvid':parser.parserSST,'upzone':parser.parserUPZONECC}[provider]
            result=method(resolver.URL(current,{'Referer':parent}))
            if not result:
                if client.meta.get('status_code')==403:raise resolver.ResolveError('source_access_denied')
                raise resolver.ResolveError('source_returned_no_variants')
            for option in result:
                meta=dict(getattr(option['url'],'meta',{}))
                meta.setdefault('User-Agent',client.getDefaultHeader()['User-Agent'])
                meta.setdefault('Referer',current)
                option['url']=resolver.URL(option['url'],meta)
            return result
        if provider=='player' and host=='mfw09.org':
            engine=resolver.Byse(client)
            engine.BYSE_ACCESS=access_cache.load()
            cached=len(engine.BYSE_ACCESS)
            started=time.monotonic()
            try:
                result=engine.parserBYSE(resolver.URL(current,{'Referer':parent}))
            finally:
                try:access_cache.save(engine.BYSE_ACCESS)
                except OSError:pass
                client.source_metrics={'cached_access_candidates':cached,'verification':engine.pow_stats,
                                       'elapsed_ms':round((time.monotonic()-started)*1000)}
            if not result:raise resolver.ResolveError('source_returned_no_variants')
            return result
        ok,body=client.getPage(current,{'header':{'Referer':parent}})
        if client.meta.get('status_code')==403 or 'cf-chl-' in body or 'Attention Required! | Cloudflare' in body:
            raise resolver.ResolveError('source_access_denied')
        if not ok:raise resolver.ResolveError('watch_or_embed_http_error')
        final=client.meta.get('url',current)
        if urllib.parse.urlsplit(final).hostname=='mfw09.org':current=final;continue
        target=None
        for pattern in [r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*target=',r'<iframe\b[^>]*src=["\']([^"\']+)["\']']:
            match=re.search(pattern,body,re.I)
            if match:target=urllib.parse.urljoin(final,html.unescape(match[1]));break
        if not target:raise resolver.ResolveError('no_normal_embed_link')
        parent,current=final,target
    raise resolver.ResolveError('embed_chain_too_long')

