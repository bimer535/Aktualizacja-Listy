"""Android Java implementation of MK's public player proof-of-work hash."""
def make_solver(path=None):
    try:
        from java import jclass
        solver=jclass('pl.mk.ekino.tv.Pow')
    except ImportError:return None
    def solve(nonce,difficulty,timeout,progress=None):
        import time
        start=time.monotonic();counter=0;shown=start
        while counter<2**32:
            if solver.isCancelled():raise RuntimeError('cancelled')
            value=solver.find(nonce,counter,256,difficulty)
            if value>=0:return str(value),int(value)+1
            if value!=-1:return None,counter
            counter+=256;now=time.monotonic()
            if now-start>=timeout:return None,counter
            if progress and now-shown>=1:shown=now;progress(int(now-start))
        return None,counter
    return solve
