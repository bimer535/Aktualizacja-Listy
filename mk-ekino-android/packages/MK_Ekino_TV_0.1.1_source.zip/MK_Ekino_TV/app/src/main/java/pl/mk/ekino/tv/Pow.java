package pl.mk.ekino.tv;

/** Exact 32-bit translation of MK's GPL public hash, with cooperative cancellation. */
public final class Pow {
    private static volatile boolean cancelled;
    public static void cancel() { cancelled=true; }
    public static void reset() { cancelled=false; }
    public static boolean isCancelled() { return cancelled; }
    private static int[] initial() { return new int[]{1779033703,(int)3144134277L,1013904242,(int)2773480762L}; }
    private static void absorb(int[] state,String data) {
        int a=state[0],b=state[1],c=state[2],d=state[3];
        for(int i=0;i<data.length();i++) {
            a+=data.charAt(i)&255;a=Integer.rotateLeft(a,7);a+=b;d^=a;d=Integer.rotateLeft(d,16);
            c+=d;b^=c;b=Integer.rotateLeft(b,12);a+=b;d^=a;d=Integer.rotateLeft(d,8);c+=d;b^=c;b=Integer.rotateLeft(b,7);
        }
        state[0]=a;state[1]=b;state[2]=c;state[3]=d;
    }
    private static int zeros(int[] state,String tail,int[] r) {
        int[] st=state.clone();absorb(st,tail);int a=st[0],b=st[1],c=st[2],d=st[3];
        for(int i=0;i<520;i++) {
            a+=b;d^=a;d=Integer.rotateLeft(d,16);c+=d;b^=c;b=Integer.rotateLeft(b,12);
            a+=b;d^=a;d=Integer.rotateLeft(d,8);c+=d;b^=c;b=Integer.rotateLeft(b,7);
            if(i>=8)r[i-8]=a^c;
        }
        for(int round=0;round<2;round++)for(int i=0;i<512;i++) {
            int x=r[i];x+=r[x&511];x=Integer.rotateLeft(x,13);x^=r[(i+1)&511]*(int)2654435761L;r[i]=x;a^=x;
            a+=b;d^=a;d=Integer.rotateLeft(d,16);c+=d;b^=c;b=Integer.rotateLeft(b,12);
            a+=b;d^=a;d=Integer.rotateLeft(d,8);c+=d;b^=c;b=Integer.rotateLeft(b,7);
        }
        int bits=0;
        for(int i=0;i<512;i+=64) {
            a+=b;d^=a;d=Integer.rotateLeft(d,16);c+=d;b^=c;b=Integer.rotateLeft(b,12);
            a+=b;d^=a;d=Integer.rotateLeft(d,8);c+=d;b^=c;b=Integer.rotateLeft(b,7);
            int s=a;for(int j=i;j<i+64;j++){s+=r[j];s=Integer.rotateLeft(s,5);s^=r[j]*(int)2246822519L;}s^=c;
            if(s!=0)return bits+Integer.numberOfLeadingZeros(s);bits+=32;
        }
        return bits;
    }
    public static int zeroBits(String input) { return zeros(initial(),input,new int[512]); }
    public static long find(String nonce,long start,int count,int difficulty) {
        if(nonce.length()>4096||start<0||start>0xffffffffL||count<0||count>4096||difficulty<0||difficulty>256)return -2;
        int[] state=initial(),r=new int[512];absorb(state,nonce+":");
        for(long i=start;i<start+count&&i<=0xffffffffL;i++) {
            if(cancelled)return -2;
            if(zeros(state,Long.toString(i),r)>=difficulty)return i;
        }
        return -1;
    }
}
