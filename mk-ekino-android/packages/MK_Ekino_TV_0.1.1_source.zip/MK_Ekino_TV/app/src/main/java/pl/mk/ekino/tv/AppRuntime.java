package pl.mk.ekino.tv;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class AppRuntime {
    interface Callback { void done(JSONObject value); }
    private static final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private static final Handler main=new Handler(Looper.getMainLooper());
    private static PyObject engine;
    static JSONObject object(Object... fields) {
        JSONObject value=new JSONObject();
        try { for(int i=0;i<fields.length;i+=2)value.put((String)fields[i],fields[i+1]); }
        catch(Exception error){throw new IllegalArgumentException("Invalid request");}
        return value;
    }
    static JSONObject copy(JSONObject value) {
        try{return new JSONObject(value.toString());}catch(Exception ignored){return new JSONObject();}
    }
    static void init(Context context,Callback callback) {
        Context app=context.getApplicationContext();
        jobs.execute(()->{
            JSONObject result;
            try {
                if(!Python.isStarted())Python.start(new AndroidPlatform(app));
                engine=Python.getInstance().getModule("engine");
                result=new JSONObject(engine.callAttr("init",app.getFilesDir().getAbsolutePath(),app.getCacheDir().getAbsolutePath()).toString());
            }catch(Exception error){result=failure();}
            JSONObject value=result;main.post(()->callback.done(value));
        });
    }
    static void submit(JSONObject request,Callback callback) {
        jobs.execute(()->{
            JSONObject result;
            try { Pow.reset();result=new JSONObject(engine.callAttr("request",request.toString()).toString()); }
            catch(Exception error){result=failure();}
            if(callback!=null){JSONObject value=result;main.post(()->callback.done(value));}
        });
    }
    private static JSONObject failure(){return object("ok",false,"message","Błąd silnika aplikacji. Uruchom ją ponownie lub zgłoś problem: bimer55@wp.pl.");}
}
