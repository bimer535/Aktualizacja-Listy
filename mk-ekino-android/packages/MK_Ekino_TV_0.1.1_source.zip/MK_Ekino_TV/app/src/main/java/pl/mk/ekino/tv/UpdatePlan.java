package pl.mk.ekino.tv;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Validates the whole release before any APK bytes are downloaded. */
final class UpdatePlan {
    static final String BASE="https://raw.githubusercontent.com/bimer535/Aktualizacja-Listy/main/mk-ekino-android/";
    static final long MAX_SIZE=100L*1024*1024;
    final long code,size;
    final String version,sha256,notes;
    final List<Part> parts;
    static final class Part {
        final String url,sha256;final long size;
        Part(String url,long size,String sha256){this.url=url;this.size=size;this.sha256=sha256;}
    }
    interface Progress {void changed(long bytes) throws Exception;}
    private UpdatePlan(long code,String version,long size,String sha,String notes,List<Part> parts){
        this.code=code;this.version=version;this.size=size;sha256=sha;this.notes=notes;
        this.parts=Collections.unmodifiableList(parts);
    }
    static UpdatePlan parse(JSONObject value) throws Exception {
        String version=value.getString("version"),sha=value.getString("sha256");
        long code=value.getLong("versionCode"),size=value.getLong("size");
        if(!value.getString("applicationId").equals("pl.mk.ekino.tv")||!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+")||code<1||code>Integer.MAX_VALUE||size<1000||size>MAX_SIZE||!sha.matches("[0-9a-f]{64}"))throw new Exception("manifest");
        String address=BASE+"packages/MK_Ekino_TV_"+version+".apk";
        if(!address.equals(value.getString("url")))throw new Exception("manifest_address");
        List<Part> parts=new ArrayList<>();
        if(value.has("parts")){
            JSONArray entries=value.getJSONArray("parts");
            if(entries.length()<1||entries.length()>128)throw new Exception("part_count");
            long total=0;
            for(int i=0;i<entries.length();i++){
                JSONObject item=entries.getJSONObject(i);long bytes=item.getLong("size");String hash=item.getString("sha256");
                String url=address+String.format(Locale.ROOT,".part%03d",i+1);
                if(!url.equals(item.getString("url"))||bytes<1||bytes>1024*1024||!hash.matches("[0-9a-f]{64}"))throw new Exception("part_manifest");
                total+=bytes;if(total>size)throw new Exception("part_size");
                parts.add(new Part(url,bytes,hash));
            }
            if(total!=size)throw new Exception("part_size");
        }else parts.add(new Part(address,size,sha));
        return new UpdatePlan(code,version,size,sha,value.optString("notes","Pobrać nową wersję?"),parts);
    }
    static String hex(byte[] digest){StringBuilder text=new StringBuilder();for(byte b:digest)text.append(String.format(Locale.ROOT,"%02x",b&255));return text.toString();}
    static long copyPart(InputStream input,OutputStream output,Part part,MessageDigest whole,long before,Progress progress) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] buffer=new byte[32768];long count=0;int length;
        while((length=input.read(buffer))!=-1){
            count+=length;if(count>part.size)throw new Exception("part_size");
            digest.update(buffer,0,length);whole.update(buffer,0,length);output.write(buffer,0,length);
            if(progress!=null)progress.changed(before+count);
        }
        if(count!=part.size||!hex(digest.digest()).equals(part.sha256))throw new Exception("part_checksum");
        return count;
    }
    void verify(long count,MessageDigest digest) throws Exception {
        if(count!=size||!hex(digest.digest()).equals(sha256))throw new Exception("checksum");
    }
}
