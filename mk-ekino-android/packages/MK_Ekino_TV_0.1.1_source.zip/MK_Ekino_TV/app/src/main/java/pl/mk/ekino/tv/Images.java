package pl.mk.ekino.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class Images {
    private static final ExecutorService jobs=Executors.newFixedThreadPool(3);
    private static final Handler main=new Handler(Looper.getMainLooper());
    private static final LruCache<String,Bitmap> cache=new LruCache<String,Bitmap>(16*1024*1024){
        @Override protected int sizeOf(String key,Bitmap bitmap){return bitmap.getByteCount();}
    };
    static void load(ImageView view,String address) {
        view.setTag(address);view.setImageResource(R.drawable.app_icon);
        if(address.isEmpty())return;
        Bitmap stored=cache.get(address);if(stored!=null){view.setImageBitmap(stored);return;}
        jobs.execute(()->{
            try {
                URL url=new URL(address);
                if(!url.getProtocol().equals("https")||!(url.getHost().equals("image.tmdb.org")||url.getHost().equals("ekino.ws")||url.getHost().endsWith(".ekino.ws")))return;
                HttpURLConnection connection=(HttpURLConnection)url.openConnection();
                connection.setConnectTimeout(8000);connection.setReadTimeout(8000);connection.setInstanceFollowRedirects(false);
                byte[] bytes;
                try {
                    if(connection.getResponseCode()!=200)return;
                    try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                        byte[] buffer=new byte[8192];int count;
                        while((count=input.read(buffer))!=-1){if(output.size()+count>2*1024*1024)return;output.write(buffer,0,count);}
                        bytes=output.toByteArray();
                    }
                }finally{connection.disconnect();}
                BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);
                if(options.outWidth<1||options.outHeight<1||(long)options.outWidth*options.outHeight>20_000_000)return;
                options.inSampleSize=1;while(options.outWidth/options.inSampleSize>600||options.outHeight/options.inSampleSize>900)options.inSampleSize*=2;
                options.inJustDecodeBounds=false;Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);
                if(bitmap!=null){cache.put(address,bitmap);main.post(()->{if(address.equals(view.getTag()))view.setImageBitmap(bitmap);});}
            }catch(Exception ignored){}
        });
    }
}
