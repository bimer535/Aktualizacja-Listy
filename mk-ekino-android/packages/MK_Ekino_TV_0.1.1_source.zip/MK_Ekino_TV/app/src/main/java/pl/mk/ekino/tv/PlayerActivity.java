package pl.mk.ekino.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.TrackSelectionDialogBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

@androidx.media3.common.util.UnstableApi
public class PlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView view;
    private JSONObject entry;
    private Button screenMode;
    private boolean fillScreen;
    private TextView buffering;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private boolean ended,leaving,centerToggles;
    private long lastPosition,lastDuration;
    private final Runnable saveTick=new Runnable(){public void run(){save();timer.postDelayed(this,5000);}};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().getDecorView().setSystemUiVisibility(5894);
        try {entry=new JSONObject(getIntent().getStringExtra("entry"));}catch(Exception error){finish();return;}
        JSONObject stream;
        try{stream=new JSONObject(getIntent().getStringExtra("stream"));}catch(Exception error){finish();return;}
        String address=stream.optString("url");Uri uri=Uri.parse(address);
        if(!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null){finish();return;}
        FrameLayout root=new FrameLayout(this);view=new PlayerView(this);root.addView(view,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        buffering=new TextView(this);buffering.setText("Buforowanie…");buffering.setTextSize(22);buffering.setTextColor(0xffffffff);buffering.setBackgroundColor(0xb0000000);buffering.setPadding(24,16,24,16);root.addView(buffering,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
        LinearLayout actions=new LinearLayout(this);actions.setPadding(16,12,16,12);
        FrameLayout.LayoutParams actionsPosition=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.END);root.addView(actions,actionsPosition);
        Button back=new Button(this);back.setText("Wróć");back.setOnClickListener(v->leave(false));actions.addView(back);
        screenMode=new Button(this);
        fillScreen=getSharedPreferences("playback",MODE_PRIVATE).getBoolean("fill_screen",true);
        applyScreenMode();screenMode.setOnClickListener(v->toggleScreenMode());actions.addView(screenMode);
        Button audio=new Button(this);audio.setText("Audio / napisy");audio.setOnClickListener(v->tracks());actions.addView(audio);
        if(entry.has("episode")){
            Button next=new Button(this);next.setText("Następny odcinek");next.setOnClickListener(v->leave(true));actions.addView(next);
        }
        DefaultTrackSelector selector=new DefaultTrackSelector(this);
        DefaultTrackSelector.Parameters.Builder selection=selector.buildUponParameters()
            .setPreferredAudioLanguage(stream.optString("language","pl")).setPreferredTextLanguage("pl")
            .setForceHighestSupportedBitrate(!stream.optBoolean("adaptive",true))
            .setExceedVideoConstraintsIfNecessary(false);
        int width=stream.optInt("width"),height=stream.optInt("height");
        if(height>0)selection.setMaxVideoSize(width>0?width:Integer.MAX_VALUE,height);
        selector.setParameters(selection);
        DefaultLoadControl buffers=new DefaultLoadControl.Builder()
            .setBufferDurationsMs(30000,90000,3000,6000).setTargetBufferBytes(64*1024*1024).build();
        player=new ExoPlayer.Builder(this,new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setTrackSelector(selector).setLoadControl(buffers)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(NativeSource.factory(stream))).build();
        view.setPlayer(player);view.setControllerShowTimeoutMs(3000);
        view.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener)visibility->actions.setVisibility(visibility));
        MediaItem.Builder media=new MediaItem.Builder().setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(entry.optString("movie_title",entry.optString("title","Film"))).build());
        if(stream.optString("mime_type").equalsIgnoreCase("application/x-mpegURL"))media.setMimeType(MimeTypes.APPLICATION_M3U8);
        try {
            JSONArray tracks=stream.optJSONArray("subtitles");List<MediaItem.SubtitleConfiguration> subtitles=new ArrayList<>();
            if(tracks==null)tracks=new JSONArray();
            for(int i=0;i<tracks.length();i++){
                JSONObject track=tracks.getJSONObject(i);Uri target=Uri.parse(track.getString("url"));
                if(!"https".equals(target.getScheme())||target.getHost()==null)continue;
                subtitles.add(new MediaItem.SubtitleConfiguration.Builder(target).setMimeType(track.optString("format").equals("srt")?MimeTypes.APPLICATION_SUBRIP:MimeTypes.TEXT_VTT).setLanguage(track.optString("language","und")).setLabel(track.optString("title","Napisy")).build());
            }
            media.setSubtitleConfigurations(subtitles);
        }catch(Exception ignored){}
        player.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int state){buffering.setVisibility(state==Player.STATE_BUFFERING?View.VISIBLE:View.GONE);if(state==Player.STATE_ENDED){ended=true;save();leave(entry.has("episode"));}}
            @Override public void onPlayerError(PlaybackException error){
                if(isFinishing())return;
                buffering.setVisibility(View.GONE);
                String details=error.getErrorCodeName();
                for(Throwable cause=error;cause!=null;cause=cause.getCause())if(cause instanceof HttpDataSource.InvalidResponseCodeException)details+=" · HTTP "+((HttpDataSource.InvalidResponseCodeException)cause).responseCode;
                new AlertDialog.Builder(PlayerActivity.this).setTitle("Błąd odtwarzania").setMessage("Strumień nie może być odtworzony. Możesz wrócić i wybrać inne źródło.\n"+details).setPositiveButton("Wróć",(d,w)->leave(false)).setNegativeButton("Ponów",(d,w)->{player.prepare();player.play();}).show();
            }
        });
        player.setMediaItem(media.build());player.seekTo(getIntent().getLongExtra("position",0)*1000L);player.prepare();player.play();view.requestFocus();timer.postDelayed(saveTick,5000);
    }
    private void applyScreenMode(){
        view.setResizeMode(fillScreen?AspectRatioFrameLayout.RESIZE_MODE_ZOOM:AspectRatioFrameLayout.RESIZE_MODE_FIT);
        screenMode.setText(fillScreen?"Obraz: wypełnij":"Obraz: dopasuj");
    }
    private void toggleScreenMode(){
        fillScreen=!fillScreen;applyScreenMode();
        getSharedPreferences("playback",MODE_PRIVATE).edit().putBoolean("fill_screen",fillScreen).apply();
        android.widget.Toast.makeText(this,fillScreen?"Wypełnij ekran — boki obrazu mogą być przycięte":"Dopasuj — cały obraz w oryginalnych proporcjach",android.widget.Toast.LENGTH_SHORT).show();
    }
    private void tracks(){
        new AlertDialog.Builder(this).setTitle("Ścieżki filmu").setItems(new String[]{"Audio","Napisy"},(d,index)->{
            try{new TrackSelectionDialogBuilder(this,index==0?"Audio":"Napisy",player,index==0?C.TRACK_TYPE_AUDIO:C.TRACK_TYPE_TEXT).setAllowAdaptiveSelections(false).build().show();}
            catch(Exception error){new AlertDialog.Builder(this).setMessage("Brak dodatkowych ścieżek w tym źródle.").setPositiveButton("OK",null).show();}
        }).show();
    }
    private void save(){
        if(player!=null){lastPosition=Math.max(0,player.getCurrentPosition()/1000);long duration=player.getDuration();lastDuration=duration==C.TIME_UNSET?0:Math.max(0,duration/1000);}
        if(entry!=null)AppRuntime.submit(AppRuntime.object("op","record","item",entry,"position",lastPosition,"duration",lastDuration,"completed",ended||(lastDuration>0&&lastPosition>=lastDuration*.95)),null);
    }
    private void leave(boolean next){
        if(leaving)return;leaving=true;save();Intent result=new Intent();result.putExtra("next",next);result.putExtra("entry",entry.toString());setResult(RESULT_OK,result);finish();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(player!=null&&event.getKeyCode()==KeyEvent.KEYCODE_DPAD_CENTER&&event.getAction()==KeyEvent.ACTION_DOWN&&!view.isControllerFullyVisible()){
            centerToggles=true;return true;
        }
        if(player!=null&&event.getAction()==KeyEvent.ACTION_UP){
            int key=event.getKeyCode();
            if(key==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE||(key==KeyEvent.KEYCODE_DPAD_CENTER&&centerToggles)){centerToggles=false;if(player.isPlaying())player.pause();else player.play();view.showController();return true;}
            if(key==KeyEvent.KEYCODE_PROG_YELLOW){toggleScreenMode();return true;}
            if(key==KeyEvent.KEYCODE_MEDIA_STOP){leave(false);return true;}
            if(key==KeyEvent.KEYCODE_PROG_BLUE&&entry.has("episode")){leave(true);return true;}
            if(!view.isControllerFullyVisible()&&(key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT)){
                player.seekTo(Math.max(0,player.getCurrentPosition()+(key==KeyEvent.KEYCODE_DPAD_RIGHT?15000:-15000)));view.showController();return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
    @Override public void onBackPressed(){leave(false);}
    @Override protected void onStop(){super.onStop();save();if(player!=null)player.pause();}
    @Override protected void onDestroy(){timer.removeCallbacksAndMessages(null);save();if(player!=null){view.setPlayer(null);player.release();player=null;}super.onDestroy();}
}
