package pl.mk.ekino.tv;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.Executors;

final class Updater {
    private static final String BASE=UpdatePlan.BASE;
    private final MainActivity activity;
    private File pending;
    private boolean running;
    private volatile boolean cancelled;
    private ProgressDialog progress;
    private static final java.util.concurrent.ExecutorService jobs=Executors.newSingleThreadExecutor();
    Updater(MainActivity activity){this.activity=activity;}
    private byte[] fetch(String address,int limit) throws Exception {
        if(!address.startsWith(BASE))throw new Exception("address");
        HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();connection.setConnectTimeout(15000);connection.setReadTimeout(30000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Cache-Control","no-cache");
        try {
            if(connection.getResponseCode()!=200)throw new Exception("http");
            try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                byte[] buffer=new byte[32768];int count;
                while((count=input.read(buffer))!=-1){if(output.size()+count>limit)throw new Exception("limit");output.write(buffer,0,count);}return output.toByteArray();
            }
        }finally{connection.disconnect();}
    }
    void check(){
        if(running)return;running=true;Toast.makeText(activity,"Sprawdzanie aktualizacji…",Toast.LENGTH_SHORT).show();
        jobs.execute(()->{
            try {
                UpdatePlan manifest=UpdatePlan.parse(new JSONObject(new String(fetch(BASE+"update.json?t="+System.currentTimeMillis(),65536),java.nio.charset.StandardCharsets.UTF_8)));
                long code=manifest.code;String version=manifest.version;
                activity.runOnUiThread(()->{running=false;if(activity.isDestroyed())return;if(code<=BuildConfig.VERSION_CODE)Toast.makeText(activity,"Wersja "+BuildConfig.VERSION_NAME+" jest aktualna",Toast.LENGTH_LONG).show();else new AlertDialog.Builder(activity).setTitle("Aktualizacja "+version).setMessage(manifest.notes).setPositiveButton("Pobierz",(d,w)->download(manifest)).setNegativeButton("Później",null).show();});
            }catch(Exception error){activity.runOnUiThread(()->{running=false;if(!activity.isDestroyed())Toast.makeText(activity,"Nie udało się sprawdzić aktualizacji. Spróbuj później.",Toast.LENGTH_LONG).show();});}
        });
    }
    private void download(UpdatePlan manifest){
        if(running)return;running=true;cancelled=false;
        progress=new ProgressDialog(activity);progress.setTitle("Aktualizacja "+manifest.version);progress.setMessage("Pobieranie aktualizacji…");
        progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);progress.setMax(100);progress.setCancelable(false);
        progress.setButton(ProgressDialog.BUTTON_NEGATIVE,"Anuluj",(dialog,which)->cancelled=true);progress.show();
        jobs.execute(()->{
            try {
                File directory=new File(activity.getCacheDir(),"updates");if(!directory.isDirectory()&&!directory.mkdirs())throw new Exception("cache");
                File file=new File(directory,"update.apk");downloadFile(manifest,file);
                verifyArchive(file,manifest);
                if(cancelled){file.delete();throw new Exception("cancelled");}
                pending=file;activity.runOnUiThread(()->{running=false;dismissProgress();installPending();});
            }catch(Exception error){activity.runOnUiThread(()->{running=false;dismissProgress();if(!activity.isDestroyed())Toast.makeText(activity,cancelled?"Anulowano pobieranie":"Nie udało się pobrać lub zweryfikować aktualizacji.",Toast.LENGTH_LONG).show();});}
        });
    }
    private void dismissProgress(){if(progress!=null){if(progress.isShowing())progress.dismiss();progress=null;}}
    private void verifyArchive(File file,UpdatePlan release) throws Exception {
        int flags=Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;
        PackageInfo archive=activity.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),flags);
        PackageInfo installed=activity.getPackageManager().getPackageInfo(activity.getPackageName(),flags);
        if(archive==null||!activity.getPackageName().equals(archive.packageName)||(Build.VERSION.SDK_INT>=28?archive.getLongVersionCode():archive.versionCode)!=release.code)throw new Exception("package");
        Signature[] received,current;
        if(Build.VERSION.SDK_INT>=28){
            if(archive.signingInfo==null||installed.signingInfo==null)throw new Exception("signature");
            received=archive.signingInfo.getApkContentsSigners();current=installed.signingInfo.getApkContentsSigners();
        }else {received=archive.signatures;current=installed.signatures;}
        if(received==null||current==null||received.length!=1||current.length!=1||!received[0].equals(current[0]))throw new Exception("signature");
    }
    private void downloadFile(UpdatePlan manifest,File file) throws Exception {
        boolean success=false;int[] percent={-1};
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");long total=0;
            try(FileOutputStream output=new FileOutputStream(file)){
                for(UpdatePlan.Part part:manifest.parts){
                    if(cancelled)throw new Exception("cancelled");
                    HttpURLConnection connection=(HttpURLConnection)new URL(part.url).openConnection();
                    connection.setConnectTimeout(15000);connection.setReadTimeout(30000);connection.setInstanceFollowRedirects(false);
                    try {
                        if(connection.getResponseCode()!=200)throw new Exception("http");
                        try(InputStream input=connection.getInputStream()){
                            total+=UpdatePlan.copyPart(input,output,part,digest,total,bytes->{
                                if(cancelled)throw new Exception("cancelled");
                                int value=(int)(bytes*100/manifest.size);
                                if(value!=percent[0]){percent[0]=value;activity.runOnUiThread(()->{if(!activity.isDestroyed()&&progress!=null)progress.setProgress(value);});}
                            });
                        }
                    }finally{connection.disconnect();}
                }
            }
            manifest.verify(total,digest);success=true;
        }finally{if(!success)file.delete();}
    }
    void installPending(){
        if(pending==null||activity.isDestroyed())return;
        if(Build.VERSION.SDK_INT>=26&&!activity.getPackageManager().canRequestPackageInstalls()){
            new AlertDialog.Builder(activity).setTitle("Zezwól na instalację aktualizacji").setMessage("Android wymaga jednorazowego zezwolenia dla MK Ekino TV. Po jego włączeniu wróć do aplikacji.").setPositiveButton("Ustawienia",(d,w)->activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())),210)).setNegativeButton("Później",null).show();return;
        }
        Uri uri=FileProvider.getUriForFile(activity,"pl.mk.ekino.tv.files",pending);
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {activity.startActivity(intent);pending=null;}catch(Exception error){Toast.makeText(activity,"Brak instalatora APK na urządzeniu.",Toast.LENGTH_LONG).show();}
    }
}
