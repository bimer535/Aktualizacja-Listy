package pl.mk.ekino.tv;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Host-side end-to-end check using the app's exact update parsing/copy code. */
public final class UpdateDownloadCheck {
    private static HttpURLConnection open(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(false);
        if(c.getResponseCode()!=200){c.disconnect();throw new IOException("HTTP failure");}return c;
    }
    public static void main(String[] args) throws Exception {
        HttpURLConnection c=open(UpdatePlan.BASE+"update.json?t="+System.currentTimeMillis());UpdatePlan plan;
        try(InputStream input=c.getInputStream()){
            plan=UpdatePlan.parse(new JSONObject(new String(input.readAllBytes(),StandardCharsets.UTF_8)));
        }finally{c.disconnect();}
        MessageDigest digest=MessageDigest.getInstance("SHA-256");long count=0;int index=0;
        try(OutputStream output=new FileOutputStream(args[0])){
            for(UpdatePlan.Part part:plan.parts){
                c=open(part.url);
                try(InputStream input=c.getInputStream()){count+=UpdatePlan.copyPart(input,output,part,digest,count,null);}
                finally{c.disconnect();}
                if(++index%10==0)System.out.println("Verified parts: "+index+"/"+plan.parts.size());
            }
        }
        plan.verify(count,digest);
        System.out.println("Verified complete APK "+plan.version+", "+count+" bytes, "+plan.parts.size()+" parts");
    }
}
