import http.cookiejar
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/src/main/python'))
import playback,resolver


class PlaybackTests(unittest.TestCase):
    def test_extensionless_hls_is_explicit_and_retains_adaptive_master(self):
        client=resolver.Http()
        option={'name':'HLS','height':1080,'url':resolver.URL('https://cdn.example/play?token=opaque',
                {'video_url':'https://cdn.example/v1080','audio_url':'https://cdn.example/audio',
                 'Referer':'https://player.example/','Origin':'https://player.example'})}
        stream=playback.descriptor(option,client)
        self.assertEqual(stream['mime_type'],'application/x-mpegURL')
        self.assertEqual(stream['url'],str(option['url']))
        self.assertNotIn('video_url',stream)
        self.assertTrue(stream['adaptive'])
        self.assertEqual(stream['headers']['Referer'],'https://player.example/')
        self.assertEqual(stream['height'],1080)

    def test_progressive_file_keeps_real_https_uri_and_source_headers(self):
        client=resolver.Http()
        option={'name':'Abyss Origin','url':resolver.URL('https://cdn.example/sora/opaque',
                {'Referer':'https://player.example/','Origin':'https://player.example','User-Agent':'Source UA'})}
        stream=playback.descriptor(option,client,False)
        self.assertEqual(stream['url'],'https://cdn.example/sora/opaque')
        self.assertEqual(stream['mime_type'],'')
        self.assertEqual(stream['headers']['User-Agent'],'Source UA')
        self.assertFalse(stream['adaptive'])

    def test_cookie_scope_and_session_lifetime_survive_native_handoff(self):
        client=resolver.Http()
        cookie=http.cookiejar.Cookie(0,'session','opaque',None,False,'player.example',False,False,
                                    '/api',True,True,None,True,None,None,{})
        client.jar.set_cookie(cookie)
        stream=playback.descriptor({'url':resolver.URL('https://cdn.example/video.mp4')},client)
        self.assertEqual(stream['cookies'],[{'name':'session','value':'opaque','domain':'player.example',
            'path':'/api','secure':True,'hostOnly':True,'expires':0}])
        self.assertNotIn('Cookie',stream['headers'])

    def test_subtitles_are_native_https_and_bad_addresses_are_ignored(self):
        url=resolver.URL('https://cdn.example/v.mp4',{'external_sub_tracks':[
            {'url':'https://cdn.example/sub.srt','lang':'pl'}, {'url':'http://127.0.0.1/secrets'}]})
        stream=playback.descriptor({'url':url},resolver.Http())
        self.assertEqual(len(stream['subtitles']),1)
        self.assertEqual(stream['subtitles'][0]['format'],'srt')
        self.assertEqual(stream['subtitles'][0]['language'],'pl')

    def test_hls_relative_uris_use_redirected_manifest_location(self):
        class Client:
            meta={'url':'https://edge.example/path/playlist'}
            def getPage(self,*args):
                body=resolver.Body('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1280x720\nvideo/720.m3u8\n')
                body.meta=self.meta
                return True,body
        options=resolver.hls_options(Client(),resolver.URL('https://origin.example/redirect',{'Referer':'https://player.example/'}))
        self.assertEqual(str(options[0]['url']),'https://edge.example/path/playlist')
        self.assertEqual(options[0]['url'].meta['video_url'],'https://edge.example/path/video/720.m3u8')
        self.assertEqual(options[0]['url'].meta['iptv_proto'],'m3u8')


if __name__=='__main__':unittest.main()
