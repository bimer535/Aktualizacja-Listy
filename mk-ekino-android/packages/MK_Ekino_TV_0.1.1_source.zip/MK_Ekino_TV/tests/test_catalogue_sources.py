import json
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock,patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
import catalogue as c
import resolver
import source_adapter


class CatalogueSourceTests(unittest.TestCase):
    def test_filters_keep_category_language_and_year(self):
        doc='<ul class="movieCategories"><a href="/movie/cat/kategoria[36]">FHD</a></ul><ul class="quality"><li data-id="Lektor">Lektor PL</li></ul><ul class="filtyear"><li data-id="2026">2026</li></ul>'
        cat=c.filters(doc,'categories',{})[1]
        lang=c.filters(doc,'versions',cat)[1]
        year=c.filters(doc,'years',lang)[1]
        self.assertIn('kategoria[36]+wersja[Lektor]+rok[2026]+',c.movie_url(year))

    def test_cards_have_ekino_rating_cover_and_canonical_address(self):
        text='<div class="movies-list-item"><a href="/movie/show/example/123"><img alt="Film" src="/cover.jpg"></a><div class="title"><a>Film</a></div><div class="movieDesc">Opis</div><div class="sum-vote"><div>8.5</div></div><font>Ocen</font><br><font>17</font></div>'
        movie=c.cards(text,c.BASE)[0]
        self.assertEqual(movie['url'],c.BASE+'movie/show/example/123')
        self.assertEqual(movie['rating'],8.5)
        self.assertIn('8,5/10',movie['rating_label'])
        self.assertEqual(movie['icon'],c.BASE+'cover.jpg')

    def test_only_player_voe_mix_are_listed_and_source_ids_are_not_stored(self):
        doc="ShowPlayer('mix','PRIVATE1') ShowPlayer('upzone','PRIVATE2') ShowPlayer('player','PRIVATE3') ShowPlayer('voe','PRIVATE4')"
        values=c.source_items(doc,{'url':c.BASE+'movie/show/test/123','title':'Film'})
        self.assertEqual([v['provider'] for v in values],['player','voe','mix'])
        self.assertNotIn('PRIVATE',json.dumps(values))

    def test_player_refreshes_watch_reference_and_keeps_headers(self):
        client=Mock();client.steps=[];client.meta={'url':c.BASE+'watch/f/player/NEW'}
        client.getPage.side_effect=[(True,"ShowPlayer('player','NEW')"),(True,'<iframe src="https://mfw09.org/e/example"></iframe>')]
        with patch.object(resolver.Byse,'parserBYSE',return_value=[{'url':resolver.URL('https://cdn.example/master.m3u8')}]) as parse,patch.object(source_adapter.access_cache,'load',return_value={}),patch.object(source_adapter.access_cache,'save'):
            result=source_adapter.source_options(client,{'provider':'player','url':c.BASE+'movie/show/test/123'})
        self.assertEqual(str(parse.call_args.args[0]),'https://mfw09.org/e/example')
        self.assertEqual(result[0]['url'],'https://cdn.example/master.m3u8')

    def test_next_episode_moves_between_seasons(self):
        text='<p>Sezon 2</p><ul class="list-series"><a href="/serie/watch/test+season[2]+episode[1]+">S02E01</a></ul><p>Sezon 1</p><ul class="list-series"><a href="/serie/watch/test+season[1]+episode[2]+">S01E02</a></ul>'
        client=Mock();client.getPage.return_value=(True,text)
        result=c.browse(client,{'action':'next_episode','series_url':c.BASE+'serie/show/test/123','series_title':'Test','season':'1','episode':2})
        self.assertEqual((result[0]['season'],result[0]['episode']),('2',1))
