import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
import engine
import resolver
import catalogue


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.backend=engine.Backend(Path(self.tmp.name)/'files',Path(self.tmp.name)/'cache')
        self.old=engine.backend;engine.backend=self.backend;self.addCleanup(self.restore)
        self.film={'action':'sources','title':'Film','url':catalogue.BASE+'movie/show/test/123','icon':'https://image.tmdb.org/t/p/w500/a.jpg'}
    def restore(self):
        self.backend.stop();engine.backend=self.old
    def request(self,**value):return json.loads(engine.request(json.dumps(value)))
    def test_menu_and_anonymous_session_do_not_require_an_account(self):
        result=self.request(op='browse',item={'action':'main'})
        self.assertTrue(result['ok']);self.assertEqual(result['items'][0]['title'],'Filmy')
        self.assertFalse(any('login' in key for key in self.backend.library.read()))
    def test_entering_film_only_lists_sources_and_does_not_start_playback(self):
        source=dict(self.film,action='resolve',provider='player')
        with patch.object(engine.catalogue,'browse',return_value=[source]),patch.object(engine,'source_options') as resolve:
            result=self.request(op='browse',item=self.film)
        self.assertTrue(result['ok']);resolve.assert_not_called();self.assertIsNone(self.backend.relay)
    def test_favourite_resolver_row_stores_canonical_film_without_streams(self):
        selected=dict(self.film,action='resolve',movie_title='Prawdziwy tytuł',title='Player · 1080p',provider='player')
        self.assertTrue(self.request(op='favourite',item=selected)['added'])
        item=self.request(op='browse',item={'action':'favourites'})['items'][0]
        self.assertEqual(item['action'],'sources');self.assertEqual(item['title'],'Prawdziwy tytuł')
        self.assertNotIn('provider',item)
    def test_progress_is_restored_and_completed_films_leave_continue_list(self):
        self.request(op='record',item=self.film,position=141,duration=3500,completed=False)
        self.assertEqual(self.request(op='progress',item=self.film)['progress']['position'],141)
        self.assertEqual(len(self.request(op='browse',item={'action':'continue'})['items']),1)
        self.request(op='record',item=self.film,position=3500,duration=3500,completed=True)
        self.assertEqual(self.request(op='browse',item={'action':'continue'})['items'],[])
    def test_manual_quality_setting_is_persistent(self):
        self.request(op='settings',key='auto_play',value=False)
        restarted=engine.Backend(self.backend.files,self.backend.cache)
        self.assertFalse(restarted.library.settings()['auto_play'])
    def test_sources_resolve_to_choices_then_explicit_play_uses_native_https(self):
        options=[{'url':resolver.URL('https://cdn.example/master.m3u8'),'height':720},
                 {'url':resolver.URL('https://cdn.example/high.m3u8'),'height':1080}]
        with patch.object(engine,'source_options',return_value=options):result=self.request(op='resolve',item=self.film)
        self.assertEqual(result['preferred'],1);self.assertIsNone(self.backend.relay)
        answer=self.request(op='play',item=self.film,index=1)
        self.assertTrue(answer['ok']);self.assertEqual(answer['url'],'https://cdn.example/high.m3u8')
        self.assertEqual(answer['mime_type'],'application/x-mpegURL')
        self.assertTrue(answer['adaptive']);self.assertIsNone(self.backend.relay)
        self.assertNotIn('cdn.example',json.dumps(result))
        self.request(op='stop');self.assertIsNone(self.backend.relay)
    def test_search_history_accepts_unicode_without_changing_shared_library(self):
        with patch.object(engine.catalogue,'browse',return_value=[]):
            self.request(op='browse',item={'action':'search_results','query':'Łączy nas krew'})
        result=self.request(op='browse',item={'action':'history'})
        self.assertEqual(result['items'][0]['query'],'Łączy nas krew')
        self.assertEqual(self.backend.library.favourites(),[])
    def test_error_response_does_not_reveal_temporary_stream_or_headers(self):
        with patch.object(engine.catalogue,'browse',side_effect=RuntimeError('https://cdn.example/video?token=secret')):
            result=self.request(op='browse',item={'action':'movies'})
        self.assertFalse(result['ok']);self.assertNotIn('secret',json.dumps(result));self.assertNotIn('cdn.example',json.dumps(result))


if __name__=='__main__':unittest.main()
