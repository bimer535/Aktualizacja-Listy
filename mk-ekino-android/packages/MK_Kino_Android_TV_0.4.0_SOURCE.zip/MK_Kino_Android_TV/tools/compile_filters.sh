#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then
    echo "Użycie: sh tools/compile_filters.sh /sciezka/android.jar /sciezka/r8lib.jar" >&2
    exit 2
fi
android_jar=$(realpath "$1")
r8_jar=$(realpath "$2")
project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
task_build=$(mktemp -d)
trap 'rm -rf "$task_build"' EXIT HUP INT TERM
mkdir -p "$task_build/classes" "$task_build/dex"
java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 -Xlint:-options -encoding UTF-8 \
    -classpath "$android_jar" -d "$task_build/classes" \
    "$project_root"/tools/stubs/pl/mk/ekino/tv/*.java \
    "$project_root"/android/pl/mk/ekino/tv/Cinema*.java \
    "$project_root/android/pl/mk/ekino/tv/SeekMath.java"
find "$task_build/classes/pl/mk/ekino/tv" \( -name 'Cinema*.class' -o -name 'SeekMath.class' \) -print0 |
    xargs -0 java -cp "$r8_jar" com.android.tools.r8.D8 --release --min-api 24 \
    --lib "$android_jar" --classpath "$task_build/classes" --output "$task_build/dex"
cp "$task_build/dex/classes.dex" "$project_root/android/classes3.dex"
echo "Zbudowano android/classes3.dex"
