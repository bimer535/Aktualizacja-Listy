# SPDX-License-Identifier: GPL-3.0-only
"""Package MK Kino 0.4.0 with a shelf interface and TV playback controls."""
import argparse
from copy import copy
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path
import struct
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
import zlib

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization.pkcs12 import load_key_and_certificates
from build_apk import dex, manifest, sign, verify, verify_zip, get32

ROOT = Path(__file__).resolve().parents[1]
BASE_SHA = '8ac960491297c72b9befdb901f852832fbd8a8e42560caf6d9c3f44b08d9165c'
OPTIONS = dict(previous_version='0.3.1', previous_code=10,
               version='0.4.0', version_code=11, rebrand=False)


def class_names(dex_bytes):
    count, offset = struct.unpack_from('<II', dex_bytes, 0x38)
    from build_apk import uleb
    strings = []
    for index in range(count):
        _, start = uleb(dex_bytes, get32(dex_bytes, offset + 4 * index))
        strings.append(dex_bytes[start:dex_bytes.index(0, start)].decode('utf-8', 'replace'))
    _, types = struct.unpack_from('<II', dex_bytes, 0x40)
    count, offset = struct.unpack_from('<II', dex_bytes, 0x60)
    return {strings[get32(dex_bytes, types + 4 * get32(dex_bytes, pos))]
            for pos in range(offset, offset + 32 * count, 32)}


def python_bundle(original):
    result = BytesIO()
    with ZipFile(BytesIO(original)) as before, ZipFile(result, 'w', ZIP_DEFLATED) as after:
        replaced = {p.name: p for p in (ROOT / 'python').glob('*.py')}
        for info in before.infolist():
            value = replaced.pop(info.filename, None)
            after.writestr(copy(info), value.read_bytes() if value else before.read(info))
        for name, path in sorted(replaced.items()):
            after.writestr(name, path.read_bytes())
    return result.getvalue()


def raw_deflate(content, level=6):
    compressor = zlib.compressobj(level, zlib.DEFLATED, -15)
    return compressor.compress(content) + compressor.flush()


def padded_extra(start, desired=None, alignment=4):
    if desired is not None and 0 <= desired - start <= 65535:
        size = desired - start
        if size == 0:
            return b''
        if size >= 4:
            return struct.pack('<HH', 0xA11E, size - 4) + bytes(size - 4)
    if start % alignment == 0:
        return b''
    size = (-(start + 4)) % alignment
    return struct.pack('<HH', 0xA11E, size) + bytes(size)


def repack(apk, replacement, ui_dex):
    out = BytesIO()
    central = []
    with ZipFile(BytesIO(apk)) as source:
        records = [(info, replacement.get(info.filename)) for info in source.infolist()]
        ui_info = copy(source.getinfo('classes2.dex'))
        ui_info.filename = 'classes3.dex'
        ui_info.orig_filename = ui_info.filename
        ui_info.extra = b''
        ui_info.compress_type = ZIP_DEFLATED
        if 'classes3.dex' not in source.namelist():
            records.append((ui_info, ui_dex))
        for info, changed in records:
            name = info.filename.encode('utf-8')
            if info.flag_bits:
                raise ValueError('Unexpected ZIP flags')
            flags = 0
            if changed is None:
                old_name, old_extra = struct.unpack_from('<HH', apk, info.header_offset + 26)
                begin = info.header_offset + 30 + old_name + old_extra
                payload = apk[begin:begin + info.compress_size]
                crc, size = info.CRC, info.file_size
            else:
                payload = raw_deflate(changed, 9 if info.filename == 'classes2.dex' else 6) if info.compress_type == ZIP_DEFLATED else changed
                crc, size = zlib.crc32(changed), len(changed)
            offset = out.tell()
            extra = b''
            if info.compress_type == ZIP_STORED and not info.is_dir():
                start = offset + 30 + len(name)
                native = info.filename.startswith('lib/') and info.filename.endswith('.so')
                desired = None
                if native:
                    old_name, old_extra = struct.unpack_from('<HH', apk, info.header_offset + 26)
                    desired = info.header_offset + 30 + old_name + old_extra
                extra = padded_extra(start, desired, 16384 if native else 4)
            year, month, day, hour, minute, second = info.date_time
            dos_time = (hour << 11) | (minute << 5) | (second // 2)
            dos_date = ((year - 1980) << 9) | (month << 5) | day
            header = struct.pack('<IHHHHHIIIHH', 0x04034B50, info.extract_version, flags,
                                 info.compress_type, dos_time, dos_date, crc, len(payload), size, len(name), len(extra))
            out.write(header + name + extra + payload)
            made_by = (info.create_system << 8) | info.create_version
            directory = struct.pack('<IHHHHHHIIIHHHHHII', 0x02014B50, made_by, info.extract_version, flags,
                                    info.compress_type, dos_time, dos_date, crc, len(payload), size,
                                    len(name), len(extra), len(info.comment), 0, info.internal_attr,
                                    info.external_attr, offset)
            central.append(directory + name + extra + info.comment)
    start = out.tell()
    directory = b''.join(central)
    out.write(directory)
    out.write(struct.pack('<IHHHHIIH', 0x06054B50, 0, 0, len(central), len(central), len(directory), start, 0))
    return out.getvalue()


def build(original, signing_backup):
    if sha256(original).hexdigest() != BASE_SHA:
        raise ValueError('Expected published MK Kino 0.3.1')
    cert_der = verify(original)
    ui_dex = (ROOT / 'android/classes3.dex').read_bytes()
    names = class_names(ui_dex)
    if not names or any(not name.startswith(('Lpl/mk/ekino/tv/CinemaActivity',
                                             'Lpl/mk/ekino/tv/CinemaPlayerActivity',
                                             'Lpl/mk/ekino/tv/SeekMath;')) for name in names):
        raise ValueError('Native UI DEX contains unexpected class definitions')
    with ZipFile(BytesIO(original)) as z:
        existing_classes = class_names(z.read('classes.dex')) | class_names(z.read('classes2.dex'))
        if names & existing_classes:
            raise ValueError('Duplicate Android class definitions')
        original_dex = z.read('classes2.dex')
        for member in (b'current', b'root', b'busy', b'ready', b'rows', b'stack', b'request', b'load'):
            if member + b'\0' not in original_dex:
                raise ValueError('The Android compatibility interface changed')
        app = python_bundle(z.read('assets/chaquopy/app.imy'))
        config = json.loads(z.read('assets/chaquopy/build.json'))
        config['assets']['app.imy'] = sha1(app).hexdigest()
        options = dict(OPTIONS, activity_name='pl.mk.ekino.tv.CinemaActivity',
                       activity_previous_name='pl.mk.ekino.tv.FilterActivity',
                       player_activity_name='pl.mk.ekino.tv.CinemaPlayerActivity')
        replacement = {
            'AndroidManifest.xml': manifest(z.read('AndroidManifest.xml'), **options),
            'classes2.dex': dex(original_dex, **OPTIONS),
            'assets/chaquopy/app.imy': app,
            'assets/chaquopy/build.json': json.dumps(config).encode(),
            'classes3.dex': ui_dex,
        }
    with ZipFile(signing_backup) as backup:
        key, cert, _ = load_key_and_certificates(backup.read('mk-ekino-release.p12'),
                                                backup.read('password.txt').strip())
    if not isinstance(key, rsa.RSAPrivateKey) or cert.public_bytes(serialization.Encoding.DER) != cert_der:
        raise ValueError('Signing certificate differs from installed MK Kino')
    apk = sign(repack(original, replacement, ui_dex), key, cert)
    verify_zip(apk)
    if verify(apk) != cert_der:
        raise ValueError('Signature verification failed')
    with ZipFile(BytesIO(original)) as before, ZipFile(BytesIO(apk)) as after:
        if set(after.namelist()) != set(before.namelist()):
            raise ValueError('APK member list changed unexpectedly')
        for name in before.namelist():
            expected = replacement[name] if name in replacement else before.read(name)
            if after.read(name) != expected:
                raise ValueError('Unexpected APK content: ' + name)
        for item in after.infolist():
            if item.filename.startswith('lib/') and after.read(item) != before.read(item.filename):
                raise ValueError('Native playback library changed')
        if after.read('classes2.dex').count(b'bimer535@wp.pl') != 2:
            raise ValueError('Author contact missing')
    return apk


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('signing_backup', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    apk = build(args.original.read_bytes(), args.signing_backup)
    args.output.write_bytes(apk)
    print(args.output.name, len(apk), 'bytes')
    print('SHA-256:', sha256(apk).hexdigest())


if __name__ == '__main__':
    main()
