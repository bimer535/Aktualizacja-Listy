# MK Kino 0.4.0 na Android TV

Pakiet `pl.mk.ekino.tv`, numer kompilacji 11, dotychczasowy certyfikat. Aktualizacja na obecną aplikację zachowuje ustawienia, ulubione i postęp.

## Nowy interfejs

- Boczne menu: Filmy, Seriale, Szukaj, Ulubione, Oglądaj dalej, Aktualizacja i Ustawienia.
- Duże okładki w poziomych rzędach, z przewijaniem pilotem i podglądem tytułu, opisu oraz oceny.
- Ciemna kolorystyka, turkusowe zaznaczenie, półprzezroczyste panele oraz animacja aktywnej okładki.
- Półki gatunków filmowych: Ostatnio dodane, Akcja i przygoda, Na dobry humor, Napięcie i tajemnica. Aktywne filtry języka i roku obowiązują też półki gatunkowe.
- Pobieranie półek w tle przez osobnego klienta HTTP. Wejście do filmu i sterowanie nie czekają na pobranie pozostałych rzędów. Katalogi obu dostawców pozostają dostępne.
- Więcej pozycji jest dopisywane do właściwego rzędu. Błąd pobierania następnej strony nie usuwa już pokazanych kart.
- Oceny Filmweb uzupełniają się bez przeładowania widoku. Pozostają zapis ulubionych, znaczniki obejrzenia, wznawianie i następny odcinek.

## Odtwarzacz

Nowy panel sterowania korzysta z dotychczasowego silnika Media3 i zapisuje postęp jak poprzednio.

- Gdy panel jest ukryty: OK przełącza pauzę i odtwarzanie; góra/dół pokazuje przyciski.
- Lewo/prawo przy ukrytym panelu lub na pasku postępu przesuwa wybraną pozycję o 10 sekund. Przytrzymanie przyspiesza przewijanie. Przeskok następuje po puszczeniu przycisku.
- Wstecz podczas wybierania pozycji anuluje przewijanie. Przy widocznym panelu ukrywa sterowanie; kolejny Wstecz wraca do źródeł.
- Przyciski: przewijanie, pauza/odtwarzanie, proporcje obrazu, audio/napisy i następny odcinek dla serialu.
- Żółty w odtwarzaczu zmienia proporcje, niebieski otwiera następny odcinek.

## Instalacja

MENU → Sprawdź aktualizację albo niebieski przycisk w katalogu. Potwierdź instalację w Androidzie. Nie odinstalowuj poprzedniej wersji.

Kontakt: bimer535@wp.pl. GPL-3.0-only.

## Walidacja i budowanie

34 testy logiki katalogu, filtrów, ocen, zapisów i półek. Kompilacja interfejsu względem Android API 35, weryfikacja dostępności interfejsów Media3, podpisu APK i niezmienionych bibliotek. Test pobierania rzeczywistych filmów i seriali potwierdził wyniki z obu katalogów. Nowy układ i nawigacja wymagają jeszcze sprawdzenia pilotem na fizycznym Android TV.

```sh
python3 -m unittest discover -s tests -v
sh tools/compile_filters.sh /sciezka/android.jar /sciezka/r8lib.jar
python3 tools/build_filters.py MK_Kino_Android_TV_0.3.1.apk MK_Ekino_TV_private_signing_backup.zip MK_Kino_Android_TV_0.4.0.apk
```

Wymagane: Python 3 z cryptography, JDK z kompilatorem, Android API 35 i D8/R8 8.3.37. Nakładki znajdują się w `python/`, nowy interfejs w `android/pl/mk/ekino/tv/CinemaActivity.java` i `CinemaPlayerActivity.java`. Stare źródła w `reference/legacy_python/` służą do testów. Klucz i hasło podpisujące są przechowywane oddzielnie i nie są publikowane.
