# SPDX-License-Identifier: GPL-3.0-only
"""Independent, cancellable shelf loading for the TV catalogue interface."""
import copy
import json
import queue
import threading
import time
import combined
import catalogue
import filmweb_ratings
import movie_filters
import premium
import resolver

SERVICE = None


def row_queries(kind, state):
    state = movie_filters.normalize(state)
    if kind == 'series':
        return [('new-series', 'Nowe seriale', {'action': 'tv_series'}),
                ('updated-series', 'Ostatnio aktualizowane', {'action': 'tv_ekino_series'})]
    queries = [('new-movies', 'Filmy dla Ciebie' if state['genre'] else 'Ostatnio dodane', movie_filters.query(state))]
    if not state['genre']:
        for code, label in [('action', 'Akcja i przygoda'), ('comedy', 'Na dobry humor'), ('thriller', 'Napięcie i tajemnica')]:
            queries.append((code, label, movie_filters.query(dict(state, genre=code))))
    return queries


def _ekino_series(client, section=0):
    sections = combined.EKINO_BROWSE(client, {'action': 'series'})
    choices = [x for x in sections if x.get('action') == 'series_section']
    if not choices:
        return []
    result = combined.EKINO_BROWSE(client, choices[min(section, len(choices)-1)])
    rows, seen = [], set()
    for item in result:
        row = dict(item)
        if row.get('episode') and row.get('series_url'):
            row.update(action='seasons', url=row['series_url'], title=row.get('series_title') or row['title'])
            row.pop('episode', None); row.pop('season', None)
        if row.get('action') == 'seasons' and row.get('url') not in seen:
            seen.add(row.get('url')); rows.append(row)
    return rows


def fetch_rows(client, query):
    if query.get('action') == 'tv_series':
        first, second = combined._pair(lambda: premium.channel(client, {}, 1, series=True),
                                        lambda: _ekino_series(client))
        rows, following = first or ([], None)
        # Keep both catalogue entries when their seasons/sources can differ.
        rows = combined._unique(rows + (second or []))
        next_item = {'action': 'tv_series_page', 'page': following} if following else None
        return rows, next_item
    if query.get('action') == 'tv_ekino_series':
        return _ekino_series(client, 1), None
    if query.get('action') == 'tv_series_page':
        rows, following = premium.channel(client, {}, query.get('page'), series=True)
        return rows, ({'action': 'tv_series_page', 'page': following} if following else None)
    rows = combined.browse(client, query)
    return [x for x in rows if x.get('action') != 'page'], next((x for x in rows if x.get('action') == 'page'), None)


class ShelfService:
    def __init__(self, fetch=fetch_rows, client_factory=resolver.Http, start=True, library=None):
        self.fetch, self.client_factory = fetch, client_factory
        self.client = None
        self.lock = threading.RLock()
        self.jobs = queue.Queue(maxsize=30)
        self.models = {}
        self.active = None
        self.generation = 0
        self.closed = False
        self.library = library
        if start:
            threading.Thread(target=self._worker, name='tv-shelves', daemon=True).start()

    def start(self, kind, state):
        kind = 'series' if kind == 'series' else 'movies'
        state = movie_filters.normalize(state)
        cache_key = json.dumps([kind, state], sort_keys=True)
        with self.lock:
            self.generation += 1
            self.active = cache_key
            if cache_key not in self.models:
                self.models[cache_key] = {'kind': kind, 'shelves': [
                    {'id': rid, 'title': title, 'query': query, 'items': [], 'next': None,
                     'loading': False, 'loaded': False, 'error': False}
                    for rid, title, query in row_queries(kind, state)]}
            while len(self.models) > 6:
                victim = next(k for k in self.models if k != cache_key)
                self.models.pop(victim)
            for shelf in self.models[cache_key]['shelves']:
                shelf['loading'] = False
                if not shelf['loaded'] or shelf['error']:
                    self._queue(cache_key, shelf, shelf['query'], False)
            return self.snapshot()

    def _queue(self, cache_key, shelf, query, append):
        if shelf['loading'] or self.closed:
            return
        try:
            self.jobs.put_nowait((self.generation, cache_key, shelf['id'], copy.deepcopy(query), append))
            shelf['loading'] = True; shelf['error'] = False
        except queue.Full:
            shelf['error'] = True

    def more(self, row_id):
        with self.lock:
            model = self.models.get(self.active, {})
            for shelf in model.get('shelves', []):
                if shelf['id'] == row_id:
                    query = shelf.get('next') if shelf['loaded'] and shelf.get('next') else shelf['query']
                    if query:
                        self._queue(self.active, shelf, query, bool(shelf['loaded'] and shelf.get('next')))
            return self.snapshot()

    def cancel(self):
        with self.lock:
            self.generation += 1
            self.active = None
        return {}

    def invalidate(self):
        with self.lock:
            self.cancel()
            self.models.clear()
        return {}

    def snapshot(self):
        with self.lock:
            model = copy.deepcopy(self.models.get(self.active) or {'kind': 'movies', 'shelves': []})
            for shelf in model['shelves']:
                shelf.pop('query', None)
            rows = [item for shelf in model['shelves'] for item in shelf['items']]
            decorated = filmweb_ratings.prepare(rows)
            progress = self.library.read().get('progress', {}) if self.library else {}
            if not isinstance(progress, dict):
                progress = {}
            for item in decorated:
                saved = progress.get(item.get('url'), {})
                item['watched'] = isinstance(saved, dict) and bool(saved.get('completed'))
            offset = 0
            for shelf in model['shelves']:
                count = len(shelf['items']); shelf['items'] = decorated[offset:offset+count]; offset += count
            model['pending'] = any(s['loading'] for s in model['shelves']) or bool(
                filmweb_ratings.SERVICE and filmweb_ratings.SERVICE.has_pending())
            return model

    def process_one(self):
        try:
            generation, cache_key, row_id, query, append = self.jobs.get_nowait()
        except queue.Empty:
            return False
        try:
            with self.lock:
                if generation != self.generation or cache_key != self.active:
                    return True
            if self.client is None:
                self.client = self.client_factory()
            try:
                items, following = self.fetch(self.client, query)
                items = [dict(x) for x in items if isinstance(x, dict)]
                error = False
            except Exception:
                items, following, error = [], None, True
            with self.lock:
                if generation != self.generation or cache_key != self.active:
                    return True
                for shelf in self.models[cache_key]['shelves']:
                    if shelf['id'] == row_id:
                        if not error:
                            previous = shelf['items'] if append else []
                            shelf['items'] = combined._unique(previous + items)
                            shelf['next'] = following; shelf['loaded'] = True
                        shelf['error'] = error; shelf['loading'] = False
        finally:
            self.jobs.task_done()
        return True

    def _worker(self):
        while not self.closed:
            if not self.process_one():
                time.sleep(0.1)


def init(library=None):
    global SERVICE
    if SERVICE:
        SERVICE.closed = True
    SERVICE = ShelfService(library=library)
