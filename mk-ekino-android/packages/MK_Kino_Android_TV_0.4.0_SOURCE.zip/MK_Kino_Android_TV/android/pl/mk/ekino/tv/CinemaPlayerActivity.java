package pl.mk.ekino.tv;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;

/** TV controls over the existing, unchanged Media3 playback and progress engine. */
public final class CinemaPlayerActivity extends PlayerActivity {
    private final Handler timer=new Handler(Looper.getMainLooper());
    private Object player, playerView;
    private Class<?> playerType,viewType;
    private LinearLayout controls, titleBar;
    private TextView movieTitle, positionLabel, durationLabel, preview;
    private SeekBar timeline;
    private Button pause;
    private JSONObject item;
    private boolean active,seeking,resumePlayback;
    private long target,lastInput;
    private int seekDirection;
    private final Runnable commitSeek=()->commit();
    private final Runnable tick=new Runnable(){public void run(){if(!active||player==null)return;refresh();timer.postDelayed(this,400);}};
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable box(int color,int border){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));d.setStroke(dp(2),border);return d;}
    private Button button(String label,Runnable click){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(Color.WHITE);StateListDrawable bg=new StateListDrawable();bg.addState(new int[]{android.R.attr.state_focused},box(0xff1d626c,0xff63eee0));bg.addState(new int[]{},box(0xc91a3043,0x5554778c));b.setBackground(bg);b.setOnClickListener(v->{lastInput=SystemClock.elapsedRealtime();click.run();});return b;}
    @Override public void onCreate(Bundle state){super.onCreate(state);if(isFinishing())return;try{
        Field pf=PlayerActivity.class.getDeclaredField("player");pf.setAccessible(true);player=pf.get(this);
        Field vf=PlayerActivity.class.getDeclaredField("view");vf.setAccessible(true);playerView=vf.get(this);
        playerType=Class.forName("androidx.media3.common.Player");viewType=Class.forName("androidx.media3.ui.PlayerView");
        item=new JSONObject(getIntent().getStringExtra("entry"));
        FrameLayout root=(FrameLayout)((ViewGroup)findViewById(android.R.id.content)).getChildAt(0);
        viewType.getMethod("setUseController",boolean.class).invoke(playerView,false);
        for(int i=0;i<root.getChildCount();i++)if(root.getChildAt(i) instanceof LinearLayout)root.getChildAt(i).setVisibility(View.GONE);
        build(root);lastInput=SystemClock.elapsedRealtime();
    }catch(Exception error){player=null;}}
    private void build(FrameLayout root){
        titleBar=new LinearLayout(this);titleBar.setOrientation(LinearLayout.VERTICAL);titleBar.setPadding(dp(26),dp(20),dp(26),dp(24));titleBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xe6091422,0x00091422}));
        movieTitle=text(item.optString("movie_title",item.optString("title","Film")),23,Color.WHITE);movieTitle.setTypeface(null,Typeface.BOLD);titleBar.addView(movieTitle);TextView sub=text("MK Kino  ·  "+item.optString("year")+"  "+item.optString("language_version"),12,0xffb1c7d6);sub.setPadding(0,dp(5),0,0);titleBar.addView(sub);root.addView(titleBar,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
        controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(dp(26),dp(28),dp(26),dp(16));controls.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00091422,0xee091422,0xfa091422}));
        preview=text("",18,0xff68e8df);preview.setGravity(Gravity.CENTER);preview.setPadding(0,0,0,dp(6));controls.addView(preview);
        LinearLayout times=new LinearLayout(this);positionLabel=text("0:00",13,Color.WHITE);durationLabel=text("",13,0xffb3c8d8);durationLabel.setGravity(Gravity.END);times.addView(positionLabel,new LinearLayout.LayoutParams(0,-2,1));times.addView(durationLabel,new LinearLayout.LayoutParams(0,-2,1));controls.addView(times);
        timeline=new SeekBar(this);timeline.setMax(10000);timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(0xff43d7d0));timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(0xff9bfff2));timeline.setSecondaryProgressTintList(android.content.res.ColorStateList.valueOf(0xff37576d));timeline.setPadding(dp(5),0,dp(5),0);controls.addView(timeline,new LinearLayout.LayoutParams(-1,dp(34)));
        timeline.setOnKeyListener((v,key,event)->{if(key!=KeyEvent.KEYCODE_DPAD_LEFT&&key!=KeyEvent.KEYCODE_DPAD_RIGHT)return false;if(event.getAction()==KeyEvent.ACTION_DOWN)jump(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:-1,event.getRepeatCount());else scheduleCommit();return true;});
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){seeking=true;target=duration()*progress/10000;preview.setText("Przewiń do "+stamp(target));lastInput=SystemClock.elapsedRealtime();}}public void onStartTrackingTouch(SeekBar b){seeking=true;timer.removeCallbacks(commitSeek);}public void onStopTrackingTouch(SeekBar b){commit();}});
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER_VERTICAL);
        addButton(buttons,button("↶ 10 s",()->{jump(-1,0);scheduleCommit();}),0.85f);
        pause=button("Ⅱ  Pauza",this::toggle);addButton(buttons,pause,1);
        addButton(buttons,button("10 s ↷",()->{jump(1,0);scheduleCommit();}),0.85f);
        addButton(buttons,button("Obraz",()->invokeParent("toggleScreenMode")),0.8f);
        addButton(buttons,button("Audio / napisy",()->invokeParent("tracks")),1.25f);
        if(item.has("episode"))addButton(buttons,button("Następny",()->leave(true)),1);
        addButton(buttons,button("Wróć",()->leave(false)),0.8f);
        controls.addView(buttons);TextView help=text("← →  przewijaj   ·   przytrzymaj strzałkę, aby przewijać szybciej   ·   OK  sterowanie",11,0xff8aa7bb);help.setGravity(Gravity.CENTER);help.setPadding(0,dp(10),0,0);controls.addView(help);
        root.addView(controls,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));hide();
    }
    private void addButton(LinearLayout row,Button button,float weight){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),weight);p.setMargins(0,0,dp(7),0);row.addView(button,p);}
    private Object call(String method,Class<?>[] types,Object... args){try{return playerType.getMethod(method,types).invoke(player,args);}catch(Exception e){return null;}}
    private long number(String name){Object value=call(name,new Class<?>[0]);return value instanceof Number?Math.max(0,((Number)value).longValue()):0;}
    private long duration(){return number("getDuration");}
    private boolean playing(){return Boolean.TRUE.equals(call("isPlaying",new Class<?>[0]));}
    private String stamp(long milliseconds){long t=Math.max(0,milliseconds/1000);return t>=3600?String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60):String.format(Locale.ROOT,"%d:%02d",t/60,t%60);}
    private void show(boolean focusSeek){if(controls==null)return;lastInput=SystemClock.elapsedRealtime();controls.setVisibility(View.VISIBLE);titleBar.setVisibility(View.VISIBLE);if(focusSeek)timeline.requestFocus();else pause.requestFocus();refresh();}
    private void hide(){if(controls!=null){controls.setVisibility(View.GONE);titleBar.setVisibility(View.GONE);}}
    private void toggle(){if(player==null)return;call(playing()?"pause":"play",new Class<?>[0]);show(false);}
    private void jump(int direction,int repeats){long length=duration();if(length<=0){show(false);return;}if(!seeking){target=number("getCurrentPosition");seeking=true;}seekDirection=direction;long step=repeats>=15?60000:repeats>=5?30000:10000;target=SeekMath.clamp(target+direction*step,length);timer.removeCallbacks(commitSeek);show(true);preview.setText("Przewiń do "+stamp(target)+(direction>0?"  →":"  ←"));timeline.setProgress((int)(target*10000/Math.max(1,length)));}
    private void scheduleCommit(){if(seeking){timer.removeCallbacks(commitSeek);timer.postDelayed(commitSeek,300);}}
    private void commit(){if(!seeking||player==null)return;seeking=false;call("seekTo",new Class<?>[]{long.class},SeekMath.clamp(target,duration()));if(preview!=null)preview.setText("");lastInput=SystemClock.elapsedRealtime();refresh();}
    private void refresh(){if(controls==null||player==null)return;long length=duration(),position=seeking?target:number("getCurrentPosition");positionLabel.setText(stamp(position));durationLabel.setText(stamp(length));if(!seeking)timeline.setProgress((int)(position*10000/Math.max(1,length)));timeline.setSecondaryProgress((int)(number("getBufferedPosition")*10000/Math.max(1,length)));pause.setText(playing()?"Ⅱ  Pauza":"▶  Odtwórz");if(!seeking&&playing()&&SystemClock.elapsedRealtime()-lastInput>5000)hide();}
    private void invokeParent(String name){try{Method m=PlayerActivity.class.getDeclaredMethod(name);m.setAccessible(true);m.invoke(this);}catch(Exception ignored){}}
    private void leave(boolean next){commit();try{Method m=PlayerActivity.class.getDeclaredMethod("leave",boolean.class);m.setAccessible(true);m.invoke(this,next);}catch(Exception ignored){finish();}}
    @Override public boolean dispatchKeyEvent(KeyEvent e){if(player==null||controls==null)return super.dispatchKeyEvent(e);int key=e.getKeyCode();boolean down=e.getAction()==KeyEvent.ACTION_DOWN;boolean up=e.getAction()==KeyEvent.ACTION_UP;lastInput=SystemClock.elapsedRealtime();
        if(key==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD||key==KeyEvent.KEYCODE_MEDIA_REWIND){if(down)jump(key==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD?1:-1,e.getRepeatCount());if(up)scheduleCommit();return true;}
        if((key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT)&&(controls.getVisibility()!=View.VISIBLE||seeking)){if(down)jump(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:-1,e.getRepeatCount());if(up)scheduleCommit();return true;}
        if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){if(controls.getVisibility()!=View.VISIBLE){if(up)toggle();return true;}if(getCurrentFocus()==timeline){if(up)toggle();return true;}return getWindow().superDispatchKeyEvent(e);}
        if((key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN)&&controls.getVisibility()!=View.VISIBLE){if(up)show(false);return true;}
        if(up&&key==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){toggle();return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_PLAY){call("play",new Class<?>[0]);show(false);return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_PAUSE){call("pause",new Class<?>[0]);show(false);return true;}
        if(up&&key==KeyEvent.KEYCODE_PROG_YELLOW){invokeParent("toggleScreenMode");return true;}if(up&&key==KeyEvent.KEYCODE_PROG_BLUE&&item.has("episode")){leave(true);return true;}if(up&&key==KeyEvent.KEYCODE_MEDIA_STOP){leave(false);return true;}
        return super.dispatchKeyEvent(e);
    }
    @Override public void onBackPressed(){if(seeking){seeking=false;timer.removeCallbacks(commitSeek);if(preview!=null)preview.setText("");hide();return;}if(controls!=null&&controls.getVisibility()==View.VISIBLE&&!seeking){hide();return;}commit();super.onBackPressed();}
    @Override protected void onResume(){super.onResume();active=true;timer.removeCallbacks(tick);timer.post(tick);if(resumePlayback&&player!=null){call("play",new Class<?>[0]);resumePlayback=false;}}
    @Override protected void onStop(){resumePlayback=player!=null&&playing();commit();active=false;timer.removeCallbacks(tick);super.onStop();}
    @Override protected void onDestroy(){active=false;timer.removeCallbacksAndMessages(null);super.onDestroy();}
}
