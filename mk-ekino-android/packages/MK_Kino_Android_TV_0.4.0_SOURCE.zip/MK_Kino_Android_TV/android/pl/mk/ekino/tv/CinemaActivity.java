package pl.mk.ekino.tv;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Original MK TV interface: poster shelves, persistent navigation and focus-safe updates. */
public final class CinemaActivity extends MainActivity {
    private static final int INK=0xff0a101c, PANEL=0xe61a2c3e, ACCENT=0xff43d7d0, MUTED=0xff9db3c7;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ArrayDeque<State> history=new ArrayDeque<>();
    private final Map<String,TextView> scores=new HashMap<>();
    private final Map<String,View> cards=new LinkedHashMap<>();
    private final Map<String,HorizontalScrollView> rails=new HashMap<>();
    private final Button[] filters=new Button[4];
    private final String[] filterKeys={"genre","language","year","sort"};
    private final String[] filterNames={"Gatunek","Język","Rok","Sortowanie"};
    private JSONObject current=new JSONObject(), settings=new JSONObject(), model=new JSONObject();
    private JSONArray entries=new JSONArray();
    private LinearLayout content,side,filterBar;
    private ScrollView scroller;
    private TextView heading,heroTitle,heroMeta,heroDescription,status;
    private ImageView heroPoster;
    private ProgressBar spinner;
    private Updater updates;
    private boolean ready,busy,active,polling,board=true,firstFocus=true,ratingsPending=true;
    private int generation, selected;
    private String kind="movies", layoutSignature="", focusKey="", currentShelf="";
    private Button activeNav;
    private static final class State {
        final JSONObject item;final JSONArray entries;final boolean board;final String kind,focus;
        State(JSONObject i,JSONArray e,boolean b,String k,String f){item=i;entries=e;board=b;kind=k;focus=f;}
    }
    private final Runnable tick=new Runnable(){public void run(){if(!active)return;poll();ui.postDelayed(this,1000);}};
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private StateListDrawable surface(int normal){StateListDrawable d=new StateListDrawable();d.addState(new int[]{android.R.attr.state_focused},shape(0xee20565f,ACCENT,13));d.addState(new int[]{android.R.attr.state_pressed},shape(0xff277079,ACCENT,13));d.addState(new int[]{},shape(normal,0x334e8299,13));return d;}
    private Button button(String title,Runnable action){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setPadding(dp(11),0,dp(11),0);b.setBackground(surface(PANEL));b.setOnClickListener(v->action.run());return b;}
    private static JSONObject obj(Object... values){JSONObject o=new JSONObject();try{for(int i=0;i<values.length;i+=2)o.put((String)values[i],values[i+1]);}catch(Exception e){throw new IllegalArgumentException(e);}return o;}
    private static JSONObject copy(JSONObject value){try{return new JSONObject(value.toString());}catch(Exception e){return new JSONObject();}}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);updates=new Updater(this);build();
        AppRuntime.submit(obj("op","state"),answer->{if(isDestroyed())return;ready=answer.optBoolean("ok");settings=answer.optJSONObject("settings");if(settings==null)settings=new JSONObject();if(ready){loadFilters();openBoard("movies",true);}else error(answer);});
    }
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff080d17,0xff102336,0xff102c36}));setContentView(root);
        side=new LinearLayout(this);side.setOrientation(LinearLayout.VERTICAL);side.setPadding(dp(12),dp(12),dp(12),dp(12));side.setBackgroundColor(0xc6091423);root.addView(side,new LinearLayout.LayoutParams(dp(142),-1));
        ImageView logo=new ImageView(this);logo.setImageDrawable(getApplicationInfo().loadIcon(getPackageManager()));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);side.addView(logo,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView brand=text("MK KINO",18,Color.WHITE);brand.setTypeface(null,Typeface.BOLD);brand.setGravity(Gravity.CENTER);side.addView(brand,new LinearLayout.LayoutParams(-1,dp(28)));
        nav("Filmy",()->openBoard("movies",true));nav("Seriale",()->openBoard("series",true));nav("Szukaj",this::search);nav("Ulubione",()->openLibrary("favourites","Ulubione"));nav("Oglądaj dalej",()->openLibrary("continue","Oglądaj dalej"));
        View spacer=new View(this);side.addView(spacer,new LinearLayout.LayoutParams(1,0,1));nav("Aktualizacja",()->{if(!busy)updates.check();});nav("Ustawienia",this::options);
        TextView version=text("MK Kino 0.4.0",11,MUTED);version.setGravity(Gravity.CENTER);side.addView(version,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout main=new LinearLayout(this);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(22),dp(14),dp(20),dp(9));root.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);heading=text("Filmy",22,Color.WHITE);heading.setTypeface(null,Typeface.BOLD);header.addView(heading,new LinearLayout.LayoutParams(0,dp(35),1));
        TextView hint=text("MENU  opcje   ·   ← →  przewijaj",11,MUTED);header.addView(hint);main.addView(header);
        LinearLayout hero=new LinearLayout(this);hero.setPadding(dp(13),dp(11),dp(13),dp(11));hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xd9224055,0x44203d50}));
        heroPoster=new ImageView(this);heroPoster.setScaleType(ImageView.ScaleType.FIT_CENTER);hero.addView(heroPoster,new LinearLayout.LayoutParams(dp(72),-1));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(15),0,0,0);hero.addView(words,new LinearLayout.LayoutParams(0,-1,1));
        heroTitle=text("Wybierz film lub serial",24,Color.WHITE);heroTitle.setTypeface(null,Typeface.BOLD);heroTitle.setMaxLines(1);heroTitle.setEllipsize(TextUtils.TruncateAt.END);words.addView(heroTitle);
        heroMeta=text("",12,ACCENT);heroMeta.setMaxLines(1);heroMeta.setPadding(0,dp(5),0,dp(5));words.addView(heroMeta);
        heroDescription=text("Duże okładki. Wybierz pozycję pilotem i naciśnij OK.",13,0xffd1dce7);heroDescription.setMaxLines(3);heroDescription.setEllipsize(TextUtils.TruncateAt.END);words.addView(heroDescription);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(130));hp.setMargins(0,dp(6),0,dp(10));main.addView(hero,hp);
        filterBar=new LinearLayout(this);for(int i=0;i<4;i++){final int index=i;filters[i]=button(filterNames[i],()->chooseFilter(index));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(36),1);p.setMargins(0,0,dp(7),0);filterBar.addView(filters[i],p);}main.addView(filterBar);
        scroller=new ScrollView(this);scroller.setClipToPadding(false);scroller.setVerticalScrollBarEnabled(false);scroller.setFillViewport(false);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(8),0,dp(18));scroller.addView(content,new ScrollView.LayoutParams(-1,-2));main.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER_VERTICAL);spinner=new ProgressBar(this);spinner.setVisibility(View.GONE);footer.addView(spinner,new LinearLayout.LayoutParams(dp(17),dp(17)));status=text("OK: otwórz   ·   Przytrzymaj OK: ulubione   ·   Wstecz: wróć",11,MUTED);status.setPadding(dp(7),0,0,0);footer.addView(status);main.addView(footer,new LinearLayout.LayoutParams(-1,dp(24)));
    }
    private void nav(String label,Runnable action){Button b=button(label,()->{if(!ready||busy)return;action.run();});b.setId(View.generateViewId());b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setTextSize(14);b.setOnFocusChangeListener((v,has)->{if(has)activeNav=b;});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(36));p.setMargins(0,dp(4),0,0);side.addView(b,p);if(activeNav==null)activeNav=b;}
    private void setBusy(boolean value,String label){busy=value;spinner.setVisibility(value?View.VISIBLE:View.GONE);status.setText(label.isEmpty()?"OK: otwórz   ·   Przytrzymaj OK: ulubione   ·   Wstecz: wróć":label);}
    private void request(JSONObject query,String label,AppRuntime.Callback callback){if(!ready)return;final int token=++generation;setBusy(true,label);AppRuntime.submit(query,result->{if(isDestroyed()||token!=generation)return;setBusy(false,"");if(!result.optBoolean("ok")){error(result);return;}callback.done(result);});}
    private void openBoard(String value,boolean clear){if(!ready||busy)return;if(clear)history.clear();kind=value;board=true;current=obj("action","tv_board","kind",kind);heading.setText(kind.equals("series")?"Seriale":"Filmy");filterBar.setVisibility(kind.equals("movies")?View.VISIBLE:View.GONE);layoutSignature="";model=new JSONObject();focusKey="";firstFocus=true;content.removeAllViews();
        request(obj("op","shelves_start","kind",kind),"Pobieranie katalogu…",answer->{model=answer;renderBoard();});}
    private void openLibrary(String action,String label){history.clear();load(obj("action",action,"title",label),false);}
    private void push(){history.push(new State(copy(current),entries,board,kind,focusKey));}
    private void load(JSONObject item,boolean addHistory){if(!ready||busy)return;if(addHistory)push();board=false;ratingsPending=true;AppRuntime.submit(obj("op","shelves_cancel"),null);current=copy(item);filterBar.setVisibility(View.GONE);heading.setText(item.optString("title","Katalog"));
        request(obj("op","browse","item",item),"Pobieranie…",answer->{entries=answer.optJSONArray("items");if(entries==null)entries=new JSONArray();selected=0;focusKey="";renderEntries();});}
    private String cardKey(String row,JSONObject item,int index){return row+"|"+item.optString("url",item.optString("action"))+"|"+index;}
    private void showDetail(JSONObject entry){heroTitle.setText(entry.optString("movie_title",entry.optString("title","")));String info=entry.optString("rating_label");for(String k:new String[]{"year","language_version","progress_label"})if(!entry.optString(k).isEmpty())info+=(info.isEmpty()?"":"  ·  ")+entry.optString(k);heroMeta.setText(info);heroDescription.setText(entry.optString("synopsis",entry.optString("desc","")));Images.load(heroPoster,entry.optString("icon"));}
    private boolean hasPoster(JSONArray items){for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);if(x!=null&&!x.optString("icon").isEmpty())return true;}return false;}
    private void clearViews(){scores.clear();cards.clear();rails.clear();content.removeAllViews();}
    private void renderBoard(){JSONArray groups=model.optJSONArray("shelves");if(groups==null)return;// Rating text changes are applied in place; they do not rebuild poster views.
        String nextSignature=structuralSignature(groups);if(nextSignature.equals(layoutSignature)){updateBoardScores(groups);return;}layoutSignature=nextSignature;
        String restore=focusKey;View focused=getCurrentFocus();boolean sideFocus=focused!=null&&isInside(focused,side);Map<String,Integer> positions=new HashMap<>();for(Map.Entry<String,HorizontalScrollView> e:rails.entrySet())positions.put(e.getKey(),e.getValue().getScrollX());int top=scroller.getScrollY();clearViews();
        for(int i=0;i<groups.length();i++){JSONObject group=groups.optJSONObject(i);if(group==null)continue;JSONArray items=group.optJSONArray("items");if(items==null)items=new JSONArray();addShelf(group.optString("id"),group.optString("title"),items,group.optJSONObject("next"),group.optBoolean("loading"),group.optBoolean("error"),true);}
        for(Map.Entry<String,Integer> e:positions.entrySet()){HorizontalScrollView rail=rails.get(e.getKey());if(rail!=null)rail.post(()->rail.scrollTo(e.getValue(),0));}scroller.post(()->scroller.scrollTo(0,top));
        if(cards.containsKey(restore)&&!sideFocus)cards.get(restore).requestFocus();else if(firstFocus&&!cards.isEmpty()){View first=cards.values().iterator().next();first.requestFocus();firstFocus=false;}else if(sideFocus&&activeNav!=null)activeNav.requestFocus();
        boolean loading=false;for(int i=0;i<groups.length();i++)loading|=groups.optJSONObject(i).optBoolean("loading");spinner.setVisibility(loading?View.VISIBLE:View.GONE);
    }
    private static boolean isInside(View view,ViewGroup parent){for(android.view.ViewParent p=view.getParent();p!=null;p=p.getParent())if(p==parent)return true;return false;}
    private String structuralSignature(JSONArray groups){StringBuilder b=new StringBuilder();for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);b.append(s.optString("id")).append(s.optBoolean("loading")).append(s.optBoolean("error"));JSONArray xs=s.optJSONArray("items");if(xs!=null)for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);b.append(x.optString("url")).append(x.optString("title")).append(x.optBoolean("watched"));}b.append(s.has("next")&&!s.isNull("next"));}return b.toString();}
    private void updateBoardScores(JSONArray groups){for(int i=0;i<groups.length();i++){JSONObject s=groups.optJSONObject(i);JSONArray xs=s.optJSONArray("items");if(xs==null)continue;for(int j=0;j<xs.length();j++){JSONObject x=xs.optJSONObject(j);String k=cardKey(s.optString("id"),x,j);TextView score=scores.get(k);if(score!=null)score.setText(x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey))showDetail(x);}}}
    private void renderEntries(){clearViews();if(entries.length()==0){TextView empty=text("Brak pozycji. Wróć lub zmień filtr.",18,MUTED);empty.setPadding(dp(12),dp(24),0,0);content.addView(empty);return;}
        boolean posters=hasPoster(entries);if(posters){addShelf("entries",current.optString("title","Wybierz pozycję"),entries,null,false,false,false);View restore=cards.get(focusKey);if(restore!=null)restore.requestFocus();else if(!cards.isEmpty())cards.values().iterator().next().requestFocus();}
        else for(int i=0;i<entries.length();i++){final int index=i;JSONObject entry=entries.optJSONObject(i);if(entry==null)continue;Button b=button(entry.optString("title"),()->select(entry));b.setTextSize(16);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setOnFocusChangeListener((v,has)->{if(has){selected=index;showDetail(entry);}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,0,0,dp(8));content.addView(b,p);if(i==selected)b.requestFocus();}}
    private void addShelf(String id,String label,JSONArray items,JSONObject next,boolean loading,boolean failed,boolean remote){TextView title=text(label,17,Color.WHITE);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(3),dp(8),0,dp(9));content.addView(title);
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);scroll.setClipToPadding(false);scroll.setPadding(dp(3),dp(3),dp(6),dp(6));LinearLayout row=new LinearLayout(this);row.setPadding(0,dp(3),dp(4),dp(4));scroll.addView(row,new HorizontalScrollView.LayoutParams(-2,-2));rails.put(id,scroll);content.addView(scroll,new LinearLayout.LayoutParams(-1,-2));
        if(items.length()==0){Button retry=button(loading?"Ładowanie…":failed?"Spróbuj ponownie":"Brak pozycji",()->more(id));retry.setEnabled(!loading&&failed);row.addView(retry,new LinearLayout.LayoutParams(dp(200),dp(92)));return;}
        for(int i=0;i<items.length();i++){final int index=i;JSONObject item=items.optJSONObject(i);if(item==null)continue;String key=cardKey(id,item,i);LinearLayout card=new LinearLayout(this);card.setTag(item);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(6),dp(6),dp(6),dp(8));card.setFocusable(true);card.setClickable(true);card.setBackground(surface(0x90203447));card.setId(View.generateViewId());
            ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackground(shape(0xff172a3b,0,8));card.addView(poster,new LinearLayout.LayoutParams(-1,dp(174)));Images.load(poster,item.optString("icon"));
            TextView name=text((item.optBoolean("watched")?"✓ ":"")+item.optString("title"),13,Color.WHITE);name.setTypeface(null,Typeface.BOLD);name.setMaxLines(2);name.setMinHeight(dp(36));name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(dp(3),dp(6),dp(3),0);card.addView(name,new LinearLayout.LayoutParams(-1,-2));TextView score=text(item.optString("rating_label"),10,ACCENT);score.setMaxLines(1);score.setEllipsize(TextUtils.TruncateAt.END);score.setPadding(dp(3),dp(3),0,0);card.addView(score);scores.put(key,score);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(130),-2);p.setMargins(0,0,dp(11),0);row.addView(card,p);cards.put(key,card);
            card.setOnFocusChangeListener((v,has)->{card.animate().scaleX(has?1.035f:1).scaleY(has?1.035f:1).setDuration(110).start();if(has){focusKey=key;currentShelf=id;selected=index;showDetail((JSONObject)card.getTag());scroll.post(()->scroll.smoothScrollTo(Math.max(0,card.getLeft()-dp(12)),0));}});
            card.setOnClickListener(v->select((JSONObject)card.getTag()));card.setOnLongClickListener(v->{favourite((JSONObject)card.getTag());return true;});
            if(i==0&&activeNav!=null)card.setNextFocusLeftId(activeNav.getId());
        }
        if(next!=null||loading||failed){Button more=button(loading?"Pobieranie…":failed?"Ponów":"Więcej  →",()->{if(remote)more(id);else select(next);});more.setEnabled(!loading);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(125),dp(174));p.setMargins(0,dp(6),0,0);row.addView(more,p);}
    }
    private void more(String shelf){if(busy||!board)return;final int token=generation;AppRuntime.submit(obj("op","shelves_more","shelf",shelf),r->{if(isDestroyed()||!board||token!=generation)return;model=r;renderBoard();});}
    private void poll(){if(!ready||busy||polling)return;if(board&&model.has("shelves")&&!model.optBoolean("pending",true))return;if(!board&&!ratingsPending)return;polling=true;final int token=generation;final boolean wasBoard=board;JSONObject query=board?obj("op","shelves_poll"):obj("op","filmweb_ratings","items",entries);
        AppRuntime.submit(query,r->{polling=false;if(!active||isDestroyed()||token!=generation||wasBoard!=board||!r.optBoolean("ok"))return;if(board){model=r;renderBoard();}else{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()!=entries.length())return;ratingsPending=r.optBoolean("pending");entries=xs;for(int i=0;i<xs.length();i++){JSONObject x=xs.optJSONObject(i);String k=cardKey("entries",x,i);TextView score=scores.get(k);if(score!=null)score.setText(x.optString("rating_label"));View card=cards.get(k);if(card!=null)card.setTag(x);if(k.equals(focusKey))showDetail(x);}}});}
    private void select(JSONObject item){if(item==null||busy)return;String action=item.optString("action");if(action.equals("search")){search();return;}if(action.equals("resolve")){resolve(item);return;}load(item,true);}
    private void favourite(JSONObject item){if(busy||item==null)return;String action=item.optString("action");if(!Arrays.asList("sources","seasons","resolve").contains(action))return;request(obj("op","favourite","item",item),"Zapisywanie…",r->{Toast.makeText(this,r.optBoolean("added")?"Dodano do ulubionych":"Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(current.optString("action").equals("favourites"))load(current,false);});}
    private JSONObject selectedItem(){View view=cards.get(focusKey);if(view!=null&&view.getTag() instanceof JSONObject)return (JSONObject)view.getTag();JSONObject row=entries.optJSONObject(selected);return row==null?new JSONObject():row;}
    private void loadFilters(){AppRuntime.submit(obj("op","movie_filter_state"),r->{JSONObject labels=r.optJSONObject("filter_labels");if(labels!=null)for(int i=0;i<4;i++)filters[i].setText(filterNames[i]+": "+labels.optString(filterKeys[i]));});}
    private void chooseFilter(int index){if(busy||!board||!kind.equals("movies"))return;request(obj("op","movie_filter_options","filter",filterKeys[index]),"Otwieranie filtra…",r->{JSONArray xs=r.optJSONArray("choices");if(xs==null)return;String[] labels=new String[xs.length()];for(int i=0;i<labels.length;i++)labels[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle(filterNames[index]).setItems(labels,(dialog,n)->request(obj("op","movie_filter_set","filter",filterKeys[index],"value",xs.optJSONObject(n).optString("id")),"Zapisywanie…",answer->{loadFilters();openBoard("movies",true);})).setNegativeButton("Wróć",null).show();});}
    private void search(){if(busy)return;EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Tytuł filmu lub serialu");AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Szukaj w filmach i serialach").setView(input).setPositiveButton("Szukaj",(d,w)->{String term=input.getText().toString().trim();if(!term.isEmpty())load(obj("action","search_results","query",term,"title","Szukaj: "+term),true);}).setNegativeButton("Wróć",null).create();dialog.setOnShowListener(d->{input.requestFocus();dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});dialog.show();}
    private void options(){if(busy)return;String[] labels={"Dodaj / usuń z ulubionych","Odśwież katalog","Jakość: "+(settings.optBoolean("auto_play",true)?"automatyczna":"wybór ręczny"),"Sprawdź aktualizację","Autor i kontakt"};new AlertDialog.Builder(this).setTitle("Ustawienia MK Kino").setItems(labels,(d,n)->{if(n==0)favourite(selectedItem());if(n==1){if(board){AppRuntime.submit(obj("op","shelves_invalidate"),null);openBoard(kind,true);}else load(current,false);}if(n==2)request(obj("op","settings","key","auto_play","value",!settings.optBoolean("auto_play",true)),"Zapisywanie…",r->settings=r.optJSONObject("settings"));if(n==3)updates.check();if(n==4)new AlertDialog.Builder(this).setTitle("MK Kino 0.4.0").setMessage("Projekt i rozwój: MK\nKontakt: bimer535@wp.pl\nGPL-3.0").setPositiveButton("OK",null).show();}).show();}
    private void resolve(JSONObject item){request(obj("op","resolve","item",item),"Pobieranie źródła… Wstecz: anuluj",r->{JSONArray xs=r.optJSONArray("variants");if(xs==null||xs.length()==0){error(obj("message","Brak dostępnego wariantu. Wybierz inne źródło."));return;}if(settings.optBoolean("auto_play",true)){play(item,r.optInt("preferred",0));return;}String[] names=new String[xs.length()];for(int i=0;i<names.length;i++)names[i]=xs.optJSONObject(i).optString("label");new AlertDialog.Builder(this).setTitle("Jakość filmu").setItems(names,(d,n)->play(item,n)).setNegativeButton("Wróć",null).show();});}
    private void play(JSONObject item,int index){request(obj("op","play","item",item,"index",index),"Uruchamianie…",r->{JSONObject progress=r.optJSONObject("progress");long position=progress==null?0:progress.optLong("position");if(position>=15&&!progress.optBoolean("completed"))new AlertDialog.Builder(this).setTitle("Kontynuować oglądanie?").setMessage("Wznowić od "+stamp(position)+"?").setPositiveButton("Wznów",(d,w)->launch(item,r,position)).setNegativeButton("Od początku",(d,w)->launch(item,r,0)).show();else launch(item,r,0);});}
    private void launch(JSONObject item,JSONObject stream,long position){Intent intent=new Intent(this,CinemaPlayerActivity.class);intent.putExtra("entry",item.toString());intent.putExtra("stream",stream.toString());intent.putExtra("position",position);startActivityForResult(intent,200);}
    private String stamp(long t){return String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60);}
    private void error(JSONObject answer){new AlertDialog.Builder(this).setTitle("Nie udało się otworzyć").setMessage(answer.optString("message","Spróbuj ponownie później.")).setPositiveButton("OK",null).show();}
    @Override public void onBackPressed(){if(busy){try{Class.forName("pl.mk.ekino.tv.Pow").getDeclaredMethod("cancel").invoke(null);}catch(Exception ignored){}generation++;setBusy(false,"");return;}if(!history.isEmpty()){State old=history.pop();if(old.board){String target=old.focus;openBoard(old.kind,false);focusKey=target;firstFocus=false;}else{board=false;current=old.item;entries=old.entries;kind=old.kind;focusKey=old.focus;heading.setText(current.optString("title"));filterBar.setVisibility(View.GONE);renderEntries();}}else if(!board)openBoard("movies",true);else new AlertDialog.Builder(this).setTitle("Zamknąć MK Kino?").setPositiveButton("Wyjdź",(d,w)->finish()).setNegativeButton("Zostań",null).show();}
    @Override public boolean dispatchKeyEvent(KeyEvent event){if(event.getAction()==KeyEvent.ACTION_UP){if(event.getKeyCode()==KeyEvent.KEYCODE_MENU){options();return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_YELLOW){if(board&&kind.equals("movies"))chooseFilter(0);return true;}if(event.getKeyCode()==KeyEvent.KEYCODE_PROG_BLUE){if(!busy)updates.check();return true;}}return super.dispatchKeyEvent(event);}
    @Override protected void onActivityResult(int code,int result,Intent data){if(code==210){updates.installPending();return;}if(code!=200){super.onActivityResult(code,result,data);return;}AppRuntime.submit(obj("op","stop"),null);if(data!=null&&data.getBooleanExtra("next",false)){try{JSONObject item=new JSONObject(data.getStringExtra("entry"));item.put("action","next_episode");request(obj("op","browse","item",item),"Następny odcinek…",r->{JSONArray xs=r.optJSONArray("items");if(xs==null||xs.length()==0){Toast.makeText(this,"Brak następnego odcinka",Toast.LENGTH_SHORT).show();return;}load(xs.optJSONObject(0),true);});}catch(Exception ignored){}}else if(current.optString("action").equals("continue"))load(current,false);}
    @Override protected void onResume(){super.onResume();active=true;ui.removeCallbacks(tick);ui.postDelayed(tick,600);}
    @Override protected void onPause(){active=false;ui.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){active=false;ui.removeCallbacksAndMessages(null);super.onDestroy();}
}
